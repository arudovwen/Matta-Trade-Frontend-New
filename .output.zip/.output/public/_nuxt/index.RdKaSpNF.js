import{_ as c}from"./_plugin-vue_export-helper.x3n3nnut.js";const e={};function n(r,t){return" Applications "}const o=c(e,[["render",n]]);export{o as default};
