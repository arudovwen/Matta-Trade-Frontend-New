import{_ as m}from"./AppIcon.I2lsiXWf.js";import{_ as y}from"./nuxt-link.syb4tB46.js";import{_ as g}from"./_plugin-vue_export-helper.x3n3nnut.js";import{f as e,g as n,O as h,q as l,k as d,H as i,x as r,F as a,m as u,a3 as _,y as k,l as x,j as o}from"./entry.mFzZsma0.js";const w={components:{},name:"Button",props:{text:{type:String,default:""},isDisabled:{type:Boolean,default:!1},isLoading:{type:Boolean,default:!1},btnClass:{type:String,default:"bg-primary-500  text-white"},icon:{type:String,default:""},iconPosition:{type:String,default:"left"},iconClass:{type:String,default:"text-[20px]"},loadingClass:{type:String,default:""},link:{type:String,default:""},div:{type:Boolean,default:!1}}},C=["disabled"],v={key:0,class:"flex items-center"},L={key:1},b=o("circle",{class:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor","stroke-width":"4"},null,-1),B=o("path",{class:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"},null,-1),S=[b,B],P={key:2},z={key:0,class:"flex items-center"},V={key:1},D=o("circle",{class:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor","stroke-width":"4"},null,-1),N=o("path",{class:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"},null,-1),j=[D,N],A={key:2},H={key:0,class:"flex items-center"},M={key:1},F=o("circle",{class:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor","stroke-width":"4"},null,-1),q=o("path",{class:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"},null,-1),E=[F,q],I={key:2};function O(s,T,t,G,J,K){const c=m,f=y;return e(),n(a,null,[!t.link&&!t.div?(e(),n("button",h({key:0,disabled:t.isDisabled,class:[`
      ${t.isLoading?" pointer-events-none":""}
      ${t.isDisabled?" opacity-40 cursor-not-allowed":""}
      ${t.btnClass}
      `,"btn inline-flex justify-center"]},s.$attrs),[!t.isLoading&&!s.$slots.default?(e(),n("span",v,[t.icon?(e(),n("span",{key:0,class:l(`
            ${t.iconPosition==="right"?"order-1 ml-2":" "}
            ${t.text&&t.iconPosition==="left"?"mr-2":""}
            
            ${t.iconClass}
            
            `)},[d(c,{icon:t.icon},null,8,["icon"])],2)):i("",!0),t.text?(e(),n("span",L,r(t.text),1)):i("",!0)])):i("",!0),t.isLoading?(e(),n(a,{key:1},[(e(),n("svg",{class:l(["animate-spin -ml-1 mr-3 h-5 w-5",t.loadingClass]),xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24"},S,2)),u(" Loading ... ")],64)):i("",!0),s.$slots.default&&!t.isLoading?(e(),n("div",P,[_(s.$slots,"default")])):i("",!0)],16,C)):i("",!0),t.link&&!t.div?(e(),k(f,{key:1,to:t.link,class:l(["btn inline-flex justify-center",`
      ${t.isLoading?" pointer-events-none":""}
      ${t.isDisabled?" opacity-40 cursor-not-allowed":""}
      ${t.btnClass}
      `])},{default:x(()=>[!t.isLoading&&!s.$slots.default?(e(),n("span",z,[t.icon?(e(),n("span",{key:0,class:l(`
            ${t.iconPosition==="right"?"order-1 ml-2":" "}
            ${t.text&&t.iconPosition==="left"?"mr-2":""}
            
            ${t.iconClass}
            
            `)},[d(c,{icon:t.icon},null,8,["icon"])],2)):i("",!0),t.text?(e(),n("span",V,r(t.text),1)):i("",!0)])):i("",!0),t.isLoading?(e(),n(a,{key:1},[(e(),n("svg",{class:l(["animate-spin -ml-1 mr-3 h-5 w-5",t.loadingClass]),xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24"},j,2)),u(" Loading ... ")],64)):i("",!0),s.$slots.default&&!t.isLoading?(e(),n("div",A,[_(s.$slots,"default")])):i("",!0)]),_:3},8,["to","class"])):i("",!0),t.div&&!t.link?(e(),n("div",{key:2,class:l(["btn inline-flex justify-center",`
      ${t.isLoading?" pointer-events-none":""}
      ${t.isDisabled?" opacity-40 cursor-not-allowed":""}
      ${t.btnClass}
      `])},[!t.isLoading&&!s.$slots.default?(e(),n("span",H,[t.icon?(e(),n("span",{key:0,class:l(`
            ${t.iconPosition==="right"?"order-1 ml-2":" "}
            ${t.text&&t.iconPosition==="left"?"mr-2":""}
            
            ${t.iconClass}
            
            `)},[d(c,{icon:t.icon},null,8,["icon"])],2)):i("",!0),t.text?(e(),n("span",M,r(t.text),1)):i("",!0)])):i("",!0),t.isLoading?(e(),n(a,{key:1},[(e(),n("svg",{class:l(["animate-spin -ml-1 mr-3 h-5 w-5",t.loadingClass]),xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24"},E,2)),u(" Loading ... ")],64)):i("",!0),s.$slots.default&&!t.isLoading?(e(),n("div",I,[_(s.$slots,"default")])):i("",!0)],2)):i("",!0)],64)}const X=g(w,[["render",O]]);export{X as _};
