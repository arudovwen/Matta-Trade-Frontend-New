import{a,h as t,_}from"./entry.QzxjoA8A.js";const s={__name:"financing",setup(o){return(c,p)=>{const e=_;return a(),t(e,{"page-key":n=>n.fullPath},null,8,["page-key"])}}};export{s as default};
