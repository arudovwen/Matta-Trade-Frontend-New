import"./entry.CcyKD4BS.js";const t=""+new URL("logo-white.h7uaMp2X.png",import.meta.url).href;export{t as _};
