import{u as e}from"./entry.KZDzQv7x.js";const _={__name:"index",setup(t){return e(),(s,r)=>" Requests "}};export{_ as default};
