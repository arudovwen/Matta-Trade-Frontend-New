function n(e,r){if(!e||!r)return"Phone number and country code are required";if(!e.includes(r))return e;let t=e.replace(r,"0");return t.startsWith("0")?t:"Replacement failed"}export{n as r};
