import{_ as e}from"./_plugin-vue_export-helper.x3n3nnut.js";const r={};function t(c,n){return" Markets "}const s=e(r,[["render",t]]);export{s as default};
