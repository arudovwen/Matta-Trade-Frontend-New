import"./entry.CcyKD4BS.js";const r=""+new URL("logo.sC_uOug5.png",import.meta.url).href;export{r as _};
