globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import http, { Server as Server$1 } from 'node:http';
import https, { Server } from 'node:https';
import { promises, existsSync } from 'fs';
import { dirname as dirname$1, resolve as resolve$2, join } from 'path';
import { toValue } from 'vue';
import { promises as promises$1 } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { ipxFSStorage, ipxHttpStorage, createIPX, createIPXH3Handler } from 'ipx';

const suspectProtoRx = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor" && value && typeof value === "object" && "prototype" in value) {
    warnKeyDropped(key);
    return;
  }
  return value;
}
function warnKeyDropped(key) {
  console.warn(`[destr] Dropping "${key}" key to prevent prototype pollution.`);
}
function destr(value, options = {}) {
  if (typeof value !== "string") {
    return value;
  }
  const _value = value.trim();
  if (
    // eslint-disable-next-line unicorn/prefer-at
    value[0] === '"' && value.at(-1) === '"' && !value.includes("\\")
  ) {
    return _value.slice(1, -1);
  }
  if (_value.length <= 9) {
    const _lval = _value.toLowerCase();
    if (_lval === "true") {
      return true;
    }
    if (_lval === "false") {
      return false;
    }
    if (_lval === "undefined") {
      return void 0;
    }
    if (_lval === "null") {
      return null;
    }
    if (_lval === "nan") {
      return Number.NaN;
    }
    if (_lval === "infinity") {
      return Number.POSITIVE_INFINITY;
    }
    if (_lval === "-infinity") {
      return Number.NEGATIVE_INFINITY;
    }
  }
  if (!JsonSigRx.test(value)) {
    if (options.strict) {
      throw new SyntaxError("[destr] Invalid JSON");
    }
    return value;
  }
  try {
    if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
      if (options.strict) {
        throw new Error("[destr] Possible prototype pollution");
      }
      return JSON.parse(value, jsonParseTransform);
    }
    return JSON.parse(value);
  } catch (error) {
    if (options.strict) {
      throw error;
    }
    return value;
  }
}

const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const IM_RE = /\?/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
const ENC_SLASH_RE = /%2f/gi;
const ENC_ENC_SLASH_RE = /%252f/gi;
function encode$1(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode$1(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function encodePath(text) {
  return encode$1(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F").replace(ENC_ENC_SLASH_RE, "%2F").replace(AMPERSAND_RE, "%26").replace(PLUS_RE, "%2B");
}
function encodeParam(text) {
  return encodePath(text).replace(SLASH_RE, "%2F");
}
function decode$1(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodePath(text) {
  return decode$1(text.replace(ENC_SLASH_RE, "%252F"));
}
function decodeQueryKey(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = {};
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map((_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}
const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
const PROTOCOL_SCRIPT_RE = /^[\s\0]*(blob|data|javascript|vbscript):$/i;
function isScriptProtocol(protocol) {
  return !!protocol && PROTOCOL_SCRIPT_RE.test(protocol);
}
const TRAILING_SLASH_RE = /\/$|\/\?|\/#/;
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/");
  }
  return TRAILING_SLASH_RE.test(input);
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
  if (!hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex >= 0) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
  }
  const [s0, ...s] = path.split("?");
  return (s0.slice(0, -1) || "/") + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/") ? input : input + "/";
  }
  if (hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex >= 0) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
    if (!path) {
      return fragment;
    }
  }
  const [s0, ...s] = path.split("?");
  return s0 + "/" + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (input.startsWith(_base)) {
    return input;
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const trimmed = input.slice(_base.length);
  return trimmed[0] === "/" ? trimmed : "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery$1(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}
function withHttps(input) {
  return withProtocol(input, "https://");
}
function withProtocol(input, protocol) {
  const match = input.match(PROTOCOL_REGEX);
  if (!match) {
    return protocol + input;
  }
  return protocol + input.slice(match[0].length);
}

function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return defaultProto ? parseURL(defaultProto + input) : parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  const [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  const { pathname, search, hash } = parsePath(
    path.replace(/\/(?=[A-Za-z]:)/, "")
  );
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol ? parsed.protocol + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

const fieldContentRegExp = /^[\u0009\u0020-\u007E\u0080-\u00FF]+$/;
function parse(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = {};
  const opt = options || {};
  const dec = opt.decode || decode;
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode(val, dec);
    }
    index = endIdx + 1;
  }
  return obj;
}
function serialize(name, value, options) {
  const opt = options || {};
  const enc = opt.encode || encode;
  if (typeof enc !== "function") {
    throw new TypeError("option encode is invalid");
  }
  if (!fieldContentRegExp.test(name)) {
    throw new TypeError("argument name is invalid");
  }
  const encodedValue = enc(value);
  if (encodedValue && !fieldContentRegExp.test(encodedValue)) {
    throw new TypeError("argument val is invalid");
  }
  let str = name + "=" + encodedValue;
  if (void 0 !== opt.maxAge && opt.maxAge !== null) {
    const maxAge = opt.maxAge - 0;
    if (Number.isNaN(maxAge) || !Number.isFinite(maxAge)) {
      throw new TypeError("option maxAge is invalid");
    }
    str += "; Max-Age=" + Math.floor(maxAge);
  }
  if (opt.domain) {
    if (!fieldContentRegExp.test(opt.domain)) {
      throw new TypeError("option domain is invalid");
    }
    str += "; Domain=" + opt.domain;
  }
  if (opt.path) {
    if (!fieldContentRegExp.test(opt.path)) {
      throw new TypeError("option path is invalid");
    }
    str += "; Path=" + opt.path;
  }
  if (opt.expires) {
    if (!isDate(opt.expires) || Number.isNaN(opt.expires.valueOf())) {
      throw new TypeError("option expires is invalid");
    }
    str += "; Expires=" + opt.expires.toUTCString();
  }
  if (opt.httpOnly) {
    str += "; HttpOnly";
  }
  if (opt.secure) {
    str += "; Secure";
  }
  if (opt.priority) {
    const priority = typeof opt.priority === "string" ? opt.priority.toLowerCase() : opt.priority;
    switch (priority) {
      case "low":
        str += "; Priority=Low";
        break;
      case "medium":
        str += "; Priority=Medium";
        break;
      case "high":
        str += "; Priority=High";
        break;
      default:
        throw new TypeError("option priority is invalid");
    }
  }
  if (opt.sameSite) {
    const sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
    switch (sameSite) {
      case true:
        str += "; SameSite=Strict";
        break;
      case "lax":
        str += "; SameSite=Lax";
        break;
      case "strict":
        str += "; SameSite=Strict";
        break;
      case "none":
        str += "; SameSite=None";
        break;
      default:
        throw new TypeError("option sameSite is invalid");
    }
  }
  return str;
}
function isDate(val) {
  return Object.prototype.toString.call(val) === "[object Date]" || val instanceof Date;
}
function tryDecode(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}
function decode(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function encode(val) {
  return encodeURIComponent(val);
}

const NODE_TYPES = {
  NORMAL: 0,
  WILDCARD: 1,
  PLACEHOLDER: 2
};

function createRouter$1(options = {}) {
  const ctx = {
    options,
    rootNode: createRadixNode(),
    staticRoutesMap: {}
  };
  const normalizeTrailingSlash = (p) => options.strictTrailingSlash ? p : p.replace(/\/$/, "") || "/";
  if (options.routes) {
    for (const path in options.routes) {
      insert(ctx, normalizeTrailingSlash(path), options.routes[path]);
    }
  }
  return {
    ctx,
    // @ts-ignore
    lookup: (path) => lookup(ctx, normalizeTrailingSlash(path)),
    insert: (path, data) => insert(ctx, normalizeTrailingSlash(path), data),
    remove: (path) => remove(ctx, normalizeTrailingSlash(path))
  };
}
function lookup(ctx, path) {
  const staticPathNode = ctx.staticRoutesMap[path];
  if (staticPathNode) {
    return staticPathNode.data;
  }
  const sections = path.split("/");
  const params = {};
  let paramsFound = false;
  let wildcardNode = null;
  let node = ctx.rootNode;
  let wildCardParam = null;
  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    if (node.wildcardChildNode !== null) {
      wildcardNode = node.wildcardChildNode;
      wildCardParam = sections.slice(i).join("/");
    }
    const nextNode = node.children.get(section);
    if (nextNode !== void 0) {
      node = nextNode;
    } else {
      node = node.placeholderChildNode;
      if (node !== null) {
        params[node.paramName] = section;
        paramsFound = true;
      } else {
        break;
      }
    }
  }
  if ((node === null || node.data === null) && wildcardNode !== null) {
    node = wildcardNode;
    params[node.paramName || "_"] = wildCardParam;
    paramsFound = true;
  }
  if (!node) {
    return null;
  }
  if (paramsFound) {
    return {
      ...node.data,
      params: paramsFound ? params : void 0
    };
  }
  return node.data;
}
function insert(ctx, path, data) {
  let isStaticRoute = true;
  const sections = path.split("/");
  let node = ctx.rootNode;
  let _unnamedPlaceholderCtr = 0;
  for (const section of sections) {
    let childNode;
    if (childNode = node.children.get(section)) {
      node = childNode;
    } else {
      const type = getNodeType(section);
      childNode = createRadixNode({ type, parent: node });
      node.children.set(section, childNode);
      if (type === NODE_TYPES.PLACEHOLDER) {
        childNode.paramName = section === "*" ? `_${_unnamedPlaceholderCtr++}` : section.slice(1);
        node.placeholderChildNode = childNode;
        isStaticRoute = false;
      } else if (type === NODE_TYPES.WILDCARD) {
        node.wildcardChildNode = childNode;
        childNode.paramName = section.slice(
          3
          /* "**:" */
        ) || "_";
        isStaticRoute = false;
      }
      node = childNode;
    }
  }
  node.data = data;
  if (isStaticRoute === true) {
    ctx.staticRoutesMap[path] = node;
  }
  return node;
}
function remove(ctx, path) {
  let success = false;
  const sections = path.split("/");
  let node = ctx.rootNode;
  for (const section of sections) {
    node = node.children.get(section);
    if (!node) {
      return success;
    }
  }
  if (node.data) {
    const lastSection = sections[sections.length - 1];
    node.data = null;
    if (Object.keys(node.children).length === 0) {
      const parentNode = node.parent;
      parentNode.children.delete(lastSection);
      parentNode.wildcardChildNode = null;
      parentNode.placeholderChildNode = null;
    }
    success = true;
  }
  return success;
}
function createRadixNode(options = {}) {
  return {
    type: options.type || NODE_TYPES.NORMAL,
    parent: options.parent || null,
    children: /* @__PURE__ */ new Map(),
    data: options.data || null,
    paramName: options.paramName || null,
    wildcardChildNode: null,
    placeholderChildNode: null
  };
}
function getNodeType(str) {
  if (str.startsWith("**")) {
    return NODE_TYPES.WILDCARD;
  }
  if (str[0] === ":" || str === "*") {
    return NODE_TYPES.PLACEHOLDER;
  }
  return NODE_TYPES.NORMAL;
}

function toRouteMatcher(router) {
  const table = _routerNodeToTable("", router.ctx.rootNode);
  return _createMatcher(table);
}
function _createMatcher(table) {
  return {
    ctx: { table },
    matchAll: (path) => _matchRoutes(path, table)
  };
}
function _createRouteTable() {
  return {
    static: /* @__PURE__ */ new Map(),
    wildcard: /* @__PURE__ */ new Map(),
    dynamic: /* @__PURE__ */ new Map()
  };
}
function _matchRoutes(path, table) {
  const matches = [];
  for (const [key, value] of _sortRoutesMap(table.wildcard)) {
    if (path.startsWith(key)) {
      matches.push(value);
    }
  }
  for (const [key, value] of _sortRoutesMap(table.dynamic)) {
    if (path.startsWith(key + "/")) {
      const subPath = "/" + path.slice(key.length).split("/").splice(2).join("/");
      matches.push(..._matchRoutes(subPath, value));
    }
  }
  const staticMatch = table.static.get(path);
  if (staticMatch) {
    matches.push(staticMatch);
  }
  return matches.filter(Boolean);
}
function _sortRoutesMap(m) {
  return [...m.entries()].sort((a, b) => a[0].length - b[0].length);
}
function _routerNodeToTable(initialPath, initialNode) {
  const table = _createRouteTable();
  function _addNode(path, node) {
    if (path) {
      if (node.type === NODE_TYPES.NORMAL && !(path.includes("*") || path.includes(":"))) {
        table.static.set(path, node.data);
      } else if (node.type === NODE_TYPES.WILDCARD) {
        table.wildcard.set(path.replace("/**", ""), node.data);
      } else if (node.type === NODE_TYPES.PLACEHOLDER) {
        const subTable = _routerNodeToTable("", node);
        if (node.data) {
          subTable.static.set("/", node.data);
        }
        table.dynamic.set(path.replace(/\/\*|\/:\w+/, ""), subTable);
        return;
      }
    }
    for (const [childPath, child] of node.children.entries()) {
      _addNode(`${path}/${childPath}`.replace("//", "/"), child);
    }
  }
  _addNode(initialPath, initialNode);
  return table;
}

function _defu(baseObject, defaults, namespace = ".", merger) {
  if (!_isPlainObject(defaults)) {
    return _defu(baseObject, {}, namespace, merger);
  }
  const object = Object.assign({}, defaults);
  for (const key in baseObject) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger && merger(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (_isPlainObject(value) && _isPlainObject(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function _isPlainObject(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  return (prototype === null || prototype === Object.prototype || Object.getPrototypeOf(prototype) === null) && !(Symbol.toStringTag in value) && !(Symbol.iterator in value);
}
function createDefu(merger) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger), {})
  );
}
const defu = createDefu();
const defuFn = createDefu((object, key, currentValue) => {
  if (object[key] !== void 0 && typeof currentValue === "function") {
    object[key] = currentValue(object[key]);
    return true;
  }
});

function rawHeaders(headers) {
  const rawHeaders2 = [];
  for (const key in headers) {
    if (Array.isArray(headers[key])) {
      for (const h of headers[key]) {
        rawHeaders2.push(key, h);
      }
    } else {
      rawHeaders2.push(key, headers[key]);
    }
  }
  return rawHeaders2;
}
function mergeFns(...functions) {
  return function(...args) {
    for (const fn of functions) {
      fn(...args);
    }
  };
}
function createNotImplementedError(name) {
  throw new Error(`[unenv] ${name} is not implemented yet!`);
}

let defaultMaxListeners = 10;
let EventEmitter$1 = class EventEmitter {
  __unenv__ = true;
  _events = /* @__PURE__ */ Object.create(null);
  _maxListeners;
  static get defaultMaxListeners() {
    return defaultMaxListeners;
  }
  static set defaultMaxListeners(arg) {
    if (typeof arg !== "number" || arg < 0 || Number.isNaN(arg)) {
      throw new RangeError(
        'The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + arg + "."
      );
    }
    defaultMaxListeners = arg;
  }
  setMaxListeners(n) {
    if (typeof n !== "number" || n < 0 || Number.isNaN(n)) {
      throw new RangeError(
        'The value of "n" is out of range. It must be a non-negative number. Received ' + n + "."
      );
    }
    this._maxListeners = n;
    return this;
  }
  getMaxListeners() {
    return _getMaxListeners(this);
  }
  emit(type, ...args) {
    if (!this._events[type] || this._events[type].length === 0) {
      return false;
    }
    if (type === "error") {
      let er;
      if (args.length > 0) {
        er = args[0];
      }
      if (er instanceof Error) {
        throw er;
      }
      const err = new Error(
        "Unhandled error." + (er ? " (" + er.message + ")" : "")
      );
      err.context = er;
      throw err;
    }
    for (const _listener of this._events[type]) {
      (_listener.listener || _listener).apply(this, args);
    }
    return true;
  }
  addListener(type, listener) {
    return _addListener(this, type, listener, false);
  }
  on(type, listener) {
    return _addListener(this, type, listener, false);
  }
  prependListener(type, listener) {
    return _addListener(this, type, listener, true);
  }
  once(type, listener) {
    return this.on(type, _wrapOnce(this, type, listener));
  }
  prependOnceListener(type, listener) {
    return this.prependListener(type, _wrapOnce(this, type, listener));
  }
  removeListener(type, listener) {
    return _removeListener(this, type, listener);
  }
  off(type, listener) {
    return this.removeListener(type, listener);
  }
  removeAllListeners(type) {
    return _removeAllListeners(this, type);
  }
  listeners(type) {
    return _listeners(this, type, true);
  }
  rawListeners(type) {
    return _listeners(this, type, false);
  }
  listenerCount(type) {
    return this.rawListeners(type).length;
  }
  eventNames() {
    return Object.keys(this._events);
  }
};
function _addListener(target, type, listener, prepend) {
  _checkListener(listener);
  if (target._events.newListener !== void 0) {
    target.emit("newListener", type, listener.listener || listener);
  }
  if (!target._events[type]) {
    target._events[type] = [];
  }
  if (prepend) {
    target._events[type].unshift(listener);
  } else {
    target._events[type].push(listener);
  }
  const maxListeners = _getMaxListeners(target);
  if (maxListeners > 0 && target._events[type].length > maxListeners && !target._events[type].warned) {
    target._events[type].warned = true;
    const warning = new Error(
      `[unenv] Possible EventEmitter memory leak detected. ${target._events[type].length} ${type} listeners added. Use emitter.setMaxListeners() to increase limit`
    );
    warning.name = "MaxListenersExceededWarning";
    warning.emitter = target;
    warning.type = type;
    warning.count = target._events[type]?.length;
    console.warn(warning);
  }
  return target;
}
function _removeListener(target, type, listener) {
  _checkListener(listener);
  if (!target._events[type] || target._events[type].length === 0) {
    return target;
  }
  const lenBeforeFilter = target._events[type].length;
  target._events[type] = target._events[type].filter((fn) => fn !== listener);
  if (lenBeforeFilter === target._events[type].length) {
    return target;
  }
  if (target._events.removeListener) {
    target.emit("removeListener", type, listener.listener || listener);
  }
  if (target._events[type].length === 0) {
    delete target._events[type];
  }
  return target;
}
function _removeAllListeners(target, type) {
  if (!target._events[type] || target._events[type].length === 0) {
    return target;
  }
  if (target._events.removeListener) {
    for (const _listener of target._events[type]) {
      target.emit("removeListener", type, _listener.listener || _listener);
    }
  }
  delete target._events[type];
  return target;
}
function _wrapOnce(target, type, listener) {
  let fired = false;
  const wrapper = (...args) => {
    if (fired) {
      return;
    }
    target.removeListener(type, wrapper);
    fired = true;
    return args.length === 0 ? listener.call(target) : listener.apply(target, args);
  };
  wrapper.listener = listener;
  return wrapper;
}
function _getMaxListeners(target) {
  return target._maxListeners ?? EventEmitter$1.defaultMaxListeners;
}
function _listeners(target, type, unwrap) {
  let listeners = target._events[type];
  if (typeof listeners === "function") {
    listeners = [listeners];
  }
  return unwrap ? listeners.map((l) => l.listener || l) : listeners;
}
function _checkListener(listener) {
  if (typeof listener !== "function") {
    throw new TypeError(
      'The "listener" argument must be of type Function. Received type ' + typeof listener
    );
  }
}

const EventEmitter = globalThis.EventEmitter || EventEmitter$1;

class _Readable extends EventEmitter {
  __unenv__ = true;
  readableEncoding = null;
  readableEnded = true;
  readableFlowing = false;
  readableHighWaterMark = 0;
  readableLength = 0;
  readableObjectMode = false;
  readableAborted = false;
  readableDidRead = false;
  closed = false;
  errored = null;
  readable = false;
  destroyed = false;
  static from(_iterable, options) {
    return new _Readable(options);
  }
  constructor(_opts) {
    super();
  }
  _read(_size) {
  }
  read(_size) {
  }
  setEncoding(_encoding) {
    return this;
  }
  pause() {
    return this;
  }
  resume() {
    return this;
  }
  isPaused() {
    return true;
  }
  unpipe(_destination) {
    return this;
  }
  unshift(_chunk, _encoding) {
  }
  wrap(_oldStream) {
    return this;
  }
  push(_chunk, _encoding) {
    return false;
  }
  _destroy(_error, _callback) {
    this.removeAllListeners();
  }
  destroy(error) {
    this.destroyed = true;
    this._destroy(error);
    return this;
  }
  pipe(_destenition, _options) {
    return {};
  }
  compose(stream, options) {
    throw new Error("[unenv] Method not implemented.");
  }
  [Symbol.asyncDispose]() {
    this.destroy();
    return Promise.resolve();
  }
  async *[Symbol.asyncIterator]() {
    throw createNotImplementedError("Readable.asyncIterator");
  }
  iterator(options) {
    throw createNotImplementedError("Readable.iterator");
  }
  map(fn, options) {
    throw createNotImplementedError("Readable.map");
  }
  filter(fn, options) {
    throw createNotImplementedError("Readable.filter");
  }
  forEach(fn, options) {
    throw createNotImplementedError("Readable.forEach");
  }
  reduce(fn, initialValue, options) {
    throw createNotImplementedError("Readable.reduce");
  }
  find(fn, options) {
    throw createNotImplementedError("Readable.find");
  }
  findIndex(fn, options) {
    throw createNotImplementedError("Readable.findIndex");
  }
  some(fn, options) {
    throw createNotImplementedError("Readable.some");
  }
  toArray(options) {
    throw createNotImplementedError("Readable.toArray");
  }
  every(fn, options) {
    throw createNotImplementedError("Readable.every");
  }
  flatMap(fn, options) {
    throw createNotImplementedError("Readable.flatMap");
  }
  drop(limit, options) {
    throw createNotImplementedError("Readable.drop");
  }
  take(limit, options) {
    throw createNotImplementedError("Readable.take");
  }
  asIndexedPairs(options) {
    throw createNotImplementedError("Readable.asIndexedPairs");
  }
}
const Readable = globalThis.Readable || _Readable;

class _Writable extends EventEmitter {
  __unenv__ = true;
  writable = true;
  writableEnded = false;
  writableFinished = false;
  writableHighWaterMark = 0;
  writableLength = 0;
  writableObjectMode = false;
  writableCorked = 0;
  closed = false;
  errored = null;
  writableNeedDrain = false;
  destroyed = false;
  _data;
  _encoding = "utf-8";
  constructor(_opts) {
    super();
  }
  pipe(_destenition, _options) {
    return {};
  }
  _write(chunk, encoding, callback) {
    if (this.writableEnded) {
      if (callback) {
        callback();
      }
      return;
    }
    if (this._data === void 0) {
      this._data = chunk;
    } else {
      const a = typeof this._data === "string" ? Buffer.from(this._data, this._encoding || encoding || "utf8") : this._data;
      const b = typeof chunk === "string" ? Buffer.from(chunk, encoding || this._encoding || "utf8") : chunk;
      this._data = Buffer.concat([a, b]);
    }
    this._encoding = encoding;
    if (callback) {
      callback();
    }
  }
  _writev(_chunks, _callback) {
  }
  _destroy(_error, _callback) {
  }
  _final(_callback) {
  }
  write(chunk, arg2, arg3) {
    const encoding = typeof arg2 === "string" ? this._encoding : "utf-8";
    const cb = typeof arg2 === "function" ? arg2 : typeof arg3 === "function" ? arg3 : void 0;
    this._write(chunk, encoding, cb);
    return true;
  }
  setDefaultEncoding(_encoding) {
    return this;
  }
  end(arg1, arg2, arg3) {
    const callback = typeof arg1 === "function" ? arg1 : typeof arg2 === "function" ? arg2 : typeof arg3 === "function" ? arg3 : void 0;
    if (this.writableEnded) {
      if (callback) {
        callback();
      }
      return this;
    }
    const data = arg1 === callback ? void 0 : arg1;
    if (data) {
      const encoding = arg2 === callback ? void 0 : arg2;
      this.write(data, encoding, callback);
    }
    this.writableEnded = true;
    this.writableFinished = true;
    this.emit("close");
    this.emit("finish");
    return this;
  }
  cork() {
  }
  uncork() {
  }
  destroy(_error) {
    this.destroyed = true;
    delete this._data;
    this.removeAllListeners();
    return this;
  }
  compose(stream, options) {
    throw new Error("[h3] Method not implemented.");
  }
}
const Writable = globalThis.Writable || _Writable;

const __Duplex = class {
  allowHalfOpen = true;
  _destroy;
  constructor(readable = new Readable(), writable = new Writable()) {
    Object.assign(this, readable);
    Object.assign(this, writable);
    this._destroy = mergeFns(readable._destroy, writable._destroy);
  }
};
function getDuplex() {
  Object.assign(__Duplex.prototype, Readable.prototype);
  Object.assign(__Duplex.prototype, Writable.prototype);
  return __Duplex;
}
const _Duplex = /* @__PURE__ */ getDuplex();
const Duplex = globalThis.Duplex || _Duplex;

class Socket extends Duplex {
  __unenv__ = true;
  bufferSize = 0;
  bytesRead = 0;
  bytesWritten = 0;
  connecting = false;
  destroyed = false;
  pending = false;
  localAddress = "";
  localPort = 0;
  remoteAddress = "";
  remoteFamily = "";
  remotePort = 0;
  autoSelectFamilyAttemptedAddresses = [];
  readyState = "readOnly";
  constructor(_options) {
    super();
  }
  write(_buffer, _arg1, _arg2) {
    return false;
  }
  connect(_arg1, _arg2, _arg3) {
    return this;
  }
  end(_arg1, _arg2, _arg3) {
    return this;
  }
  setEncoding(_encoding) {
    return this;
  }
  pause() {
    return this;
  }
  resume() {
    return this;
  }
  setTimeout(_timeout, _callback) {
    return this;
  }
  setNoDelay(_noDelay) {
    return this;
  }
  setKeepAlive(_enable, _initialDelay) {
    return this;
  }
  address() {
    return {};
  }
  unref() {
    return this;
  }
  ref() {
    return this;
  }
  destroySoon() {
    this.destroy();
  }
  resetAndDestroy() {
    const err = new Error("ERR_SOCKET_CLOSED");
    err.code = "ERR_SOCKET_CLOSED";
    this.destroy(err);
    return this;
  }
}

class IncomingMessage extends Readable {
  __unenv__ = {};
  aborted = false;
  httpVersion = "1.1";
  httpVersionMajor = 1;
  httpVersionMinor = 1;
  complete = true;
  connection;
  socket;
  headers = {};
  trailers = {};
  method = "GET";
  url = "/";
  statusCode = 200;
  statusMessage = "";
  closed = false;
  errored = null;
  readable = false;
  constructor(socket) {
    super();
    this.socket = this.connection = socket || new Socket();
  }
  get rawHeaders() {
    return rawHeaders(this.headers);
  }
  get rawTrailers() {
    return [];
  }
  setTimeout(_msecs, _callback) {
    return this;
  }
  get headersDistinct() {
    return _distinct(this.headers);
  }
  get trailersDistinct() {
    return _distinct(this.trailers);
  }
}
function _distinct(obj) {
  const d = {};
  for (const [key, value] of Object.entries(obj)) {
    if (key) {
      d[key] = (Array.isArray(value) ? value : [value]).filter(
        Boolean
      );
    }
  }
  return d;
}

class ServerResponse extends Writable {
  __unenv__ = true;
  statusCode = 200;
  statusMessage = "";
  upgrading = false;
  chunkedEncoding = false;
  shouldKeepAlive = false;
  useChunkedEncodingByDefault = false;
  sendDate = false;
  finished = false;
  headersSent = false;
  strictContentLength = false;
  connection = null;
  socket = null;
  req;
  _headers = {};
  constructor(req) {
    super();
    this.req = req;
  }
  assignSocket(socket) {
    socket._httpMessage = this;
    this.socket = socket;
    this.connection = socket;
    this.emit("socket", socket);
    this._flush();
  }
  _flush() {
    this.flushHeaders();
  }
  detachSocket(_socket) {
  }
  writeContinue(_callback) {
  }
  writeHead(statusCode, arg1, arg2) {
    if (statusCode) {
      this.statusCode = statusCode;
    }
    if (typeof arg1 === "string") {
      this.statusMessage = arg1;
      arg1 = void 0;
    }
    const headers = arg2 || arg1;
    if (headers) {
      if (Array.isArray(headers)) ; else {
        for (const key in headers) {
          this.setHeader(key, headers[key]);
        }
      }
    }
    this.headersSent = true;
    return this;
  }
  writeProcessing() {
  }
  setTimeout(_msecs, _callback) {
    return this;
  }
  appendHeader(name, value) {
    name = name.toLowerCase();
    const current = this._headers[name];
    const all = [
      ...Array.isArray(current) ? current : [current],
      ...Array.isArray(value) ? value : [value]
    ].filter(Boolean);
    this._headers[name] = all.length > 1 ? all : all[0];
    return this;
  }
  setHeader(name, value) {
    this._headers[name.toLowerCase()] = value;
    return this;
  }
  getHeader(name) {
    return this._headers[name.toLowerCase()];
  }
  getHeaders() {
    return this._headers;
  }
  getHeaderNames() {
    return Object.keys(this._headers);
  }
  hasHeader(name) {
    return name.toLowerCase() in this._headers;
  }
  removeHeader(name) {
    delete this._headers[name.toLowerCase()];
  }
  addTrailers(_headers) {
  }
  flushHeaders() {
  }
  writeEarlyHints(_headers, cb) {
    if (typeof cb === "function") {
      cb();
    }
  }
}

function useBase(base, handler) {
  base = withoutTrailingSlash(base);
  if (!base || base === "/") {
    return handler;
  }
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _path = event._path || event.node.req.url || "/";
    event._path = withoutBase(event.path || "/", base);
    event.node.req.url = event._path;
    try {
      return await handler(event);
    } finally {
      event._path = event.node.req.url = _path;
    }
  });
}

function hasProp(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}

var __defProp$1 = Object.defineProperty;
var __defNormalProp$1 = (obj, key, value) => key in obj ? __defProp$1(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField$1 = (obj, key, value) => {
  __defNormalProp$1(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
class H3Error extends Error {
  constructor(message, opts = {}) {
    super(message, opts);
    __publicField$1(this, "statusCode", 500);
    __publicField$1(this, "fatal", false);
    __publicField$1(this, "unhandled", false);
    __publicField$1(this, "statusMessage");
    __publicField$1(this, "data");
    __publicField$1(this, "cause");
    if (opts.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
  toJSON() {
    const obj = {
      message: this.message,
      statusCode: sanitizeStatusCode(this.statusCode, 500)
    };
    if (this.statusMessage) {
      obj.statusMessage = sanitizeStatusMessage(this.statusMessage);
    }
    if (this.data !== void 0) {
      obj.data = this.data;
    }
    return obj;
  }
}
__publicField$1(H3Error, "__h3_error__", true);
function createError$1(input) {
  if (typeof input === "string") {
    return new H3Error(input);
  }
  if (isError(input)) {
    return input;
  }
  const err = new H3Error(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== void 0) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== void 0) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function sendError(event, error, debug) {
  if (event.handled) {
    return;
  }
  const h3Error = isError(error) ? error : createError$1(error);
  const responseBody = {
    statusCode: h3Error.statusCode,
    statusMessage: h3Error.statusMessage,
    stack: [],
    data: h3Error.data
  };
  if (debug) {
    responseBody.stack = (h3Error.stack || "").split("\n").map((l) => l.trim());
  }
  if (event.handled) {
    return;
  }
  const _code = Number.parseInt(h3Error.statusCode);
  setResponseStatus(event, _code, h3Error.statusMessage);
  event.node.res.setHeader("content-type", MIMES.json);
  event.node.res.end(JSON.stringify(responseBody, void 0, 2));
}
function isError(input) {
  return input?.constructor?.__h3_error__ === true;
}

function getQuery(event) {
  return getQuery$1(event.path || "");
}
function isMethod(event, expected, allowHead) {
  if (allowHead && event.method === "HEAD") {
    return true;
  }
  if (typeof expected === "string") {
    if (event.method === expected) {
      return true;
    }
  } else if (expected.includes(event.method)) {
    return true;
  }
  return false;
}
function assertMethod(event, expected, allowHead) {
  if (!isMethod(event, expected, allowHead)) {
    throw createError$1({
      statusCode: 405,
      statusMessage: "HTTP method is not allowed."
    });
  }
}
function getRequestHeaders(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader(event, name) {
  const headers = getRequestHeaders(event);
  const value = headers[name.toLowerCase()];
  return value;
}
const getHeader = getRequestHeader;
function getRequestHost(event, opts = {}) {
  if (opts.xForwardedHost) {
    const xForwardedHost = event.node.req.headers["x-forwarded-host"];
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}
function getRequestURL(event, opts = {}) {
  const host = getRequestHost(event, opts);
  const protocol = getRequestProtocol(event);
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  return new URL(path, `${protocol}://${host}`);
}

const RawBodySymbol = Symbol.for("h3RawBody");
const PayloadMethods$1 = ["PATCH", "POST", "PUT", "DELETE"];
function readRawBody(event, encoding = "utf8") {
  assertMethod(event, PayloadMethods$1);
  const _rawBody = event._requestBody || event.web?.request?.body || event.node.req[RawBodySymbol] || event.node.req.body;
  if (_rawBody) {
    const promise2 = Promise.resolve(_rawBody).then((_resolved) => {
      if (Buffer.isBuffer(_resolved)) {
        return _resolved;
      }
      if (typeof _resolved.pipeTo === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.pipeTo(
            new WritableStream({
              write(chunk) {
                chunks.push(chunk);
              },
              close() {
                resolve(Buffer.concat(chunks));
              },
              abort(reason) {
                reject(reason);
              }
            })
          ).catch(reject);
        });
      } else if (typeof _resolved.pipe === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.on("data", (chunk) => {
            chunks.push(chunk);
          }).on("end", () => {
            resolve(Buffer.concat(chunks));
          }).on("error", reject);
        });
      }
      if (_resolved.constructor === Object) {
        return Buffer.from(JSON.stringify(_resolved));
      }
      return Buffer.from(_resolved);
    });
    return encoding ? promise2.then((buff) => buff.toString(encoding)) : promise2;
  }
  if (!Number.parseInt(event.node.req.headers["content-length"] || "")) {
    return Promise.resolve(void 0);
  }
  const promise = event.node.req[RawBodySymbol] = new Promise(
    (resolve, reject) => {
      const bodyData = [];
      event.node.req.on("error", (err) => {
        reject(err);
      }).on("data", (chunk) => {
        bodyData.push(chunk);
      }).on("end", () => {
        resolve(Buffer.concat(bodyData));
      });
    }
  );
  const result = encoding ? promise.then((buff) => buff.toString(encoding)) : promise;
  return result;
}
function getRequestWebStream(event) {
  if (!PayloadMethods$1.includes(event.method)) {
    return;
  }
  return event.web?.request?.body || event._requestBody || new ReadableStream({
    start: (controller) => {
      event.node.req.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      event.node.req.on("end", () => {
        controller.close();
      });
      event.node.req.on("error", (err) => {
        controller.error(err);
      });
    }
  });
}

function handleCacheHeaders(event, opts) {
  const cacheControls = ["public", ...opts.cacheControls || []];
  let cacheMatched = false;
  if (opts.maxAge !== void 0) {
    cacheControls.push(`max-age=${+opts.maxAge}`, `s-maxage=${+opts.maxAge}`);
  }
  if (opts.modifiedTime) {
    const modifiedTime = new Date(opts.modifiedTime);
    const ifModifiedSince = event.node.req.headers["if-modified-since"];
    event.node.res.setHeader("last-modified", modifiedTime.toUTCString());
    if (ifModifiedSince && new Date(ifModifiedSince) >= opts.modifiedTime) {
      cacheMatched = true;
    }
  }
  if (opts.etag) {
    event.node.res.setHeader("etag", opts.etag);
    const ifNonMatch = event.node.req.headers["if-none-match"];
    if (ifNonMatch === opts.etag) {
      cacheMatched = true;
    }
  }
  event.node.res.setHeader("cache-control", cacheControls.join(", "));
  if (cacheMatched) {
    event.node.res.statusCode = 304;
    if (!event.handled) {
      event.node.res.end();
    }
    return true;
  }
  return false;
}

const MIMES = {
  html: "text/html",
  json: "application/json"
};

const DISALLOWED_STATUS_CHARS = /[^\u0009\u0020-\u007E]/g;
function sanitizeStatusMessage(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS, "");
}
function sanitizeStatusCode(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}

function parseCookies(event) {
  return parse(event.node.req.headers.cookie || "");
}
function getCookie(event, name) {
  return parseCookies(event)[name];
}
function setCookie(event, name, value, serializeOptions) {
  const cookieStr = serialize(name, value, {
    path: "/",
    ...serializeOptions
  });
  let setCookies = event.node.res.getHeader("set-cookie");
  if (!Array.isArray(setCookies)) {
    setCookies = [setCookies];
  }
  setCookies = setCookies.filter((cookieValue) => {
    return cookieValue && !cookieValue.startsWith(name + "=");
  });
  event.node.res.setHeader("set-cookie", [...setCookies, cookieStr]);
}
function deleteCookie(event, name, serializeOptions) {
  setCookie(event, name, "", {
    ...serializeOptions,
    maxAge: 0
  });
}
function splitCookiesString(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start, cookiesString.length));
    }
  }
  return cookiesStrings;
}

const defer = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
function send(event, data, type) {
  if (type) {
    defaultContentType(event, type);
  }
  return new Promise((resolve) => {
    defer(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve();
    });
  });
}
function sendNoContent(event, code) {
  if (event.handled) {
    return;
  }
  if (!code && event.node.res.statusCode !== 200) {
    code = event.node.res.statusCode;
  }
  const _code = sanitizeStatusCode(code, 204);
  if (_code === 204) {
    event.node.res.removeHeader("content-length");
  }
  event.node.res.writeHead(_code);
  event.node.res.end();
}
function setResponseStatus(event, code, text) {
  if (code) {
    event.node.res.statusCode = sanitizeStatusCode(
      code,
      event.node.res.statusCode
    );
  }
  if (text) {
    event.node.res.statusMessage = sanitizeStatusMessage(text);
  }
}
function getResponseStatus(event) {
  return event.node.res.statusCode;
}
function getResponseStatusText(event) {
  return event.node.res.statusMessage;
}
function defaultContentType(event, type) {
  if (type && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send(event, html, MIMES.html);
}
function getResponseHeader(event, name) {
  return event.node.res.getHeader(name);
}
function setResponseHeaders(event, headers) {
  for (const [name, value] of Object.entries(headers)) {
    event.node.res.setHeader(name, value);
  }
}
const setHeaders = setResponseHeaders;
function setResponseHeader(event, name, value) {
  event.node.res.setHeader(name, value);
}
const setHeader = setResponseHeader;
function removeResponseHeader(event, name) {
  return event.node.res.removeHeader(name);
}
function isStream(data) {
  if (!data || typeof data !== "object") {
    return false;
  }
  if (typeof data.pipe === "function") {
    if (typeof data._read === "function") {
      return true;
    }
    if (typeof data.abort === "function") {
      return true;
    }
  }
  if (typeof data.pipeTo === "function") {
    return true;
  }
  return false;
}
function isWebResponse(data) {
  return typeof Response !== "undefined" && data instanceof Response;
}
function sendStream(event, stream) {
  if (!stream || typeof stream !== "object") {
    throw new Error("[h3] Invalid stream provided.");
  }
  event.node.res._data = stream;
  if (!event.node.res.socket) {
    event._handled = true;
    return Promise.resolve();
  }
  if (hasProp(stream, "pipeTo") && typeof stream.pipeTo === "function") {
    return stream.pipeTo(
      new WritableStream({
        write(chunk) {
          event.node.res.write(chunk);
        }
      })
    ).then(() => {
      event.node.res.end();
    });
  }
  if (hasProp(stream, "pipe") && typeof stream.pipe === "function") {
    return new Promise((resolve, reject) => {
      stream.pipe(event.node.res);
      if (stream.on) {
        stream.on("end", () => {
          event.node.res.end();
          resolve();
        });
        stream.on("error", (error) => {
          reject(error);
        });
      }
      event.node.res.on("close", () => {
        if (stream.abort) {
          stream.abort();
        }
      });
    });
  }
  throw new Error("[h3] Invalid or incompatible stream provided.");
}
function sendWebResponse(event, response) {
  for (const [key, value] of response.headers) {
    if (key === "set-cookie") {
      event.node.res.appendHeader(key, splitCookiesString(value));
    } else {
      event.node.res.setHeader(key, value);
    }
  }
  if (response.status) {
    event.node.res.statusCode = sanitizeStatusCode(
      response.status,
      event.node.res.statusCode
    );
  }
  if (response.statusText) {
    event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  }
  if (response.redirected) {
    event.node.res.setHeader("location", response.url);
  }
  if (!response.body) {
    event.node.res.end();
    return;
  }
  return sendStream(event, response.body);
}

const PayloadMethods = /* @__PURE__ */ new Set(["PATCH", "POST", "PUT", "DELETE"]);
const ignoredHeaders = /* @__PURE__ */ new Set([
  "transfer-encoding",
  "connection",
  "keep-alive",
  "upgrade",
  "expect",
  "host"
]);
async function proxyRequest(event, target, opts = {}) {
  let body;
  let duplex;
  if (PayloadMethods.has(event.method)) {
    if (opts.streamRequest) {
      body = getRequestWebStream(event);
      duplex = "half";
    } else {
      body = await readRawBody(event, false).catch(() => void 0);
    }
  }
  const method = opts.fetchOptions?.method || event.method;
  const fetchHeaders = mergeHeaders(
    getProxyRequestHeaders(event),
    opts.fetchOptions?.headers,
    opts.headers
  );
  return sendProxy(event, target, {
    ...opts,
    fetchOptions: {
      method,
      body,
      duplex,
      ...opts.fetchOptions,
      headers: fetchHeaders
    }
  });
}
async function sendProxy(event, target, opts = {}) {
  const response = await _getFetch(opts.fetch)(target, {
    headers: opts.headers,
    ignoreResponseError: true,
    // make $ofetch.raw transparent
    ...opts.fetchOptions
  });
  event.node.res.statusCode = sanitizeStatusCode(
    response.status,
    event.node.res.statusCode
  );
  event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  const cookies = [];
  for (const [key, value] of response.headers.entries()) {
    if (key === "content-encoding") {
      continue;
    }
    if (key === "content-length") {
      continue;
    }
    if (key === "set-cookie") {
      cookies.push(...splitCookiesString(value));
      continue;
    }
    event.node.res.setHeader(key, value);
  }
  if (cookies.length > 0) {
    event.node.res.setHeader(
      "set-cookie",
      cookies.map((cookie) => {
        if (opts.cookieDomainRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookieDomainRewrite,
            "domain"
          );
        }
        if (opts.cookiePathRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookiePathRewrite,
            "path"
          );
        }
        return cookie;
      })
    );
  }
  if (opts.onResponse) {
    await opts.onResponse(event, response);
  }
  if (response._data !== void 0) {
    return response._data;
  }
  if (event.handled) {
    return;
  }
  if (opts.sendStream === false) {
    const data = new Uint8Array(await response.arrayBuffer());
    return event.node.res.end(data);
  }
  if (response.body) {
    for await (const chunk of response.body) {
      event.node.res.write(chunk);
    }
  }
  return event.node.res.end();
}
function getProxyRequestHeaders(event) {
  const headers = /* @__PURE__ */ Object.create(null);
  const reqHeaders = getRequestHeaders(event);
  for (const name in reqHeaders) {
    if (!ignoredHeaders.has(name)) {
      headers[name] = reqHeaders[name];
    }
  }
  return headers;
}
function fetchWithEvent(event, req, init, options) {
  return _getFetch(options?.fetch)(req, {
    ...init,
    context: init?.context || event.context,
    headers: {
      ...getProxyRequestHeaders(event),
      ...init?.headers
    }
  });
}
function _getFetch(_fetch) {
  if (_fetch) {
    return _fetch;
  }
  if (globalThis.fetch) {
    return globalThis.fetch;
  }
  throw new Error(
    "fetch is not available. Try importing `node-fetch-native/polyfill` for Node.js."
  );
}
function rewriteCookieProperty(header, map, property) {
  const _map = typeof map === "string" ? { "*": map } : map;
  return header.replace(
    new RegExp(`(;\\s*${property}=)([^;]+)`, "gi"),
    (match, prefix, previousValue) => {
      let newValue;
      if (previousValue in _map) {
        newValue = _map[previousValue];
      } else if ("*" in _map) {
        newValue = _map["*"];
      } else {
        return match;
      }
      return newValue ? prefix + newValue : "";
    }
  );
}
function mergeHeaders(defaults, ...inputs) {
  const _inputs = inputs.filter(Boolean);
  if (_inputs.length === 0) {
    return defaults;
  }
  const merged = new Headers(defaults);
  for (const input of _inputs) {
    for (const [key, value] of Object.entries(input)) {
      if (value !== void 0) {
        merged.set(key, value);
      }
    }
  }
  return merged;
}

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
class H3Event {
  constructor(req, res) {
    __publicField(this, "__is_event__", true);
    // Context
    __publicField(this, "node");
    // Node
    __publicField(this, "web");
    // Web
    __publicField(this, "context", {});
    // Shared
    // Request
    __publicField(this, "_method");
    __publicField(this, "_path");
    __publicField(this, "_headers");
    __publicField(this, "_requestBody");
    // Response
    __publicField(this, "_handled", false);
    this.node = { req, res };
  }
  // --- Request ---
  get method() {
    if (!this._method) {
      this._method = (this.node.req.method || "GET").toUpperCase();
    }
    return this._method;
  }
  get path() {
    return this._path || this.node.req.url || "/";
  }
  get headers() {
    if (!this._headers) {
      this._headers = _normalizeNodeHeaders(this.node.req.headers);
    }
    return this._headers;
  }
  // --- Respoonse ---
  get handled() {
    return this._handled || this.node.res.writableEnded || this.node.res.headersSent;
  }
  respondWith(response) {
    return Promise.resolve(response).then(
      (_response) => sendWebResponse(this, _response)
    );
  }
  // --- Utils ---
  toString() {
    return `[${this.method}] ${this.path}`;
  }
  toJSON() {
    return this.toString();
  }
  // --- Deprecated ---
  /** @deprecated Please use `event.node.req` instead. **/
  get req() {
    return this.node.req;
  }
  /** @deprecated Please use `event.node.res` instead. **/
  get res() {
    return this.node.res;
  }
}
function isEvent(input) {
  return hasProp(input, "__is_event__");
}
function createEvent(req, res) {
  return new H3Event(req, res);
}
function _normalizeNodeHeaders(nodeHeaders) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(nodeHeaders)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        headers.append(name, item);
      }
    } else if (value) {
      headers.set(name, value);
    }
  }
  return headers;
}

function defineEventHandler(handler) {
  if (typeof handler === "function") {
    return Object.assign(handler, { __is_handler__: true });
  }
  const _hooks = {
    onRequest: _normalizeArray(handler.onRequest),
    onBeforeResponse: _normalizeArray(handler.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler(event, handler.handler, _hooks);
  };
  return Object.assign(_handler, { __is_handler__: true });
}
function _normalizeArray(input) {
  return input ? Array.isArray(input) ? input : [input] : void 0;
}
async function _callHandler(event, handler, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
const eventHandler = defineEventHandler;
function isEventHandler(input) {
  return hasProp(input, "__is_handler__");
}
function toEventHandler(input, _, _route) {
  if (!isEventHandler(input)) {
    console.warn(
      "[h3] Implicit event handler conversion is deprecated. Use `eventHandler()` or `fromNodeMiddleware()` to define event handlers.",
      _route && _route !== "/" ? `
     Route: ${_route}` : "",
      `
     Handler: ${input}`
    );
  }
  return input;
}
function defineLazyEventHandler(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler = r.default || r;
        if (typeof handler !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler
          );
        }
        _resolved = toEventHandler(r.default || r);
        return _resolved;
      });
    }
    return _promise;
  };
  return eventHandler((event) => {
    if (_resolved) {
      return _resolved(event);
    }
    return resolveHandler().then((handler) => handler(event));
  });
}
const lazyEventHandler = defineLazyEventHandler;

function createApp(options = {}) {
  const stack = [];
  const handler = createAppEventHandler(stack, options);
  const app = {
    // @ts-ignore
    use: (arg1, arg2, arg3) => use(app, arg1, arg2, arg3),
    handler,
    stack,
    options
  };
  return app;
}
function use(app, arg1, arg2, arg3) {
  if (Array.isArray(arg1)) {
    for (const i of arg1) {
      use(app, i, arg2, arg3);
    }
  } else if (Array.isArray(arg2)) {
    for (const i of arg2) {
      use(app, arg1, i, arg3);
    }
  } else if (typeof arg1 === "string") {
    app.stack.push(
      normalizeLayer({ ...arg3, route: arg1, handler: arg2 })
    );
  } else if (typeof arg1 === "function") {
    app.stack.push(
      normalizeLayer({ ...arg2, route: "/", handler: arg1 })
    );
  } else {
    app.stack.push(normalizeLayer({ ...arg1 }));
  }
  return app;
}
function createAppEventHandler(stack, options) {
  const spacing = options.debug ? 2 : void 0;
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _reqPath = event._path || event.node.req.url || "/";
    let _layerPath;
    if (options.onRequest) {
      await options.onRequest(event);
    }
    for (const layer of stack) {
      if (layer.route.length > 1) {
        if (!_reqPath.startsWith(layer.route)) {
          continue;
        }
        _layerPath = _reqPath.slice(layer.route.length) || "/";
      } else {
        _layerPath = _reqPath;
      }
      if (layer.match && !layer.match(_layerPath, event)) {
        continue;
      }
      event._path = _layerPath;
      event.node.req.url = _layerPath;
      const val = await layer.handler(event);
      const _body = val === void 0 ? void 0 : await val;
      if (_body !== void 0) {
        const _response = { body: _body };
        if (options.onBeforeResponse) {
          await options.onBeforeResponse(event, _response);
        }
        await handleHandlerResponse(event, _response.body, spacing);
        if (options.onAfterResponse) {
          await options.onAfterResponse(event, _response);
        }
        return;
      }
      if (event.handled) {
        if (options.onAfterResponse) {
          await options.onAfterResponse(event, void 0);
        }
        return;
      }
    }
    if (!event.handled) {
      throw createError$1({
        statusCode: 404,
        statusMessage: `Cannot find any path matching ${event.path || "/"}.`
      });
    }
    if (options.onAfterResponse) {
      await options.onAfterResponse(event, void 0);
    }
  });
}
function normalizeLayer(input) {
  let handler = input.handler;
  if (handler.handler) {
    handler = handler.handler;
  }
  if (input.lazy) {
    handler = lazyEventHandler(handler);
  } else if (!isEventHandler(handler)) {
    handler = toEventHandler(handler, void 0, input.route);
  }
  return {
    route: withoutTrailingSlash(input.route),
    match: input.match,
    handler
  };
}
function handleHandlerResponse(event, val, jsonSpace) {
  if (val === null) {
    return sendNoContent(event);
  }
  if (val) {
    if (isWebResponse(val)) {
      return sendWebResponse(event, val);
    }
    if (isStream(val)) {
      return sendStream(event, val);
    }
    if (val.buffer) {
      return send(event, val);
    }
    if (val.arrayBuffer && typeof val.arrayBuffer === "function") {
      return val.arrayBuffer().then((arrayBuffer) => {
        return send(event, Buffer.from(arrayBuffer), val.type);
      });
    }
    if (val instanceof Error) {
      throw createError$1(val);
    }
    if (typeof val.end === "function") {
      return true;
    }
  }
  const valType = typeof val;
  if (valType === "string") {
    return send(event, val, MIMES.html);
  }
  if (valType === "object" || valType === "boolean" || valType === "number") {
    return send(event, JSON.stringify(val, void 0, jsonSpace), MIMES.json);
  }
  if (valType === "bigint") {
    return send(event, val.toString(), MIMES.json);
  }
  throw createError$1({
    statusCode: 500,
    statusMessage: `[h3] Cannot send ${valType} as response.`
  });
}

const RouterMethods = [
  "connect",
  "delete",
  "get",
  "head",
  "options",
  "post",
  "put",
  "trace",
  "patch"
];
function createRouter(opts = {}) {
  const _router = createRouter$1({});
  const routes = {};
  let _matcher;
  const router = {};
  const addRoute = (path, handler, method) => {
    let route = routes[path];
    if (!route) {
      routes[path] = route = { path, handlers: {} };
      _router.insert(path, route);
    }
    if (Array.isArray(method)) {
      for (const m of method) {
        addRoute(path, handler, m);
      }
    } else {
      route.handlers[method] = toEventHandler(handler, void 0, path);
    }
    return router;
  };
  router.use = router.add = (path, handler, method) => addRoute(path, handler, method || "all");
  for (const method of RouterMethods) {
    router[method] = (path, handle) => router.add(path, handle, method);
  }
  router.handler = eventHandler((event) => {
    let path = event.path || "/";
    const qIndex = path.indexOf("?");
    if (qIndex !== -1) {
      path = path.slice(0, Math.max(0, qIndex));
    }
    const matched = _router.lookup(path);
    if (!matched || !matched.handlers) {
      if (opts.preemptive || opts.preemtive) {
        throw createError$1({
          statusCode: 404,
          name: "Not Found",
          statusMessage: `Cannot find any route matching ${event.path || "/"}.`
        });
      } else {
        return;
      }
    }
    const method = (event.node.req.method || "get").toLowerCase();
    let handler = matched.handlers[method] || matched.handlers.all;
    if (!handler) {
      if (!_matcher) {
        _matcher = toRouteMatcher(_router);
      }
      const _matches = _matcher.matchAll(path).reverse();
      for (const _match of _matches) {
        if (_match.handlers[method]) {
          handler = _match.handlers[method];
          matched.handlers[method] = matched.handlers[method] || handler;
          break;
        }
        if (_match.handlers.all) {
          handler = _match.handlers.all;
          matched.handlers.all = matched.handlers.all || handler;
          break;
        }
      }
    }
    if (!handler) {
      if (opts.preemptive || opts.preemtive) {
        throw createError$1({
          statusCode: 405,
          name: "Method Not Allowed",
          statusMessage: `Method ${method} is not allowed on this route.`
        });
      } else {
        return;
      }
    }
    event.context.matchedRoute = matched;
    const params = matched.params || {};
    event.context.params = params;
    return Promise.resolve(handler(event)).then((res) => {
      if (res === void 0 && (opts.preemptive || opts.preemtive)) {
        return null;
      }
      return res;
    });
  });
  return router;
}
function toNodeListener(app) {
  const toNodeHandle = async function(req, res) {
    const event = createEvent(req, res);
    try {
      await app.handler(event);
    } catch (_error) {
      const error = createError$1(_error);
      if (!isError(_error)) {
        error.unhandled = true;
      }
      if (app.options.onError) {
        await app.options.onError(error, event);
      }
      if (event.handled) {
        return;
      }
      if (error.unhandled || error.fatal) {
        console.error("[h3]", error.fatal ? "[fatal]" : "[unhandled]", error);
      }
      await sendError(event, error, !!app.options.debug);
    }
  };
  return toNodeHandle;
}

const s=globalThis.Headers,i=globalThis.AbortController,l=globalThis.fetch||(()=>{throw new Error("[node-fetch-native] Failed to fetch: `globalThis.fetch` is not available!")});

class FetchError extends Error {
  constructor(message, opts) {
    super(message, opts);
    this.name = "FetchError";
    if (opts?.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
}
function createFetchError(ctx) {
  const errorMessage = ctx.error?.message || ctx.error?.toString() || "";
  const method = ctx.request?.method || ctx.options?.method || "GET";
  const url = ctx.request?.url || String(ctx.request) || "/";
  const requestStr = `[${method}] ${JSON.stringify(url)}`;
  const statusStr = ctx.response ? `${ctx.response.status} ${ctx.response.statusText}` : "<no response>";
  const message = `${requestStr}: ${statusStr}${errorMessage ? ` ${errorMessage}` : ""}`;
  const fetchError = new FetchError(
    message,
    ctx.error ? { cause: ctx.error } : void 0
  );
  for (const key of ["request", "options", "response"]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx[key];
      }
    });
  }
  for (const [key, refKey] of [
    ["data", "_data"],
    ["status", "status"],
    ["statusCode", "status"],
    ["statusText", "statusText"],
    ["statusMessage", "statusText"]
  ]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx.response && ctx.response[refKey];
      }
    });
  }
  return fetchError;
}

const payloadMethods = new Set(
  Object.freeze(["PATCH", "POST", "PUT", "DELETE"])
);
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(value) {
  if (value === void 0) {
    return false;
  }
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(value)) {
    return true;
  }
  if (value.buffer) {
    return false;
  }
  return value.constructor && value.constructor.name === "Object" || typeof value.toJSON === "function";
}
const textTypes = /* @__PURE__ */ new Set([
  "image/svg",
  "application/xml",
  "application/xhtml",
  "application/html"
]);
const JSON_RE = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift() || "";
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
function mergeFetchOptions(input, defaults, Headers = globalThis.Headers) {
  const merged = {
    ...defaults,
    ...input
  };
  if (defaults?.params && input?.params) {
    merged.params = {
      ...defaults?.params,
      ...input?.params
    };
  }
  if (defaults?.query && input?.query) {
    merged.query = {
      ...defaults?.query,
      ...input?.query
    };
  }
  if (defaults?.headers && input?.headers) {
    merged.headers = new Headers(defaults?.headers || {});
    for (const [key, value] of new Headers(input?.headers || {})) {
      merged.headers.set(key, value);
    }
  }
  return merged;
}

const retryStatusCodes = /* @__PURE__ */ new Set([
  408,
  // Request Timeout
  409,
  // Conflict
  425,
  // Too Early
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
  //  Gateway Timeout
]);
const nullBodyResponses$1 = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createFetch$1(globalOptions = {}) {
  const {
    fetch = globalThis.fetch,
    Headers = globalThis.Headers,
    AbortController = globalThis.AbortController
  } = globalOptions;
  async function onError(context) {
    const isAbort = context.error && context.error.name === "AbortError" && !context.options.timeout || false;
    if (context.options.retry !== false && !isAbort) {
      let retries;
      if (typeof context.options.retry === "number") {
        retries = context.options.retry;
      } else {
        retries = isPayloadMethod(context.options.method) ? 0 : 1;
      }
      const responseCode = context.response && context.response.status || 500;
      if (retries > 0 && (Array.isArray(context.options.retryStatusCodes) ? context.options.retryStatusCodes.includes(responseCode) : retryStatusCodes.has(responseCode))) {
        const retryDelay = context.options.retryDelay || 0;
        if (retryDelay > 0) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
        return $fetchRaw(context.request, {
          ...context.options,
          retry: retries - 1,
          timeout: context.options.timeout
        });
      }
    }
    const error = createFetchError(context);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(error, $fetchRaw);
    }
    throw error;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _options = {}) {
    const context = {
      request: _request,
      options: mergeFetchOptions(_options, globalOptions.defaults, Headers),
      response: void 0,
      error: void 0
    };
    context.options.method = context.options.method?.toUpperCase();
    if (context.options.onRequest) {
      await context.options.onRequest(context);
    }
    if (typeof context.request === "string") {
      if (context.options.baseURL) {
        context.request = withBase(context.request, context.options.baseURL);
      }
      if (context.options.query || context.options.params) {
        context.request = withQuery(context.request, {
          ...context.options.params,
          ...context.options.query
        });
      }
    }
    if (context.options.body && isPayloadMethod(context.options.method)) {
      if (isJSONSerializable(context.options.body)) {
        context.options.body = typeof context.options.body === "string" ? context.options.body : JSON.stringify(context.options.body);
        context.options.headers = new Headers(context.options.headers || {});
        if (!context.options.headers.has("content-type")) {
          context.options.headers.set("content-type", "application/json");
        }
        if (!context.options.headers.has("accept")) {
          context.options.headers.set("accept", "application/json");
        }
      } else if (
        // ReadableStream Body
        "pipeTo" in context.options.body && typeof context.options.body.pipeTo === "function" || // Node.js Stream Body
        typeof context.options.body.pipe === "function"
      ) {
        if (!("duplex" in context.options)) {
          context.options.duplex = "half";
        }
      }
    }
    if (!context.options.signal && context.options.timeout) {
      const controller = new AbortController();
      setTimeout(() => controller.abort(), context.options.timeout);
      context.options.signal = controller.signal;
    }
    try {
      context.response = await fetch(
        context.request,
        context.options
      );
    } catch (error) {
      context.error = error;
      if (context.options.onRequestError) {
        await context.options.onRequestError(context);
      }
      return await onError(context);
    }
    const hasBody = context.response.body && !nullBodyResponses$1.has(context.response.status) && context.options.method !== "HEAD";
    if (hasBody) {
      const responseType = (context.options.parseResponse ? "json" : context.options.responseType) || detectResponseType(context.response.headers.get("content-type") || "");
      switch (responseType) {
        case "json": {
          const data = await context.response.text();
          const parseFunction = context.options.parseResponse || destr;
          context.response._data = parseFunction(data);
          break;
        }
        case "stream": {
          context.response._data = context.response.body;
          break;
        }
        default: {
          context.response._data = await context.response[responseType]();
        }
      }
    }
    if (context.options.onResponse) {
      await context.options.onResponse(context);
    }
    if (!context.options.ignoreResponseError && context.response.status >= 400 && context.response.status < 600) {
      if (context.options.onResponseError) {
        await context.options.onResponseError(context);
      }
      return await onError(context);
    }
    return context.response;
  };
  const $fetch = async function $fetch2(request, options) {
    const r = await $fetchRaw(request, options);
    return r._data;
  };
  $fetch.raw = $fetchRaw;
  $fetch.native = (...args) => fetch(...args);
  $fetch.create = (defaultOptions = {}) => createFetch$1({
    ...globalOptions,
    defaults: {
      ...globalOptions.defaults,
      ...defaultOptions
    }
  });
  return $fetch;
}

function createNodeFetch() {
  const useKeepAlive = JSON.parse(process.env.FETCH_KEEP_ALIVE || "false");
  if (!useKeepAlive) {
    return l;
  }
  const agentOptions = { keepAlive: true };
  const httpAgent = new http.Agent(agentOptions);
  const httpsAgent = new https.Agent(agentOptions);
  const nodeFetchOptions = {
    agent(parsedURL) {
      return parsedURL.protocol === "http:" ? httpAgent : httpsAgent;
    }
  };
  return function nodeFetchWithKeepAlive(input, init) {
    return l(input, { ...nodeFetchOptions, ...init });
  };
}
const fetch = globalThis.fetch || createNodeFetch();
const Headers$1 = globalThis.Headers || s;
const AbortController$1 = globalThis.AbortController || i;
const ofetch = createFetch$1({ fetch, Headers: Headers$1, AbortController: AbortController$1 });
const $fetch = ofetch;

const nullBodyResponses = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createCall(handle) {
  return function callHandle(context) {
    const req = new IncomingMessage();
    const res = new ServerResponse(req);
    req.url = context.url || "/";
    req.method = context.method || "GET";
    req.headers = {};
    if (context.headers) {
      const headerEntries = typeof context.headers.entries === "function" ? context.headers.entries() : Object.entries(context.headers);
      for (const [name, value] of headerEntries) {
        if (!value) {
          continue;
        }
        req.headers[name.toLowerCase()] = value;
      }
    }
    req.headers.host = req.headers.host || context.host || "localhost";
    req.connection.encrypted = // @ts-ignore
    req.connection.encrypted || context.protocol === "https";
    req.body = context.body || null;
    req.__unenv__ = context.context;
    return handle(req, res).then(() => {
      let body = res._data;
      if (nullBodyResponses.has(res.statusCode) || req.method.toUpperCase() === "HEAD") {
        body = null;
        delete res._headers["content-length"];
      }
      const r = {
        body,
        headers: res._headers,
        status: res.statusCode,
        statusText: res.statusMessage
      };
      req.destroy();
      res.destroy();
      return r;
    });
  };
}

function createFetch(call, _fetch = global.fetch) {
  return async function ufetch(input, init) {
    const url = input.toString();
    if (!url.startsWith("/")) {
      return _fetch(url, init);
    }
    try {
      const r = await call({ url, ...init });
      return new Response(r.body, {
        status: r.status,
        statusText: r.statusText,
        headers: Object.fromEntries(
          Object.entries(r.headers).map(([name, value]) => [
            name,
            Array.isArray(value) ? value.join(",") : String(value) || ""
          ])
        )
      });
    } catch (error) {
      return new Response(error.toString(), {
        status: Number.parseInt(error.statusCode || error.code) || 500,
        statusText: error.statusText
      });
    }
  };
}

function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
const defaultTask = { run: (function_) => function_() };
const _createTask = () => defaultTask;
const createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce(
    (promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))),
    Promise.resolve()
  );
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}

class Hookable {
  constructor() {
    this._hooks = {};
    this._before = void 0;
    this._after = void 0;
    this._deprecatedMessages = void 0;
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, function_, options = {}) {
    if (!name || typeof function_ !== "function") {
      return () => {
      };
    }
    const originalName = name;
    let dep;
    while (this._deprecatedHooks[name]) {
      dep = this._deprecatedHooks[name];
      name = dep.to;
    }
    if (dep && !options.allowDeprecated) {
      let message = dep.message;
      if (!message) {
        message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
      }
      if (!this._deprecatedMessages) {
        this._deprecatedMessages = /* @__PURE__ */ new Set();
      }
      if (!this._deprecatedMessages.has(message)) {
        console.warn(message);
        this._deprecatedMessages.add(message);
      }
    }
    if (!function_.name) {
      try {
        Object.defineProperty(function_, "name", {
          get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
          configurable: true
        });
      } catch {
      }
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(function_);
    return () => {
      if (function_) {
        this.removeHook(name, function_);
        function_ = void 0;
      }
    };
  }
  hookOnce(name, function_) {
    let _unreg;
    let _function = (...arguments_) => {
      if (typeof _unreg === "function") {
        _unreg();
      }
      _unreg = void 0;
      _function = void 0;
      return function_(...arguments_);
    };
    _unreg = this.hook(name, _function);
    return _unreg;
  }
  removeHook(name, function_) {
    if (this._hooks[name]) {
      const index = this._hooks[name].indexOf(function_);
      if (index !== -1) {
        this._hooks[name].splice(index, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
    const _hooks = this._hooks[name] || [];
    delete this._hooks[name];
    for (const hook of _hooks) {
      this.hook(name, hook);
    }
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
    for (const name in deprecatedHooks) {
      this.deprecateHook(name, deprecatedHooks[name]);
    }
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map(
      (key) => this.hook(key, hooks[key])
    );
    return () => {
      for (const unreg of removeFns.splice(0, removeFns.length)) {
        unreg();
      }
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  removeAllHooks() {
    for (const key in this._hooks) {
      delete this._hooks[key];
    }
  }
  callHook(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(serialTaskCaller, name, ...arguments_);
  }
  callHookParallel(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(parallelTaskCaller, name, ...arguments_);
  }
  callHookWith(caller, name, ...arguments_) {
    const event = this._before || this._after ? { name, args: arguments_, context: {} } : void 0;
    if (this._before) {
      callEachWith(this._before, event);
    }
    const result = caller(
      name in this._hooks ? [...this._hooks[name]] : [],
      arguments_
    );
    if (result instanceof Promise) {
      return result.finally(() => {
        if (this._after && event) {
          callEachWith(this._after, event);
        }
      });
    }
    if (this._after && event) {
      callEachWith(this._after, event);
    }
    return result;
  }
  beforeEach(function_) {
    this._before = this._before || [];
    this._before.push(function_);
    return () => {
      if (this._before !== void 0) {
        const index = this._before.indexOf(function_);
        if (index !== -1) {
          this._before.splice(index, 1);
        }
      }
    };
  }
  afterEach(function_) {
    this._after = this._after || [];
    this._after.push(function_);
    return () => {
      if (this._after !== void 0) {
        const index = this._after.indexOf(function_);
        if (index !== -1) {
          this._after.splice(index, 1);
        }
      }
    };
  }
}
function createHooks() {
  return new Hookable();
}

const NUMBER_CHAR_RE = /\d/;
const STR_SPLITTERS = ["-", "_", "/", "."];
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char)) {
    return void 0;
  }
  return char.toUpperCase() === char;
}
function splitByCase(str, separators) {
  const splitters = separators ?? STR_SPLITTERS;
  const parts = [];
  if (!str || typeof str !== "string") {
    return parts;
  }
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = splitters.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function kebabCase(str, joiner) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => p.toLowerCase()).join(joiner ?? "-") : "";
}
function snakeCase(str) {
  return kebabCase(str || "", "_");
}

function klona(x) {
	if (typeof x !== 'object') return x;

	var k, tmp, str=Object.prototype.toString.call(x);

	if (str === '[object Object]') {
		if (x.constructor !== Object && typeof x.constructor === 'function') {
			tmp = new x.constructor();
			for (k in x) {
				if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
					tmp[k] = klona(x[k]);
				}
			}
		} else {
			tmp = {}; // null
			for (k in x) {
				if (k === '__proto__') {
					Object.defineProperty(tmp, k, {
						value: klona(x[k]),
						configurable: true,
						enumerable: true,
						writable: true,
					});
				} else {
					tmp[k] = klona(x[k]);
				}
			}
		}
		return tmp;
	}

	if (str === '[object Array]') {
		k = x.length;
		for (tmp=Array(k); k--;) {
			tmp[k] = klona(x[k]);
		}
		return tmp;
	}

	if (str === '[object Set]') {
		tmp = new Set;
		x.forEach(function (val) {
			tmp.add(klona(val));
		});
		return tmp;
	}

	if (str === '[object Map]') {
		tmp = new Map;
		x.forEach(function (val, key) {
			tmp.set(klona(key), klona(val));
		});
		return tmp;
	}

	if (str === '[object Date]') {
		return new Date(+x);
	}

	if (str === '[object RegExp]') {
		tmp = new RegExp(x.source, x.flags);
		tmp.lastIndex = x.lastIndex;
		return tmp;
	}

	if (str === '[object DataView]') {
		return new x.constructor( klona(x.buffer) );
	}

	if (str === '[object ArrayBuffer]') {
		return x.slice(0);
	}

	// ArrayBuffer.isView(x)
	// ~> `new` bcuz `Buffer.slice` => ref
	if (str.slice(-6) === 'Array]') {
		return new x.constructor(x);
	}

	return x;
}

const inlineAppConfig = {
  "nuxt": {
    "buildId": "f27a72af-debe-404d-aafc-5b121d36cb1d"
  }
};



const appConfig = defuFn(inlineAppConfig);

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/sitemap.xsl": {
        "headers": {
          "Content-Type": "application/xslt+xml"
        }
      },
      "/sitemap.xml": {
        "swr": 600,
        "cache": {
          "varies": [
            "X-Forwarded-Host",
            "X-Forwarded-Proto",
            "Host"
          ],
          "swr": true,
          "maxAge": 600
        }
      },
      "/_nuxt/builds/meta/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/builds/**": {
        "headers": {
          "cache-control": "public, max-age=1, immutable"
        }
      },
      "/_nuxt/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      }
    }
  },
  "public": {
    "API_BASE_URL": "https://dev.gateway.matta.trade/api/",
    "APP_MONNIFYAPIKEY": "8FCBCRUJ2V1Z1L3WEP8MVAU3NWW10GR8",
    "APP_MONNIFYCONTRACTCODE": "3626165521",
    "APP_MONNIFYISTEST": "MK_TEST_U7NMPWUT9C",
    "APP_MONNIFYISTESTMODE": "true",
    "googleSignIn": {
      "clientId": "56799988480-4d51egljupar9la4djc2tknjodn2vsj5.apps.googleusercontent.com"
    },
    "persistedState": {
      "storage": "cookies",
      "debug": false,
      "cookieOptions": {}
    }
  },
  "nuxt-simple-sitemap": {
    "isI18nMapped": false,
    "sitemapName": "sitemap.xml",
    "isMultiSitemap": false,
    "excludeAppSources": [],
    "autoLastmod": false,
    "defaultSitemapsChunkSize": 1000,
    "sortEntries": true,
    "debug": false,
    "discoverImages": true,
    "isNuxtContentDocumentDriven": false,
    "xsl": "/__sitemap__/style.xsl",
    "xslTips": true,
    "xslColumns": [
      {
        "label": "URL",
        "width": "50%"
      },
      {
        "label": "Images",
        "width": "25%",
        "select": "count(image:image)"
      },
      {
        "label": "Last Updated",
        "width": "25%",
        "select": "concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)),concat(' ', substring(sitemap:lastmod,20,6)))"
      }
    ],
    "credits": true,
    "version": "4.2.1",
    "sitemaps": {
      "sitemap.xml": {
        "sitemapName": "sitemap.xml",
        "route": "sitemap.xml",
        "defaults": {},
        "include": [],
        "exclude": [
          "/_nuxt/**",
          "/api/**"
        ],
        "includeAppSources": true
      }
    }
  },
  "nuxt-site-config": {
    "stack": [
      {
        "_context": "system",
        "_priority": -15,
        "name": "Matta",
        "env": "production"
      },
      {
        "_context": "package.json",
        "_priority": -10,
        "name": "nuxt-app"
      },
      {
        "_priority": -3,
        "_context": "nuxt-site-config:config",
        "url": "https://matta.trade"
      }
    ],
    "version": "2.1.1",
    "debug": false
  },
  "ipx": {
    "baseURL": "/_ipx",
    "alias": {},
    "fs": {
      "dir": "../public"
    },
    "http": {
      "domains": []
    }
  }
};
const ENV_PREFIX = "NITRO_";
const ENV_PREFIX_ALT = _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_";
const _sharedRuntimeConfig = _deepFreeze(
  _applyEnv(klona(_inlineRuntimeConfig))
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  _applyEnv(runtimeConfig);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
const _sharedAppConfig = _deepFreeze(klona(appConfig));
function useAppConfig(event) {
  if (!event) {
    return _sharedAppConfig;
  }
  if (event.context.nitro.appConfig) {
    return event.context.nitro.appConfig;
  }
  const appConfig$1 = klona(appConfig);
  event.context.nitro.appConfig = appConfig$1;
  return appConfig$1;
}
function _getEnv(key) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[ENV_PREFIX + envKey] ?? process.env[ENV_PREFIX_ALT + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function _applyEnv(obj, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = _getEnv(subKey);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
      }
      _applyEnv(obj[key], subKey);
    } else {
      obj[key] = envValue ?? obj[key];
    }
  }
  return obj;
}
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

const defaults = Object.freeze({
  ignoreUnknown: false,
  respectType: false,
  respectFunctionNames: false,
  respectFunctionProperties: false,
  unorderedObjects: true,
  unorderedArrays: false,
  unorderedSets: false,
  excludeKeys: void 0,
  excludeValues: void 0,
  replacer: void 0
});
function objectHash(object, options) {
  if (options) {
    options = { ...defaults, ...options };
  } else {
    options = defaults;
  }
  const hasher = createHasher(options);
  hasher.dispatch(object);
  return hasher.toString();
}
const defaultPrototypesKeys = Object.freeze([
  "prototype",
  "__proto__",
  "constructor"
]);
function createHasher(options) {
  let buff = "";
  let context = /* @__PURE__ */ new Map();
  const write = (str) => {
    buff += str;
  };
  return {
    toString() {
      return buff;
    },
    getContext() {
      return context;
    },
    dispatch(value) {
      if (options.replacer) {
        value = options.replacer(value);
      }
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    },
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      if (objectLength < 10) {
        objType = "unknown:[" + objString + "]";
      } else {
        objType = objString.slice(8, objectLength - 1);
      }
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = context.get(object)) === void 0) {
        context.set(object, context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        write("buffer:");
        return write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else if (!options.ignoreUnknown) {
          this.unkown(object, objType);
        }
      } else {
        let keys = Object.keys(object);
        if (options.unorderedObjects) {
          keys = keys.sort();
        }
        let extraKeys = [];
        if (options.respectType !== false && !isNativeFunction(object)) {
          extraKeys = defaultPrototypesKeys;
        }
        if (options.excludeKeys) {
          keys = keys.filter((key) => {
            return !options.excludeKeys(key);
          });
          extraKeys = extraKeys.filter((key) => {
            return !options.excludeKeys(key);
          });
        }
        write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          write(":");
          if (!options.excludeValues) {
            this.dispatch(object[key]);
          }
          write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    },
    array(arr, unordered) {
      unordered = unordered === void 0 ? options.unorderedArrays !== false : unordered;
      write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = createHasher(options);
        hasher.dispatch(entry);
        for (const [key, value] of hasher.getContext()) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    },
    date(date) {
      return write("date:" + date.toJSON());
    },
    symbol(sym) {
      return write("symbol:" + sym.toString());
    },
    unkown(value, type) {
      write(type);
      if (!value) {
        return;
      }
      write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          Array.from(value.entries()),
          true
          /* ordered */
        );
      }
    },
    error(err) {
      return write("error:" + err.toString());
    },
    boolean(bool) {
      return write("bool:" + bool);
    },
    string(string) {
      write("string:" + string.length + ":");
      write(string);
    },
    function(fn) {
      write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
      if (options.respectFunctionNames !== false) {
        this.dispatch("function-name:" + String(fn.name));
      }
      if (options.respectFunctionProperties) {
        this.object(fn);
      }
    },
    number(number) {
      return write("number:" + number);
    },
    xml(xml) {
      return write("xml:" + xml.toString());
    },
    null() {
      return write("Null");
    },
    undefined() {
      return write("Undefined");
    },
    regexp(regex) {
      return write("regex:" + regex.toString());
    },
    uint8array(arr) {
      write("uint8array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    uint8clampedarray(arr) {
      write("uint8clampedarray:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    int8array(arr) {
      write("int8array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    uint16array(arr) {
      write("uint16array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    int16array(arr) {
      write("int16array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    uint32array(arr) {
      write("uint32array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    int32array(arr) {
      write("int32array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    float32array(arr) {
      write("float32array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    float64array(arr) {
      write("float64array:");
      return this.dispatch(Array.prototype.slice.call(arr));
    },
    arraybuffer(arr) {
      write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    },
    url(url) {
      return write("url:" + url.toString());
    },
    map(map) {
      write("map:");
      const arr = [...map];
      return this.array(arr, options.unorderedSets !== false);
    },
    set(set) {
      write("set:");
      const arr = [...set];
      return this.array(arr, options.unorderedSets !== false);
    },
    file(file) {
      write("file:");
      return this.dispatch([file.name, file.size, file.type, file.lastModfied]);
    },
    blob() {
      if (options.ignoreUnknown) {
        return write("[blob]");
      }
      throw new Error(
        'Hashing Blob objects is currently not supported\nUse "options.replacer" or "options.ignoreUnknown"\n'
      );
    },
    domwindow() {
      return write("domwindow");
    },
    bigint(number) {
      return write("bigint:" + number.toString());
    },
    /* Node.js standard native objects */
    process() {
      return write("process");
    },
    timer() {
      return write("timer");
    },
    pipe() {
      return write("pipe");
    },
    tcp() {
      return write("tcp");
    },
    udp() {
      return write("udp");
    },
    tty() {
      return write("tty");
    },
    statwatcher() {
      return write("statwatcher");
    },
    securecontext() {
      return write("securecontext");
    },
    connection() {
      return write("connection");
    },
    zlib() {
      return write("zlib");
    },
    context() {
      return write("context");
    },
    nodescript() {
      return write("nodescript");
    },
    httpparser() {
      return write("httpparser");
    },
    dataview() {
      return write("dataview");
    },
    signal() {
      return write("signal");
    },
    fsevent() {
      return write("fsevent");
    },
    tlswrap() {
      return write("tlswrap");
    }
  };
}
const nativeFunc = "[native code] }";
const nativeFuncLength = nativeFunc.length;
function isNativeFunction(f) {
  if (typeof f !== "function") {
    return false;
  }
  return Function.prototype.toString.call(f).slice(-nativeFuncLength) === nativeFunc;
}

class WordArray {
  constructor(words, sigBytes) {
    words = this.words = words || [];
    this.sigBytes = sigBytes === void 0 ? words.length * 4 : sigBytes;
  }
  toString(encoder) {
    return (encoder || Hex).stringify(this);
  }
  concat(wordArray) {
    this.clamp();
    if (this.sigBytes % 4) {
      for (let i = 0; i < wordArray.sigBytes; i++) {
        const thatByte = wordArray.words[i >>> 2] >>> 24 - i % 4 * 8 & 255;
        this.words[this.sigBytes + i >>> 2] |= thatByte << 24 - (this.sigBytes + i) % 4 * 8;
      }
    } else {
      for (let j = 0; j < wordArray.sigBytes; j += 4) {
        this.words[this.sigBytes + j >>> 2] = wordArray.words[j >>> 2];
      }
    }
    this.sigBytes += wordArray.sigBytes;
    return this;
  }
  clamp() {
    this.words[this.sigBytes >>> 2] &= 4294967295 << 32 - this.sigBytes % 4 * 8;
    this.words.length = Math.ceil(this.sigBytes / 4);
  }
  clone() {
    return new WordArray([...this.words]);
  }
}
const Hex = {
  stringify(wordArray) {
    const hexChars = [];
    for (let i = 0; i < wordArray.sigBytes; i++) {
      const bite = wordArray.words[i >>> 2] >>> 24 - i % 4 * 8 & 255;
      hexChars.push((bite >>> 4).toString(16), (bite & 15).toString(16));
    }
    return hexChars.join("");
  }
};
const Base64 = {
  stringify(wordArray) {
    const keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    const base64Chars = [];
    for (let i = 0; i < wordArray.sigBytes; i += 3) {
      const byte1 = wordArray.words[i >>> 2] >>> 24 - i % 4 * 8 & 255;
      const byte2 = wordArray.words[i + 1 >>> 2] >>> 24 - (i + 1) % 4 * 8 & 255;
      const byte3 = wordArray.words[i + 2 >>> 2] >>> 24 - (i + 2) % 4 * 8 & 255;
      const triplet = byte1 << 16 | byte2 << 8 | byte3;
      for (let j = 0; j < 4 && i * 8 + j * 6 < wordArray.sigBytes * 8; j++) {
        base64Chars.push(keyStr.charAt(triplet >>> 6 * (3 - j) & 63));
      }
    }
    return base64Chars.join("");
  }
};
const Latin1 = {
  parse(latin1Str) {
    const latin1StrLength = latin1Str.length;
    const words = [];
    for (let i = 0; i < latin1StrLength; i++) {
      words[i >>> 2] |= (latin1Str.charCodeAt(i) & 255) << 24 - i % 4 * 8;
    }
    return new WordArray(words, latin1StrLength);
  }
};
const Utf8 = {
  parse(utf8Str) {
    return Latin1.parse(unescape(encodeURIComponent(utf8Str)));
  }
};
class BufferedBlockAlgorithm {
  constructor() {
    this._data = new WordArray();
    this._nDataBytes = 0;
    this._minBufferSize = 0;
    this.blockSize = 512 / 32;
  }
  reset() {
    this._data = new WordArray();
    this._nDataBytes = 0;
  }
  _append(data) {
    if (typeof data === "string") {
      data = Utf8.parse(data);
    }
    this._data.concat(data);
    this._nDataBytes += data.sigBytes;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  _doProcessBlock(_dataWords, _offset) {
  }
  _process(doFlush) {
    let processedWords;
    let nBlocksReady = this._data.sigBytes / (this.blockSize * 4);
    if (doFlush) {
      nBlocksReady = Math.ceil(nBlocksReady);
    } else {
      nBlocksReady = Math.max((nBlocksReady | 0) - this._minBufferSize, 0);
    }
    const nWordsReady = nBlocksReady * this.blockSize;
    const nBytesReady = Math.min(nWordsReady * 4, this._data.sigBytes);
    if (nWordsReady) {
      for (let offset = 0; offset < nWordsReady; offset += this.blockSize) {
        this._doProcessBlock(this._data.words, offset);
      }
      processedWords = this._data.words.splice(0, nWordsReady);
      this._data.sigBytes -= nBytesReady;
    }
    return new WordArray(processedWords, nBytesReady);
  }
}
class Hasher extends BufferedBlockAlgorithm {
  update(messageUpdate) {
    this._append(messageUpdate);
    this._process();
    return this;
  }
  finalize(messageUpdate) {
    if (messageUpdate) {
      this._append(messageUpdate);
    }
  }
}

const H = [
  1779033703,
  -1150833019,
  1013904242,
  -1521486534,
  1359893119,
  -1694144372,
  528734635,
  1541459225
];
const K = [
  1116352408,
  1899447441,
  -1245643825,
  -373957723,
  961987163,
  1508970993,
  -1841331548,
  -1424204075,
  -670586216,
  310598401,
  607225278,
  1426881987,
  1925078388,
  -2132889090,
  -1680079193,
  -1046744716,
  -459576895,
  -272742522,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  -1740746414,
  -1473132947,
  -1341970488,
  -1084653625,
  -958395405,
  -710438585,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  -2117940946,
  -1838011259,
  -1564481375,
  -1474664885,
  -1035236496,
  -949202525,
  -778901479,
  -694614492,
  -200395387,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  -2067236844,
  -1933114872,
  -1866530822,
  -1538233109,
  -1090935817,
  -965641998
];
const W = [];
class SHA256 extends Hasher {
  constructor() {
    super(...arguments);
    this._hash = new WordArray([...H]);
  }
  reset() {
    super.reset();
    this._hash = new WordArray([...H]);
  }
  _doProcessBlock(M, offset) {
    const H2 = this._hash.words;
    let a = H2[0];
    let b = H2[1];
    let c = H2[2];
    let d = H2[3];
    let e = H2[4];
    let f = H2[5];
    let g = H2[6];
    let h = H2[7];
    for (let i = 0; i < 64; i++) {
      if (i < 16) {
        W[i] = M[offset + i] | 0;
      } else {
        const gamma0x = W[i - 15];
        const gamma0 = (gamma0x << 25 | gamma0x >>> 7) ^ (gamma0x << 14 | gamma0x >>> 18) ^ gamma0x >>> 3;
        const gamma1x = W[i - 2];
        const gamma1 = (gamma1x << 15 | gamma1x >>> 17) ^ (gamma1x << 13 | gamma1x >>> 19) ^ gamma1x >>> 10;
        W[i] = gamma0 + W[i - 7] + gamma1 + W[i - 16];
      }
      const ch = e & f ^ ~e & g;
      const maj = a & b ^ a & c ^ b & c;
      const sigma0 = (a << 30 | a >>> 2) ^ (a << 19 | a >>> 13) ^ (a << 10 | a >>> 22);
      const sigma1 = (e << 26 | e >>> 6) ^ (e << 21 | e >>> 11) ^ (e << 7 | e >>> 25);
      const t1 = h + sigma1 + ch + K[i] + W[i];
      const t2 = sigma0 + maj;
      h = g;
      g = f;
      f = e;
      e = d + t1 | 0;
      d = c;
      c = b;
      b = a;
      a = t1 + t2 | 0;
    }
    H2[0] = H2[0] + a | 0;
    H2[1] = H2[1] + b | 0;
    H2[2] = H2[2] + c | 0;
    H2[3] = H2[3] + d | 0;
    H2[4] = H2[4] + e | 0;
    H2[5] = H2[5] + f | 0;
    H2[6] = H2[6] + g | 0;
    H2[7] = H2[7] + h | 0;
  }
  finalize(messageUpdate) {
    super.finalize(messageUpdate);
    const nBitsTotal = this._nDataBytes * 8;
    const nBitsLeft = this._data.sigBytes * 8;
    this._data.words[nBitsLeft >>> 5] |= 128 << 24 - nBitsLeft % 32;
    this._data.words[(nBitsLeft + 64 >>> 9 << 4) + 14] = Math.floor(
      nBitsTotal / 4294967296
    );
    this._data.words[(nBitsLeft + 64 >>> 9 << 4) + 15] = nBitsTotal;
    this._data.sigBytes = this._data.words.length * 4;
    this._process();
    return this._hash;
  }
}
function sha256base64(message) {
  return new SHA256().finalize(message).toString(Base64);
}

function hash(object, options = {}) {
  const hashed = typeof object === "string" ? object : objectHash(object, options);
  return sha256base64(hashed).slice(0, 10);
}

function isEqual(object1, object2, hashOptions = {}) {
  if (object1 === object2) {
    return true;
  }
  if (objectHash(object1, hashOptions) === objectHash(object2, hashOptions)) {
    return true;
  }
  return false;
}

function wrapToPromise(value) {
  if (!value || typeof value.then !== "function") {
    return Promise.resolve(value);
  }
  return value;
}
function asyncCall(function_, ...arguments_) {
  try {
    return wrapToPromise(function_(...arguments_));
  } catch (error) {
    return Promise.reject(error);
  }
}
function isPrimitive$1(value) {
  const type = typeof value;
  return value === null || type !== "object" && type !== "function";
}
function isPureObject(value) {
  const proto = Object.getPrototypeOf(value);
  return !proto || proto.isPrototypeOf(Object);
}
function stringify(value) {
  if (isPrimitive$1(value)) {
    return String(value);
  }
  if (isPureObject(value) || Array.isArray(value)) {
    return JSON.stringify(value);
  }
  if (typeof value.toJSON === "function") {
    return stringify(value.toJSON());
  }
  throw new Error("[unstorage] Cannot stringify value!");
}
function checkBufferSupport() {
  if (typeof Buffer === void 0) {
    throw new TypeError("[unstorage] Buffer is not supported!");
  }
}
const BASE64_PREFIX = "base64:";
function serializeRaw(value) {
  if (typeof value === "string") {
    return value;
  }
  checkBufferSupport();
  const base64 = Buffer.from(value).toString("base64");
  return BASE64_PREFIX + base64;
}
function deserializeRaw(value) {
  if (typeof value !== "string") {
    return value;
  }
  if (!value.startsWith(BASE64_PREFIX)) {
    return value;
  }
  checkBufferSupport();
  return Buffer.from(value.slice(BASE64_PREFIX.length), "base64");
}

const storageKeyProperties = [
  "hasItem",
  "getItem",
  "getItemRaw",
  "setItem",
  "setItemRaw",
  "removeItem",
  "getMeta",
  "setMeta",
  "removeMeta",
  "getKeys",
  "clear",
  "mount",
  "unmount"
];
function prefixStorage(storage, base) {
  base = normalizeBaseKey(base);
  if (!base) {
    return storage;
  }
  const nsStorage = { ...storage };
  for (const property of storageKeyProperties) {
    nsStorage[property] = (key = "", ...args) => (
      // @ts-ignore
      storage[property](base + key, ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  return nsStorage;
}
function normalizeKey$1(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0].replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "");
}
function joinKeys(...keys) {
  return normalizeKey$1(keys.join(":"));
}
function normalizeBaseKey(base) {
  base = normalizeKey$1(base);
  return base ? base + ":" : "";
}

function defineDriver$1(factory) {
  return factory;
}

const DRIVER_NAME$1 = "memory";
const memory = defineDriver$1(() => {
  const data = /* @__PURE__ */ new Map();
  return {
    name: DRIVER_NAME$1,
    options: {},
    hasItem(key) {
      return data.has(key);
    },
    getItem(key) {
      return data.get(key) ?? null;
    },
    getItemRaw(key) {
      return data.get(key) ?? null;
    },
    setItem(key, value) {
      data.set(key, value);
    },
    setItemRaw(key, value) {
      data.set(key, value);
    },
    removeItem(key) {
      data.delete(key);
    },
    getKeys() {
      return Array.from(data.keys());
    },
    clear() {
      data.clear();
    },
    dispose() {
      data.clear();
    }
  };
});

function createStorage(options = {}) {
  const context = {
    mounts: { "": options.driver || memory() },
    mountpoints: [""],
    watching: false,
    watchListeners: [],
    unwatch: {}
  };
  const getMount = (key) => {
    for (const base of context.mountpoints) {
      if (key.startsWith(base)) {
        return {
          base,
          relativeKey: key.slice(base.length),
          driver: context.mounts[base]
        };
      }
    }
    return {
      base: "",
      relativeKey: key,
      driver: context.mounts[""]
    };
  };
  const getMounts = (base, includeParent) => {
    return context.mountpoints.filter(
      (mountpoint) => mountpoint.startsWith(base) || includeParent && base.startsWith(mountpoint)
    ).map((mountpoint) => ({
      relativeBase: base.length > mountpoint.length ? base.slice(mountpoint.length) : void 0,
      mountpoint,
      driver: context.mounts[mountpoint]
    }));
  };
  const onChange = (event, key) => {
    if (!context.watching) {
      return;
    }
    key = normalizeKey$1(key);
    for (const listener of context.watchListeners) {
      listener(event, key);
    }
  };
  const startWatch = async () => {
    if (context.watching) {
      return;
    }
    context.watching = true;
    for (const mountpoint in context.mounts) {
      context.unwatch[mountpoint] = await watch(
        context.mounts[mountpoint],
        onChange,
        mountpoint
      );
    }
  };
  const stopWatch = async () => {
    if (!context.watching) {
      return;
    }
    for (const mountpoint in context.unwatch) {
      await context.unwatch[mountpoint]();
    }
    context.unwatch = {};
    context.watching = false;
  };
  const runBatch = (items, commonOptions, cb) => {
    const batches = /* @__PURE__ */ new Map();
    const getBatch = (mount) => {
      let batch = batches.get(mount.base);
      if (!batch) {
        batch = {
          driver: mount.driver,
          base: mount.base,
          items: []
        };
        batches.set(mount.base, batch);
      }
      return batch;
    };
    for (const item of items) {
      const isStringItem = typeof item === "string";
      const key = normalizeKey$1(isStringItem ? item : item.key);
      const value = isStringItem ? void 0 : item.value;
      const options2 = isStringItem || !item.options ? commonOptions : { ...commonOptions, ...item.options };
      const mount = getMount(key);
      getBatch(mount).items.push({
        key,
        value,
        relativeKey: mount.relativeKey,
        options: options2
      });
    }
    return Promise.all([...batches.values()].map((batch) => cb(batch))).then(
      (r) => r.flat()
    );
  };
  const storage = {
    // Item
    hasItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.hasItem, relativeKey, opts);
    },
    getItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => destr(value)
      );
    },
    getItems(items, commonOptions) {
      return runBatch(items, commonOptions, (batch) => {
        if (batch.driver.getItems) {
          return asyncCall(
            batch.driver.getItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              options: item.options
            })),
            commonOptions
          ).then(
            (r) => r.map((item) => ({
              key: joinKeys(batch.base, item.key),
              value: destr(item.value)
            }))
          );
        }
        return Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.getItem,
              item.relativeKey,
              item.options
            ).then((value) => ({
              key: item.key,
              value: destr(value)
            }));
          })
        );
      });
    },
    getItemRaw(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.getItemRaw) {
        return asyncCall(driver.getItemRaw, relativeKey, opts);
      }
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => deserializeRaw(value)
      );
    },
    async setItem(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.setItem) {
        return;
      }
      await asyncCall(driver.setItem, relativeKey, stringify(value), opts);
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async setItems(items, commonOptions) {
      await runBatch(items, commonOptions, async (batch) => {
        if (batch.driver.setItems) {
          await asyncCall(
            batch.driver.setItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              value: stringify(item.value),
              options: item.options
            })),
            commonOptions
          );
        }
        if (!batch.driver.setItem) {
          return;
        }
        await Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.setItem,
              item.relativeKey,
              stringify(item.value),
              item.options
            );
          })
        );
      });
    },
    async setItemRaw(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key, opts);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.setItemRaw) {
        await asyncCall(driver.setItemRaw, relativeKey, value, opts);
      } else if (driver.setItem) {
        await asyncCall(driver.setItem, relativeKey, serializeRaw(value), opts);
      } else {
        return;
      }
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async removeItem(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { removeMeta: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.removeItem) {
        return;
      }
      await asyncCall(driver.removeItem, relativeKey, opts);
      if (opts.removeMeta || opts.removeMata) {
        await asyncCall(driver.removeItem, relativeKey + "$", opts);
      }
      if (!driver.watch) {
        onChange("remove", key);
      }
    },
    // Meta
    async getMeta(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { nativeOnly: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      const meta = /* @__PURE__ */ Object.create(null);
      if (driver.getMeta) {
        Object.assign(meta, await asyncCall(driver.getMeta, relativeKey, opts));
      }
      if (!opts.nativeOnly) {
        const value = await asyncCall(
          driver.getItem,
          relativeKey + "$",
          opts
        ).then((value_) => destr(value_));
        if (value && typeof value === "object") {
          if (typeof value.atime === "string") {
            value.atime = new Date(value.atime);
          }
          if (typeof value.mtime === "string") {
            value.mtime = new Date(value.mtime);
          }
          Object.assign(meta, value);
        }
      }
      return meta;
    },
    setMeta(key, value, opts = {}) {
      return this.setItem(key + "$", value, opts);
    },
    removeMeta(key, opts = {}) {
      return this.removeItem(key + "$", opts);
    },
    // Keys
    async getKeys(base, opts = {}) {
      base = normalizeBaseKey(base);
      const mounts = getMounts(base, true);
      let maskedMounts = [];
      const allKeys = [];
      for (const mount of mounts) {
        const rawKeys = await asyncCall(
          mount.driver.getKeys,
          mount.relativeBase,
          opts
        );
        const keys = rawKeys.map((key) => mount.mountpoint + normalizeKey$1(key)).filter((key) => !maskedMounts.some((p) => key.startsWith(p)));
        allKeys.push(...keys);
        maskedMounts = [
          mount.mountpoint,
          ...maskedMounts.filter((p) => !p.startsWith(mount.mountpoint))
        ];
      }
      return base ? allKeys.filter((key) => key.startsWith(base) && !key.endsWith("$")) : allKeys.filter((key) => !key.endsWith("$"));
    },
    // Utils
    async clear(base, opts = {}) {
      base = normalizeBaseKey(base);
      await Promise.all(
        getMounts(base, false).map(async (m) => {
          if (m.driver.clear) {
            return asyncCall(m.driver.clear, m.relativeBase, opts);
          }
          if (m.driver.removeItem) {
            const keys = await m.driver.getKeys(m.relativeBase || "", opts);
            return Promise.all(
              keys.map((key) => m.driver.removeItem(key, opts))
            );
          }
        })
      );
    },
    async dispose() {
      await Promise.all(
        Object.values(context.mounts).map((driver) => dispose(driver))
      );
    },
    async watch(callback) {
      await startWatch();
      context.watchListeners.push(callback);
      return async () => {
        context.watchListeners = context.watchListeners.filter(
          (listener) => listener !== callback
        );
        if (context.watchListeners.length === 0) {
          await stopWatch();
        }
      };
    },
    async unwatch() {
      context.watchListeners = [];
      await stopWatch();
    },
    // Mount
    mount(base, driver) {
      base = normalizeBaseKey(base);
      if (base && context.mounts[base]) {
        throw new Error(`already mounted at ${base}`);
      }
      if (base) {
        context.mountpoints.push(base);
        context.mountpoints.sort((a, b) => b.length - a.length);
      }
      context.mounts[base] = driver;
      if (context.watching) {
        Promise.resolve(watch(driver, onChange, base)).then((unwatcher) => {
          context.unwatch[base] = unwatcher;
        }).catch(console.error);
      }
      return storage;
    },
    async unmount(base, _dispose = true) {
      base = normalizeBaseKey(base);
      if (!base || !context.mounts[base]) {
        return;
      }
      if (context.watching && base in context.unwatch) {
        context.unwatch[base]();
        delete context.unwatch[base];
      }
      if (_dispose) {
        await dispose(context.mounts[base]);
      }
      context.mountpoints = context.mountpoints.filter((key) => key !== base);
      delete context.mounts[base];
    },
    getMount(key = "") {
      key = normalizeKey$1(key) + ":";
      const m = getMount(key);
      return {
        driver: m.driver,
        base: m.base
      };
    },
    getMounts(base = "", opts = {}) {
      base = normalizeKey$1(base);
      const mounts = getMounts(base, opts.parents);
      return mounts.map((m) => ({
        driver: m.driver,
        base: m.mountpoint
      }));
    }
  };
  return storage;
}
function watch(driver, onChange, base) {
  return driver.watch ? driver.watch((event, key) => onChange(event, base + key)) : () => {
  };
}
async function dispose(driver) {
  if (typeof driver.dispose === "function") {
    await asyncCall(driver.dispose);
  }
}

const _assets = {

};

const normalizeKey = function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0].replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "");
};

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

function defineDriver(factory) {
  return factory;
}
function createError(driver, message, opts) {
  const err = new Error(`[unstorage] [${driver}] ${message}`, opts);
  return err;
}
function createRequiredError(driver, name) {
  if (Array.isArray(name)) {
    return createError(
      driver,
      `Missing some of the required options ${name.map((n) => "`" + n + "`").join(", ")}`
    );
  }
  return createError(driver, `Missing required option \`${name}\`.`);
}

function ignoreNotfound(err) {
  return err.code === "ENOENT" || err.code === "EISDIR" ? null : err;
}
function ignoreExists(err) {
  return err.code === "EEXIST" ? null : err;
}
async function writeFile(path, data, encoding) {
  await ensuredir(dirname$1(path));
  return promises.writeFile(path, data, encoding);
}
function readFile(path, encoding) {
  return promises.readFile(path, encoding).catch(ignoreNotfound);
}
function unlink(path) {
  return promises.unlink(path).catch(ignoreNotfound);
}
function readdir(dir) {
  return promises.readdir(dir, { withFileTypes: true }).catch(ignoreNotfound).then((r) => r || []);
}
async function ensuredir(dir) {
  if (existsSync(dir)) {
    return;
  }
  await ensuredir(dirname$1(dir)).catch(ignoreExists);
  await promises.mkdir(dir).catch(ignoreExists);
}
async function readdirRecursive(dir, ignore) {
  if (ignore && ignore(dir)) {
    return [];
  }
  const entries = await readdir(dir);
  const files = [];
  await Promise.all(
    entries.map(async (entry) => {
      const entryPath = resolve$2(dir, entry.name);
      if (entry.isDirectory()) {
        const dirFiles = await readdirRecursive(entryPath, ignore);
        files.push(...dirFiles.map((f) => entry.name + "/" + f));
      } else {
        if (!(ignore && ignore(entry.name))) {
          files.push(entry.name);
        }
      }
    })
  );
  return files;
}
async function rmRecursive(dir) {
  const entries = await readdir(dir);
  await Promise.all(
    entries.map((entry) => {
      const entryPath = resolve$2(dir, entry.name);
      if (entry.isDirectory()) {
        return rmRecursive(entryPath).then(() => promises.rmdir(entryPath));
      } else {
        return promises.unlink(entryPath);
      }
    })
  );
}

const PATH_TRAVERSE_RE = /\.\.\:|\.\.$/;
const DRIVER_NAME = "fs-lite";
const unstorage_47drivers_47fs_45lite = defineDriver((opts = {}) => {
  if (!opts.base) {
    throw createRequiredError(DRIVER_NAME, "base");
  }
  opts.base = resolve$2(opts.base);
  const r = (key) => {
    if (PATH_TRAVERSE_RE.test(key)) {
      throw createError(
        DRIVER_NAME,
        `Invalid key: ${JSON.stringify(key)}. It should not contain .. segments`
      );
    }
    const resolved = join(opts.base, key.replace(/:/g, "/"));
    return resolved;
  };
  return {
    name: DRIVER_NAME,
    options: opts,
    hasItem(key) {
      return existsSync(r(key));
    },
    getItem(key) {
      return readFile(r(key), "utf8");
    },
    getItemRaw(key) {
      return readFile(r(key));
    },
    async getMeta(key) {
      const { atime, mtime, size, birthtime, ctime } = await promises.stat(r(key)).catch(() => ({}));
      return { atime, mtime, size, birthtime, ctime };
    },
    setItem(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value, "utf8");
    },
    setItemRaw(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value);
    },
    removeItem(key) {
      if (opts.readOnly) {
        return;
      }
      return unlink(r(key));
    },
    getKeys() {
      return readdirRecursive(r("."), opts.ignore);
    },
    async clear() {
      if (opts.readOnly || opts.noClear) {
        return;
      }
      await rmRecursive(r("."));
    }
  };
});

const storage = createStorage({});

storage.mount('/assets', assets$1);

storage.mount('data', unstorage_47drivers_47fs_45lite({"driver":"fsLite","base":"/Users/user/Documents/GitHub/Matta/.data/kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

const defaultCacheOptions = {
  name: "_",
  base: "/cache",
  swr: true,
  maxAge: 1
};
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions, ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    const entry = await useStorage().getItem(cacheKey) || {};
    const ttl = (opts.maxAge ?? opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          const promise = useStorage().setItem(cacheKey, entry).catch((error) => {
            console.error(`[nitro] [cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event && event.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[nitro] [cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
const cachedFunction = defineCachedFunction;
function getKey(...args) {
  return args.length > 0 ? hash(args, {}) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      const _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        variableHeaders[header] = incomingEvent.node.req.headers[header];
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            for (const header in headers2) {
              this.setHeader(header, headers2[header]);
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.context = incomingEvent.context;
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(event);
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        event.node.res.setHeader(name, value);
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

function hasReqHeader(event, name, includes) {
  const value = getRequestHeader(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}
function isJsonRequest(event) {
  if (hasReqHeader(event, "accept", "text/html")) {
    return false;
  }
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function normalizeError(error) {
  const cwd = typeof process.cwd === "function" ? process.cwd() : "/";
  const stack = (error.stack || "").split("\n").splice(1).filter((line) => line.includes("at ")).map((line) => {
    const text = line.replace(cwd + "/", "./").replace("webpack:/", "").replace("file://", "").trim();
    return {
      text,
      internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
    };
  });
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage ?? (statusCode === 404 ? "Not Found" : "");
  const message = error.message || error.toString();
  return {
    stack,
    statusCode,
    statusMessage,
    message
  };
}
function _captureError(error, type) {
  console.error(`[nitro] [${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter$1({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      return sendRedirect(
        event,
        routeRules.redirect.to,
        routeRules.redirect.statusCode
      );
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$";
const unsafeChars = /[<>\b\f\n\r\t\0\u2028\u2029]/g;
const reserved = /^(?:do|if|in|for|int|let|new|try|var|byte|case|char|else|enum|goto|long|this|void|with|await|break|catch|class|const|final|float|short|super|throw|while|yield|delete|double|export|import|native|return|switch|throws|typeof|boolean|default|extends|finally|package|private|abstract|continue|debugger|function|volatile|interface|protected|transient|implements|instanceof|synchronized)$/;
const escaped = {
  "<": "\\u003C",
  ">": "\\u003E",
  "/": "\\u002F",
  "\\": "\\\\",
  "\b": "\\b",
  "\f": "\\f",
  "\n": "\\n",
  "\r": "\\r",
  "	": "\\t",
  "\0": "\\0",
  "\u2028": "\\u2028",
  "\u2029": "\\u2029"
};
const objectProtoOwnPropertyNames = Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
function devalue(value) {
  const counts = /* @__PURE__ */ new Map();
  let logNum = 0;
  function log(message) {
    if (logNum < 100) {
      console.warn(message);
      logNum += 1;
    }
  }
  function walk(thing) {
    if (typeof thing === "function") {
      log(`Cannot stringify a function ${thing.name}`);
      return;
    }
    if (counts.has(thing)) {
      counts.set(thing, counts.get(thing) + 1);
      return;
    }
    counts.set(thing, 1);
    if (!isPrimitive(thing)) {
      const type = getType(thing);
      switch (type) {
        case "Number":
        case "String":
        case "Boolean":
        case "Date":
        case "RegExp":
          return;
        case "Array":
          thing.forEach(walk);
          break;
        case "Set":
        case "Map":
          Array.from(thing).forEach(walk);
          break;
        default:
          const proto = Object.getPrototypeOf(thing);
          if (proto !== Object.prototype && proto !== null && Object.getOwnPropertyNames(proto).sort().join("\0") !== objectProtoOwnPropertyNames) {
            if (typeof thing.toJSON !== "function") {
              log(`Cannot stringify arbitrary non-POJOs ${thing.constructor.name}`);
            }
          } else if (Object.getOwnPropertySymbols(thing).length > 0) {
            log(`Cannot stringify POJOs with symbolic keys ${Object.getOwnPropertySymbols(thing).map((symbol) => symbol.toString())}`);
          } else {
            Object.keys(thing).forEach((key) => walk(thing[key]));
          }
      }
    }
  }
  walk(value);
  const names = /* @__PURE__ */ new Map();
  Array.from(counts).filter((entry) => entry[1] > 1).sort((a, b) => b[1] - a[1]).forEach((entry, i) => {
    names.set(entry[0], getName(i));
  });
  function stringify(thing) {
    if (names.has(thing)) {
      return names.get(thing);
    }
    if (isPrimitive(thing)) {
      return stringifyPrimitive(thing);
    }
    const type = getType(thing);
    switch (type) {
      case "Number":
      case "String":
      case "Boolean":
        return `Object(${stringify(thing.valueOf())})`;
      case "RegExp":
        return thing.toString();
      case "Date":
        return `new Date(${thing.getTime()})`;
      case "Array":
        const members = thing.map((v, i) => i in thing ? stringify(v) : "");
        const tail = thing.length === 0 || thing.length - 1 in thing ? "" : ",";
        return `[${members.join(",")}${tail}]`;
      case "Set":
      case "Map":
        return `new ${type}([${Array.from(thing).map(stringify).join(",")}])`;
      default:
        if (thing.toJSON) {
          let json = thing.toJSON();
          if (getType(json) === "String") {
            try {
              json = JSON.parse(json);
            } catch (e) {
            }
          }
          return stringify(json);
        }
        if (Object.getPrototypeOf(thing) === null) {
          if (Object.keys(thing).length === 0) {
            return "Object.create(null)";
          }
          return `Object.create(null,{${Object.keys(thing).map((key) => `${safeKey(key)}:{writable:true,enumerable:true,value:${stringify(thing[key])}}`).join(",")}})`;
        }
        return `{${Object.keys(thing).map((key) => `${safeKey(key)}:${stringify(thing[key])}`).join(",")}}`;
    }
  }
  const str = stringify(value);
  if (names.size) {
    const params = [];
    const statements = [];
    const values = [];
    names.forEach((name, thing) => {
      params.push(name);
      if (isPrimitive(thing)) {
        values.push(stringifyPrimitive(thing));
        return;
      }
      const type = getType(thing);
      switch (type) {
        case "Number":
        case "String":
        case "Boolean":
          values.push(`Object(${stringify(thing.valueOf())})`);
          break;
        case "RegExp":
          values.push(thing.toString());
          break;
        case "Date":
          values.push(`new Date(${thing.getTime()})`);
          break;
        case "Array":
          values.push(`Array(${thing.length})`);
          thing.forEach((v, i) => {
            statements.push(`${name}[${i}]=${stringify(v)}`);
          });
          break;
        case "Set":
          values.push("new Set");
          statements.push(`${name}.${Array.from(thing).map((v) => `add(${stringify(v)})`).join(".")}`);
          break;
        case "Map":
          values.push("new Map");
          statements.push(`${name}.${Array.from(thing).map(([k, v]) => `set(${stringify(k)}, ${stringify(v)})`).join(".")}`);
          break;
        default:
          values.push(Object.getPrototypeOf(thing) === null ? "Object.create(null)" : "{}");
          Object.keys(thing).forEach((key) => {
            statements.push(`${name}${safeProp(key)}=${stringify(thing[key])}`);
          });
      }
    });
    statements.push(`return ${str}`);
    return `(function(${params.join(",")}){${statements.join(";")}}(${values.join(",")}))`;
  } else {
    return str;
  }
}
function getName(num) {
  let name = "";
  do {
    name = chars[num % chars.length] + name;
    num = ~~(num / chars.length) - 1;
  } while (num >= 0);
  return reserved.test(name) ? `${name}0` : name;
}
function isPrimitive(thing) {
  return Object(thing) !== thing;
}
function stringifyPrimitive(thing) {
  if (typeof thing === "string") {
    return stringifyString(thing);
  }
  if (thing === void 0) {
    return "void 0";
  }
  if (thing === 0 && 1 / thing < 0) {
    return "-0";
  }
  const str = String(thing);
  if (typeof thing === "number") {
    return str.replace(/^(-)?0\./, "$1.");
  }
  return str;
}
function getType(thing) {
  return Object.prototype.toString.call(thing).slice(8, -1);
}
function escapeUnsafeChar(c) {
  return escaped[c] || c;
}
function escapeUnsafeChars(str) {
  return str.replace(unsafeChars, escapeUnsafeChar);
}
function safeKey(key) {
  return /^[_$a-zA-Z][_$a-zA-Z0-9]*$/.test(key) ? key : escapeUnsafeChars(JSON.stringify(key));
}
function safeProp(key) {
  return /^[_$a-zA-Z][_$a-zA-Z0-9]*$/.test(key) ? `.${key}` : `[${escapeUnsafeChars(JSON.stringify(key))}]`;
}
function stringifyString(str) {
  let result = '"';
  for (let i = 0; i < str.length; i += 1) {
    const char = str.charAt(i);
    const code = char.charCodeAt(0);
    if (char === '"') {
      result += '\\"';
    } else if (char in escaped) {
      result += escaped[char];
    } else if (code >= 55296 && code <= 57343) {
      const next = str.charCodeAt(i + 1);
      if (code <= 56319 && (next >= 56320 && next <= 57343)) {
        result += char + str[++i];
      } else {
        result += `\\u${code.toString(16).toUpperCase()}`;
      }
    } else {
      result += char;
    }
  }
  result += '"';
  return result;
}

function defineNitroPlugin(def) {
  return def;
}

function normalizeSiteConfig(config) {
  if (typeof config.indexable !== "undefined")
    config.indexable = String(config.indexable) !== "false";
  if (typeof config.trailingSlash !== "undefined" && !config.trailingSlash)
    config.trailingSlash = String(config.trailingSlash) !== "false";
  if (config.url && !hasProtocol(config.url, { acceptRelative: true, strict: false }))
    config.url = withHttps(config.url);
  const keys = Object.keys(config).sort((a, b) => a.localeCompare(b));
  const newConfig = {};
  for (const k of keys)
    newConfig[k] = config[k];
  return newConfig;
}
function createSiteConfigStack(options) {
  const debug = options?.debug || false;
  const stack = [];
  function push(input) {
    if (!input || typeof input !== "object" || Object.keys(input).length === 0)
      return;
    if (!input._context && debug) {
      let lastFunctionName = new Error("tmp").stack?.split("\n")[2].split(" ")[5];
      if (lastFunctionName?.includes("/"))
        lastFunctionName = "anonymous";
      input._context = lastFunctionName;
    }
    const entry = {};
    for (const k in input) {
      const val = input[k];
      if (typeof val !== "undefined" && val !== "")
        entry[k] = val;
    }
    if (Object.keys(entry).filter((k) => !k.startsWith("_")).length > 0)
      stack.push(entry);
  }
  function get(options2) {
    const siteConfig = {};
    if (options2?.debug)
      siteConfig._context = {};
    for (const o in stack.sort((a, b) => (a._priority || 0) - (b._priority || 0))) {
      for (const k in stack[o]) {
        const key = k;
        const val = stack[o][k];
        if (!k.startsWith("_")) {
          siteConfig[k] = options2?.resolveRefs ? toValue(val) : val;
          if (options2?.debug)
            siteConfig._context[key] = stack[o]._context?.[key] || stack[o]._context || "anonymous";
        }
      }
    }
    return options2?.skipNormalize ? siteConfig : normalizeSiteConfig(siteConfig);
  }
  return {
    stack,
    push,
    get
  };
}

function envSiteConfig(env) {
  return Object.fromEntries(Object.entries(env).filter(([k]) => k.startsWith("NUXT_SITE_") || k.startsWith("NUXT_PUBLIC_SITE_")).map(([k, v]) => [
    k.replace(/^NUXT_(PUBLIC_)?SITE_/, "").split("_").map((s, i) => i === 0 ? s.toLowerCase() : s[0].toUpperCase() + s.slice(1).toLowerCase()).join(""),
    v
  ]));
}

function useSiteConfig(e, _options) {
  e.context.siteConfig = e.context.siteConfig || createSiteConfigStack();
  const options = defu(_options, useRuntimeConfig(e)["nuxt-site-config"], { debug: false });
  return e.context.siteConfig.get(options);
}

function useNitroOrigin(e) {
  const cert = process.env.NITRO_SSL_CERT;
  const key = process.env.NITRO_SSL_KEY;
  let host = process.env.NITRO_HOST || process.env.HOST || false;
  let port = false;
  let protocol = cert && key || !false ? "https" : "http";
  if (!e) ; else {
    host = getRequestHost(e, { xForwardedHost: true }) || host;
    protocol = getRequestProtocol(e, { xForwardedProto: true }) || protocol;
  }
  if (typeof host === "string" && host.includes(":")) {
    port = host.split(":").pop();
    host = host.split(":")[0];
  }
  port = port ? `:${port}` : "";
  return `${protocol}://${host}${port}/`;
}

function resolveSitePath(pathOrUrl, options) {
  let path = pathOrUrl;
  if (hasProtocol(pathOrUrl, { strict: false, acceptRelative: true })) {
    const parsed = parseURL(pathOrUrl);
    path = parsed.pathname;
  }
  const base = withLeadingSlash(options.base || "/");
  if (base !== "/" && path.startsWith(base)) {
    path = path.slice(base.length);
  }
  const origin = options.absolute ? options.siteUrl : "";
  const baseWithOrigin = options.withBase ? withBase(base, origin || "/") : origin;
  const resolvedUrl = withBase(path, baseWithOrigin);
  return path === "/" && !options.withBase ? withTrailingSlash(resolvedUrl) : fixSlashes(options.trailingSlash, resolvedUrl);
}
function fixSlashes(trailingSlash, pathOrUrl) {
  const $url = parseURL(pathOrUrl);
  const isFileUrl = $url.pathname.includes(".");
  if (isFileUrl)
    return pathOrUrl;
  const fixedPath = trailingSlash ? withTrailingSlash($url.pathname) : withoutTrailingSlash($url.pathname);
  return `${$url.protocol ? `${$url.protocol}//` : ""}${$url.host || ""}${fixedPath}${$url.search || ""}${$url.hash || ""}`;
}

function createSitePathResolver(e, options = {}) {
  const siteConfig = useSiteConfig(e);
  const nitroOrigin = useNitroOrigin(e);
  const nuxtBase = useRuntimeConfig(e).app.baseURL || "/";
  return (path) => {
    return resolveSitePath(path, {
      ...options,
      siteUrl: options.canonical !== false || false ? siteConfig.url : nitroOrigin,
      trailingSlash: siteConfig.trailingSlash,
      base: nuxtBase
    });
  };
}

const _INAxINPva5 = defineNitroPlugin(async (nitroApp) => {
  nitroApp.hooks.hook("render:html", async (ctx, { event }) => {
    const routeOptions = getRouteRules(event);
    const isIsland = false ;
    event.path;
    const noSSR = event.context.nuxt?.noSSR || routeOptions.ssr === false && !isIsland || (false);
    if (noSSR) {
      const siteConfig = Object.fromEntries(
        Object.entries(useSiteConfig(event)).map(([k, v]) => [k, toValue(v)])
      );
      ctx.body.push(`<script>window.__NUXT_SITE_CONFIG__=${devalue(siteConfig)}<\/script>`);
    }
  });
});

const script = "\"use strict\";(()=>{const a=window,e=document.documentElement,m=[\"dark\",\"light\"],c=window&&window.localStorage&&window.localStorage.getItem&&window.localStorage.getItem(\"nuxt-color-mode\")||\"system\";let n=c===\"system\"?d():c;const l=e.getAttribute(\"data-color-mode-forced\");l&&(n=l),i(n),a[\"__NUXT_COLOR_MODE__\"]={preference:c,value:n,getColorScheme:d,addColorScheme:i,removeColorScheme:f};function i(o){const t=\"\"+o+\"\",s=\"\";e.classList?e.classList.add(t):e.className+=\" \"+t,s&&e.setAttribute(\"data-\"+s,o)}function f(o){const t=\"\"+o+\"\",s=\"\";e.classList?e.classList.remove(t):e.className=e.className.replace(new RegExp(t,\"g\"),\"\"),s&&e.removeAttribute(\"data-\"+s)}function r(o){return a.matchMedia(\"(prefers-color-scheme\"+o+\")\")}function d(){if(a.matchMedia&&r(\"\").media!==\"not all\"){for(const o of m)if(r(\":\"+o).matches)return o}return\"light\"}})();\n";

const _DOlFsWxR4p = (function(nitro) {
  nitro.hooks.hook("render:html", (htmlContext) => {
    htmlContext.head.push(`<script>${script}<\/script>`);
  });
});

const plugins = [
  _INAxINPva5,
_DOlFsWxR4p
];

const errorHandler = (async function errorhandler(error, event) {
  const { stack, statusCode, statusMessage, message } = normalizeError(error);
  const errorObject = {
    url: event.path,
    statusCode,
    statusMessage,
    message,
    stack: "",
    data: error.data
  };
  if (error.unhandled || error.fatal) {
    const tags = [
      "[nuxt]",
      "[request error]",
      error.unhandled && "[unhandled]",
      error.fatal && "[fatal]",
      Number(errorObject.statusCode) !== 200 && `[${errorObject.statusCode}]`
    ].filter(Boolean).join(" ");
    console.error(tags, errorObject.message + "\n" + stack.map((l) => "  " + l.text).join("  \n"));
  }
  if (event.handled) {
    return;
  }
  setResponseStatus(event, errorObject.statusCode !== 200 && errorObject.statusCode || 500, errorObject.statusMessage);
  if (isJsonRequest(event)) {
    setResponseHeader(event, "Content-Type", "application/json");
    return send(event, JSON.stringify(errorObject));
  }
  const reqHeaders = getRequestHeaders(event);
  const isRenderingError = event.path.startsWith("/__nuxt_error") || !!reqHeaders["x-nuxt-error"];
  const res = isRenderingError ? null : await useNitroApp().localFetch(
    withQuery(joinURL(useRuntimeConfig().app.baseURL, "/__nuxt_error"), errorObject),
    {
      headers: { ...reqHeaders, "x-nuxt-error": "true" },
      redirect: "manual"
    }
  ).catch(() => null);
  if (!res) {
    const { template } = await import('../error-500.mjs');
    if (event.handled) {
      return;
    }
    setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
    return send(event, template(errorObject));
  }
  const html = await res.text();
  if (event.handled) {
    return;
  }
  for (const [header, value] of res.headers.entries()) {
    setResponseHeader(event, header, value);
  }
  setResponseStatus(event, res.status && res.status !== 200 ? res.status : void 0, res.statusText);
  return send(event, html);
});

const assets = {
  "/.DS_Store": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"2004-mCkDtUhnD7kN5IzWgxfs4DA6gp0\"",
    "mtime": "2024-02-02T10:24:18.129Z",
    "size": 8196,
    "path": "../public/.DS_Store"
  },
  "/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-ZhkbVKyQ1QRmRD1yRjh8/DnFLiw\"",
    "mtime": "2024-02-02T10:23:58.359Z",
    "size": 62,
    "path": "../public/_payload.json"
  },
  "/avatar.svg": {
    "type": "image/svg+xml",
    "etag": "\"344-jlrvMpSRk4UU3NKayeanecCBVac\"",
    "mtime": "2024-02-02T10:24:18.135Z",
    "size": 836,
    "path": "../public/avatar.svg"
  },
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"47e-vN/GySwSCH6ZGhoyi5wx+kESMTE\"",
    "mtime": "2024-02-02T10:24:18.136Z",
    "size": 1150,
    "path": "../public/favicon.ico"
  },
  "/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"44bb5-LXzB09zI8+TXOOQw1tZcFoX8H8c\"",
    "mtime": "2024-02-02T10:23:58.176Z",
    "size": 281525,
    "path": "../public/index.html"
  },
  "/logo-blue-white.png": {
    "type": "image/png",
    "etag": "\"cf1f-oaU62q69wEjNEtKQCzKroI/pL+I\"",
    "mtime": "2024-02-02T10:24:18.131Z",
    "size": 53023,
    "path": "../public/logo-blue-white.png"
  },
  "/logo-matta-black.png": {
    "type": "image/png",
    "etag": "\"dd12-oStiUP8iExETWuQ0PUX4W0Qp2c8\"",
    "mtime": "2024-02-02T10:24:18.132Z",
    "size": 56594,
    "path": "../public/logo-matta-black.png"
  },
  "/logo-matta-white.png": {
    "type": "image/png",
    "etag": "\"c1cc-5+TrcN3ITkCQBS3qNCs5plwKbnE\"",
    "mtime": "2024-02-02T10:24:18.126Z",
    "size": 49612,
    "path": "../public/logo-matta-white.png"
  },
  "/manifest.json": {
    "type": "application/json",
    "etag": "\"317-q8tmPxor3J1RrRBHUT8PhHRhN5E\"",
    "mtime": "2024-02-02T10:24:18.127Z",
    "size": 791,
    "path": "../public/manifest.json"
  },
  "/manifest.webmanifest": {
    "type": "application/manifest+json",
    "etag": "\"254-IbEu6jHTtl1CtSRNeJ0mrf0FGBg\"",
    "mtime": "2024-02-02T10:24:17.750Z",
    "size": 596,
    "path": "../public/manifest.webmanifest"
  },
  "/shot1.png": {
    "type": "image/png",
    "etag": "\"108995-L4VIWXRhlHy9a4Q9qeoHTGOSFhQ\"",
    "mtime": "2024-02-02T10:24:18.132Z",
    "size": 1083797,
    "path": "../public/shot1.png"
  },
  "/shot2.png": {
    "type": "image/png",
    "etag": "\"5fe5e-vNwga5Hlc5rfJyO7oyGI4hN1JzY\"",
    "mtime": "2024-02-02T10:24:18.130Z",
    "size": 392798,
    "path": "../public/shot2.png"
  },
  "/sw.js": {
    "type": "application/javascript",
    "etag": "\"437-4ix49qT0a/affNy37qUD3uCzHbo\"",
    "mtime": "2024-02-02T10:24:21.955Z",
    "size": 1079,
    "path": "../public/sw.js"
  },
  "/version.json": {
    "type": "application/json",
    "etag": "\"1b-f2Pnj3AmC1LFQqVdSiZEh1/PQM4\"",
    "mtime": "2024-02-02T10:24:18.126Z",
    "size": 27,
    "path": "../public/version.json"
  },
  "/workbox-3e911b1d.js": {
    "type": "application/javascript",
    "etag": "\"3ae2-e/UFf/p4R18WVC2R9oy8KC2wMfM\"",
    "mtime": "2024-02-02T10:24:21.956Z",
    "size": 15074,
    "path": "../public/workbox-3e911b1d.js"
  },
  "/_nuxt/AppButton.FIbptzhk.js": {
    "type": "application/javascript",
    "etag": "\"1221-87JWWTCe9VvYFfarlM9Sn2QNEPU\"",
    "mtime": "2024-02-02T10:24:17.848Z",
    "size": 4641,
    "path": "../public/_nuxt/AppButton.FIbptzhk.js"
  },
  "/_nuxt/AppFooter.4WsEk6Ke.js": {
    "type": "application/javascript",
    "etag": "\"5e87-9y/FdqY0R/q+emXTtdiZb14dISk\"",
    "mtime": "2024-02-02T10:24:17.843Z",
    "size": 24199,
    "path": "../public/_nuxt/AppFooter.4WsEk6Ke.js"
  },
  "/_nuxt/AppFooter.UJcXQJ9f.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1a3-8FWs0nV1qt6Lg2HWV0yBmp81Gyk\"",
    "mtime": "2024-02-02T10:24:17.841Z",
    "size": 419,
    "path": "../public/_nuxt/AppFooter.UJcXQJ9f.css"
  },
  "/_nuxt/AppIcon._UQOEVX7.js": {
    "type": "application/javascript",
    "etag": "\"4dbe-IATcGlKo6DTZKY73O/BthT3zcXM\"",
    "mtime": "2024-02-02T10:24:17.842Z",
    "size": 19902,
    "path": "../public/_nuxt/AppIcon._UQOEVX7.js"
  },
  "/_nuxt/AppLoader.AR_N_WA4.js": {
    "type": "application/javascript",
    "etag": "\"1c1-pmrXnkMp4njBlQU82QF73D2X/3I\"",
    "mtime": "2024-02-02T10:24:17.843Z",
    "size": 449,
    "path": "../public/_nuxt/AppLoader.AR_N_WA4.js"
  },
  "/_nuxt/AppLoader.VX6_gNqr.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1b0-3IxSMCxsbHcJu2MCBtsEgadHhxA\"",
    "mtime": "2024-02-02T10:24:17.841Z",
    "size": 432,
    "path": "../public/_nuxt/AppLoader.VX6_gNqr.css"
  },
  "/_nuxt/AppTab.963xjkCo.js": {
    "type": "application/javascript",
    "etag": "\"35a-DonPKmvDUfJPF5rIWNfIkrwvFTA\"",
    "mtime": "2024-02-02T10:24:17.841Z",
    "size": 858,
    "path": "../public/_nuxt/AppTab.963xjkCo.js"
  },
  "/_nuxt/Board.VfT8WsEY.js": {
    "type": "application/javascript",
    "etag": "\"2cf-xT7OISuu3iBJ17+cChYyD7OLHzU\"",
    "mtime": "2024-02-02T10:24:17.847Z",
    "size": 719,
    "path": "../public/_nuxt/Board.VfT8WsEY.js"
  },
  "/_nuxt/Call.rNhe09nL.js": {
    "type": "application/javascript",
    "etag": "\"4c5-gBrR2vvQNGc9F6ogytTHuwSYgN4\"",
    "mtime": "2024-02-02T10:24:17.844Z",
    "size": 1221,
    "path": "../public/_nuxt/Call.rNhe09nL.js"
  },
  "/_nuxt/Card.ooEg4A_v.js": {
    "type": "application/javascript",
    "etag": "\"bc9-EYkwEUHiUE5ZanvVldyShxKK0F4\"",
    "mtime": "2024-02-02T10:24:17.844Z",
    "size": 3017,
    "path": "../public/_nuxt/Card.ooEg4A_v.js"
  },
  "/_nuxt/CartButton.QejEeJBQ.js": {
    "type": "application/javascript",
    "etag": "\"4c9-Gy1drOY8Br6/4n/hHtYnBqPeAaM\"",
    "mtime": "2024-02-02T10:24:17.844Z",
    "size": 1225,
    "path": "../public/_nuxt/CartButton.QejEeJBQ.js"
  },
  "/_nuxt/Center.oOhM78p8.js": {
    "type": "application/javascript",
    "etag": "\"76d-vdkYsh+RrYGvOl4KZd/tonk2EMI\"",
    "mtime": "2024-02-02T10:24:17.845Z",
    "size": 1901,
    "path": "../public/_nuxt/Center.oOhM78p8.js"
  },
  "/_nuxt/CheckCircleIcon.Q0fYhCh9.js": {
    "type": "application/javascript",
    "etag": "\"170-MwQIKtz0y3VqoVq5CMpkDV7dZek\"",
    "mtime": "2024-02-02T10:24:17.852Z",
    "size": 368,
    "path": "../public/_nuxt/CheckCircleIcon.Q0fYhCh9.js"
  },
  "/_nuxt/CheckIcon.u7ocdVHH.js": {
    "type": "application/javascript",
    "etag": "\"194-n5eQop/aALl3uEgQIpk+cGkKa2A\"",
    "mtime": "2024-02-02T10:24:17.852Z",
    "size": 404,
    "path": "../public/_nuxt/CheckIcon.u7ocdVHH.js"
  },
  "/_nuxt/ChevronDownIcon.VyUG4MaR.js": {
    "type": "application/javascript",
    "etag": "\"17a-1V+oErA0JVwxIpDfLUN0/3ufyzQ\"",
    "mtime": "2024-02-02T10:24:17.845Z",
    "size": 378,
    "path": "../public/_nuxt/ChevronDownIcon.VyUG4MaR.js"
  },
  "/_nuxt/CountriesSelect.yLOR4Ixv.js": {
    "type": "application/javascript",
    "etag": "\"a8b-QXtKWCT5dFPQTsbRe65NrsJVvA0\"",
    "mtime": "2024-02-02T10:24:17.845Z",
    "size": 2699,
    "path": "../public/_nuxt/CountriesSelect.yLOR4Ixv.js"
  },
  "/_nuxt/CurrencyInput.8Mht4yOG.js": {
    "type": "application/javascript",
    "etag": "\"373a-BQSQSOw9/rzHAXCPeJue8CeTRck\"",
    "mtime": "2024-02-02T10:24:17.847Z",
    "size": 14138,
    "path": "../public/_nuxt/CurrencyInput.8Mht4yOG.js"
  },
  "/_nuxt/CustomSelect.1-DHTYS6.js": {
    "type": "application/javascript",
    "etag": "\"c12-R18n9yp7MtNlOQyGWLXQnwXAke4\"",
    "mtime": "2024-02-02T10:24:17.845Z",
    "size": 3090,
    "path": "../public/_nuxt/CustomSelect.1-DHTYS6.js"
  },
  "/_nuxt/DeleteModal.A-a2Ur2q.js": {
    "type": "application/javascript",
    "etag": "\"a3a-cgosqY3QJTxTq1+vSYPs+fw/ITI\"",
    "mtime": "2024-02-02T10:24:17.846Z",
    "size": 2618,
    "path": "../public/_nuxt/DeleteModal.A-a2Ur2q.js"
  },
  "/_nuxt/DeleteModal.XV_LjARV.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-Zmj3Cj6KdIlLFhbuxcoHf1zXkkA\"",
    "mtime": "2024-02-02T10:24:17.845Z",
    "size": 1959,
    "path": "../public/_nuxt/DeleteModal.XV_LjARV.css"
  },
  "/_nuxt/Directors.L41hBrJe.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"16f3-YMmtGyfpjSEa8qabdYbFte3Z3eg\"",
    "mtime": "2024-02-02T10:24:17.846Z",
    "size": 5875,
    "path": "../public/_nuxt/Directors.L41hBrJe.css"
  },
  "/_nuxt/Directors.gbDqaXgc.js": {
    "type": "application/javascript",
    "etag": "\"7870-f3ZWvX5i1NpZJa/FAaj+7prhdsc\"",
    "mtime": "2024-02-02T10:24:17.846Z",
    "size": 30832,
    "path": "../public/_nuxt/Directors.gbDqaXgc.js"
  },
  "/_nuxt/EmptyData.kC_S59ml.js": {
    "type": "application/javascript",
    "etag": "\"24e5-hiLV3Mq932tGQ27Nf3/h6mWpwz4\"",
    "mtime": "2024-02-02T10:24:17.847Z",
    "size": 9445,
    "path": "../public/_nuxt/EmptyData.kC_S59ml.js"
  },
  "/_nuxt/EyeIcon._ffFuHFs.js": {
    "type": "application/javascript",
    "etag": "\"48a-TyCe5iqqGB86tumDEFTSWICOyMM\"",
    "mtime": "2024-02-02T10:24:17.848Z",
    "size": 1162,
    "path": "../public/_nuxt/EyeIcon._ffFuHFs.js"
  },
  "/_nuxt/FileUpload.5O6pirCX.js": {
    "type": "application/javascript",
    "etag": "\"8cd-X6EpzO2jzI0nttWMCo8+6wJohaM\"",
    "mtime": "2024-02-02T10:24:17.847Z",
    "size": 2253,
    "path": "../public/_nuxt/FileUpload.5O6pirCX.js"
  },
  "/_nuxt/HeaderComponent.T0RsYrAW.js": {
    "type": "application/javascript",
    "etag": "\"546-wWpICoIyMgeo2S9GMlT8z3IKNCw\"",
    "mtime": "2024-02-02T10:24:17.858Z",
    "size": 1350,
    "path": "../public/_nuxt/HeaderComponent.T0RsYrAW.js"
  },
  "/_nuxt/IndexModal.nMO7LfVv.js": {
    "type": "application/javascript",
    "etag": "\"86a-QrIc+tzL1pH7tvODU1k0YP2aHBk\"",
    "mtime": "2024-02-02T10:24:17.847Z",
    "size": 2154,
    "path": "../public/_nuxt/IndexModal.nMO7LfVv.js"
  },
  "/_nuxt/Manrope-200-2.tc1pcmBl.woff2": {
    "type": "font/woff2",
    "etag": "\"377c-P21Fqhq8FZlQh3pIAJ4/dq083JM\"",
    "mtime": "2024-02-02T10:24:17.848Z",
    "size": 14204,
    "path": "../public/_nuxt/Manrope-200-2.tc1pcmBl.woff2"
  },
  "/_nuxt/Manrope-200-3.PilIel9p.woff2": {
    "type": "font/woff2",
    "etag": "\"23e8-8oyWLnQHg7DeSfhU688gTUaZW+c\"",
    "mtime": "2024-02-02T10:24:17.849Z",
    "size": 9192,
    "path": "../public/_nuxt/Manrope-200-3.PilIel9p.woff2"
  },
  "/_nuxt/Manrope-200-4.rzxPwudx.woff2": {
    "type": "font/woff2",
    "etag": "\"2074-atSB0WLl08CdnVgpghvv7le/9lk\"",
    "mtime": "2024-02-02T10:24:17.848Z",
    "size": 8308,
    "path": "../public/_nuxt/Manrope-200-4.rzxPwudx.woff2"
  },
  "/_nuxt/Manrope-200-5.-trWxN4o.woff2": {
    "type": "font/woff2",
    "etag": "\"39d4-DnKHMntuQ0aSkandFFZMXbB/A64\"",
    "mtime": "2024-02-02T10:24:17.849Z",
    "size": 14804,
    "path": "../public/_nuxt/Manrope-200-5.-trWxN4o.woff2"
  },
  "/_nuxt/Manrope-200-6.1panvsZo.woff2": {
    "type": "font/woff2",
    "etag": "\"5f38-chBgcZmLDvXxRepPnVNFnlKjPp8\"",
    "mtime": "2024-02-02T10:24:17.849Z",
    "size": 24376,
    "path": "../public/_nuxt/Manrope-200-6.1panvsZo.woff2"
  },
  "/_nuxt/OrderComponent.4Ev8yfTc.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"60-49kQZaH7Jza/SNmPinBj7Z7yCjU\"",
    "mtime": "2024-02-02T10:24:17.849Z",
    "size": 96,
    "path": "../public/_nuxt/OrderComponent.4Ev8yfTc.css"
  },
  "/_nuxt/OrderComponent.UoRQ7uoj.js": {
    "type": "application/javascript",
    "etag": "\"130a-7KyS2aMfxsIegiOS2+TNV4gIukw\"",
    "mtime": "2024-02-02T10:24:17.921Z",
    "size": 4874,
    "path": "../public/_nuxt/OrderComponent.UoRQ7uoj.js"
  },
  "/_nuxt/PhoneCodes.4wsOhpb-.js": {
    "type": "application/javascript",
    "etag": "\"47e6-sCQmYDVsC1ULeiHZl3oyOEHnEwA\"",
    "mtime": "2024-02-02T10:24:17.850Z",
    "size": 18406,
    "path": "../public/_nuxt/PhoneCodes.4wsOhpb-.js"
  },
  "/_nuxt/SelectComponent.dVMlMgGy.js": {
    "type": "application/javascript",
    "etag": "\"c19-/AfYN2t7bilDPgpfoXUcuICLpXk\"",
    "mtime": "2024-02-02T10:24:17.850Z",
    "size": 3097,
    "path": "../public/_nuxt/SelectComponent.dVMlMgGy.js"
  },
  "/_nuxt/SideModal.tgWdbIw3.js": {
    "type": "application/javascript",
    "etag": "\"6f9-N/95hbUSkptmieYLVsOLqxBkn0Q\"",
    "mtime": "2024-02-02T10:24:17.851Z",
    "size": 1785,
    "path": "../public/_nuxt/SideModal.tgWdbIw3.js"
  },
  "/_nuxt/Simple.0GEEqC3H.js": {
    "type": "application/javascript",
    "etag": "\"aa0-jXs7FyxnNrhxBJZEoLwa3YtSf3A\"",
    "mtime": "2024-02-02T10:24:17.850Z",
    "size": 2720,
    "path": "../public/_nuxt/Simple.0GEEqC3H.js"
  },
  "/_nuxt/Simple.hWm1Xyw-.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"12e8-zhe26ZzT0ke3cGD0AptjblcshJU\"",
    "mtime": "2024-02-02T10:24:17.851Z",
    "size": 4840,
    "path": "../public/_nuxt/Simple.hWm1Xyw-.css"
  },
  "/_nuxt/Skelenton.XZkVxyZr.js": {
    "type": "application/javascript",
    "etag": "\"543-8pwCeA23a9jcKgOfiJz3Uyj4Lao\"",
    "mtime": "2024-02-02T10:24:17.850Z",
    "size": 1347,
    "path": "../public/_nuxt/Skelenton.XZkVxyZr.js"
  },
  "/_nuxt/StatesSelect.4ElWr12u.js": {
    "type": "application/javascript",
    "etag": "\"ab5-wZzuYcCb4GmlvvNsI31d7kXp4ts\"",
    "mtime": "2024-02-02T10:24:17.851Z",
    "size": 2741,
    "path": "../public/_nuxt/StatesSelect.4ElWr12u.js"
  },
  "/_nuxt/Stepper.vk8qwReu.js": {
    "type": "application/javascript",
    "etag": "\"67f-ebQ5gIrXTsCRv+uUC5Na65YSCkI\"",
    "mtime": "2024-02-02T10:24:17.851Z",
    "size": 1663,
    "path": "../public/_nuxt/Stepper.vk8qwReu.js"
  },
  "/_nuxt/TopBar.A9wbrxB3.js": {
    "type": "application/javascript",
    "etag": "\"479-v2oSKqtzHNCPt+wPR0RhjENb4ts\"",
    "mtime": "2024-02-02T10:24:17.851Z",
    "size": 1145,
    "path": "../public/_nuxt/TopBar.A9wbrxB3.js"
  },
  "/_nuxt/TopBar.lqxuM1cz.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"47f-b1ullUMvj8bh67YWsGjvDTw7SLo\"",
    "mtime": "2024-02-02T10:24:17.851Z",
    "size": 1151,
    "path": "../public/_nuxt/TopBar.lqxuM1cz.css"
  },
  "/_nuxt/UploadComponent.AYKd-CkU.js": {
    "type": "application/javascript",
    "etag": "\"ebc-Eyc4MTouqRZZI05LESQ82zrTpaw\"",
    "mtime": "2024-02-02T10:24:17.854Z",
    "size": 3772,
    "path": "../public/_nuxt/UploadComponent.AYKd-CkU.js"
  },
  "/_nuxt/VueSelect.MUeiRNx_.js": {
    "type": "application/javascript",
    "etag": "\"4dc9-MbYuZo1LFg5TTPNHpMRF7gR+YvU\"",
    "mtime": "2024-02-02T10:24:17.857Z",
    "size": 19913,
    "path": "../public/_nuxt/VueSelect.MUeiRNx_.js"
  },
  "/_nuxt/VueSelect.pJG8nTWo.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2b15-1iXZwF250ZXSnlBkoEJG2dbQLN8\"",
    "mtime": "2024-02-02T10:24:17.854Z",
    "size": 11029,
    "path": "../public/_nuxt/VueSelect.pJG8nTWo.css"
  },
  "/_nuxt/_email_.069y8uR3.js": {
    "type": "application/javascript",
    "etag": "\"ab3-jlbKV1bezAcpn8hleTA+Ebx8tI0\"",
    "mtime": "2024-02-02T10:24:17.851Z",
    "size": 2739,
    "path": "../public/_nuxt/_email_.069y8uR3.js"
  },
  "/_nuxt/_id_.-GWCNwZ7.js": {
    "type": "application/javascript",
    "etag": "\"192d-Ohs4KBuGwgXxKpPn+gij5+hpYBw\"",
    "mtime": "2024-02-02T10:24:17.854Z",
    "size": 6445,
    "path": "../public/_nuxt/_id_.-GWCNwZ7.js"
  },
  "/_nuxt/_id_.0p-PYPdy.js": {
    "type": "application/javascript",
    "etag": "\"1d70-7+7g+1qpP7nsP3UgU49WsCa/2DI\"",
    "mtime": "2024-02-02T10:24:17.852Z",
    "size": 7536,
    "path": "../public/_nuxt/_id_.0p-PYPdy.js"
  },
  "/_nuxt/_id_.2bcUs1LH.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-J9IcuK++nUsKS05Fv4I0gogaoLU\"",
    "mtime": "2024-02-02T10:24:17.853Z",
    "size": 1959,
    "path": "../public/_nuxt/_id_.2bcUs1LH.css"
  },
  "/_nuxt/_id_.5P7p_dIV.js": {
    "type": "application/javascript",
    "etag": "\"153ce-e2LDtL1RKCuoKiArxEivFSsAEck\"",
    "mtime": "2024-02-02T10:24:17.853Z",
    "size": 86990,
    "path": "../public/_nuxt/_id_.5P7p_dIV.js"
  },
  "/_nuxt/_id_.9YXn5Oed.js": {
    "type": "application/javascript",
    "etag": "\"13ec-O7miwv2Jd/0GMKMO2GChD34qUe8\"",
    "mtime": "2024-02-02T10:24:17.852Z",
    "size": 5100,
    "path": "../public/_nuxt/_id_.9YXn5Oed.js"
  },
  "/_nuxt/_id_.D_DFsiza.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"80e-YrvYWH5rlntvYg+8rqEnHdyKbM4\"",
    "mtime": "2024-02-02T10:24:17.853Z",
    "size": 2062,
    "path": "../public/_nuxt/_id_.D_DFsiza.css"
  },
  "/_nuxt/_id_.UQEjhb5O.js": {
    "type": "application/javascript",
    "etag": "\"15f4-HuHqsQ1l6uvi5jxEU/DJpquj+e0\"",
    "mtime": "2024-02-02T10:24:17.853Z",
    "size": 5620,
    "path": "../public/_nuxt/_id_.UQEjhb5O.js"
  },
  "/_nuxt/_plugin-vue_export-helper.x3n3nnut.js": {
    "type": "application/javascript",
    "etag": "\"5b-eFCz/UrraTh721pgAl0VxBNR1es\"",
    "mtime": "2024-02-02T10:24:17.853Z",
    "size": 91,
    "path": "../public/_nuxt/_plugin-vue_export-helper.x3n3nnut.js"
  },
  "/_nuxt/_type_.DBPVb24F.js": {
    "type": "application/javascript",
    "etag": "\"44b-2IeuA4AGcOBEcPRySMSHeo/FHXs\"",
    "mtime": "2024-02-02T10:24:17.854Z",
    "size": 1099,
    "path": "../public/_nuxt/_type_.DBPVb24F.js"
  },
  "/_nuxt/_type_.gQGdREv2.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1e99-HoaTwPkRGzXCiih/8HNBQg/MDXE\"",
    "mtime": "2024-02-02T10:24:17.853Z",
    "size": 7833,
    "path": "../public/_nuxt/_type_.gQGdREv2.css"
  },
  "/_nuxt/_type_.iU9MjBIZ.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-vxsW53LR3z73Kur2tIuPOEoVr2o\"",
    "mtime": "2024-02-02T10:24:17.875Z",
    "size": 1959,
    "path": "../public/_nuxt/_type_.iU9MjBIZ.css"
  },
  "/_nuxt/_type_.rKvlLebI.js": {
    "type": "application/javascript",
    "etag": "\"4aad-qICrSIWYTVLAhfZnwF4j+AAUjnk\"",
    "mtime": "2024-02-02T10:24:17.855Z",
    "size": 19117,
    "path": "../public/_nuxt/_type_.rKvlLebI.js"
  },
  "/_nuxt/account.lZEzXyHr.js": {
    "type": "application/javascript",
    "etag": "\"b91-qxHaQ6AHohm7WFFCWYc5w5DIuaY\"",
    "mtime": "2024-02-02T10:24:17.854Z",
    "size": 2961,
    "path": "../public/_nuxt/account.lZEzXyHr.js"
  },
  "/_nuxt/add-product.HzkyDR38.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"16f3-vBbNL+bHHiT/9FvavSLUygKPDvQ\"",
    "mtime": "2024-02-02T10:24:17.855Z",
    "size": 5875,
    "path": "../public/_nuxt/add-product.HzkyDR38.css"
  },
  "/_nuxt/add-product.hk0R4TEa.js": {
    "type": "application/javascript",
    "etag": "\"d433-Tz8nhLhfLLC3SGbIRhTzi0QMlnQ\"",
    "mtime": "2024-02-02T10:24:17.856Z",
    "size": 54323,
    "path": "../public/_nuxt/add-product.hk0R4TEa.js"
  },
  "/_nuxt/auth.ISFMv-TG.js": {
    "type": "application/javascript",
    "etag": "\"63a-H5xi9AzajDIpBRnnyU82y2qprFY\"",
    "mtime": "2024-02-02T10:24:17.856Z",
    "size": 1594,
    "path": "../public/_nuxt/auth.ISFMv-TG.js"
  },
  "/_nuxt/auth.qk1oPeJK.js": {
    "type": "application/javascript",
    "etag": "\"11e-ig1epnZBJLsaA7gnVUGfSKXXcYs\"",
    "mtime": "2024-02-02T10:24:17.855Z",
    "size": 286,
    "path": "../public/_nuxt/auth.qk1oPeJK.js"
  },
  "/_nuxt/authbg.Nh0asBXz.png": {
    "type": "image/png",
    "etag": "\"577f3-GwsrQCXMCUZfHFsQVLmQfBnLI38\"",
    "mtime": "2024-02-02T10:24:17.876Z",
    "size": 358387,
    "path": "../public/_nuxt/authbg.Nh0asBXz.png"
  },
  "/_nuxt/authservices._CWkNuWP.js": {
    "type": "application/javascript",
    "etag": "\"2f1-4dhxcHqb6QVCgR4qfyFbRXT92Dw\"",
    "mtime": "2024-02-02T10:24:17.856Z",
    "size": 753,
    "path": "../public/_nuxt/authservices._CWkNuWP.js"
  },
  "/_nuxt/callbg.UMfoadiA.png": {
    "type": "image/png",
    "etag": "\"1ef61-VpX6aJ92zMY2GJabp4PSKmS51g4\"",
    "mtime": "2024-02-02T10:24:17.858Z",
    "size": 126817,
    "path": "../public/_nuxt/callbg.UMfoadiA.png"
  },
  "/_nuxt/campaign.vZFzglyg.js": {
    "type": "application/javascript",
    "etag": "\"ca-gyUeb/6K/9E6sMk1arXtxa2CDeQ\"",
    "mtime": "2024-02-02T10:24:17.856Z",
    "size": 202,
    "path": "../public/_nuxt/campaign.vZFzglyg.js"
  },
  "/_nuxt/carousel.es.9JtvHDAa.js": {
    "type": "application/javascript",
    "etag": "\"2606-9+WdaXUf307E7bov5lBoVJD3xSg\"",
    "mtime": "2024-02-02T10:24:17.880Z",
    "size": 9734,
    "path": "../public/_nuxt/carousel.es.9JtvHDAa.js"
  },
  "/_nuxt/cart.rI8Wy8rj.js": {
    "type": "application/javascript",
    "etag": "\"889-mz9zbldJIZH37jKwsxNecdLhj+o\"",
    "mtime": "2024-02-02T10:24:17.856Z",
    "size": 2185,
    "path": "../public/_nuxt/cart.rI8Wy8rj.js"
  },
  "/_nuxt/cartservice.YavTIjxL.js": {
    "type": "application/javascript",
    "etag": "\"317-yAgbuKeVpOtpNFFQBCgeA2g4awI\"",
    "mtime": "2024-02-02T10:24:17.857Z",
    "size": 791,
    "path": "../public/_nuxt/cartservice.YavTIjxL.js"
  },
  "/_nuxt/ck-white.hx3Z0Mtl.js": {
    "type": "application/javascript",
    "etag": "\"12c-DEUnQ8TSrYOMt7WHRHdXcWLDyEo\"",
    "mtime": "2024-02-02T10:24:17.858Z",
    "size": 300,
    "path": "../public/_nuxt/ck-white.hx3Z0Mtl.js"
  },
  "/_nuxt/client-only.4EqHAOXJ.js": {
    "type": "application/javascript",
    "etag": "\"1d4-Em1tTzEiV9bdehSM2EVS8ZcFC7s\"",
    "mtime": "2024-02-02T10:24:17.857Z",
    "size": 468,
    "path": "../public/_nuxt/client-only.4EqHAOXJ.js"
  },
  "/_nuxt/company.X6a55YMf.js": {
    "type": "application/javascript",
    "etag": "\"3e44-LsYIUKSfxQ1aNRPZLX296A7jKcY\"",
    "mtime": "2024-02-02T10:24:17.858Z",
    "size": 15940,
    "path": "../public/_nuxt/company.X6a55YMf.js"
  },
  "/_nuxt/company.cDqcGzLb.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"f4d-8SEABOBx6B4hSeIXebGEqyBKZ40\"",
    "mtime": "2024-02-02T10:24:17.877Z",
    "size": 3917,
    "path": "../public/_nuxt/company.cDqcGzLb.css"
  },
  "/_nuxt/company.rfmEoY_l.js": {
    "type": "application/javascript",
    "etag": "\"c9-1t6HAnVZeNMYgYeGyzyBmLFos2o\"",
    "mtime": "2024-02-02T10:24:17.859Z",
    "size": 201,
    "path": "../public/_nuxt/company.rfmEoY_l.js"
  },
  "/_nuxt/confirm-email.7jancBr1.js": {
    "type": "application/javascript",
    "etag": "\"99a-Na7uZaWLSKpaqbEgt+LgdUdSQqw\"",
    "mtime": "2024-02-02T10:24:17.859Z",
    "size": 2458,
    "path": "../public/_nuxt/confirm-email.7jancBr1.js"
  },
  "/_nuxt/confirm-email.fezE_g13.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-m7au80ihrXxeXSq8oQnXMfOSKq0\"",
    "mtime": "2024-02-02T10:24:17.926Z",
    "size": 1959,
    "path": "../public/_nuxt/confirm-email.fezE_g13.css"
  },
  "/_nuxt/constants.7pc_kfFZ.js": {
    "type": "application/javascript",
    "etag": "\"473-E9YrrRxIAUZp+RwD6QAtFV6tZO8\"",
    "mtime": "2024-02-02T10:24:17.876Z",
    "size": 1139,
    "path": "../public/_nuxt/constants.7pc_kfFZ.js"
  },
  "/_nuxt/countries.MBd8PBQQ.js": {
    "type": "application/javascript",
    "etag": "\"34407-IEUULgG/AN0LIRiiAxYK4OCTC4A\"",
    "mtime": "2024-02-02T10:24:17.883Z",
    "size": 214023,
    "path": "../public/_nuxt/countries.MBd8PBQQ.js"
  },
  "/_nuxt/currencyFormat.2FTIJc9J.js": {
    "type": "application/javascript",
    "etag": "\"dd-dctaam/OhHSzqyNpz2b9qRE5y0k\"",
    "mtime": "2024-02-02T10:24:17.859Z",
    "size": 221,
    "path": "../public/_nuxt/currencyFormat.2FTIJc9J.js"
  },
  "/_nuxt/custom.QiWLtW2K.js": {
    "type": "application/javascript",
    "etag": "\"10c-UU1SPxAlEKgyirYSf827P8eJJf8\"",
    "mtime": "2024-02-02T10:24:17.877Z",
    "size": 268,
    "path": "../public/_nuxt/custom.QiWLtW2K.js"
  },
  "/_nuxt/customization.4ocgH6fe.js": {
    "type": "application/javascript",
    "etag": "\"104d-c+p46+7QacTFPWZ4/Or859tvoi8\"",
    "mtime": "2024-02-02T10:24:17.876Z",
    "size": 4173,
    "path": "../public/_nuxt/customization.4ocgH6fe.js"
  },
  "/_nuxt/customization.g2L-cSvu.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-tXGYXSwN2wL1zk4z5ZTiI683q/8\"",
    "mtime": "2024-02-02T10:24:17.877Z",
    "size": 1959,
    "path": "../public/_nuxt/customization.g2L-cSvu.css"
  },
  "/_nuxt/dashboard.26jXjN0j.js": {
    "type": "application/javascript",
    "etag": "\"11d7-0aP1AJqSUy5ZByIX0sW8IHQI4gY\"",
    "mtime": "2024-02-02T10:24:17.882Z",
    "size": 4567,
    "path": "../public/_nuxt/dashboard.26jXjN0j.js"
  },
  "/_nuxt/data.qctYKBbr.js": {
    "type": "application/javascript",
    "etag": "\"725-P2Th5LHqn9zw6X60lJ/oNwKYRM0\"",
    "mtime": "2024-02-02T10:24:17.881Z",
    "size": 1829,
    "path": "../public/_nuxt/data.qctYKBbr.js"
  },
  "/_nuxt/debounce.ooXclcwP.js": {
    "type": "application/javascript",
    "etag": "\"9b2-Ha9kLs4pH1GNym1uERutRGxIm+4\"",
    "mtime": "2024-02-02T10:24:17.877Z",
    "size": 2482,
    "path": "../public/_nuxt/debounce.ooXclcwP.js"
  },
  "/_nuxt/default.mHRNCUtS.js": {
    "type": "application/javascript",
    "etag": "\"802-cglNOyW429eUsLWuWZC/vk/NBVk\"",
    "mtime": "2024-02-02T10:24:17.881Z",
    "size": 2050,
    "path": "../public/_nuxt/default.mHRNCUtS.js"
  },
  "/_nuxt/description.b6n3o986.js": {
    "type": "application/javascript",
    "etag": "\"16e-AsxHf9fU1fFqx1PGcu7DyjtEZq0\"",
    "mtime": "2024-02-02T10:24:17.881Z",
    "size": 366,
    "path": "../public/_nuxt/description.b6n3o986.js"
  },
  "/_nuxt/edit-product.5L3JuLue.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"16f3-LV3B05/FWgUqWM3l0bFS7VQmmIA\"",
    "mtime": "2024-02-02T10:24:17.880Z",
    "size": 5875,
    "path": "../public/_nuxt/edit-product.5L3JuLue.css"
  },
  "/_nuxt/edit-product.650zveHL.js": {
    "type": "application/javascript",
    "etag": "\"bb0f-xz1TuKIJaW11cpAmobke1gWA1K8\"",
    "mtime": "2024-02-02T10:24:17.922Z",
    "size": 47887,
    "path": "../public/_nuxt/edit-product.650zveHL.js"
  },
  "/_nuxt/entry.cJnt5O0l.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"cec6-H8VhYSL+ldJUVNS1xJ1+QGj3Rw4\"",
    "mtime": "2024-02-02T10:24:17.927Z",
    "size": 52934,
    "path": "../public/_nuxt/entry.cJnt5O0l.css"
  },
  "/_nuxt/entry.wzZS1uGs.js": {
    "type": "application/javascript",
    "etag": "\"ebf66-Rmbu8uU8klQbjx2JAOstu7VP0PU\"",
    "mtime": "2024-02-02T10:24:17.888Z",
    "size": 966502,
    "path": "../public/_nuxt/entry.wzZS1uGs.js"
  },
  "/_nuxt/filetype.4yqEo8vn.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1003-pk60F5sW+qjDgbFxOBiqEjNDboM\"",
    "mtime": "2024-02-02T10:24:17.882Z",
    "size": 4099,
    "path": "../public/_nuxt/filetype.4yqEo8vn.css"
  },
  "/_nuxt/filetype.uiAN79jh.js": {
    "type": "application/javascript",
    "etag": "\"100d2-jSbnQNgDg0XXVYM2S3C/809IDiQ\"",
    "mtime": "2024-02-02T10:24:17.883Z",
    "size": 65746,
    "path": "../public/_nuxt/filetype.uiAN79jh.js"
  },
  "/_nuxt/finance.i_J6TVBw.js": {
    "type": "application/javascript",
    "etag": "\"665-nZU+vCMbA104BOt4EPTFNkHODoQ\"",
    "mtime": "2024-02-02T10:24:17.921Z",
    "size": 1637,
    "path": "../public/_nuxt/finance.i_J6TVBw.js"
  },
  "/_nuxt/financing.5EJie3DB.js": {
    "type": "application/javascript",
    "etag": "\"c1-t7hIGrZC+HRz1Q2gK1SMde1WEsY\"",
    "mtime": "2024-02-02T10:24:17.883Z",
    "size": 193,
    "path": "../public/_nuxt/financing.5EJie3DB.js"
  },
  "/_nuxt/forgot-password.oGzIAgxa.js": {
    "type": "application/javascript",
    "etag": "\"aa3-XrrZ6kpF7GWnGDy8Li19flFn19o\"",
    "mtime": "2024-02-02T10:24:17.921Z",
    "size": 2723,
    "path": "../public/_nuxt/forgot-password.oGzIAgxa.js"
  },
  "/_nuxt/hidden.HWieKAef.js": {
    "type": "application/javascript",
    "etag": "\"f5b-Lyxw/6EMQmUrS/VgrFToYKk9PN0\"",
    "mtime": "2024-02-02T10:24:17.924Z",
    "size": 3931,
    "path": "../public/_nuxt/hidden.HWieKAef.js"
  },
  "/_nuxt/home.a4gTl0q2.js": {
    "type": "application/javascript",
    "etag": "\"a981-IYTCmYl2UZyFCPA2tBTnMrXbe9A\"",
    "mtime": "2024-02-02T10:24:17.923Z",
    "size": 43393,
    "path": "../public/_nuxt/home.a4gTl0q2.js"
  },
  "/_nuxt/home.dg5K0XfN.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3d31-CAi1W1xJ4r/4ScXyELN5mprKD1A\"",
    "mtime": "2024-02-02T10:24:17.922Z",
    "size": 15665,
    "path": "../public/_nuxt/home.dg5K0XfN.css"
  },
  "/_nuxt/index.4DFWR05U.js": {
    "type": "application/javascript",
    "etag": "\"dd6-j85S9XJL048UznRjIIEYaA2Fk3M\"",
    "mtime": "2024-02-02T10:24:17.924Z",
    "size": 3542,
    "path": "../public/_nuxt/index.4DFWR05U.js"
  },
  "/_nuxt/index.4hK3DN6Z.js": {
    "type": "application/javascript",
    "etag": "\"22ff-iB2YMog83h90QmdzCjGYNGwZ/rg\"",
    "mtime": "2024-02-02T10:24:17.922Z",
    "size": 8959,
    "path": "../public/_nuxt/index.4hK3DN6Z.js"
  },
  "/_nuxt/index.BYl3rJTx.js": {
    "type": "application/javascript",
    "etag": "\"6e6-BgQCtjqbTF88ERolb+zQslwCdSg\"",
    "mtime": "2024-02-02T10:24:17.924Z",
    "size": 1766,
    "path": "../public/_nuxt/index.BYl3rJTx.js"
  },
  "/_nuxt/index.CbtyC2sl.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-r/krnlk49BIre40C6ZcsK0h8Zvo\"",
    "mtime": "2024-02-02T10:24:17.923Z",
    "size": 1959,
    "path": "../public/_nuxt/index.CbtyC2sl.css"
  },
  "/_nuxt/index.DrvDMLvU.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"135-mvSjHuDxx5PSTCwdNA7+2d+tXa4\"",
    "mtime": "2024-02-02T10:24:17.926Z",
    "size": 309,
    "path": "../public/_nuxt/index.DrvDMLvU.css"
  },
  "/_nuxt/index.E7h0NfXb.js": {
    "type": "application/javascript",
    "etag": "\"9b-Nn5p64KPLqvCl4qmpb50z+Q+wYo\"",
    "mtime": "2024-02-02T10:24:17.925Z",
    "size": 155,
    "path": "../public/_nuxt/index.E7h0NfXb.js"
  },
  "/_nuxt/index.Hnkchkzs.js": {
    "type": "application/javascript",
    "etag": "\"a58-TbIpIljMmYqFF5Ya1gLDaQ5dHi8\"",
    "mtime": "2024-02-02T10:24:17.923Z",
    "size": 2648,
    "path": "../public/_nuxt/index.Hnkchkzs.js"
  },
  "/_nuxt/index.KkcbRfyV.js": {
    "type": "application/javascript",
    "etag": "\"226e-ZkZmtkQ+nsfneDP/0ZbhzVVbpQ8\"",
    "mtime": "2024-02-02T10:24:17.926Z",
    "size": 8814,
    "path": "../public/_nuxt/index.KkcbRfyV.js"
  },
  "/_nuxt/index.PtPZ4vGM.js": {
    "type": "application/javascript",
    "etag": "\"1d84-5KXnjY/2ToLvk/4ZB3/TUVQK67k\"",
    "mtime": "2024-02-02T10:24:17.947Z",
    "size": 7556,
    "path": "../public/_nuxt/index.PtPZ4vGM.js"
  },
  "/_nuxt/index.RdKaSpNF.js": {
    "type": "application/javascript",
    "etag": "\"a0-bf+EcR7cvNk7Yqtpx+NSfwJFxB4\"",
    "mtime": "2024-02-02T10:24:17.926Z",
    "size": 160,
    "path": "../public/_nuxt/index.RdKaSpNF.js"
  },
  "/_nuxt/index.SDv64rEk.js": {
    "type": "application/javascript",
    "etag": "\"4b5a-RSmF58OcaFbTEQI1iWPGf424vgI\"",
    "mtime": "2024-02-02T10:24:17.925Z",
    "size": 19290,
    "path": "../public/_nuxt/index.SDv64rEk.js"
  },
  "/_nuxt/index.WlpW6G5g.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"12e8-jLz13v9hSwIzUALhiPCK/d3YWfE\"",
    "mtime": "2024-02-02T10:24:17.927Z",
    "size": 4840,
    "path": "../public/_nuxt/index.WlpW6G5g.css"
  },
  "/_nuxt/index.ZgA-dDD9.js": {
    "type": "application/javascript",
    "etag": "\"1728-Exgcsy+c0YrTsVVSurJg4H4oN1Y\"",
    "mtime": "2024-02-02T10:24:17.938Z",
    "size": 5928,
    "path": "../public/_nuxt/index.ZgA-dDD9.js"
  },
  "/_nuxt/index.cBQ7B-n7.js": {
    "type": "application/javascript",
    "etag": "\"2a0e-zlxfBKnPVuvA0ZnJ/ZvsPE831MU\"",
    "mtime": "2024-02-02T10:24:17.938Z",
    "size": 10766,
    "path": "../public/_nuxt/index.cBQ7B-n7.js"
  },
  "/_nuxt/index.es._EKK0RK_.js": {
    "type": "application/javascript",
    "etag": "\"1990-xO5HLJ2pZ3TqL5wBXCkycvDFUMw\"",
    "mtime": "2024-02-02T10:24:17.925Z",
    "size": 6544,
    "path": "../public/_nuxt/index.es._EKK0RK_.js"
  },
  "/_nuxt/index.esm-bundler.kODPEtU7.js": {
    "type": "application/javascript",
    "etag": "\"133f9-hPLT1J2RgAYVDk6K2QBtVG7ve5A\"",
    "mtime": "2024-02-02T10:24:17.939Z",
    "size": 78841,
    "path": "../public/_nuxt/index.esm-bundler.kODPEtU7.js"
  },
  "/_nuxt/index.esm.kQvXSjzx.js": {
    "type": "application/javascript",
    "etag": "\"140b4-4Ab5lHwyU93+VFDzQwkClJ6lPMQ\"",
    "mtime": "2024-02-02T10:24:17.928Z",
    "size": 82100,
    "path": "../public/_nuxt/index.esm.kQvXSjzx.js"
  },
  "/_nuxt/index.gQWT6SPx.js": {
    "type": "application/javascript",
    "etag": "\"bec76-ixc7buFlJZ5pbApQY4IOr3pNkcc\"",
    "mtime": "2024-02-02T10:24:17.948Z",
    "size": 781430,
    "path": "../public/_nuxt/index.gQWT6SPx.js"
  },
  "/_nuxt/index.mZZpEQOf.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"11e-M0t18yx9Fn4KTiGlI2VDuRlRL/w\"",
    "mtime": "2024-02-02T10:24:17.938Z",
    "size": 286,
    "path": "../public/_nuxt/index.mZZpEQOf.css"
  },
  "/_nuxt/index.n8bsD1MY.js": {
    "type": "application/javascript",
    "etag": "\"1e26-34kVBTcNacHu5128vrQGzOT0+pM\"",
    "mtime": "2024-02-02T10:24:17.939Z",
    "size": 7718,
    "path": "../public/_nuxt/index.n8bsD1MY.js"
  },
  "/_nuxt/index.oaL_I3Ka.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-6i7akOyCl6//rMwx0HKgKOxhsqA\"",
    "mtime": "2024-02-02T10:24:17.939Z",
    "size": 1959,
    "path": "../public/_nuxt/index.oaL_I3Ka.css"
  },
  "/_nuxt/index.pEi3zRBh.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-gUO99C2PAvAHwexqtL3Jyllbugw\"",
    "mtime": "2024-02-02T10:24:17.939Z",
    "size": 1959,
    "path": "../public/_nuxt/index.pEi3zRBh.css"
  },
  "/_nuxt/index.v6Rx7pnf.js": {
    "type": "application/javascript",
    "etag": "\"3be6-z8cUH3+oKVjDywCtTADrVkgkLTA\"",
    "mtime": "2024-02-02T10:24:17.949Z",
    "size": 15334,
    "path": "../public/_nuxt/index.v6Rx7pnf.js"
  },
  "/_nuxt/index.vo2QIWYm.js": {
    "type": "application/javascript",
    "etag": "\"2f5-ARosepcLwBVp0NAZxAU9HQUPt/Q\"",
    "mtime": "2024-02-02T10:24:17.940Z",
    "size": 757,
    "path": "../public/_nuxt/index.vo2QIWYm.js"
  },
  "/_nuxt/index.vv2vu54W.js": {
    "type": "application/javascript",
    "etag": "\"562-xcwTXFqvEs9Iz+eBjRP/Ht3cEtY\"",
    "mtime": "2024-02-02T10:24:17.940Z",
    "size": 1378,
    "path": "../public/_nuxt/index.vv2vu54W.js"
  },
  "/_nuxt/index.yY5rFiLh.js": {
    "type": "application/javascript",
    "etag": "\"1ff-RNL0BH49HGoAVbsriokI6I5RUFE\"",
    "mtime": "2024-02-02T10:24:17.943Z",
    "size": 511,
    "path": "../public/_nuxt/index.yY5rFiLh.js"
  },
  "/_nuxt/listbox.ma0SkTED.js": {
    "type": "application/javascript",
    "etag": "\"28d6-KY7XbZwWcbqPPPyQ/pA6UvrK+V8\"",
    "mtime": "2024-02-02T10:24:17.945Z",
    "size": 10454,
    "path": "../public/_nuxt/listbox.ma0SkTED.js"
  },
  "/_nuxt/login.oJpJA0yC.js": {
    "type": "application/javascript",
    "etag": "\"1112-EAtZhza5wfJy7gLlz5mIrwVoaZY\"",
    "mtime": "2024-02-02T10:24:17.940Z",
    "size": 4370,
    "path": "../public/_nuxt/login.oJpJA0yC.js"
  },
  "/_nuxt/logo.0AODuwjp.svg": {
    "type": "image/svg+xml",
    "etag": "\"1b7a-oYe3/5/jej6x3fZoFL6U+QErBuA\"",
    "mtime": "2024-02-02T10:24:17.940Z",
    "size": 7034,
    "path": "../public/_nuxt/logo.0AODuwjp.svg"
  },
  "/_nuxt/mail.kNGna4vI.svg": {
    "type": "image/svg+xml",
    "etag": "\"1da9-9uUlZZ7KqjA7B1Y+Ko6luDvUQJc\"",
    "mtime": "2024-02-02T10:24:17.952Z",
    "size": 7593,
    "path": "../public/_nuxt/mail.kNGna4vI.svg"
  },
  "/_nuxt/menu.dRx0Dpx1.js": {
    "type": "application/javascript",
    "etag": "\"1da2-Ffvy835BksctflGpAARPpoMciFU\"",
    "mtime": "2024-02-02T10:24:17.941Z",
    "size": 7586,
    "path": "../public/_nuxt/menu.dRx0Dpx1.js"
  },
  "/_nuxt/moment.U6uhAU_N.js": {
    "type": "application/javascript",
    "etag": "\"ea6a-wqEkpAGnYlIUL95I51yueHlcBfY\"",
    "mtime": "2024-02-02T10:24:17.941Z",
    "size": 60010,
    "path": "../public/_nuxt/moment.U6uhAU_N.js"
  },
  "/_nuxt/my-orders.XnEVR_tn.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-Ca9R5ou/dg9zbpgRL2ABo8DyXyY\"",
    "mtime": "2024-02-02T10:24:17.942Z",
    "size": 1959,
    "path": "../public/_nuxt/my-orders.XnEVR_tn.css"
  },
  "/_nuxt/my-orders.sOyypbYm.js": {
    "type": "application/javascript",
    "etag": "\"2efd-/8VfxKYK+f9SMrlQZa1VbiZPxNI\"",
    "mtime": "2024-02-02T10:24:17.941Z",
    "size": 12029,
    "path": "../public/_nuxt/my-orders.sOyypbYm.js"
  },
  "/_nuxt/my-requests.4jwjNP1I.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"26fd-5ojWouC/OGIvRmqHOR/8ov4WYWQ\"",
    "mtime": "2024-02-02T10:24:17.942Z",
    "size": 9981,
    "path": "../public/_nuxt/my-requests.4jwjNP1I.css"
  },
  "/_nuxt/my-requests.z7a4Fc2M.js": {
    "type": "application/javascript",
    "etag": "\"a04a-1Usm8F6K7MefJm4nwDWtquMqUQ4\"",
    "mtime": "2024-02-02T10:24:17.945Z",
    "size": 41034,
    "path": "../public/_nuxt/my-requests.z7a4Fc2M.js"
  },
  "/_nuxt/new.cesEXYWg.js": {
    "type": "application/javascript",
    "etag": "\"1107-l9IYWu7vdLRUntOdFAUHIS6PnUU\"",
    "mtime": "2024-02-02T10:24:17.941Z",
    "size": 4359,
    "path": "../public/_nuxt/new.cesEXYWg.js"
  },
  "/_nuxt/new.o29_2yQG.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-mF4qITLkTVAQAPFIXuCyB6I++t8\"",
    "mtime": "2024-02-02T10:24:17.942Z",
    "size": 1959,
    "path": "../public/_nuxt/new.o29_2yQG.css"
  },
  "/_nuxt/notifications.4f0iq3rc.js": {
    "type": "application/javascript",
    "etag": "\"21ab-eymOfigPHeUQcOwQTx3/u8YmIq0\"",
    "mtime": "2024-02-02T10:24:17.942Z",
    "size": 8619,
    "path": "../public/_nuxt/notifications.4f0iq3rc.js"
  },
  "/_nuxt/notifications.fPXG9bSe.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-zbkHP4mkqOym33Nog6Efuo3RrkQ\"",
    "mtime": "2024-02-02T10:24:17.951Z",
    "size": 1959,
    "path": "../public/_nuxt/notifications.fPXG9bSe.css"
  },
  "/_nuxt/nuxt-img.HKwtr8s8.js": {
    "type": "application/javascript",
    "etag": "\"c56-i7T0yJGt6TcYYYBkksyjV1CBmBU\"",
    "mtime": "2024-02-02T10:24:17.943Z",
    "size": 3158,
    "path": "../public/_nuxt/nuxt-img.HKwtr8s8.js"
  },
  "/_nuxt/nuxt-link.i5p0d-Sz.js": {
    "type": "application/javascript",
    "etag": "\"1087-5P4k6FC2E6myPxXNxTwYsf182IU\"",
    "mtime": "2024-02-02T10:24:17.945Z",
    "size": 4231,
    "path": "../public/_nuxt/nuxt-link.i5p0d-Sz.js"
  },
  "/_nuxt/onboarding.H7TbYMkV.js": {
    "type": "application/javascript",
    "etag": "\"1be-Z5YP2qr68OI/a/yYphCFTsBfSxc\"",
    "mtime": "2024-02-02T10:24:17.947Z",
    "size": 446,
    "path": "../public/_nuxt/onboarding.H7TbYMkV.js"
  },
  "/_nuxt/onboardingservices.isPIK40V.js": {
    "type": "application/javascript",
    "etag": "\"1dc-xwwTRdIx8FhB1fRSJtR5YEs7nSE\"",
    "mtime": "2024-02-02T10:24:17.944Z",
    "size": 476,
    "path": "../public/_nuxt/onboardingservices.isPIK40V.js"
  },
  "/_nuxt/order-success.UkE9L7Hn.js": {
    "type": "application/javascript",
    "etag": "\"546-SjnhtoaWol58pCJXHbYqQznC+qw\"",
    "mtime": "2024-02-02T10:24:17.946Z",
    "size": 1350,
    "path": "../public/_nuxt/order-success.UkE9L7Hn.js"
  },
  "/_nuxt/orders.J-DVilz_.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-e5xKQPbPNh1fHturhmrnrI4lbIk\"",
    "mtime": "2024-02-02T10:24:17.946Z",
    "size": 1959,
    "path": "../public/_nuxt/orders.J-DVilz_.css"
  },
  "/_nuxt/orders.k9KLE17U.js": {
    "type": "application/javascript",
    "etag": "\"1cb2-FRuuaNOJoK8TtjnFm6B6ov/hNk0\"",
    "mtime": "2024-02-02T10:24:17.947Z",
    "size": 7346,
    "path": "../public/_nuxt/orders.k9KLE17U.js"
  },
  "/_nuxt/overview.YYULU6xF.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"6475-iszTn9O+7qBlJ1ju/cYCyR8GICs\"",
    "mtime": "2024-02-02T10:24:17.948Z",
    "size": 25717,
    "path": "../public/_nuxt/overview.YYULU6xF.css"
  },
  "/_nuxt/overview.h09JItYI.js": {
    "type": "application/javascript",
    "etag": "\"23eed-/F1Dr12xReF4mRN8YetrKgRQvzY\"",
    "mtime": "2024-02-02T10:24:17.949Z",
    "size": 147181,
    "path": "../public/_nuxt/overview.h09JItYI.js"
  },
  "/_nuxt/personal.49Icfeev.js": {
    "type": "application/javascript",
    "etag": "\"3457-fR15K/hBNAMEtqD60THQ/u+UF8Y\"",
    "mtime": "2024-02-02T10:24:17.949Z",
    "size": 13399,
    "path": "../public/_nuxt/personal.49Icfeev.js"
  },
  "/_nuxt/personal.vunFAwHl.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-dKRcTx4d9VduLu9F/Jh8qvtt1cY\"",
    "mtime": "2024-02-02T10:24:17.950Z",
    "size": 1959,
    "path": "../public/_nuxt/personal.vunFAwHl.css"
  },
  "/_nuxt/policy.5K3pHnVe.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"195-7ArqI/UR/8KmuXEXYcUaN68yvz4\"",
    "mtime": "2024-02-02T10:24:17.950Z",
    "size": 405,
    "path": "../public/_nuxt/policy.5K3pHnVe.css"
  },
  "/_nuxt/policy.7WdamJBA.js": {
    "type": "application/javascript",
    "etag": "\"536c-WnCtra8IfTVw6Wjovsg03Z3CtSg\"",
    "mtime": "2024-02-02T10:24:17.951Z",
    "size": 21356,
    "path": "../public/_nuxt/policy.7WdamJBA.js"
  },
  "/_nuxt/procurementservice.jNdmaskD.js": {
    "type": "application/javascript",
    "etag": "\"346-KUOsgl9ZMOelMGgZSYwjd8aQogA\"",
    "mtime": "2024-02-02T10:24:17.950Z",
    "size": 838,
    "path": "../public/_nuxt/procurementservice.jNdmaskD.js"
  },
  "/_nuxt/quoteservice.wYf6YacB.js": {
    "type": "application/javascript",
    "etag": "\"312-shnnOGIih8VbtSMaeHt5xaKdCWk\"",
    "mtime": "2024-02-02T10:24:17.950Z",
    "size": 786,
    "path": "../public/_nuxt/quoteservice.wYf6YacB.js"
  },
  "/_nuxt/register.LcTbrjHX.js": {
    "type": "application/javascript",
    "etag": "\"141b-KGEqP3niqYPCAzWhSPJGrwohU8Y\"",
    "mtime": "2024-02-02T10:24:17.959Z",
    "size": 5147,
    "path": "../public/_nuxt/register.LcTbrjHX.js"
  },
  "/_nuxt/register.vgsTUyqx.js": {
    "type": "application/javascript",
    "etag": "\"c19-9VzYvJrZ/jRKDvqYTBcKtFVFzjc\"",
    "mtime": "2024-02-02T10:24:17.955Z",
    "size": 3097,
    "path": "../public/_nuxt/register.vgsTUyqx.js"
  },
  "/_nuxt/replaceCountryCode.5oONUebo.js": {
    "type": "application/javascript",
    "etag": "\"bf-Vr9ptcuStGsD9AQuJJSDs4ryaUc\"",
    "mtime": "2024-02-02T10:24:18.007Z",
    "size": 191,
    "path": "../public/_nuxt/replaceCountryCode.5oONUebo.js"
  },
  "/_nuxt/request-product.nsihlUVd.js": {
    "type": "application/javascript",
    "etag": "\"2723-XA2SAR1WP43TKrka4ceSB0MLFkc\"",
    "mtime": "2024-02-02T10:24:17.951Z",
    "size": 10019,
    "path": "../public/_nuxt/request-product.nsihlUVd.js"
  },
  "/_nuxt/requests.QbbpgJoh.js": {
    "type": "application/javascript",
    "etag": "\"8192-PWpzsXJLjhvm896LzJ22DMuyCyw\"",
    "mtime": "2024-02-02T10:24:17.956Z",
    "size": 33170,
    "path": "../public/_nuxt/requests.QbbpgJoh.js"
  },
  "/_nuxt/requests.YqacystV.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1f57-sry3wQCyAxmB6uqg0BgEssXS09c\"",
    "mtime": "2024-02-02T10:24:17.951Z",
    "size": 8023,
    "path": "../public/_nuxt/requests.YqacystV.css"
  },
  "/_nuxt/requestservice.wtfX65Lm.js": {
    "type": "application/javascript",
    "etag": "\"566-CBWkUc+uo5uZ4MeZ56MdgFoTdjk\"",
    "mtime": "2024-02-02T10:24:17.951Z",
    "size": 1382,
    "path": "../public/_nuxt/requestservice.wtfX65Lm.js"
  },
  "/_nuxt/reset-password.6YM8FAUG.js": {
    "type": "application/javascript",
    "etag": "\"b03-0cweGld1EoeP4O+KdM52/xJxxz0\"",
    "mtime": "2024-02-02T10:24:17.951Z",
    "size": 2819,
    "path": "../public/_nuxt/reset-password.6YM8FAUG.js"
  },
  "/_nuxt/retry-handling.ImLN2kBi.js": {
    "type": "application/javascript",
    "etag": "\"113-KGL4uX4Q3T6RrPyukzsl9Wg2yes\"",
    "mtime": "2024-02-02T10:24:17.952Z",
    "size": 275,
    "path": "../public/_nuxt/retry-handling.ImLN2kBi.js"
  },
  "/_nuxt/saved-searches.TDuJgzi8.js": {
    "type": "application/javascript",
    "etag": "\"68d-XBS8afbhVnHuJHv4vqDI80L5QrI\"",
    "mtime": "2024-02-02T10:24:17.952Z",
    "size": 1677,
    "path": "../public/_nuxt/saved-searches.TDuJgzi8.js"
  },
  "/_nuxt/saved-searches.vptTStW3.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-cdLSU3A3swDr3yBk6SWM/qDKteI\"",
    "mtime": "2024-02-02T10:24:17.952Z",
    "size": 1959,
    "path": "../public/_nuxt/saved-searches.vptTStW3.css"
  },
  "/_nuxt/settings.1d8eN0u4.js": {
    "type": "application/javascript",
    "etag": "\"436d-x8NnMWy1RxL7I020BymhhjL4xSE\"",
    "mtime": "2024-02-02T10:24:17.958Z",
    "size": 17261,
    "path": "../public/_nuxt/settings.1d8eN0u4.js"
  },
  "/_nuxt/settings.61uarlqI.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1e99-QJ/L4YoQrAEbZsM8JQZYjA+5Ga4\"",
    "mtime": "2024-02-02T10:24:17.953Z",
    "size": 7833,
    "path": "../public/_nuxt/settings.61uarlqI.css"
  },
  "/_nuxt/settings.FmjzhAHC.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-kfSsOJM2TDHxGfharYtyHXBvvX4\"",
    "mtime": "2024-02-02T10:24:17.953Z",
    "size": 1959,
    "path": "../public/_nuxt/settings.FmjzhAHC.css"
  },
  "/_nuxt/settings.QjvNAO7_.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-VYOWsU3KTbdDBqC0kFEpmBTGSBk\"",
    "mtime": "2024-02-02T10:24:17.953Z",
    "size": 1959,
    "path": "../public/_nuxt/settings.QjvNAO7_.css"
  },
  "/_nuxt/settings.c0igHJ1t.js": {
    "type": "application/javascript",
    "etag": "\"382d-icr07arxKM+85bW/rEAR9IQRCm8\"",
    "mtime": "2024-02-02T10:24:17.959Z",
    "size": 14381,
    "path": "../public/_nuxt/settings.c0igHJ1t.js"
  },
  "/_nuxt/settings.pOc4n0lF.js": {
    "type": "application/javascript",
    "etag": "\"75e-ZmtDCazjs/Z9RzB9hmzqIU36rMA\"",
    "mtime": "2024-02-02T10:24:17.953Z",
    "size": 1886,
    "path": "../public/_nuxt/settings.pOc4n0lF.js"
  },
  "/_nuxt/settingservices.QUA4tSsw.js": {
    "type": "application/javascript",
    "etag": "\"381-Zw0zNKP7lYatrf7K1JUCNeMmWZw\"",
    "mtime": "2024-02-02T10:24:17.953Z",
    "size": 897,
    "path": "../public/_nuxt/settingservices.QUA4tSsw.js"
  },
  "/_nuxt/shipping-addresses.p-JVmd5O.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-osm12sY1oOwpKZWsk9y/ZgKI4ng\"",
    "mtime": "2024-02-02T10:24:17.953Z",
    "size": 1959,
    "path": "../public/_nuxt/shipping-addresses.p-JVmd5O.css"
  },
  "/_nuxt/shipping-addresses.wECSlSCY.js": {
    "type": "application/javascript",
    "etag": "\"c55-2bSxHtskf5lDfSm9VKeaWuIENq0\"",
    "mtime": "2024-02-02T10:24:17.954Z",
    "size": 3157,
    "path": "../public/_nuxt/shipping-addresses.wECSlSCY.js"
  },
  "/_nuxt/shipping.H2Ll0sn3.js": {
    "type": "application/javascript",
    "etag": "\"1e1f-T969Wto0n7Z9dPmDX06PvM4trZU\"",
    "mtime": "2024-02-02T10:24:17.954Z",
    "size": 7711,
    "path": "../public/_nuxt/shipping.H2Ll0sn3.js"
  },
  "/_nuxt/style.WU5a8wCA.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"10b7-z+ZHKZHy0sAa+P7/w7Hkx2ocKBo\"",
    "mtime": "2024-02-02T10:24:17.953Z",
    "size": 4279,
    "path": "../public/_nuxt/style.WU5a8wCA.css"
  },
  "/_nuxt/supplier.ze62QSVJ.js": {
    "type": "application/javascript",
    "etag": "\"376-rv1e3ILpg0Vk/p+Vjr9NEbR9Te0\"",
    "mtime": "2024-02-02T10:24:17.954Z",
    "size": 886,
    "path": "../public/_nuxt/supplier.ze62QSVJ.js"
  },
  "/_nuxt/swiper-vue.fELadPwW.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"478f-DzGvnMvBlX0SkLPiatuO+LZZ5qw\"",
    "mtime": "2024-02-02T10:24:17.954Z",
    "size": 18319,
    "path": "../public/_nuxt/swiper-vue.fELadPwW.css"
  },
  "/_nuxt/terms.5NadKw-f.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1a7-74ffsyBE68dxl/2Ce94mMRVySNk\"",
    "mtime": "2024-02-02T10:24:17.954Z",
    "size": 423,
    "path": "../public/_nuxt/terms.5NadKw-f.css"
  },
  "/_nuxt/terms.O_TXil4s.js": {
    "type": "application/javascript",
    "etag": "\"56b0-wpYtSMCmPCmP9NN1kwRQxZB6UDE\"",
    "mtime": "2024-02-02T10:24:17.954Z",
    "size": 22192,
    "path": "../public/_nuxt/terms.O_TXil4s.js"
  },
  "/_nuxt/transactions.phRxZYDm.js": {
    "type": "application/javascript",
    "etag": "\"e58-AFnUmCzXzG1vFSnScYlwR3L9+S0\"",
    "mtime": "2024-02-02T10:24:17.958Z",
    "size": 3672,
    "path": "../public/_nuxt/transactions.phRxZYDm.js"
  },
  "/_nuxt/transactions.wux4Btcn.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a7-nEU5AIywF5viW+U3Kz32k6QKAek\"",
    "mtime": "2024-02-02T10:24:17.955Z",
    "size": 1959,
    "path": "../public/_nuxt/transactions.wux4Btcn.css"
  },
  "/_nuxt/transition.OMLt14Qq.js": {
    "type": "application/javascript",
    "etag": "\"5867-fpjM18dhcK2QTzSeuVY6I1NWUo0\"",
    "mtime": "2024-02-02T10:24:17.955Z",
    "size": 22631,
    "path": "../public/_nuxt/transition.OMLt14Qq.js"
  },
  "/_nuxt/ucFirst.a5qgXy6T.js": {
    "type": "application/javascript",
    "etag": "\"b8c-4RtJNQvCmxUfWP48c1ATvB+eHlM\"",
    "mtime": "2024-02-02T10:24:17.955Z",
    "size": 2956,
    "path": "../public/_nuxt/ucFirst.a5qgXy6T.js"
  },
  "/_nuxt/use-controllable.cGF3QaPj.js": {
    "type": "application/javascript",
    "etag": "\"3c1-qQKohXDyrEtFEDUc0WNJ28a8PIQ\"",
    "mtime": "2024-02-02T10:24:17.955Z",
    "size": 961,
    "path": "../public/_nuxt/use-controllable.cGF3QaPj.js"
  },
  "/_nuxt/use-outside-click.SyOzhn-r.js": {
    "type": "application/javascript",
    "etag": "\"1478-aG9Mp4buPY1OD2F4kmFTmma9m74\"",
    "mtime": "2024-02-02T10:24:17.956Z",
    "size": 5240,
    "path": "../public/_nuxt/use-outside-click.SyOzhn-r.js"
  },
  "/_nuxt/use-resolve-button-type.Rw7MgWU2.js": {
    "type": "application/javascript",
    "etag": "\"1c2-5idBDtkwKN/028eyWAOinwQsPjQ\"",
    "mtime": "2024-02-02T10:24:17.958Z",
    "size": 450,
    "path": "../public/_nuxt/use-resolve-button-type.Rw7MgWU2.js"
  },
  "/_nuxt/use-text-value.lcYP8To1.js": {
    "type": "application/javascript",
    "etag": "\"80c-Jm2KYsiyjMMYlIvoS/oo7juO4Gg\"",
    "mtime": "2024-02-02T10:24:17.957Z",
    "size": 2060,
    "path": "../public/_nuxt/use-text-value.lcYP8To1.js"
  },
  "/_nuxt/use-tree-walker.vxquv35S.js": {
    "type": "application/javascript",
    "etag": "\"177-TUU1L4DG/wImrJBEAWNPyS1+s2U\"",
    "mtime": "2024-02-02T10:24:17.956Z",
    "size": 375,
    "path": "../public/_nuxt/use-tree-walker.vxquv35S.js"
  },
  "/_nuxt/user-management.cjujjAjA.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"f4d-c1AAJQ+mPhtyNFW57sAnez8FNeU\"",
    "mtime": "2024-02-02T10:24:17.956Z",
    "size": 3917,
    "path": "../public/_nuxt/user-management.cjujjAjA.css"
  },
  "/_nuxt/user-management.pL79cMmW.js": {
    "type": "application/javascript",
    "etag": "\"35d3-DKNH7i248BqPkjrRAIn1G+MlRQI\"",
    "mtime": "2024-02-02T10:24:17.956Z",
    "size": 13779,
    "path": "../public/_nuxt/user-management.pL79cMmW.js"
  },
  "/_nuxt/userservices.ez7GX_bF.js": {
    "type": "application/javascript",
    "etag": "\"3e8-d/Fh/ISxWDIClhVQrOFFSZyu7Rw\"",
    "mtime": "2024-02-02T10:24:17.956Z",
    "size": 1000,
    "path": "../public/_nuxt/userservices.ez7GX_bF.js"
  },
  "/_nuxt/vendor-register.IFZAgs75.js": {
    "type": "application/javascript",
    "etag": "\"151b-KxR+dPd6tSfTVOT822hnlCZG7/c\"",
    "mtime": "2024-02-02T10:24:17.957Z",
    "size": 5403,
    "path": "../public/_nuxt/vendor-register.IFZAgs75.js"
  },
  "/_nuxt/walletservice.JLqyKZem.js": {
    "type": "application/javascript",
    "etag": "\"2fd-j7qi5ehfuZYck+e7MxdqPnh6Rm4\"",
    "mtime": "2024-02-02T10:24:17.957Z",
    "size": 765,
    "path": "../public/_nuxt/walletservice.JLqyKZem.js"
  },
  "/_nuxt/whatsapp.11g7H9tU.png": {
    "type": "image/png",
    "etag": "\"4f3d-xFjpoIj5+7gyDXY8CN3nmKp68AA\"",
    "mtime": "2024-02-02T10:24:17.959Z",
    "size": 20285,
    "path": "../public/_nuxt/whatsapp.11g7H9tU.png"
  },
  "/_nuxt/workbox-window.prod.es5.prqDwDSL.js": {
    "type": "application/javascript",
    "etag": "\"14a9-PgD6LVq3AWVnktFTXJIaapz+xFw\"",
    "mtime": "2024-02-02T10:24:17.957Z",
    "size": 5289,
    "path": "../public/_nuxt/workbox-window.prod.es5.prqDwDSL.js"
  },
  "/_nuxt/wrapper.3V4OFfi4.png": {
    "type": "image/png",
    "etag": "\"b64b-4l++jFv4cQSx41IZP99GtE0hzsc\"",
    "mtime": "2024-02-02T10:24:17.958Z",
    "size": 46667,
    "path": "../public/_nuxt/wrapper.3V4OFfi4.png"
  },
  "/cart/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-pGWGfYbqTQ5z/FZDqXbzMcBeeEk\"",
    "mtime": "2024-02-02T10:23:59.781Z",
    "size": 62,
    "path": "../public/cart/_payload.json"
  },
  "/cart/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3ebc9-xoz4V1aqedhDgKfzEdHCpndLPmI\"",
    "mtime": "2024-02-02T10:23:58.943Z",
    "size": 256969,
    "path": "../public/cart/index.html"
  },
  "/checkout/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-kGn/lxdzerc3TzJwAjzHSG3p1GI\"",
    "mtime": "2024-02-02T10:24:00.261Z",
    "size": 62,
    "path": "../public/checkout/_payload.json"
  },
  "/checkout/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3de38-NdTG7Quit0DFAB4wdhtvU1orbB0\"",
    "mtime": "2024-02-02T10:24:00.039Z",
    "size": 253496,
    "path": "../public/checkout/index.html"
  },
  "/css/nuxt-google-fonts.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3175-ICV/i5NYQ2HOp2pubpfSuq7NAbo\"",
    "mtime": "2024-02-02T10:24:17.730Z",
    "size": 12661,
    "path": "../public/css/nuxt-google-fonts.css"
  },
  "/finance/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-OZCYcoHwoPTbAcFM89QH2ZhOh2I\"",
    "mtime": "2024-02-02T10:23:59.688Z",
    "size": 62,
    "path": "../public/finance/_payload.json"
  },
  "/finance/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3dd54-skztUd2Pw7u86ucAT63Lcw4g0Vc\"",
    "mtime": "2024-02-02T10:23:58.942Z",
    "size": 253268,
    "path": "../public/finance/index.html"
  },
  "/icons/android-icon-144x144.png": {
    "type": "image/png",
    "etag": "\"24b1-MEfBRniAWNMqz3g8KP+Qaz1EhDw\"",
    "mtime": "2024-02-02T10:24:18.051Z",
    "size": 9393,
    "path": "../public/icons/android-icon-144x144.png"
  },
  "/icons/android-icon-192x192.png": {
    "type": "image/png",
    "etag": "\"2eb0-4f1um7XmcSQAoXJHSgJau8HRy4U\"",
    "mtime": "2024-02-02T10:24:18.080Z",
    "size": 11952,
    "path": "../public/icons/android-icon-192x192.png"
  },
  "/icons/android-icon-36x36.png": {
    "type": "image/png",
    "etag": "\"8ca-KUvjtuSvlp3deiwHQy17jHy3b40\"",
    "mtime": "2024-02-02T10:24:18.052Z",
    "size": 2250,
    "path": "../public/icons/android-icon-36x36.png"
  },
  "/icons/android-icon-48x48.png": {
    "type": "image/png",
    "etag": "\"b81-8C28stvNt/WPNi6sd6l4g8lw+Wg\"",
    "mtime": "2024-02-02T10:24:18.053Z",
    "size": 2945,
    "path": "../public/icons/android-icon-48x48.png"
  },
  "/icons/android-icon-72x72.png": {
    "type": "image/png",
    "etag": "\"10f3-s4usgENjO+idR2wYF5+gnafzXdM\"",
    "mtime": "2024-02-02T10:24:18.053Z",
    "size": 4339,
    "path": "../public/icons/android-icon-72x72.png"
  },
  "/icons/android-icon-96x96.png": {
    "type": "image/png",
    "etag": "\"1752-bB74mfNTQhYQL4mtkYH8UJCsn3E\"",
    "mtime": "2024-02-02T10:24:18.053Z",
    "size": 5970,
    "path": "../public/icons/android-icon-96x96.png"
  },
  "/icons/apple-icon-114x114.png": {
    "type": "image/png",
    "etag": "\"1b89-iDyltenxoV5ueI5Rs5DmUIomw/o\"",
    "mtime": "2024-02-02T10:24:18.053Z",
    "size": 7049,
    "path": "../public/icons/apple-icon-114x114.png"
  },
  "/icons/apple-icon-120x120.png": {
    "type": "image/png",
    "etag": "\"1e13-X9Ksf77WyJke2iGGQgFQp6ffVSs\"",
    "mtime": "2024-02-02T10:24:18.054Z",
    "size": 7699,
    "path": "../public/icons/apple-icon-120x120.png"
  },
  "/icons/apple-icon-144x144.png": {
    "type": "image/png",
    "etag": "\"24b1-MEfBRniAWNMqz3g8KP+Qaz1EhDw\"",
    "mtime": "2024-02-02T10:24:18.053Z",
    "size": 9393,
    "path": "../public/icons/apple-icon-144x144.png"
  },
  "/icons/apple-icon-152x152.png": {
    "type": "image/png",
    "etag": "\"27e5-p31gx25HEjS+u5/VgboMdGm+GNQ\"",
    "mtime": "2024-02-02T10:24:18.054Z",
    "size": 10213,
    "path": "../public/icons/apple-icon-152x152.png"
  },
  "/icons/apple-icon-180x180.png": {
    "type": "image/png",
    "etag": "\"30e5-TtGuPFvuIxo+GmVPrIFwdryXMNI\"",
    "mtime": "2024-02-02T10:24:18.054Z",
    "size": 12517,
    "path": "../public/icons/apple-icon-180x180.png"
  },
  "/icons/apple-icon-57x57.png": {
    "type": "image/png",
    "etag": "\"d4f-gpjJz8MCJysi7bC8Sha/hYgb3MA\"",
    "mtime": "2024-02-02T10:24:18.084Z",
    "size": 3407,
    "path": "../public/icons/apple-icon-57x57.png"
  },
  "/icons/apple-icon-60x60.png": {
    "type": "image/png",
    "etag": "\"ded-IUjKSpLpIsDM8/l+CYmM0LgTr6M\"",
    "mtime": "2024-02-02T10:24:18.053Z",
    "size": 3565,
    "path": "../public/icons/apple-icon-60x60.png"
  },
  "/icons/apple-icon-72x72.png": {
    "type": "image/png",
    "etag": "\"10f3-s4usgENjO+idR2wYF5+gnafzXdM\"",
    "mtime": "2024-02-02T10:24:18.054Z",
    "size": 4339,
    "path": "../public/icons/apple-icon-72x72.png"
  },
  "/icons/apple-icon-76x76.png": {
    "type": "image/png",
    "etag": "\"11a5-c839HdLx4UkFgcCxY8HP5GxFNys\"",
    "mtime": "2024-02-02T10:24:18.055Z",
    "size": 4517,
    "path": "../public/icons/apple-icon-76x76.png"
  },
  "/icons/apple-icon-precomposed.png": {
    "type": "image/png",
    "etag": "\"30ce-qLoWl2iCUbbX06nBZSCUyA61EPM\"",
    "mtime": "2024-02-02T10:24:18.054Z",
    "size": 12494,
    "path": "../public/icons/apple-icon-precomposed.png"
  },
  "/icons/apple-icon.png": {
    "type": "image/png",
    "etag": "\"30ce-qLoWl2iCUbbX06nBZSCUyA61EPM\"",
    "mtime": "2024-02-02T10:24:18.055Z",
    "size": 12494,
    "path": "../public/icons/apple-icon.png"
  },
  "/icons/browserconfig.xml": {
    "type": "application/xml",
    "etag": "\"119-hTOJtsQnOWWJnrEwLWZeuROV/Qw\"",
    "mtime": "2024-02-02T10:24:18.055Z",
    "size": 281,
    "path": "../public/icons/browserconfig.xml"
  },
  "/icons/favicon-16x16.png": {
    "type": "image/png",
    "etag": "\"583-HirTvwzvHTs9RJsMa4ui77DNaBY\"",
    "mtime": "2024-02-02T10:24:18.055Z",
    "size": 1411,
    "path": "../public/icons/favicon-16x16.png"
  },
  "/icons/favicon-32x32.png": {
    "type": "image/png",
    "etag": "\"7c6-1PrxfIIk9ihATO9l+f89Dok5cGc\"",
    "mtime": "2024-02-02T10:24:18.055Z",
    "size": 1990,
    "path": "../public/icons/favicon-32x32.png"
  },
  "/icons/favicon-96x96.png": {
    "type": "image/png",
    "etag": "\"1752-bB74mfNTQhYQL4mtkYH8UJCsn3E\"",
    "mtime": "2024-02-02T10:24:18.055Z",
    "size": 5970,
    "path": "../public/icons/favicon-96x96.png"
  },
  "/icons/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"47e-vN/GySwSCH6ZGhoyi5wx+kESMTE\"",
    "mtime": "2024-02-02T10:24:18.110Z",
    "size": 1150,
    "path": "../public/icons/favicon.ico"
  },
  "/icons/favicon.svg": {
    "type": "image/svg+xml",
    "etag": "\"721-OIwOCrr4+6rP5kCK5jtvGhCtQto\"",
    "mtime": "2024-02-02T10:24:18.055Z",
    "size": 1825,
    "path": "../public/icons/favicon.svg"
  },
  "/icons/ms-icon-144x144.png": {
    "type": "image/png",
    "etag": "\"24b1-MEfBRniAWNMqz3g8KP+Qaz1EhDw\"",
    "mtime": "2024-02-02T10:24:18.056Z",
    "size": 9393,
    "path": "../public/icons/ms-icon-144x144.png"
  },
  "/icons/ms-icon-150x150.png": {
    "type": "image/png",
    "etag": "\"2717-Rq2V4nbAixDsAkW5+DdPa0kHxFE\"",
    "mtime": "2024-02-02T10:24:18.074Z",
    "size": 10007,
    "path": "../public/icons/ms-icon-150x150.png"
  },
  "/icons/ms-icon-310x310.png": {
    "type": "image/png",
    "etag": "\"6d2a-xViC3CN2G7fInhhDG2wjm6/BKUU\"",
    "mtime": "2024-02-02T10:24:18.056Z",
    "size": 27946,
    "path": "../public/icons/ms-icon-310x310.png"
  },
  "/icons/ms-icon-70x70.png": {
    "type": "image/png",
    "etag": "\"106e-G80MIXch1ZrrL61hjN5PUO6Yq18\"",
    "mtime": "2024-02-02T10:24:18.056Z",
    "size": 4206,
    "path": "../public/icons/ms-icon-70x70.png"
  },
  "/fonts/Manrope-200-1.woff2": {
    "type": "font/woff2",
    "etag": "\"9c4-ONuPwALKIAeIOpZlTrPEkKsL8l4\"",
    "mtime": "2024-02-02T10:24:17.731Z",
    "size": 2500,
    "path": "../public/fonts/Manrope-200-1.woff2"
  },
  "/fonts/Manrope-200-2.woff2": {
    "type": "font/woff2",
    "etag": "\"377c-P21Fqhq8FZlQh3pIAJ4/dq083JM\"",
    "mtime": "2024-02-02T10:24:17.732Z",
    "size": 14204,
    "path": "../public/fonts/Manrope-200-2.woff2"
  },
  "/fonts/Manrope-200-3.woff2": {
    "type": "font/woff2",
    "etag": "\"23e8-8oyWLnQHg7DeSfhU688gTUaZW+c\"",
    "mtime": "2024-02-02T10:24:17.728Z",
    "size": 9192,
    "path": "../public/fonts/Manrope-200-3.woff2"
  },
  "/fonts/Manrope-200-4.woff2": {
    "type": "font/woff2",
    "etag": "\"2074-atSB0WLl08CdnVgpghvv7le/9lk\"",
    "mtime": "2024-02-02T10:24:17.728Z",
    "size": 8308,
    "path": "../public/fonts/Manrope-200-4.woff2"
  },
  "/fonts/Manrope-200-5.woff2": {
    "type": "font/woff2",
    "etag": "\"39d4-DnKHMntuQ0aSkandFFZMXbB/A64\"",
    "mtime": "2024-02-02T10:24:17.729Z",
    "size": 14804,
    "path": "../public/fonts/Manrope-200-5.woff2"
  },
  "/fonts/Manrope-200-6.woff2": {
    "type": "font/woff2",
    "etag": "\"5f38-chBgcZmLDvXxRepPnVNFnlKjPp8\"",
    "mtime": "2024-02-02T10:24:17.729Z",
    "size": 24376,
    "path": "../public/fonts/Manrope-200-6.woff2"
  },
  "/fonts/Manrope-300-10.woff2": {
    "type": "font/woff2",
    "etag": "\"2074-atSB0WLl08CdnVgpghvv7le/9lk\"",
    "mtime": "2024-02-02T10:24:17.729Z",
    "size": 8308,
    "path": "../public/fonts/Manrope-300-10.woff2"
  },
  "/fonts/Manrope-300-11.woff2": {
    "type": "font/woff2",
    "etag": "\"39d4-DnKHMntuQ0aSkandFFZMXbB/A64\"",
    "mtime": "2024-02-02T10:24:17.728Z",
    "size": 14804,
    "path": "../public/fonts/Manrope-300-11.woff2"
  },
  "/fonts/Manrope-300-12.woff2": {
    "type": "font/woff2",
    "etag": "\"5f38-chBgcZmLDvXxRepPnVNFnlKjPp8\"",
    "mtime": "2024-02-02T10:24:17.730Z",
    "size": 24376,
    "path": "../public/fonts/Manrope-300-12.woff2"
  },
  "/fonts/Manrope-300-7.woff2": {
    "type": "font/woff2",
    "etag": "\"9c4-ONuPwALKIAeIOpZlTrPEkKsL8l4\"",
    "mtime": "2024-02-02T10:24:17.739Z",
    "size": 2500,
    "path": "../public/fonts/Manrope-300-7.woff2"
  },
  "/fonts/Manrope-300-8.woff2": {
    "type": "font/woff2",
    "etag": "\"377c-P21Fqhq8FZlQh3pIAJ4/dq083JM\"",
    "mtime": "2024-02-02T10:24:17.731Z",
    "size": 14204,
    "path": "../public/fonts/Manrope-300-8.woff2"
  },
  "/fonts/Manrope-300-9.woff2": {
    "type": "font/woff2",
    "etag": "\"23e8-8oyWLnQHg7DeSfhU688gTUaZW+c\"",
    "mtime": "2024-02-02T10:24:17.730Z",
    "size": 9192,
    "path": "../public/fonts/Manrope-300-9.woff2"
  },
  "/fonts/Manrope-400-13.woff2": {
    "type": "font/woff2",
    "etag": "\"9c4-ONuPwALKIAeIOpZlTrPEkKsL8l4\"",
    "mtime": "2024-02-02T10:24:17.729Z",
    "size": 2500,
    "path": "../public/fonts/Manrope-400-13.woff2"
  },
  "/fonts/Manrope-400-14.woff2": {
    "type": "font/woff2",
    "etag": "\"377c-P21Fqhq8FZlQh3pIAJ4/dq083JM\"",
    "mtime": "2024-02-02T10:24:17.733Z",
    "size": 14204,
    "path": "../public/fonts/Manrope-400-14.woff2"
  },
  "/fonts/Manrope-400-15.woff2": {
    "type": "font/woff2",
    "etag": "\"23e8-8oyWLnQHg7DeSfhU688gTUaZW+c\"",
    "mtime": "2024-02-02T10:24:17.731Z",
    "size": 9192,
    "path": "../public/fonts/Manrope-400-15.woff2"
  },
  "/fonts/Manrope-400-16.woff2": {
    "type": "font/woff2",
    "etag": "\"2074-atSB0WLl08CdnVgpghvv7le/9lk\"",
    "mtime": "2024-02-02T10:24:17.733Z",
    "size": 8308,
    "path": "../public/fonts/Manrope-400-16.woff2"
  },
  "/fonts/Manrope-400-17.woff2": {
    "type": "font/woff2",
    "etag": "\"39d4-DnKHMntuQ0aSkandFFZMXbB/A64\"",
    "mtime": "2024-02-02T10:24:17.732Z",
    "size": 14804,
    "path": "../public/fonts/Manrope-400-17.woff2"
  },
  "/fonts/Manrope-400-18.woff2": {
    "type": "font/woff2",
    "etag": "\"5f38-chBgcZmLDvXxRepPnVNFnlKjPp8\"",
    "mtime": "2024-02-02T10:24:17.732Z",
    "size": 24376,
    "path": "../public/fonts/Manrope-400-18.woff2"
  },
  "/fonts/Manrope-500-19.woff2": {
    "type": "font/woff2",
    "etag": "\"9c4-ONuPwALKIAeIOpZlTrPEkKsL8l4\"",
    "mtime": "2024-02-02T10:24:17.733Z",
    "size": 2500,
    "path": "../public/fonts/Manrope-500-19.woff2"
  },
  "/fonts/Manrope-500-20.woff2": {
    "type": "font/woff2",
    "etag": "\"377c-P21Fqhq8FZlQh3pIAJ4/dq083JM\"",
    "mtime": "2024-02-02T10:24:17.734Z",
    "size": 14204,
    "path": "../public/fonts/Manrope-500-20.woff2"
  },
  "/fonts/Manrope-500-21.woff2": {
    "type": "font/woff2",
    "etag": "\"23e8-8oyWLnQHg7DeSfhU688gTUaZW+c\"",
    "mtime": "2024-02-02T10:24:17.734Z",
    "size": 9192,
    "path": "../public/fonts/Manrope-500-21.woff2"
  },
  "/fonts/Manrope-500-22.woff2": {
    "type": "font/woff2",
    "etag": "\"2074-atSB0WLl08CdnVgpghvv7le/9lk\"",
    "mtime": "2024-02-02T10:24:17.733Z",
    "size": 8308,
    "path": "../public/fonts/Manrope-500-22.woff2"
  },
  "/fonts/Manrope-500-23.woff2": {
    "type": "font/woff2",
    "etag": "\"39d4-DnKHMntuQ0aSkandFFZMXbB/A64\"",
    "mtime": "2024-02-02T10:24:17.735Z",
    "size": 14804,
    "path": "../public/fonts/Manrope-500-23.woff2"
  },
  "/fonts/Manrope-500-24.woff2": {
    "type": "font/woff2",
    "etag": "\"5f38-chBgcZmLDvXxRepPnVNFnlKjPp8\"",
    "mtime": "2024-02-02T10:24:17.734Z",
    "size": 24376,
    "path": "../public/fonts/Manrope-500-24.woff2"
  },
  "/fonts/Manrope-600-25.woff2": {
    "type": "font/woff2",
    "etag": "\"9c4-ONuPwALKIAeIOpZlTrPEkKsL8l4\"",
    "mtime": "2024-02-02T10:24:17.739Z",
    "size": 2500,
    "path": "../public/fonts/Manrope-600-25.woff2"
  },
  "/fonts/Manrope-600-26.woff2": {
    "type": "font/woff2",
    "etag": "\"377c-P21Fqhq8FZlQh3pIAJ4/dq083JM\"",
    "mtime": "2024-02-02T10:24:17.735Z",
    "size": 14204,
    "path": "../public/fonts/Manrope-600-26.woff2"
  },
  "/fonts/Manrope-600-27.woff2": {
    "type": "font/woff2",
    "etag": "\"23e8-8oyWLnQHg7DeSfhU688gTUaZW+c\"",
    "mtime": "2024-02-02T10:24:17.734Z",
    "size": 9192,
    "path": "../public/fonts/Manrope-600-27.woff2"
  },
  "/fonts/Manrope-600-28.woff2": {
    "type": "font/woff2",
    "etag": "\"2074-atSB0WLl08CdnVgpghvv7le/9lk\"",
    "mtime": "2024-02-02T10:24:17.735Z",
    "size": 8308,
    "path": "../public/fonts/Manrope-600-28.woff2"
  },
  "/fonts/Manrope-600-29.woff2": {
    "type": "font/woff2",
    "etag": "\"39d4-DnKHMntuQ0aSkandFFZMXbB/A64\"",
    "mtime": "2024-02-02T10:24:17.735Z",
    "size": 14804,
    "path": "../public/fonts/Manrope-600-29.woff2"
  },
  "/fonts/Manrope-600-30.woff2": {
    "type": "font/woff2",
    "etag": "\"5f38-chBgcZmLDvXxRepPnVNFnlKjPp8\"",
    "mtime": "2024-02-02T10:24:17.736Z",
    "size": 24376,
    "path": "../public/fonts/Manrope-600-30.woff2"
  },
  "/fonts/Manrope-700-31.woff2": {
    "type": "font/woff2",
    "etag": "\"9c4-ONuPwALKIAeIOpZlTrPEkKsL8l4\"",
    "mtime": "2024-02-02T10:24:17.736Z",
    "size": 2500,
    "path": "../public/fonts/Manrope-700-31.woff2"
  },
  "/fonts/Manrope-700-32.woff2": {
    "type": "font/woff2",
    "etag": "\"377c-P21Fqhq8FZlQh3pIAJ4/dq083JM\"",
    "mtime": "2024-02-02T10:24:17.737Z",
    "size": 14204,
    "path": "../public/fonts/Manrope-700-32.woff2"
  },
  "/fonts/Manrope-700-33.woff2": {
    "type": "font/woff2",
    "etag": "\"23e8-8oyWLnQHg7DeSfhU688gTUaZW+c\"",
    "mtime": "2024-02-02T10:24:17.738Z",
    "size": 9192,
    "path": "../public/fonts/Manrope-700-33.woff2"
  },
  "/fonts/Manrope-700-34.woff2": {
    "type": "font/woff2",
    "etag": "\"2074-atSB0WLl08CdnVgpghvv7le/9lk\"",
    "mtime": "2024-02-02T10:24:17.737Z",
    "size": 8308,
    "path": "../public/fonts/Manrope-700-34.woff2"
  },
  "/fonts/Manrope-700-35.woff2": {
    "type": "font/woff2",
    "etag": "\"39d4-DnKHMntuQ0aSkandFFZMXbB/A64\"",
    "mtime": "2024-02-02T10:24:17.737Z",
    "size": 14804,
    "path": "../public/fonts/Manrope-700-35.woff2"
  },
  "/fonts/Manrope-700-36.woff2": {
    "type": "font/woff2",
    "etag": "\"5f38-chBgcZmLDvXxRepPnVNFnlKjPp8\"",
    "mtime": "2024-02-02T10:24:17.737Z",
    "size": 24376,
    "path": "../public/fonts/Manrope-700-36.woff2"
  },
  "/fonts/Manrope-800-37.woff2": {
    "type": "font/woff2",
    "etag": "\"9c4-ONuPwALKIAeIOpZlTrPEkKsL8l4\"",
    "mtime": "2024-02-02T10:24:17.738Z",
    "size": 2500,
    "path": "../public/fonts/Manrope-800-37.woff2"
  },
  "/fonts/Manrope-800-38.woff2": {
    "type": "font/woff2",
    "etag": "\"377c-P21Fqhq8FZlQh3pIAJ4/dq083JM\"",
    "mtime": "2024-02-02T10:24:17.738Z",
    "size": 14204,
    "path": "../public/fonts/Manrope-800-38.woff2"
  },
  "/fonts/Manrope-800-39.woff2": {
    "type": "font/woff2",
    "etag": "\"23e8-8oyWLnQHg7DeSfhU688gTUaZW+c\"",
    "mtime": "2024-02-02T10:24:17.738Z",
    "size": 9192,
    "path": "../public/fonts/Manrope-800-39.woff2"
  },
  "/fonts/Manrope-800-40.woff2": {
    "type": "font/woff2",
    "etag": "\"2074-atSB0WLl08CdnVgpghvv7le/9lk\"",
    "mtime": "2024-02-02T10:24:17.739Z",
    "size": 8308,
    "path": "../public/fonts/Manrope-800-40.woff2"
  },
  "/fonts/Manrope-800-41.woff2": {
    "type": "font/woff2",
    "etag": "\"39d4-DnKHMntuQ0aSkandFFZMXbB/A64\"",
    "mtime": "2024-02-02T10:24:17.739Z",
    "size": 14804,
    "path": "../public/fonts/Manrope-800-41.woff2"
  },
  "/fonts/Manrope-800-42.woff2": {
    "type": "font/woff2",
    "etag": "\"5f38-chBgcZmLDvXxRepPnVNFnlKjPp8\"",
    "mtime": "2024-02-02T10:24:17.738Z",
    "size": 24376,
    "path": "../public/fonts/Manrope-800-42.woff2"
  },
  "/images/1.png": {
    "type": "image/png",
    "etag": "\"15708-wxTnX6nVsQXsRDKW+OsE38FVrCc\"",
    "mtime": "2024-02-02T10:24:18.059Z",
    "size": 87816,
    "path": "../public/images/1.png"
  },
  "/images/10.png": {
    "type": "image/png",
    "etag": "\"170af-wMh25Qr9kqot86A0TFQLx+dG2gA\"",
    "mtime": "2024-02-02T10:24:18.052Z",
    "size": 94383,
    "path": "../public/images/10.png"
  },
  "/images/11.png": {
    "type": "image/png",
    "etag": "\"1c5b0-MdTK8gj3dc8jI2AyIZoni0hvq/A\"",
    "mtime": "2024-02-02T10:24:18.059Z",
    "size": 116144,
    "path": "../public/images/11.png"
  },
  "/images/2.png": {
    "type": "image/png",
    "etag": "\"156fd-lZN6RY+iqR0jvnxb33XX55SoOyA\"",
    "mtime": "2024-02-02T10:24:18.058Z",
    "size": 87805,
    "path": "../public/images/2.png"
  },
  "/images/3.png": {
    "type": "image/png",
    "etag": "\"1c8a0-MvDJ5XSWBuHAcOkOPYxgVckQOfQ\"",
    "mtime": "2024-02-02T10:24:18.075Z",
    "size": 116896,
    "path": "../public/images/3.png"
  },
  "/images/4.png": {
    "type": "image/png",
    "etag": "\"16203-nKIb30UONeQKgB27qhj3yEm9kMI\"",
    "mtime": "2024-02-02T10:24:18.058Z",
    "size": 90627,
    "path": "../public/images/4.png"
  },
  "/images/5.png": {
    "type": "image/png",
    "etag": "\"17993-x3idBJzNic6JbSO/fKGHaQMIpyE\"",
    "mtime": "2024-02-02T10:24:18.113Z",
    "size": 96659,
    "path": "../public/images/5.png"
  },
  "/images/6.png": {
    "type": "image/png",
    "etag": "\"9e57-9Ea6mMPf2SwR0kOjniiMJyxfnRk\"",
    "mtime": "2024-02-02T10:24:18.073Z",
    "size": 40535,
    "path": "../public/images/6.png"
  },
  "/images/7.png": {
    "type": "image/png",
    "etag": "\"10fa8-PaCDcsGRW8Sze1cA9z9fO5vS1KY\"",
    "mtime": "2024-02-02T10:24:18.075Z",
    "size": 69544,
    "path": "../public/images/7.png"
  },
  "/images/8.png": {
    "type": "image/png",
    "etag": "\"a1d0-qEzOInOHtLqpgpQxd2f7hyk6TIU\"",
    "mtime": "2024-02-02T10:24:18.075Z",
    "size": 41424,
    "path": "../public/images/8.png"
  },
  "/images/9.png": {
    "type": "image/png",
    "etag": "\"19353-LGWHI2e1JDoQFxbvVrJYr/cA5o0\"",
    "mtime": "2024-02-02T10:24:18.076Z",
    "size": 103251,
    "path": "../public/images/9.png"
  },
  "/images/amos.png": {
    "type": "image/png",
    "etag": "\"d79-Jj9CWgNx2n24NosilrW1gqsg6bc\"",
    "mtime": "2024-02-02T10:24:18.076Z",
    "size": 3449,
    "path": "../public/images/amos.png"
  },
  "/images/amosban.png": {
    "type": "image/png",
    "etag": "\"8ed94-IbZYS/yPxWzpAGpuZkI8bpOFN3A\"",
    "mtime": "2024-02-02T10:24:18.080Z",
    "size": 585108,
    "path": "../public/images/amosban.png"
  },
  "/images/banner.jpeg": {
    "type": "image/jpeg",
    "etag": "\"43850-ibWvYZC/z+IUZWakeK8KTBUj2Us\"",
    "mtime": "2024-02-02T10:24:18.080Z",
    "size": 276560,
    "path": "../public/images/banner.jpeg"
  },
  "/images/basf.png": {
    "type": "image/png",
    "etag": "\"8bc-SSYwbpAnVmjpaaGKwIv57iflMwM\"",
    "mtime": "2024-02-02T10:24:18.076Z",
    "size": 2236,
    "path": "../public/images/basf.png"
  },
  "/images/board.png": {
    "type": "image/png",
    "etag": "\"c9b59-PInOL56liF+VfTcxxOJtfyKhX8Y\"",
    "mtime": "2024-02-02T10:24:18.084Z",
    "size": 826201,
    "path": "../public/images/board.png"
  },
  "/images/campaign.png": {
    "type": "image/png",
    "etag": "\"f99-xQ+heCy+Y4QOnPDlRXjJ6sWpcsk\"",
    "mtime": "2024-02-02T10:24:18.079Z",
    "size": 3993,
    "path": "../public/images/campaign.png"
  },
  "/images/cargill.svg": {
    "type": "image/svg+xml",
    "etag": "\"1480-w+aLTnsHe4CDfmWVwwsgOveiFd8\"",
    "mtime": "2024-02-02T10:24:18.077Z",
    "size": 5248,
    "path": "../public/images/cargill.svg"
  },
  "/images/check.svg": {
    "type": "image/svg+xml",
    "etag": "\"1c45-GGKxqLIpztDOTn3ss/hg/FnBZd0\"",
    "mtime": "2024-02-02T10:24:18.077Z",
    "size": 7237,
    "path": "../public/images/check.svg"
  },
  "/images/code.svg": {
    "type": "image/svg+xml",
    "etag": "\"560-5dkN4bzmOWaOGPX3CJNMVKngj5o\"",
    "mtime": "2024-02-02T10:24:18.080Z",
    "size": 1376,
    "path": "../public/images/code.svg"
  },
  "/images/coke.png": {
    "type": "image/png",
    "etag": "\"26fd-F3qRWIHxuHwAvcEZrKY4NLL4unE\"",
    "mtime": "2024-02-02T10:24:18.078Z",
    "size": 9981,
    "path": "../public/images/coke.png"
  },
  "/images/cormart.png": {
    "type": "image/png",
    "etag": "\"1376-qRttBtrjOwl3Vr4TSG+J6E3zQU8\"",
    "mtime": "2024-02-02T10:24:18.083Z",
    "size": 4982,
    "path": "../public/images/cormart.png"
  },
  "/images/delete.svg": {
    "type": "image/svg+xml",
    "etag": "\"365-c2vTGtS0tjnNyG7Ew59Fz5l6M0Q\"",
    "mtime": "2024-02-02T10:24:18.081Z",
    "size": 869,
    "path": "../public/images/delete.svg"
  },
  "/images/earth-africa.svg": {
    "type": "image/svg+xml",
    "etag": "\"1028-NNBk62ymVu/aCcDT1o7zMcfWe3s\"",
    "mtime": "2024-02-02T10:24:18.080Z",
    "size": 4136,
    "path": "../public/images/earth-africa.svg"
  },
  "/images/finance1.png": {
    "type": "image/png",
    "etag": "\"2c4a1-VO2eBMXm7nvVT9+wXLyWudkJH74\"",
    "mtime": "2024-02-02T10:24:18.082Z",
    "size": 181409,
    "path": "../public/images/finance1.png"
  },
  "/images/finance2.png": {
    "type": "image/png",
    "etag": "\"33936-umiUNsyugckGnktcXgokY9HwNz4\"",
    "mtime": "2024-02-02T10:24:18.083Z",
    "size": 211254,
    "path": "../public/images/finance2.png"
  },
  "/images/finance3.png": {
    "type": "image/png",
    "etag": "\"268ae-49dCm/q3rGed3H48hmxsN6a54dU\"",
    "mtime": "2024-02-02T10:24:18.082Z",
    "size": 157870,
    "path": "../public/images/finance3.png"
  },
  "/images/finance4.png": {
    "type": "image/png",
    "etag": "\"2ee07-uCiFhioxdePLpwCNYK6Uai4kGaY\"",
    "mtime": "2024-02-02T10:24:18.084Z",
    "size": 192007,
    "path": "../public/images/finance4.png"
  },
  "/images/financebanner.png": {
    "type": "image/png",
    "etag": "\"97857-5gHQ0eBDJacQ+Z1CoQOKo+qwTJ8\"",
    "mtime": "2024-02-02T10:24:18.116Z",
    "size": 620631,
    "path": "../public/images/financebanner.png"
  },
  "/images/folder.svg": {
    "type": "image/svg+xml",
    "etag": "\"12e9-DgxtYq485NTQUzfjrAx7+0cJaKk\"",
    "mtime": "2024-02-02T10:24:18.082Z",
    "size": 4841,
    "path": "../public/images/folder.svg"
  },
  "/images/grid.svg": {
    "type": "image/svg+xml",
    "etag": "\"1449-wfOkFM/Aie6syg8TXXND8gLoBMw\"",
    "mtime": "2024-02-02T10:24:18.084Z",
    "size": 5193,
    "path": "../public/images/grid.svg"
  },
  "/images/honywell.png": {
    "type": "image/png",
    "etag": "\"1936-fwt5WOsDCljZMGEOn6GSDoniGXc\"",
    "mtime": "2024-02-02T10:24:18.084Z",
    "size": 6454,
    "path": "../public/images/honywell.png"
  },
  "/images/imgplace.png": {
    "type": "image/png",
    "etag": "\"e38-VqFebRUN6MD3vOc5nwC5RjxiDfY\"",
    "mtime": "2024-02-02T10:24:18.084Z",
    "size": 3640,
    "path": "../public/images/imgplace.png"
  },
  "/images/layer.svg": {
    "type": "image/svg+xml",
    "etag": "\"19ed-joeMbjnaXSDknhOC9wv5kokfuQI\"",
    "mtime": "2024-02-02T10:24:18.084Z",
    "size": 6637,
    "path": "../public/images/layer.svg"
  },
  "/images/liquide.png": {
    "type": "image/png",
    "etag": "\"e52-fxD/EcbdpfFQrDVmpE1TQFaxfNI\"",
    "mtime": "2024-02-02T10:24:18.108Z",
    "size": 3666,
    "path": "../public/images/liquide.png"
  },
  "/images/logo-white.png": {
    "type": "image/png",
    "etag": "\"2518-DHNQor7gleLvkUi+nIIJT4BCtsk\"",
    "mtime": "2024-02-02T10:24:18.108Z",
    "size": 9496,
    "path": "../public/images/logo-white.png"
  },
  "/images/logo.png": {
    "type": "image/png",
    "etag": "\"274d-ifWorQQxDYA2MTNK9mrPRmBGRqs\"",
    "mtime": "2024-02-02T10:24:18.084Z",
    "size": 10061,
    "path": "../public/images/logo.png"
  },
  "/images/matta-icon.png": {
    "type": "image/png",
    "etag": "\"73f-b9ioSuZ72vPrIySYs2QcvuQ3XSs\"",
    "mtime": "2024-02-02T10:24:18.109Z",
    "size": 1855,
    "path": "../public/images/matta-icon.png"
  },
  "/images/sent.png": {
    "type": "image/png",
    "etag": "\"dbe-4/QF3m12ZwAe+A0DwSQmtfdi7kk\"",
    "mtime": "2024-02-02T10:24:18.110Z",
    "size": 3518,
    "path": "../public/images/sent.png"
  },
  "/images/success.png": {
    "type": "image/png",
    "etag": "\"e81-QDMuMli2RutdxOhLOZJEK2hWY8E\"",
    "mtime": "2024-02-02T10:24:18.109Z",
    "size": 3713,
    "path": "../public/images/success.png"
  },
  "/images/test.png": {
    "type": "image/png",
    "etag": "\"1a698-wFFERxpkASc5zqpsBZvsE0SGcC4\"",
    "mtime": "2024-02-02T10:24:18.111Z",
    "size": 108184,
    "path": "../public/images/test.png"
  },
  "/images/users.svg": {
    "type": "image/svg+xml",
    "etag": "\"635-KCvCojlWQefxHmEZ+2OmqUzxF7I\"",
    "mtime": "2024-02-02T10:24:18.110Z",
    "size": 1589,
    "path": "../public/images/users.svg"
  },
  "/policy/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-/JnG+Ofo5H7RZZQD8BURu1L1DIY\"",
    "mtime": "2024-02-02T10:23:59.794Z",
    "size": 62,
    "path": "../public/policy/_payload.json"
  },
  "/policy/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"41d4a-KCvjl8XawZTE984nYopsdBh5/aA\"",
    "mtime": "2024-02-02T10:23:58.970Z",
    "size": 269642,
    "path": "../public/policy/index.html"
  },
  "/request-product/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-1NrvSUeg8HNI5K2P8V2ejrJmcvs\"",
    "mtime": "2024-02-02T10:24:00.023Z",
    "size": 62,
    "path": "../public/request-product/_payload.json"
  },
  "/request-product/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3dd71-igP1iPhSSPIvLVdXKyNN6ZKE0Mo\"",
    "mtime": "2024-02-02T10:23:59.282Z",
    "size": 253297,
    "path": "../public/request-product/index.html"
  },
  "/terms/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-lUmi+eMgELZc9H6L8yWkatVrVlI\"",
    "mtime": "2024-02-02T10:23:59.834Z",
    "size": 62,
    "path": "../public/terms/_payload.json"
  },
  "/terms/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"42098-nAZm9p1IweIL3VylLu8SW16PWDY\"",
    "mtime": "2024-02-02T10:23:58.986Z",
    "size": 270488,
    "path": "../public/terms/index.html"
  },
  "/_ipx/_/logo-matta-white.png": {
    "type": "image/png",
    "etag": "\"1486f-p8NPTe5Vceu0OuGxJsz1Q8S845M\"",
    "mtime": "2024-02-02T10:24:00.243Z",
    "size": 84079,
    "path": "../public/_ipx/_/logo-matta-white.png"
  },
  "/auth/forgot-password/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-vwhIzP+nr2sRZISg1uDGdlvoh9g\"",
    "mtime": "2024-02-02T10:24:00.271Z",
    "size": 62,
    "path": "../public/auth/forgot-password/_payload.json"
  },
  "/auth/forgot-password/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3afb2-2wO/admc1CGs0pQB60imYtoNBjc\"",
    "mtime": "2024-02-02T10:24:00.194Z",
    "size": 241586,
    "path": "../public/auth/forgot-password/index.html"
  },
  "/auth/login/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-T2sKvCH2l0yjLxQQfjTDQr6f8n8\"",
    "mtime": "2024-02-02T10:24:00.072Z",
    "size": 62,
    "path": "../public/auth/login/_payload.json"
  },
  "/auth/login/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3b44f-rCYKU5hHpY9gYtL4JK9VejD3mAs\"",
    "mtime": "2024-02-02T10:23:59.365Z",
    "size": 242767,
    "path": "../public/auth/login/index.html"
  },
  "/auth/register/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-M8dEfTDz5MFH6UBeGlZnxqYVyxs\"",
    "mtime": "2024-02-02T10:24:00.039Z",
    "size": 62,
    "path": "../public/auth/register/_payload.json"
  },
  "/auth/register/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3bc89-iHkEjCP4Yl+VUTKyS+WgmdXbLxw\"",
    "mtime": "2024-02-02T10:23:59.356Z",
    "size": 244873,
    "path": "../public/auth/register/index.html"
  },
  "/auth/vendor-register/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-2HDd3m3GMEQHaHf/kikJDoKYZq4\"",
    "mtime": "2024-02-02T10:24:00.173Z",
    "size": 62,
    "path": "../public/auth/vendor-register/_payload.json"
  },
  "/auth/vendor-register/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3c644-JQTDLc9wyuXhbSsSih8DPd6plbY\"",
    "mtime": "2024-02-02T10:23:59.365Z",
    "size": 247364,
    "path": "../public/auth/vendor-register/index.html"
  },
  "/_nuxt/builds/latest.json": {
    "type": "application/json",
    "etag": "\"47-JBacVo3wammlhVHnPeo1THBmczc\"",
    "mtime": "2024-02-02T10:24:17.711Z",
    "size": 71,
    "path": "../public/_nuxt/builds/latest.json"
  },
  "/market/Ammonia Liquor/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-ZRgM7A6F9Yj7H8J4wgkz3RzAJGw\"",
    "mtime": "2024-02-02T10:24:00.232Z",
    "size": 62,
    "path": "../public/market/Ammonia Liquor/_payload.json"
  },
  "/market/Ammonia Liquor/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3f782-MvmBgPuCuZgeER6zE2d1SEwuNvo\"",
    "mtime": "2024-02-02T10:23:59.554Z",
    "size": 259970,
    "path": "../public/market/Ammonia Liquor/index.html"
  },
  "/market/Caustic Soda/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-4Z2Y3IsT2tCqzpsPZ9leDoEgOjY\"",
    "mtime": "2024-02-02T10:24:00.254Z",
    "size": 62,
    "path": "../public/market/Caustic Soda/_payload.json"
  },
  "/market/Caustic Soda/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3f776-FsC50OHHXBmvYHMm4Z6d4FBzjmw\"",
    "mtime": "2024-02-02T10:23:59.674Z",
    "size": 259958,
    "path": "../public/market/Caustic Soda/index.html"
  },
  "/market/all/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-OmFzQv9WReUcGXnJDxUYKs8PEa4\"",
    "mtime": "2024-02-02T10:23:59.961Z",
    "size": 62,
    "path": "../public/market/all/_payload.json"
  },
  "/market/all/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3f738-U/GxIc/FsE1bMDNC8o0vNdCQdBg\"",
    "mtime": "2024-02-02T10:23:59.173Z",
    "size": 259896,
    "path": "../public/market/all/index.html"
  },
  "/market/all products/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-cU8gV0neUIGMTZqt9UoFjhDBT8w\"",
    "mtime": "2024-02-02T10:24:00.257Z",
    "size": 62,
    "path": "../public/market/all products/_payload.json"
  },
  "/market/all products/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3f776-9EgvkA8XdWJoU/vMvRbvqBx5vW8\"",
    "mtime": "2024-02-02T10:23:59.782Z",
    "size": 259958,
    "path": "../public/market/all products/index.html"
  },
  "/market/products/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-3GqH3q23v/zY4Hr3+v2bY9L15Hk\"",
    "mtime": "2024-02-02T10:23:59.961Z",
    "size": 62,
    "path": "../public/market/products/_payload.json"
  },
  "/market/products/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3f756-5t4MP0CgSlEgGt4XGX/S8A2IX4Q\"",
    "mtime": "2024-02-02T10:23:59.161Z",
    "size": 259926,
    "path": "../public/market/products/index.html"
  },
  "/market/Hydrogenated Oil/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"3e-2g0685a86cMxIDTBMSp1WBxPi20\"",
    "mtime": "2024-02-02T10:24:00.252Z",
    "size": 62,
    "path": "../public/market/Hydrogenated Oil/_payload.json"
  },
  "/market/Hydrogenated Oil/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3f78e-K/+foeYRj0we6/PIeaEd4I4K55o\"",
    "mtime": "2024-02-02T10:23:59.608Z",
    "size": 259982,
    "path": "../public/market/Hydrogenated Oil/index.html"
  },
  "/_ipx/_/images/code.svg": {
    "type": "image/svg+xml",
    "etag": "\"555-tn256WBrwLPrFr16HfKMiQ5dm4U\"",
    "mtime": "2024-02-02T10:24:00.272Z",
    "size": 1365,
    "path": "../public/_ipx/_/images/code.svg"
  },
  "/_ipx/_/images/earth-africa.svg": {
    "type": "image/svg+xml",
    "etag": "\"101d-L3RHhL5W1IH3Q5+wjBntqbnPXcs\"",
    "mtime": "2024-02-02T10:24:00.258Z",
    "size": 4125,
    "path": "../public/_ipx/_/images/earth-africa.svg"
  },
  "/_ipx/_/images/finance1.png": {
    "type": "image/png",
    "etag": "\"3f44c-iHX6bSMUo5LmLRPWIyIe9WBFt1w\"",
    "mtime": "2024-02-02T10:24:00.028Z",
    "size": 259148,
    "path": "../public/_ipx/_/images/finance1.png"
  },
  "/_ipx/_/images/finance2.png": {
    "type": "image/png",
    "etag": "\"421fa-T6jQl1vEgU1SgISN+Hi3zNDNeEY\"",
    "mtime": "2024-02-02T10:24:00.032Z",
    "size": 270842,
    "path": "../public/_ipx/_/images/finance2.png"
  },
  "/_ipx/_/images/finance3.png": {
    "type": "image/png",
    "etag": "\"37f41-Otr94OMAbWYLXOAXUY97mesV+zM\"",
    "mtime": "2024-02-02T10:24:00.026Z",
    "size": 229185,
    "path": "../public/_ipx/_/images/finance3.png"
  },
  "/_ipx/_/images/finance4.png": {
    "type": "image/png",
    "etag": "\"37850-OzVLcGi6DJcc+iV7Ab4kHYnpYiQ\"",
    "mtime": "2024-02-02T10:24:00.026Z",
    "size": 227408,
    "path": "../public/_ipx/_/images/finance4.png"
  },
  "/_ipx/_/images/financebanner.png": {
    "type": "image/png",
    "etag": "\"d0bd4-qFyuzksn7VIT4DgSPwiop5z6HgA\"",
    "mtime": "2024-02-02T10:24:00.039Z",
    "size": 854996,
    "path": "../public/_ipx/_/images/financebanner.png"
  },
  "/_ipx/_/images/logo.png": {
    "type": "image/png",
    "etag": "\"1be4-127vLeUGgj5usHNzCv8XqhVjPAM\"",
    "mtime": "2024-02-02T10:23:59.162Z",
    "size": 7140,
    "path": "../public/_ipx/_/images/logo.png"
  },
  "/_ipx/_/images/users.svg": {
    "type": "image/svg+xml",
    "etag": "\"62a-fC+gohjwmgeey2d1f6/Ygp1NcjU\"",
    "mtime": "2024-02-02T10:24:00.261Z",
    "size": 1578,
    "path": "../public/_ipx/_/images/users.svg"
  },
  "/_ipx/s_100x26/images/logo-white.png": {
    "type": "image/png",
    "etag": "\"1096-ubwIk4SxNI9Xu7DN6pNcYXqnUPU\"",
    "mtime": "2024-02-02T10:24:00.261Z",
    "size": 4246,
    "path": "../public/_ipx/s_100x26/images/logo-white.png"
  },
  "/_ipx/s_100x26/images/logo.png": {
    "type": "image/png",
    "etag": "\"d87-qfh038OI/KL/Wj/eTaPFpFlDloc\"",
    "mtime": "2024-02-02T10:24:00.253Z",
    "size": 3463,
    "path": "../public/_ipx/s_100x26/images/logo.png"
  },
  "/_ipx/s_200x52/images/logo-white.png": {
    "type": "image/png",
    "etag": "\"2c69-4U8XtH1RWnbd7YGxymj+ZHy8owo\"",
    "mtime": "2024-02-02T10:24:00.261Z",
    "size": 11369,
    "path": "../public/_ipx/s_200x52/images/logo-white.png"
  },
  "/_ipx/s_200x52/images/logo.png": {
    "type": "image/png",
    "etag": "\"1bda-FdKc5WRQqIInUSVzWnAiIQD+LdY\"",
    "mtime": "2024-02-02T10:24:00.252Z",
    "size": 7130,
    "path": "../public/_ipx/s_200x52/images/logo.png"
  },
  "/_ipx/s_40x40/images/check.svg": {
    "type": "image/svg+xml",
    "etag": "\"1c3c-aZixBwQE/x+jtaK3KZ1CLQuddTI\"",
    "mtime": "2024-02-02T10:23:59.327Z",
    "size": 7228,
    "path": "../public/_ipx/s_40x40/images/check.svg"
  },
  "/_ipx/s_40x40/images/folder.svg": {
    "type": "image/svg+xml",
    "etag": "\"12e0-ad+BH+zcKlNp+K2f5tuiWcxFHjQ\"",
    "mtime": "2024-02-02T10:23:59.321Z",
    "size": 4832,
    "path": "../public/_ipx/s_40x40/images/folder.svg"
  },
  "/_ipx/s_40x40/images/grid.svg": {
    "type": "image/svg+xml",
    "etag": "\"1440-R0MoN2XT7p75H/+vqZ/pP2X3QXk\"",
    "mtime": "2024-02-02T10:23:59.016Z",
    "size": 5184,
    "path": "../public/_ipx/s_40x40/images/grid.svg"
  },
  "/_ipx/s_40x40/images/layer.svg": {
    "type": "image/svg+xml",
    "etag": "\"19e4-2jOauiFAVBfAuzUiNZ1pcOQvTOk\"",
    "mtime": "2024-02-02T10:23:59.387Z",
    "size": 6628,
    "path": "../public/_ipx/s_40x40/images/layer.svg"
  },
  "/_ipx/s_80x80/images/check.svg": {
    "type": "image/svg+xml",
    "etag": "\"1c3c-aZixBwQE/x+jtaK3KZ1CLQuddTI\"",
    "mtime": "2024-02-02T10:23:59.317Z",
    "size": 7228,
    "path": "../public/_ipx/s_80x80/images/check.svg"
  },
  "/_ipx/s_80x80/images/folder.svg": {
    "type": "image/svg+xml",
    "etag": "\"12e0-ad+BH+zcKlNp+K2f5tuiWcxFHjQ\"",
    "mtime": "2024-02-02T10:23:59.365Z",
    "size": 4832,
    "path": "../public/_ipx/s_80x80/images/folder.svg"
  },
  "/_ipx/s_80x80/images/grid.svg": {
    "type": "image/svg+xml",
    "etag": "\"1440-R0MoN2XT7p75H/+vqZ/pP2X3QXk\"",
    "mtime": "2024-02-02T10:23:59.341Z",
    "size": 5184,
    "path": "../public/_ipx/s_80x80/images/grid.svg"
  },
  "/_ipx/s_80x80/images/layer.svg": {
    "type": "image/svg+xml",
    "etag": "\"19e4-2jOauiFAVBfAuzUiNZ1pcOQvTOk\"",
    "mtime": "2024-02-02T10:23:59.408Z",
    "size": 6628,
    "path": "../public/_ipx/s_80x80/images/layer.svg"
  },
  "/_ipx/w_132/images/logo.png": {
    "type": "image/png",
    "etag": "\"125e-XcP283kUTbh/cyTye18gjFXm2YQ\"",
    "mtime": "2024-02-02T10:23:59.717Z",
    "size": 4702,
    "path": "../public/_ipx/w_132/images/logo.png"
  },
  "/_ipx/w_150/images/basf.png": {
    "type": "image/png",
    "etag": "\"9fe-qa9gXreXpsIG324vlqXapvDKzGs\"",
    "mtime": "2024-02-02T10:23:59.608Z",
    "size": 2558,
    "path": "../public/_ipx/w_150/images/basf.png"
  },
  "/_ipx/w_150/images/cargill.svg": {
    "type": "image/svg+xml",
    "etag": "\"1473-3pIbm4yYFGvPUyyLmpgoJkpmqps\"",
    "mtime": "2024-02-02T10:23:59.674Z",
    "size": 5235,
    "path": "../public/_ipx/w_150/images/cargill.svg"
  },
  "/_ipx/w_150/images/coke.png": {
    "type": "image/png",
    "etag": "\"1afb-C+Mp/lkUuacDQVIsVhMyO/e5q6I\"",
    "mtime": "2024-02-02T10:23:59.483Z",
    "size": 6907,
    "path": "../public/_ipx/w_150/images/coke.png"
  },
  "/_ipx/w_150/images/cormart.png": {
    "type": "image/png",
    "etag": "\"1019-vt5DzuySbM/Lisg5LsxrJ5nqEC4\"",
    "mtime": "2024-02-02T10:23:59.425Z",
    "size": 4121,
    "path": "../public/_ipx/w_150/images/cormart.png"
  },
  "/_ipx/w_150/images/honywell.png": {
    "type": "image/png",
    "etag": "\"193f-jYrvMcIJBhnkM5mRNHd+YK/hZfY\"",
    "mtime": "2024-02-02T10:23:59.537Z",
    "size": 6463,
    "path": "../public/_ipx/w_150/images/honywell.png"
  },
  "/_ipx/w_150/images/liquide.png": {
    "type": "image/png",
    "etag": "\"ae8-Jn1ke3JqD7ZW3Vpk3iLYTi9/eg0\"",
    "mtime": "2024-02-02T10:23:59.644Z",
    "size": 2792,
    "path": "../public/_ipx/w_150/images/liquide.png"
  },
  "/_ipx/w_264/images/logo.png": {
    "type": "image/png",
    "etag": "\"27eb-0Gc8RWNKJPjC/NA1MkgBZH3QHuI\"",
    "mtime": "2024-02-02T10:23:59.771Z",
    "size": 10219,
    "path": "../public/_ipx/w_264/images/logo.png"
  },
  "/_nuxt/builds/meta/dev.json": {
    "type": "application/json",
    "etag": "\"6a-cV9fHTxSEgyWKfvtl2/rJxIRWeI\"",
    "mtime": "2024-02-02T10:24:17.706Z",
    "size": 106,
    "path": "../public/_nuxt/builds/meta/dev.json"
  },
  "/_nuxt/builds/meta/f27a72af-debe-404d-aafc-5b121d36cb1d.json": {
    "type": "application/json",
    "etag": "\"1a5-E1RxYq3X3kuAyPTEJnXQHpsUfjE\"",
    "mtime": "2024-02-02T10:24:17.706Z",
    "size": 421,
    "path": "../public/_nuxt/builds/meta/f27a72af-debe-404d-aafc-5b121d36cb1d.json"
  },
  "/_ipx/w_300/images/basf.png": {
    "type": "image/png",
    "etag": "\"700-d+gjKZT+PRmPrr6rmW1DQsZEiAo\"",
    "mtime": "2024-02-02T10:23:59.608Z",
    "size": 1792,
    "path": "../public/_ipx/w_300/images/basf.png"
  },
  "/_ipx/w_300/images/cargill.svg": {
    "type": "image/svg+xml",
    "etag": "\"1473-3pIbm4yYFGvPUyyLmpgoJkpmqps\"",
    "mtime": "2024-02-02T10:23:59.674Z",
    "size": 5235,
    "path": "../public/_ipx/w_300/images/cargill.svg"
  },
  "/_ipx/w_300/images/coke.png": {
    "type": "image/png",
    "etag": "\"1afb-C+Mp/lkUuacDQVIsVhMyO/e5q6I\"",
    "mtime": "2024-02-02T10:23:59.527Z",
    "size": 6907,
    "path": "../public/_ipx/w_300/images/coke.png"
  },
  "/_ipx/w_300/images/cormart.png": {
    "type": "image/png",
    "etag": "\"1019-vt5DzuySbM/Lisg5LsxrJ5nqEC4\"",
    "mtime": "2024-02-02T10:23:59.438Z",
    "size": 4121,
    "path": "../public/_ipx/w_300/images/cormart.png"
  },
  "/_ipx/w_300/images/honywell.png": {
    "type": "image/png",
    "etag": "\"193f-jYrvMcIJBhnkM5mRNHd+YK/hZfY\"",
    "mtime": "2024-02-02T10:23:59.553Z",
    "size": 6463,
    "path": "../public/_ipx/w_300/images/honywell.png"
  },
  "/_ipx/w_300/images/liquide.png": {
    "type": "image/png",
    "etag": "\"ae8-Jn1ke3JqD7ZW3Vpk3iLYTi9/eg0\"",
    "mtime": "2024-02-02T10:23:59.644Z",
    "size": 2792,
    "path": "../public/_ipx/w_300/images/liquide.png"
  },
  "/financing/requests/export/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"8c-ncUjZVX1ZSM7nqFjl4UNfWpYf6g\"",
    "mtime": "2024-02-02T10:24:00.063Z",
    "size": 140,
    "path": "../public/financing/requests/export/index.html"
  },
  "/financing/requests/import/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"8c-gXGF1gMpqtbPGl/STnfIQPCezY0\"",
    "mtime": "2024-02-02T10:24:00.072Z",
    "size": 140,
    "path": "../public/financing/requests/import/index.html"
  },
  "/financing/requests/supply/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"8c-nKFrkJwYxapzbOGdNXYONVm1NUA\"",
    "mtime": "2024-02-02T10:24:00.072Z",
    "size": 140,
    "path": "../public/financing/requests/supply/index.html"
  },
  "/financing/requests/trade/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"8b-n5RaNScAFH3Ca5PYvR1DIpoJjK4\"",
    "mtime": "2024-02-02T10:24:00.040Z",
    "size": 139,
    "path": "../public/financing/requests/trade/index.html"
  }
};

function normalizeWindowsPath(input = "") {
  if (!input || !input.includes("\\")) {
    return input;
  }
  return input.replace(/\\/g, "/");
}
const _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
const _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
function cwd() {
  if (typeof process !== "undefined") {
    return process.cwd().replace(/\\/g, "/");
  }
  return "/";
}
const resolve$1 = function(...arguments_) {
  arguments_ = arguments_.map((argument) => normalizeWindowsPath(argument));
  let resolvedPath = "";
  let resolvedAbsolute = false;
  for (let index = arguments_.length - 1; index >= -1 && !resolvedAbsolute; index--) {
    const path = index >= 0 ? arguments_[index] : cwd();
    if (!path || path.length === 0) {
      continue;
    }
    resolvedPath = `${path}/${resolvedPath}`;
    resolvedAbsolute = isAbsolute(path);
  }
  resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute);
  if (resolvedAbsolute && !isAbsolute(resolvedPath)) {
    return `/${resolvedPath}`;
  }
  return resolvedPath.length > 0 ? resolvedPath : ".";
};
function normalizeString(path, allowAboveRoot) {
  let res = "";
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let char = null;
  for (let index = 0; index <= path.length; ++index) {
    if (index < path.length) {
      char = path[index];
    } else if (char === "/") {
      break;
    } else {
      char = "/";
    }
    if (char === "/") {
      if (lastSlash === index - 1 || dots === 1) ; else if (dots === 2) {
        if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
          if (res.length > 2) {
            const lastSlashIndex = res.lastIndexOf("/");
            if (lastSlashIndex === -1) {
              res = "";
              lastSegmentLength = 0;
            } else {
              res = res.slice(0, lastSlashIndex);
              lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
            }
            lastSlash = index;
            dots = 0;
            continue;
          } else if (res.length > 0) {
            res = "";
            lastSegmentLength = 0;
            lastSlash = index;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          res += res.length > 0 ? "/.." : "..";
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0) {
          res += `/${path.slice(lastSlash + 1, index)}`;
        } else {
          res = path.slice(lastSlash + 1, index);
        }
        lastSegmentLength = index - lastSlash - 1;
      }
      lastSlash = index;
      dots = 0;
    } else if (char === "." && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}
const isAbsolute = function(p) {
  return _IS_ABSOLUTE_RE.test(p);
};
const dirname = function(p) {
  const segments = normalizeWindowsPath(p).replace(/\/$/, "").split("/").slice(0, -1);
  if (segments.length === 1 && _DRIVE_LETTER_RE.test(segments[0])) {
    segments[0] += "/";
  }
  return segments.join("/") || (isAbsolute(p) ? "/" : ".");
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises$1.readFile(resolve$1(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt/builds/meta":{"maxAge":31536000},"/_nuxt/builds":{"maxAge":1},"/_nuxt":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _f4b49z = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  if (encodings.length > 1) {
    setResponseHeader(event, "Vary", "Accept-Encoding");
  }
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError$1({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  return readAsset(id);
});

const _54Xj4Y = defineEventHandler(async (e) => {
  if (e.context.siteConfig)
    return;
  const config = useRuntimeConfig(e)["nuxt-site-config"];
  const nitroApp = useNitroApp();
  const siteConfig = createSiteConfigStack({
    debug: config.debug
  });
  const appConfig = useAppConfig(e);
  const nitroOrigin = useNitroOrigin(e);
  e.context.siteConfigNitroOrigin = nitroOrigin;
  siteConfig.push({
    _context: "nitro:init",
    _priority: -4,
    url: nitroOrigin
  });
  siteConfig.push({
    _context: "runtimeEnv",
    _priority: 0,
    // @ts-expect-error untyped
    ...envSiteConfig(globalThis._importMeta_.env)
  });
  const buildStack = config.stack || [];
  buildStack.forEach((c) => siteConfig.push(c));
  if (appConfig.site) {
    siteConfig.push({
      _priority: -2,
      _context: "app:config",
      ...appConfig.site
    });
  }
  if (e.context._nitro.routeRules.site) {
    siteConfig.push({
      _context: "route-rules",
      ...e.context._nitro.routeRules.site
    });
  }
  const ctx = { siteConfig, event: e };
  await nitroApp.hooks.callHook("site-config:init", ctx);
  e.context.siteConfig = ctx.siteConfig;
});

const merger = createDefu((obj, key, value) => {
  if (Array.isArray(obj[key]) && Array.isArray(value))
    obj[key] = Array.from(/* @__PURE__ */ new Set([...obj[key], ...value]));
  return obj[key];
});
function mergeOnKey(arr, key) {
  const res = {};
  arr.forEach((item) => {
    const k = item[key];
    res[k] = merger(item, res[k] || {});
  });
  return Object.values(res);
}
function splitForLocales(path, locales) {
  const prefix = withLeadingSlash(path).split("/")[1];
  if (locales.includes(prefix))
    return [prefix, path.replace(`/${prefix}`, "")];
  return [null, path];
}

const StringifiedRegExpPattern = /\/(.*?)\/([gimsuy]*)$/;
function normalizeRuntimeFilters(input) {
  return (input || []).map((rule) => {
    if (rule instanceof RegExp || typeof rule === "string")
      return rule;
    const match = rule.regex.match(StringifiedRegExpPattern);
    if (match)
      return new RegExp(match[1], match[2]);
    return false;
  }).filter(Boolean);
}
function useSimpleSitemapRuntimeConfig() {
  const clone = JSON.parse(JSON.stringify(useRuntimeConfig()["nuxt-simple-sitemap"]));
  for (const k in clone.sitemaps) {
    const sitemap = clone.sitemaps[k];
    sitemap.include = normalizeRuntimeFilters(sitemap.include);
    sitemap.exclude = normalizeRuntimeFilters(sitemap.exclude);
    clone.sitemaps[k] = sitemap;
  }
  return Object.freeze(clone);
}

const _rzAExA = defineEventHandler(async (e) => {
  setHeader(e, "Content-Type", "application/xslt+xml");
  setHeader(e, "Cache-Control", "max-age=600, must-revalidate");
  const fixPath = createSitePathResolver(e, { absolute: false, withBase: true });
  const { sitemapName: fallbackSitemapName, version, xslColumns, xslTips } = useSimpleSitemapRuntimeConfig();
  const { name: siteName, url: siteUrl } = useSiteConfig(e);
  const referrer = getHeader(e, "Referer") || "/";
  const isNotIndexButHasIndex = referrer !== fixPath("/sitemap.xml") && parseURL(referrer).pathname.endsWith("-sitemap.xml");
  const sitemapName = parseURL(referrer).pathname.split("/").pop()?.split("-sitemap")[0] || fallbackSitemapName;
  const title = `${siteName}${sitemapName !== "sitemap.xml" ? ` - ${sitemapName === "sitemap_index.xml" ? "index" : sitemapName}` : ""}`.replace(/&/g, "&amp;");
  const canonicalQuery = getQuery$1(referrer).canonical;
  const isShowingCanonical = typeof canonicalQuery !== "undefined" && canonicalQuery !== "false";
  const conditionalTips = [
    'You are looking at a <a href="https://developer.mozilla.org/en-US/docs/Web/XSLT/Transforming_XML_with_XSLT/An_Overview" style="color: #398465" target="_blank">XML stylesheet</a>. Read the <a href="https://nuxtseo.com/sitemap/guides/customising-ui" style="color: #398465" target="_blank">docs</a> to learn how to customize it.',
    `URLs missing? Check Nuxt Devtools Sitemap tab (or the <a href="${withQuery("/__sitemap__/debug.json", { sitemap: sitemapName })}" style="color: #398465" target="_blank">debug endpoint</a>).`
  ];
  if (!isShowingCanonical) {
    const canonicalPreviewUrl = withQuery(referrer, { canonical: "" });
    conditionalTips.push(`Your canonical site URL is <strong>${siteUrl}</strong>.`);
    conditionalTips.push(`You can preview your canonical sitemap by visiting <a href="${canonicalPreviewUrl}" style="color: #398465; white-space: nowrap;">${fixPath(canonicalPreviewUrl)}?canonical</a>`);
  } else {
    conditionalTips.push(`You are viewing the canonical sitemap. You can switch to using the request origin: <a href="${fixPath(referrer)}" style="color: #398465; white-space: nowrap ">${fixPath(referrer)}</a>`);
  }
  let columns = [...xslColumns];
  if (!columns.length) {
    columns = [
      { label: "URL", width: "50%" },
      { label: "Images", width: "25%", select: "count(image:image)" },
      { label: "Last Updated", width: "25%", select: "concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)),concat(' ', substring(sitemap:lastmod,20,6)))" }
    ];
  }
  return `<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="2.0"
                xmlns:html="http://www.w3.org/TR/REC-html40"
                xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
                xmlns:sitemap="http://www.sitemaps.org/schemas/sitemap/0.9"
                xmlns:xhtml="http://www.w3.org/1999/xhtml"
                xmlns:news="http://www.google.com/schemas/sitemap-news/0.9"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="html" version="1.0" encoding="UTF-8" indent="yes"/>
  <xsl:template match="/">
    <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
        <title>XML Sitemap</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <style type="text/css">
          body {
            font-family: Inter, Helvetica, Arial, sans-serif;
            font-size: 14px;
            color: #333;
          }

          table {
            border: none;
            border-collapse: collapse;
          }

          .bg-yellow-200 {
            background-color: #fef9c3;
          }

          .p-5 {
            padding: 1.25rem;
          }

          .rounded {
            border-radius: 4px;
            }

          .shadow {
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
          }

          #sitemap tr:nth-child(odd) td {
            background-color: #f8f8f8 !important;
          }

          #sitemap tbody tr:hover td {
            background-color: #fff;
          }

          #sitemap tbody tr:hover td, #sitemap tbody tr:hover td a {
            color: #000;
          }

          .expl a {
            color: #398465
            font-weight: 600;
          }

          .expl a:visited {
            color: #398465
          }

          a {
            color: #000;
            text-decoration: none;
          }

          a:visited {
            color: #777;
          }

          a:hover {
            text-decoration: underline;
          }

          td {
            font-size: 12px;
          }

          .text-2xl {
            font-size: 2rem;
            font-weight: 600;
            line-height: 1.25;
          }

          th {
            text-align: left;
            padding-right: 30px;
            font-size: 12px;
          }

          thead th {
            border-bottom: 1px solid #000;
          }
          .fixed { position: fixed; }
          .right-2 { right: 2rem; }
          .top-2 { top: 2rem; }
          .w-30 { width: 30rem; }
          p { margin: 0; }
          li { padding-bottom: 0.5rem; line-height: 1.5; }
          h1 { margin: 0; }
          .mb-5 { margin-bottom: 1.25rem; }
          .mb-3 { margin-bottom: 0.75rem; }
        </style>
      </head>
      <body>
        <div style="grid-template-columns: 1fr 1fr; display: grid; margin: 3rem;">
            <div>
             <div id="content">
          <h1 class="text-2xl mb-3">XML Sitemap</h1>
          <h2>${title}</h2>
          ${isNotIndexButHasIndex ? `<p style="font-size: 12px; margin-bottom: 1rem;"><a href="${fixPath("/sitemap_index.xml")}">${fixPath("/sitemap_index.xml")}</a></p>` : ""}
          <xsl:if test="count(sitemap:sitemapindex/sitemap:sitemap) &gt; 0">
            <p class="expl" style="margin-bottom: 1rem;">
              This XML Sitemap Index file contains
              <xsl:value-of select="count(sitemap:sitemapindex/sitemap:sitemap)"/> sitemaps.
            </p>
            <table id="sitemap" cellpadding="3">
              <thead>
                <tr>
                  <th width="75%">Sitemap</th>
                  <th width="25%">Last Modified</th>
                </tr>
              </thead>
              <tbody>
                <xsl:for-each select="sitemap:sitemapindex/sitemap:sitemap">
                  <xsl:variable name="sitemapURL">
                    <xsl:value-of select="sitemap:loc"/>
                  </xsl:variable>
                  <tr>
                    <td>
                      <a href="{$sitemapURL}">
                        <xsl:value-of select="sitemap:loc"/>
                      </a>
                    </td>
                    <td>
                      <xsl:value-of
                        select="concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)),concat(' ', substring(sitemap:lastmod,20,6)))"/>
                    </td>
                  </tr>
                </xsl:for-each>
              </tbody>
            </table>
          </xsl:if>
          <xsl:if test="count(sitemap:sitemapindex/sitemap:sitemap) &lt; 1">
            <p class="expl" style="margin-bottom: 1rem;">
              This XML Sitemap contains
              <xsl:value-of select="count(sitemap:urlset/sitemap:url)"/> URLs.
            </p>
            <table id="sitemap" cellpadding="3">
              <thead>
                <tr>
                  ${columns.map((c) => `<th width="${c.width}">${c.label}</th>`).join("\n")}
                </tr>
              </thead>
              <tbody>
                <xsl:variable name="lower" select="'abcdefghijklmnopqrstuvwxyz'"/>
                <xsl:variable name="upper" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'"/>
                <xsl:for-each select="sitemap:urlset/sitemap:url">
                  <tr>
                    <td>
                      <xsl:variable name="itemURL">
                        <xsl:value-of select="sitemap:loc"/>
                      </xsl:variable>
                      <a href="{$itemURL}">
                        <xsl:value-of select="sitemap:loc"/>
                      </a>
                    </td>
                    ${columns.filter((c) => c.label !== "URL").map((c) => `<td>
<xsl:value-of select="${c.select}"/>
</td>`).join("\n")}
                  </tr>
                </xsl:for-each>
              </tbody>
            </table>
          </xsl:if>
        </div>
        </div>
                    ${""}
        </div>
      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
`;
});

function resolve(s, resolvers) {
  if (typeof s === "undefined")
    return s;
  s = typeof s === "string" ? s : s.toString();
  if (hasProtocol(s, { acceptRelative: true, strict: false }))
    return resolvers.fixSlashes(s);
  return resolvers.canonicalUrlResolver(s);
}
function normaliseSitemapUrls(data, resolvers) {
  const entries = data.map((e) => typeof e === "string" ? { loc: e } : e).map((e) => {
    e = { ...e };
    if (e.url) {
      e.loc = e.url;
      delete e.url;
    }
    e.loc = fixSlashes(false, e.loc);
    return e;
  }).filter(Boolean);
  function normaliseEntry(e) {
    if (e.lastmod) {
      const date = normaliseDate(e.lastmod);
      if (date)
        e.lastmod = date;
      else
        delete e.lastmod;
    }
    if (!e.lastmod)
      delete e.lastmod;
    e.loc = resolve(e.loc, resolvers);
    if (e.alternatives) {
      e.alternatives = mergeOnKey(e.alternatives.map((e2) => {
        const a = { ...e2 };
        if (typeof a.href === "string")
          a.href = resolve(a.href, resolvers);
        else if (typeof a.href === "object" && a.href)
          a.href = resolve(a.href.href, resolvers);
        return a;
      }), "hreflang");
    }
    if (e.images) {
      e.images = mergeOnKey(e.images.map((i) => {
        i = { ...i };
        i.loc = resolve(i.loc, resolvers);
        return i;
      }), "loc");
    }
    if (e.videos) {
      e.videos = e.videos.map((v) => {
        v = { ...v };
        if (v.content_loc)
          v.content_loc = resolve(v.content_loc, resolvers);
        return v;
      });
    }
    return e;
  }
  return mergeOnKey(
    entries.map(normaliseEntry).map((e) => ({ ...e, _key: `${e._sitemap || ""}${e.loc}` })),
    "_key"
  );
}
function normaliseDate(d) {
  if (typeof d === "string") {
    d = d.replace("Z", "");
    d = d.replace(/\.\d+$/, "");
    if (d.match(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/) || d.match(/^\d{4}-\d{2}-\d{2}$/))
      return d;
    d = new Date(d);
    if (Number.isNaN(d.getTime()))
      return false;
  }
  const z = (n) => `0${n}`.slice(-2);
  return `${d.getUTCFullYear()}-${z(d.getUTCMonth() + 1)}-${z(d.getUTCDate())}T${z(d.getUTCHours())}:${z(d.getUTCMinutes())}:${z(d.getUTCSeconds())}+00:00`;
}

async function fetchDataSource(input) {
  const context = typeof input.context === "string" ? { name: input.context } : input.context || { name: "fetch" };
  context.tips = context.tips || [];
  const url = typeof input.fetch === "string" ? input.fetch : input.fetch[0];
  const options = typeof input.fetch === "string" ? {} : input.fetch[1];
  const start = Date.now();
  const timeout = options.timeout || 5e3;
  const timeoutController = new AbortController();
  const abortRequestTimeout = setTimeout(() => timeoutController.abort(), timeout);
  let isHtmlResponse = false;
  try {
    const urls = await globalThis.$fetch(url, {
      responseType: "json",
      signal: timeoutController.signal,
      headers: {
        Accept: "application/json"
      },
      // @ts-expect-error untyped
      onResponse({ response }) {
        if (typeof response._data === "string" && response._data.startsWith("<!DOCTYPE html>"))
          isHtmlResponse = true;
      }
    });
    const timeTakenMs = Date.now() - start;
    if (isHtmlResponse) {
      context.tips.push("This is usually because the URL isn't correct or is throwing an error. Please check the URL");
      return {
        ...input,
        context,
        urls: [],
        timeTakenMs,
        error: "Received HTML response instead of JSON"
      };
    }
    return {
      ...input,
      context,
      timeTakenMs,
      urls
    };
  } catch (_err) {
    const error = _err;
    if (error.message.includes("This operation was aborted"))
      context.tips.push("The request has taken too long. Make sure app sources respond within 5 seconds or adjust the timeout fetch option.");
    else
      context.tips.push(`Response returned a status of ${error.response?.status || "unknown"}.`);
    console.error("[nuxt-simple-sitemap] Failed to fetch source.", { url, error });
    return {
      ...input,
      context,
      urls: [],
      error: error.message
    };
  } finally {
    abortRequestTimeout && clearTimeout(abortRequestTimeout);
  }
}
function globalSitemapSources() {
  return import('../rollup/global-sources.mjs').then((m) => m.sources);
}
function childSitemapSources(definition) {
  return definition?._hasSourceChunk ? import('../rollup/child-sources.mjs').then((m) => m.sources[definition.sitemapName] || []) : Promise.resolve([]);
}
async function resolveSitemapSources(sources) {
  return (await Promise.all(
    sources.map((source) => {
      if (typeof source === "object" && "urls" in source) {
        return {
          timeTakenMs: 0,
          ...source,
          urls: source.urls
        };
      }
      if (source.fetch)
        return fetchDataSource(source);
      return {
        ...source,
        error: "Invalid source"
      };
    })
  )).flat();
}

function createFilter(options = {}) {
  const include = options.include || [];
  const exclude = options.exclude || [];
  if (include.length === 0 && exclude.length === 0)
    return () => true;
  return function(path) {
    for (const v of [{ rules: exclude, result: false }, { rules: include, result: true }]) {
      const regexRules = v.rules.filter((r) => r instanceof RegExp);
      if (regexRules.some((r) => r.test(path)))
        return v.result;
      const stringRules = v.rules.filter((r) => typeof r === "string");
      if (stringRules.length > 0) {
        const routes = {};
        for (const r of stringRules) {
          if (r === path)
            return v.result;
          routes[r] = true;
        }
        const routeRulesMatcher = toRouteMatcher(createRouter$1({ routes, strictTrailingSlash: false }));
        if (routeRulesMatcher.matchAll(path).length > 0)
          return Boolean(v.result);
      }
    }
    return include.length === 0;
  };
}
function filterSitemapUrls(_urls, options) {
  const urlFilter = createFilter({
    include: options.include,
    exclude: options.exclude
  });
  return _urls.filter((e) => {
    let path = e.loc;
    try {
      path = parseURL(e.loc).pathname;
    } catch {
      return false;
    }
    if (!urlFilter(path))
      return false;
    if (options.isMultiSitemap && e._sitemap && options.sitemapName)
      return e._sitemap === options.sitemapName;
    return true;
  });
}

function normaliseI18nSources(sources, { autoI18n, isI18nMapped }) {
  if (autoI18n && isI18nMapped) {
    return sources.map((s) => {
      const urls = (s.urls || []).map((_url) => {
        const url = typeof _url === "string" ? { loc: _url } : _url;
        url.loc = url.loc || url.url;
        url.loc = withLeadingSlash(url.loc);
        return url;
      });
      s.urls = urls.map((url) => {
        if (url._sitemap || url._i18nTransform)
          return url;
        if (url.loc) {
          const match = splitForLocales(url.loc, autoI18n.locales.map((l) => l.code));
          const localeCode = match[0] || autoI18n.defaultLocale;
          const pathWithoutPrefix = match[1];
          const locale = autoI18n.locales.find((e) => e.code === localeCode);
          if (locale) {
            if (!url.alternatives) {
              const alternatives = urls.map((u) => {
                if (u._sitemap || u._i18nTransform)
                  return false;
                if (u?.loc) {
                  const [_localeCode, _pathWithoutPrefix] = splitForLocales(u.loc, autoI18n.locales.map((l) => l.code));
                  if (pathWithoutPrefix === _pathWithoutPrefix) {
                    const entries = [];
                    if (_localeCode === autoI18n.defaultLocale) {
                      entries.push({
                        href: u.loc,
                        hreflang: "x-default"
                      });
                    }
                    entries.push({
                      href: u.loc,
                      hreflang: _localeCode || autoI18n.defaultLocale
                    });
                    return entries;
                  }
                }
                return false;
              }).flat().filter(Boolean);
              if (alternatives.length)
                url.alternatives = alternatives;
            }
            return {
              _sitemap: locale.iso || locale.code,
              ...url
            };
          }
        }
        return url;
      });
      return s;
    });
  }
  return sources;
}
function applyI18nEnhancements(_urls, options) {
  const { autoI18n } = options;
  return _urls.map((e) => {
    if (!e._i18nTransform)
      return e;
    delete e._i18nTransform;
    const path = withLeadingSlash(parseURL(e.loc).pathname);
    const match = splitForLocales(path, autoI18n.locales.map((l) => l.code));
    let pathWithoutLocale = path;
    let locale;
    if (match[0]) {
      pathWithoutLocale = match[1] || "/";
      locale = match[0];
    }
    if (locale && false) {
      console.warn("You're providing a locale in the url, but the url is marked as inheritI18n. This will cause issues with the sitemap. Please remove the locale from the url.");
      return e;
    }
    if (autoI18n.differentDomains) {
      return {
        // will force it to pass filter
        _sitemap: options.sitemapName,
        ...e,
        alternatives: [
          {
            // apply default locale domain
            ...autoI18n.locales.find((l) => [l.code, l.iso].includes(autoI18n.defaultLocale)),
            code: "x-default"
          },
          ...autoI18n.locales.filter((l) => !!l.domain)
        ].map((locale2) => {
          return {
            hreflang: locale2.iso || locale2.code,
            href: joinURL(withHttps(locale2.domain), pathWithoutLocale)
          };
        })
      };
    }
    return autoI18n.locales.map((l) => {
      let loc = joinURL(`/${l.code}`, pathWithoutLocale);
      if (autoI18n.differentDomains || ["prefix_and_default", "prefix_except_default"].includes(autoI18n.strategy) && l.code === autoI18n.defaultLocale)
        loc = pathWithoutLocale;
      return {
        _sitemap: options.isI18nMapped ? l.iso || l.code : void 0,
        ...e,
        loc,
        alternatives: [{ code: "x-default" }, ...autoI18n.locales].map((locale2) => {
          const code = locale2.code === "x-default" ? autoI18n.defaultLocale : locale2.code;
          const isDefault = locale2.code === "x-default" || locale2.code === autoI18n.defaultLocale;
          let href = "";
          if (autoI18n.strategy === "prefix") {
            href = joinURL("/", code, pathWithoutLocale);
          } else if (["prefix_and_default", "prefix_except_default"].includes(autoI18n.strategy)) {
            if (isDefault) {
              href = pathWithoutLocale;
            } else {
              href = joinURL("/", code, pathWithoutLocale);
            }
          }
          const hreflang = locale2.iso || locale2.code;
          return {
            hreflang,
            href
          };
        })
      };
    });
  }).flat();
}

function sortSitemapUrls(urls) {
  return urls.sort(
    (a, b) => {
      const aLoc = typeof a === "string" ? a : a.loc;
      const bLoc = typeof b === "string" ? b : b.loc;
      return aLoc.localeCompare(bLoc, void 0, { numeric: true });
    }
  ).sort((a, b) => {
    const aLoc = (typeof a === "string" ? a : a.loc) || "";
    const bLoc = (typeof b === "string" ? b : b.loc) || "";
    const aSegments = aLoc.split("/").length;
    const bSegments = bLoc.split("/").length;
    if (aSegments > bSegments)
      return 1;
    if (aSegments < bSegments)
      return -1;
    return 0;
  });
}

function withoutQuery(path) {
  return path.split("?")[0];
}
function createNitroRouteRuleMatcher() {
  const { nitro, app } = useRuntimeConfig();
  const _routeRulesMatcher = toRouteMatcher(
    createRouter$1({
      routes: Object.fromEntries(
        Object.entries(nitro?.routeRules || {}).map(([path, rules]) => [withoutTrailingSlash(path), rules])
      )
    })
  );
  return (path) => {
    return defu({}, ..._routeRulesMatcher.matchAll(
      // radix3 does not support trailing slashes
      withoutBase(withoutTrailingSlash(withoutQuery(path)), app.baseURL)
    ).reverse());
  };
}

function resolveKey(k) {
  switch (k) {
    case "images":
      return "image";
    case "videos":
      return "video";
    case "news":
      return "news";
    default:
      return k;
  }
}
function handleObject(key, obj) {
  return [
    `        <${key}:${key}>`,
    ...Object.entries(obj).map(([sk, sv]) => {
      if (key === "video" && Array.isArray(sv)) {
        return sv.map((v) => {
          if (typeof v === "string") {
            return [
              `            `,
              `<${key}:${sk}>`,
              escapeValueForXml(v),
              `</${key}:${sk}>`
            ].join("");
          }
          const attributes = Object.entries(v).filter(([ssk]) => ssk !== sk).map(([ssk, ssv]) => `${ssk}="${escapeValueForXml(ssv)}"`).join(" ");
          return [
            `            <${key}:${sk} ${attributes}>`,
            // value is the same sk
            v[sk],
            `</${key}:${sk}>`
          ].join("");
        }).join("\n");
      }
      if (typeof sv === "object") {
        if (key === "video") {
          const attributes = Object.entries(sv).filter(([ssk]) => ssk !== sk).map(([ssk, ssv]) => `${ssk}="${escapeValueForXml(ssv)}"`).join(" ");
          return [
            `            <${key}:${sk} ${attributes}>`,
            // value is the same sk
            sv[sk],
            `</${key}:${sk}>`
          ].join("");
        }
        return [
          `            <${key}:${sk}>`,
          ...Object.entries(sv).map(([ssk, ssv]) => `                <${key}:${ssk}>${escapeValueForXml(ssv)}</${key}:${ssk}>`),
          `            </${key}:${sk}>`
        ].join("\n");
      }
      return `            <${key}:${sk}>${escapeValueForXml(sv)}</${key}:${sk}>`;
    }),
    `        </${key}:${key}>`
  ].join("\n");
}
function handleArray(key, arr) {
  if (arr.length === 0)
    return false;
  key = resolveKey(key);
  if (key === "alternatives") {
    return arr.map((obj) => [
      `        <xhtml:link rel="alternate" ${Object.entries(obj).map(([sk, sv]) => `${sk}="${escapeValueForXml(sv)}"`).join(" ")} />`
    ].join("\n")).join("\n");
  }
  return arr.map((obj) => handleObject(key, obj)).join("\n");
}
function handleEntry(k, e) {
  return Array.isArray(e[k]) ? handleArray(k, e[k]) : typeof e[k] === "object" ? handleObject(k, e[k]) : `        <${k}>${escapeValueForXml(e[k])}</${k}>`;
}
function wrapSitemapXml(input, resolvers, wrapSitemapXmlOptions) {
  const xsl = wrapSitemapXmlOptions.xsl ? resolvers.relativeBaseUrlResolver(wrapSitemapXmlOptions.xsl) : false;
  const credits = wrapSitemapXmlOptions.credits;
  input.unshift(`<?xml version="1.0" encoding="UTF-8"?>${xsl ? `<?xml-stylesheet type="text/xsl" href="${xsl}"?>` : ""}`);
  if (credits)
    input.push(`<!-- XML Sitemap generated by Nuxt Simple Sitemap v${wrapSitemapXmlOptions.version} -->`);
  return input.join("\n");
}
function escapeValueForXml(value) {
  if (value === true || value === false)
    return value ? "yes" : "no";
  return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

async function buildSitemap(sitemap, resolvers) {
  const {
    sitemaps,
    // enhancing
    autoLastmod,
    autoI18n,
    isI18nMapped,
    isMultiSitemap,
    // sorting
    sortEntries,
    // chunking
    defaultSitemapsChunkSize,
    // xls
    version,
    xsl,
    credits
  } = useSimpleSitemapRuntimeConfig();
  const isChunking = typeof sitemaps.chunks !== "undefined" && !Number.isNaN(Number(sitemap.sitemapName));
  function maybeSort(urls2) {
    return sortEntries ? sortSitemapUrls(urls2) : urls2;
  }
  function maybeSlice(urls2) {
    if (isChunking && defaultSitemapsChunkSize) {
      const chunk = Number(sitemap.sitemapName);
      return urls2.slice(chunk * defaultSitemapsChunkSize, (chunk + 1) * defaultSitemapsChunkSize);
    }
    return urls2;
  }
  if (autoI18n?.differentDomains) {
    const domain = autoI18n.locales.find((e) => [e.iso, e.code].includes(sitemap.sitemapName))?.domain;
    if (domain) {
      const _tester = resolvers.canonicalUrlResolver;
      resolvers.canonicalUrlResolver = (path) => resolveSitePath(path, {
        absolute: true,
        withBase: false,
        siteUrl: withHttps(domain),
        trailingSlash: !_tester("/test/").endsWith("/"),
        base: "/"
      });
    }
  }
  const sources = sitemap.includeAppSources ? await globalSitemapSources() : [];
  sources.push(...await childSitemapSources(sitemap));
  let resolvedSources = await resolveSitemapSources(sources);
  if (autoI18n)
    resolvedSources = normaliseI18nSources(resolvedSources, { autoI18n, isI18nMapped });
  const normalisedUrls = normaliseSitemapUrls(resolvedSources.map((e) => e.urls).flat(), resolvers);
  ({ ...sitemap.defaults || {} });
  const routeRuleMatcher = createNitroRouteRuleMatcher();
  let enhancedUrls = normalisedUrls.map((e) => defu(e, sitemap.defaults)).map((e) => {
    const path = parseURL(e.loc).pathname;
    let routeRules = routeRuleMatcher(path);
    if (autoI18n?.locales && autoI18n?.strategy !== "no_prefix") {
      const match = splitForLocales(path, autoI18n.locales.map((l) => l.code));
      const pathWithoutPrefix = match[1];
      if (pathWithoutPrefix && pathWithoutPrefix !== path)
        routeRules = defu(routeRules, routeRuleMatcher(pathWithoutPrefix));
    }
    if (routeRules.sitemap === false)
      return false;
    if (typeof routeRules.index !== "undefined" && !routeRules.index)
      return false;
    const hasRobotsDisabled = Object.entries(routeRules.headers || {}).some(([name, value]) => name.toLowerCase() === "x-robots-tag" && value.toLowerCase() === "noindex");
    if (routeRules.redirect || hasRobotsDisabled)
      return false;
    return routeRules.sitemap ? defu(e, routeRules.sitemap) : e;
  }).filter(Boolean);
  if (autoI18n?.locales)
    enhancedUrls = applyI18nEnhancements(enhancedUrls, { isI18nMapped, autoI18n, sitemapName: sitemap.sitemapName });
  const filteredUrls = filterSitemapUrls(enhancedUrls, { event: resolvers.event, isMultiSitemap, autoI18n, ...sitemap });
  const sortedUrls = maybeSort(filteredUrls);
  const slicedUrls = maybeSlice(sortedUrls);
  const nitro = useNitroApp();
  const ctx = {
    urls: slicedUrls,
    sitemapName: sitemap.sitemapName
  };
  await nitro.hooks.callHook("sitemap:resolved", ctx);
  const urls = maybeSort(normaliseSitemapUrls(ctx.urls, resolvers));
  const urlset = urls.map((e) => {
    const keys = Object.keys(e).filter((k) => !k.startsWith("_"));
    return [
      "    <url>",
      keys.map((k) => handleEntry(k, e)).filter(Boolean).join("\n"),
      "    </url>"
    ].join("\n");
  });
  return wrapSitemapXml([
    '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:video="http://www.google.com/schemas/sitemap-video/1.1" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xmlns:news="http://www.google.com/schemas/sitemap-news/0.9" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd http://www.google.com/schemas/sitemap-image/1.1 http://www.google.com/schemas/sitemap-image/1.1/sitemap-image.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
    urlset.join("\n"),
    "</urlset>"
  ], resolvers, { version, xsl, credits });
}

async function buildSitemapIndex(resolvers) {
  const {
    sitemaps,
    // enhancing
    autoLastmod,
    // chunking
    defaultSitemapsChunkSize,
    autoI18n,
    isI18nMapped,
    sortEntries,
    // xls
    version,
    xsl,
    credits
  } = useSimpleSitemapRuntimeConfig();
  if (!sitemaps)
    throw new Error("Attempting to build a sitemap index without required `sitemaps` configuration.");
  function maybeSort(urls) {
    return sortEntries ? sortSitemapUrls(urls) : urls;
  }
  const isChunking = typeof sitemaps.chunks !== "undefined";
  const chunks = {};
  if (isChunking) {
    const sitemap = sitemaps.chunks;
    const sources = await resolveSitemapSources(await globalSitemapSources());
    const normalisedUrls = normaliseSitemapUrls(sources.map((e) => e.urls).flat(), resolvers);
    let enhancedUrls = normalisedUrls.map((e) => defu(e, sitemap.defaults));
    if (autoI18n?.locales)
      enhancedUrls = applyI18nEnhancements(enhancedUrls, { isI18nMapped, autoI18n, sitemapName: sitemap.sitemapName });
    const filteredUrls = filterSitemapUrls(enhancedUrls, { ...sitemap, autoI18n, isMultiSitemap: true });
    const sortedUrls = maybeSort(filteredUrls);
    sortedUrls.forEach((url, i) => {
      const chunkIndex = Math.floor(i / defaultSitemapsChunkSize);
      chunks[chunkIndex] = chunks[chunkIndex] || { urls: [] };
      chunks[chunkIndex].urls.push(url);
    });
  } else {
    for (const sitemap in sitemaps) {
      if (sitemap !== "index") {
        chunks[sitemap] = chunks[sitemap] || { urls: [] };
      }
    }
  }
  const entries = [];
  for (const name in chunks) {
    const sitemap = chunks[name];
    const entry = {
      sitemap: resolvers.canonicalUrlResolver(`${name}-sitemap.xml`)
    };
    let lastmod = sitemap.urls.filter((a) => !!a?.lastmod).map((a) => typeof a.lastmod === "string" ? new Date(a.lastmod) : a.lastmod).sort((a, b) => (b?.getTime() || 0) - (a?.getTime() || 0))?.[0];
    if (!lastmod && autoLastmod)
      lastmod = /* @__PURE__ */ new Date();
    if (lastmod)
      entry.lastmod = normaliseDate(lastmod);
    entries.push(entry);
  }
  if (sitemaps.index)
    entries.push(...sitemaps.index.sitemaps);
  const sitemapXml = entries.map((e) => [
    "    <sitemap>",
    `        <loc>${escapeValueForXml(e.sitemap)}</loc>`,
    // lastmod is optional
    e.lastmod ? `        <lastmod>${escapeValueForXml(e.lastmod)}</lastmod>` : false,
    "    </sitemap>"
  ].filter(Boolean).join("\n")).join("\n");
  return wrapSitemapXml([
    '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
    sitemapXml,
    "</sitemapindex>"
  ], resolvers, { version, xsl, credits });
}

function useNitroUrlResolvers(e) {
  const canonicalQuery = getQuery(e).canonical;
  const isShowingCanonical = typeof canonicalQuery !== "undefined" && canonicalQuery !== "false";
  const siteConfig = useSiteConfig(e);
  return {
    event: e,
    fixSlashes: (path) => fixSlashes(siteConfig.trailingSlash, path),
    // we need these as they depend on the nitro event
    canonicalUrlResolver: createSitePathResolver(e, {
      canonical: isShowingCanonical || !false,
      absolute: true,
      withBase: true
    }),
    relativeBaseUrlResolver: createSitePathResolver(e, { absolute: false, withBase: true })
  };
}
async function createSitemap(e, definition) {
  const { sitemapName } = definition;
  const nitro = useNitroApp();
  let sitemap = await (definition.sitemapName === "index" ? buildSitemapIndex(useNitroUrlResolvers(e)) : buildSitemap(definition, useNitroUrlResolvers(e)));
  const ctx = { sitemap, sitemapName };
  await nitro.hooks.callHook("sitemap:output", ctx);
  sitemap = ctx.sitemap;
  setHeader(e, "Content-Type", "text/xml; charset=UTF-8");
  setHeader(e, "Cache-Control", "max-age=600, must-revalidate");
  return sitemap;
}

const _ScF72f = defineEventHandler(async (e) => {
  const { sitemaps } = useSimpleSitemapRuntimeConfig();
  if ("index" in sitemaps) {
    return sendRedirect(e, withBase("/sitemap_index.xml", useRuntimeConfig().app.baseURL), 301);
  }
  return createSitemap(e, Object.values(sitemaps)[0]);
});

const _r97oAP = lazyEventHandler(() => {
  const opts = useRuntimeConfig().ipx || {};
  const fsDir = opts.fs?.dir ? isAbsolute(opts.fs.dir) ? opts.fs.dir : fileURLToPath(new URL(opts.fs.dir, globalThis._importMeta_.url)) : void 0;
  const fsStorage = opts.fs?.dir ? ipxFSStorage({ ...opts.fs, dir: fsDir }) : void 0;
  const httpStorage = opts.http?.domains ? ipxHttpStorage({ ...opts.http }) : void 0;
  if (!fsStorage && !httpStorage) {
    throw new Error("IPX storage is not configured!");
  }
  const ipxOptions = {
    ...opts,
    storage: fsStorage || httpStorage,
    httpStorage
  };
  const ipx = createIPX(ipxOptions);
  const ipxHandler = createIPXH3Handler(ipx);
  return useBase(opts.baseURL, ipxHandler);
});

const _lazy_mT6n5y = () => import('../handlers/renderer.mjs').then(function (n) { return n.r; });

const handlers = [
  { route: '', handler: _f4b49z, lazy: false, middleware: true, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_mT6n5y, lazy: true, middleware: false, method: undefined },
  { route: '', handler: _54Xj4Y, lazy: false, middleware: true, method: undefined },
  { route: '/__sitemap__/style.xsl', handler: _rzAExA, lazy: false, middleware: false, method: undefined },
  { route: '/sitemap.xml', handler: _ScF72f, lazy: false, middleware: false, method: undefined },
  { route: '/_ipx/**', handler: _r97oAP, lazy: false, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_mT6n5y, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((_err) => {
      console.error("Error while capturing another error", _err);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(false),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      await nitroApp.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter({
    preemptive: true
  });
  const localCall = createCall(toNodeListener(h3App));
  const _localFetch = createFetch(localCall, globalThis.fetch);
  const localFetch = (input, init) => _localFetch(input, init).then(
    (response) => normalizeFetchResponse(response)
  );
  const $fetch = createFetch$1({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  h3App.use(
    eventHandler((event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const envContext = event.node.req?.__unenv__;
      if (envContext) {
        Object.assign(event.context, envContext);
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (envContext?.waitUntil) {
          envContext.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
    })
  );
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  for (const plugin of plugins) {
    try {
      plugin(app);
    } catch (err) {
      captureError(err, { tags: ["plugin"] });
      throw err;
    }
  }
  return app;
}
const nitroApp = createNitroApp();
const useNitroApp = () => nitroApp;

const debug = (...args) => {
};
function GracefulShutdown(server, opts) {
  opts = opts || {};
  const options = Object.assign(
    {
      signals: "SIGINT SIGTERM",
      timeout: 3e4,
      development: false,
      forceExit: true,
      onShutdown: (signal) => Promise.resolve(signal),
      preShutdown: (signal) => Promise.resolve(signal)
    },
    opts
  );
  let isShuttingDown = false;
  const connections = {};
  let connectionCounter = 0;
  const secureConnections = {};
  let secureConnectionCounter = 0;
  let failed = false;
  let finalRun = false;
  function onceFactory() {
    let called = false;
    return (emitter, events, callback) => {
      function call() {
        if (!called) {
          called = true;
          return Reflect.apply(callback, this, arguments);
        }
      }
      for (const e of events) {
        emitter.on(e, call);
      }
    };
  }
  const signals = options.signals.split(" ").map((s) => s.trim()).filter((s) => s.length > 0);
  const once = onceFactory();
  once(process, signals, (signal) => {
    shutdown(signal).then(() => {
      if (options.forceExit) {
        process.exit(failed ? 1 : 0);
      }
    }).catch((err) => {
      process.exit(1);
    });
  });
  function isFunction(functionToCheck) {
    const getType = Object.prototype.toString.call(functionToCheck);
    return /^\[object\s([A-Za-z]+)?Function]$/.test(getType);
  }
  function destroy(socket, force = false) {
    if (socket._isIdle && isShuttingDown || force) {
      socket.destroy();
      if (socket.server instanceof http.Server) {
        delete connections[socket._connectionId];
      } else {
        delete secureConnections[socket._connectionId];
      }
    }
  }
  function destroyAllConnections(force = false) {
    for (const key of Object.keys(connections)) {
      const socket = connections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        destroy(socket);
      }
    }
    for (const key of Object.keys(secureConnections)) {
      const socket = secureConnections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        destroy(socket);
      }
    }
  }
  server.on("request", function(req, res) {
    req.socket._isIdle = false;
    if (isShuttingDown && !res.headersSent) {
      res.setHeader("connection", "close");
    }
    res.on("finish", function() {
      req.socket._isIdle = true;
      destroy(req.socket);
    });
  });
  server.on("connection", function(socket) {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = connectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      connections[id] = socket;
      socket.once("close", () => {
        delete connections[socket._connectionId];
      });
    }
  });
  server.on("secureConnection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = secureConnectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      secureConnections[id] = socket;
      socket.once("close", () => {
        delete secureConnections[socket._connectionId];
      });
    }
  });
  process.on("close", function() {
  });
  function shutdown(sig) {
    function cleanupHttp() {
      destroyAllConnections();
      return new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) {
            return reject(err);
          }
          return resolve(true);
        });
      });
    }
    if (options.development) {
      return process.exit(0);
    }
    function finalHandler() {
      if (!finalRun) {
        finalRun = true;
        if (options.finally && isFunction(options.finally)) {
          options.finally();
        }
      }
      return Promise.resolve();
    }
    function waitForReadyToShutDown(totalNumInterval) {
      if (totalNumInterval === 0) {
        debug(
          `Could not close connections in time (${options.timeout}ms), will forcefully shut down`
        );
        return Promise.resolve(true);
      }
      const allConnectionsClosed = Object.keys(connections).length === 0 && Object.keys(secureConnections).length === 0;
      if (allConnectionsClosed) {
        return Promise.resolve(false);
      }
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(waitForReadyToShutDown(totalNumInterval - 1));
        }, 250);
      });
    }
    if (isShuttingDown) {
      return Promise.resolve();
    }
    return options.preShutdown(sig).then(() => {
      isShuttingDown = true;
      cleanupHttp();
    }).then(() => {
      const pollIterations = options.timeout ? Math.round(options.timeout / 250) : 0;
      return waitForReadyToShutDown(pollIterations);
    }).then((force) => {
      if (force) {
        destroyAllConnections(force);
      }
      return options.onShutdown(sig);
    }).then(finalHandler).catch((err) => {
      const errString = typeof err === "string" ? err : JSON.stringify(err);
      failed = true;
      throw errString;
    });
  }
  function shutdownManual() {
    return shutdown("manual");
  }
  return shutdownManual;
}

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT, 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  GracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((err) => {
          console.error(err);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const path = process.env.NITRO_UNIX_SOCKET;
const listener = server.listen(path ? { path } : { port, host }, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const addressInfo = listener.address();
  if (typeof addressInfo === "string") {
    console.log(`Listening on unix socket ${addressInfo}`);
    return;
  }
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${addressInfo.family === "IPv6" ? `[${addressInfo.address}]` : addressInfo.address}:${addressInfo.port}${baseURL}`;
  console.log(`Listening on ${url}`);
});
trapUnhandledNodeErrors();
setupGracefulShutdown(listener, nitroApp);
const nodeServer = {};

export { $fetch as $, withLeadingSlash as A, encodeParam as B, createHooks as C, encodePath as D, parseQuery as E, withTrailingSlash as F, withoutTrailingSlash as G, getRequestURL as H, nodeServer as I, send as a, setResponseStatus as b, setResponseHeaders as c, useRuntimeConfig as d, eventHandler as e, getQuery as f, getResponseStatus as g, createError$1 as h, getRouteRules as i, joinURL as j, getResponseStatusText as k, hasProtocol as l, isScriptProtocol as m, parse as n, getRequestHeader as o, parseURL as p, defu as q, sanitizeStatusCode as r, setResponseHeader as s, destr as t, useNitroApp as u, isEqual as v, withQuery as w, setCookie as x, getCookie as y, deleteCookie as z };
//# sourceMappingURL=node-server.mjs.map
