const withRetryHandling = (callback, { baseDelay = 4e3, logger = console, numberOfTries = 3 } = {}) => function callbackWithRetryHandling(...params) {
  const retry = async (attempt = 1) => {
    try {
      return await callback(...params);
    } catch (error) {
      if (attempt >= numberOfTries)
        throw error;
      const delay = baseDelay * attempt;
      if (logger)
        logger.warn("Retry because of", error);
      return new Promise(
        (resolve) => setTimeout(() => resolve(retry(attempt + 1)), delay)
      );
    }
  };
  return retry();
};

export { withRetryHandling as w };
//# sourceMappingURL=retry-handling-kb1itlan.mjs.map
