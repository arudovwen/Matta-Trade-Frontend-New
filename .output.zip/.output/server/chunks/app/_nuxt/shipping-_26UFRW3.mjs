import { _ as __nuxt_component_1$1 } from './AppIcon-D3CPABPP.mjs';
import { useSSRContext, ref, computed, mergeProps, inject, unref, isRef } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { _ as __nuxt_component_1$2 } from './index-eSH9oSpY.mjs';
import { _ as __nuxt_component_1$3 } from './index-mLIR32Vn.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { useForm } from 'vee-validate';
import * as yup from 'yup';
import { toast } from 'vue3-toastify';
import { e as editshipping, b as addshipping, d as getalladdress } from './cartservice-JuOkMZ9e.mjs';
import { k as defineStore, u as useRoute, e as useRouter } from '../server.mjs';

const _sfc_main$2 = {
  __name: "Address",
  __ssrInlineRender: true,
  props: ["active", "detail"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1$1;
      if (__props.detail) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "py-2" }, _attrs))}><div class="flex justify-between items-center"><p class="text-base font-bold mb-[10px]">${ssrInterpolate(__props.detail.firstName)} ${ssrInterpolate(__props.detail.lasttName)}</p>`);
        if (__props.active) {
          _push(ssrRenderComponent(_component_AppIcon, {
            icon: "lets-icons:check-fill",
            class: "text-[#2176FF] text-lg"
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div><p class="text-sm mb-[7px] max-w-[280px]">${ssrInterpolate(__props.detail.street)}, ${ssrInterpolate(__props.detail.city)}, ${ssrInterpolate(__props.detail.country)}</p><p class="text-sm">${ssrInterpolate(__props.detail.postalCode)}</p></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Checkout/shipping/Address.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "Form",
  __ssrInlineRender: true,
  setup(__props) {
    const isOpen = inject("isOpen");
    const isLoading = ref(false);
    const formValues = {
      firstName: "",
      lastName: "",
      street: "",
      country: "",
      city: "",
      postalCode: "",
      isDefault: false
    };
    const schema = yup.object({
      firstName: yup.string().required("First name is required"),
      lastName: yup.string().required("Last name is required"),
      street: yup.string().required("Address is required"),
      country: yup.string().required("Country is required"),
      city: yup.string().required("City is required"),
      postalCode: yup.string().required("Postal code is required")
    });
    const { handleSubmit, defineField, errors } = useForm({
      validationSchema: schema,
      initialValues: formValues
    });
    const [firstName, firstNameAtt] = defineField("firstName");
    const [lastName, lastNameAtt] = defineField("lastName");
    const [street, streetAtt] = defineField("street");
    const [country, countryAtt] = defineField("country");
    const [city, cityAtt] = defineField("city");
    const [postalCode, postalCodeAtt] = defineField("postalCode");
    const [isDefault, isDefaultAtt] = defineField("isDefault");
    handleSubmit((values) => {
      isLoading.value = true;
      editshipping(values).then((res) => {
        if (res.status === 200) {
          toast.info("Address updated");
          isOpen.value = false;
          useshippingStore.getAlladdress();
        }
      }).catch((err) => {
        isLoading.value = false;
        if (err.response.data.message || err.response.data.Message) {
          toast.error(err.response.data.message || err.response.data.Message);
        }
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Textinput = __nuxt_component_1$2;
      const _component_Checkbox = __nuxt_component_1$3;
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white w-full" }, _attrs))}><legend class="block text-[20px] font-bold mb-8 text-left"> Shipping address </legend><form class="grid grid-cols-1 xl:grid-cols-2 gap-x-[18px] gap-y-4 w-full"><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "First name",
        type: "text",
        name: "firstName"
      }, unref(firstNameAtt), {
        modelValue: unref(firstName),
        "onUpdate:modelValue": ($event) => isRef(firstName) ? firstName.value = $event : null,
        error: unref(errors).firstName
      }), null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Last name",
        type: "text",
        name: "lasttName"
      }, unref(lastNameAtt), {
        modelValue: unref(lastName),
        "onUpdate:modelValue": ($event) => isRef(lastName) ? lastName.value = $event : null,
        error: unref(errors).lastName
      }), null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Country",
        type: "tel",
        name: "country",
        classInput: "!h-[45px]",
        modelValue: unref(country),
        "onUpdate:modelValue": ($event) => isRef(country) ? country.value = $event : null
      }, unref(countryAtt), {
        error: unref(errors).country
      }), null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "City",
        type: "text",
        name: "city",
        classInput: "!h-[45px]",
        modelValue: unref(city),
        "onUpdate:modelValue": ($event) => isRef(city) ? city.value = $event : null
      }, unref(cityAtt), {
        error: unref(errors).city
      }), null, _parent));
      _push(`</div> <div class="xl:col-span-2">`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Address",
        name: "street",
        classInput: "!h-[45px]",
        modelValue: unref(street),
        "onUpdate:modelValue": ($event) => isRef(street) ? street.value = $event : null
      }, unref(streetAtt), {
        error: unref(errors).street
      }), null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Postal code",
        type: "tel",
        name: "postalCode",
        classInput: "!h-[45px]",
        modelValue: unref(postalCode),
        "onUpdate:modelValue": ($event) => isRef(postalCode) ? postalCode.value = $event : null
      }, unref(postalCodeAtt), {
        error: unref(errors).postalCode
      }), null, _parent));
      _push(`</div><div class="flex items-center text-[#333] darks:text-slate-400 text-xs md:text-sm gap-x-[2px]">`);
      _push(ssrRenderComponent(_component_Checkbox, mergeProps({
        label: "Set default",
        labelClass: "text-xs md:text-sm",
        modelValue: unref(isDefault),
        "onUpdate:modelValue": ($event) => isRef(isDefault) ? isDefault.value = $event : null
      }, unref(isDefaultAtt)), null, _parent));
      _push(`</div><div class="xl:col-span-2 grid gap-y-[22px] mb-9 mt-4">`);
      _push(ssrRenderComponent(_component_AppButton, {
        type: "submit",
        isLoading: unref(isLoading),
        isDisabled: unref(isLoading),
        text: "Add address",
        btnClass: "normal-case btn-primary !py-3"
      }, null, _parent));
      _push(`</div></form></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Checkout/shipping/Form.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_7 = _sfc_main$1;
const _sfc_main = {
  __name: "EditForm",
  __ssrInlineRender: true,
  setup(__props) {
    inject("detail");
    inject("type");
    const isOpen = inject("isOpen");
    const isLoading = ref(false);
    const formValues = {
      firstName: "",
      lastName: "",
      street: "",
      country: "",
      city: "",
      postalCode: "",
      isDefault: false
    };
    const schema = yup.object({
      firstName: yup.string().required("First name is required"),
      lastName: yup.string().required("Last name is required"),
      street: yup.string().required("Address is required"),
      country: yup.string().required("Country is required"),
      city: yup.string().required("City is required"),
      postalCode: yup.string().required("Postal code is required")
    });
    const { handleSubmit, defineField, errors, setValues } = useForm({
      validationSchema: schema,
      initialValues: formValues
    });
    const [firstName, firstNameAtt] = defineField("firstName");
    const [lastName, lastNameAtt] = defineField("lastName");
    const [street, streetAtt] = defineField("street");
    const [country, countryAtt] = defineField("country");
    const [city, cityAtt] = defineField("city");
    const [postalCode, postalCodeAtt] = defineField("postalCode");
    const [isDefault, isDefaultAtt] = defineField("isDefault");
    useRoute();
    useRouter();
    handleSubmit((values) => {
      isLoading.value = true;
      addshipping(values).then((res) => {
        if (res.status === 200) {
          toast.info("Address added");
          isOpen.value = false;
        }
      }).catch((err) => {
        isLoading.value = false;
        if (err.response.data.message || err.response.data.Message) {
          toast.error(err.response.data.message || err.response.data.Message);
        }
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Textinput = __nuxt_component_1$2;
      const _component_Checkbox = __nuxt_component_1$3;
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white w-full" }, _attrs))}><legend class="block text-[20px] font-bold mb-8 text-left"> Shipping address </legend><form class="grid grid-cols-1 xl:grid-cols-2 gap-x-[18px] gap-y-4 w-full"><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "First name",
        type: "text",
        name: "firstName"
      }, unref(firstNameAtt), {
        modelValue: unref(firstName),
        "onUpdate:modelValue": ($event) => isRef(firstName) ? firstName.value = $event : null,
        error: unref(errors).firstName
      }), null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Last name",
        type: "text",
        name: "lasttName"
      }, unref(lastNameAtt), {
        modelValue: unref(lastName),
        "onUpdate:modelValue": ($event) => isRef(lastName) ? lastName.value = $event : null,
        error: unref(errors).lastName
      }), null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Country",
        type: "tel",
        name: "country",
        classInput: "!h-[45px]",
        modelValue: unref(country),
        "onUpdate:modelValue": ($event) => isRef(country) ? country.value = $event : null
      }, unref(countryAtt), {
        error: unref(errors).country
      }), null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "City",
        type: "text",
        name: "city",
        classInput: "!h-[45px]",
        modelValue: unref(city),
        "onUpdate:modelValue": ($event) => isRef(city) ? city.value = $event : null
      }, unref(cityAtt), {
        error: unref(errors).city
      }), null, _parent));
      _push(`</div> <div class="xl:col-span-2">`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Address",
        name: "street",
        classInput: "!h-[45px]",
        modelValue: unref(street),
        "onUpdate:modelValue": ($event) => isRef(street) ? street.value = $event : null
      }, unref(streetAtt), {
        error: unref(errors).street
      }), null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Postal code",
        type: "tel",
        name: "postalCode",
        classInput: "!h-[45px]",
        modelValue: unref(postalCode),
        "onUpdate:modelValue": ($event) => isRef(postalCode) ? postalCode.value = $event : null
      }, unref(postalCodeAtt), {
        error: unref(errors).postalCode
      }), null, _parent));
      _push(`</div><div class="flex items-center text-[#333] darks:text-slate-400 text-xs md:text-sm gap-x-[2px]">`);
      _push(ssrRenderComponent(_component_Checkbox, mergeProps({
        label: "Set default",
        labelClass: "text-xs md:text-sm",
        modelValue: unref(isDefault),
        "onUpdate:modelValue": ($event) => isRef(isDefault) ? isDefault.value = $event : null
      }, unref(isDefaultAtt)), null, _parent));
      _push(`</div><div class="xl:col-span-2 grid gap-y-[22px] mb-9 mt-4">`);
      _push(ssrRenderComponent(_component_AppButton, {
        type: "submit",
        isLoading: unref(isLoading),
        isDisabled: unref(isLoading),
        text: "Update address",
        btnClass: "normal-case btn-primary !py-3"
      }, null, _parent));
      _push(`</div></form></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Checkout/shipping/EditForm.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_8 = _sfc_main;
const useShippingStore = defineStore("shipping", () => {
  const addresses = ref([]);
  const loading = ref(true);
  const addressesData = computed(() => addresses.value);
  const isLoading = computed(() => loading.value);
  const defaultAddress = computed(
    () => addresses.value.find((i) => i.isDefault)
  );
  function setAddresses(data) {
    addresses.value = data;
  }
  function getAlladdress() {
    loading.value = true;
    getalladdress().then((res) => {
      addresses.value = res.data.data;
      loading.value = false;
    }).catch(() => {
      loading.value = false;
    });
  }
  return {
    addressesData,
    addresses,
    setAddresses,
    defaultAddress,
    getAlladdress,
    isLoading
  };
});

export { __nuxt_component_1 as _, __nuxt_component_7 as a, __nuxt_component_8 as b, useShippingStore as u };
//# sourceMappingURL=shipping-_26UFRW3.mjs.map
