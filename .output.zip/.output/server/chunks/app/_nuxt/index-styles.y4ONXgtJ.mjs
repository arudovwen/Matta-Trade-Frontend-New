const Banner_vue_vue_type_style_index_0_scoped_9d1a16a5_lang = "";

const Testimonials_vue_vue_type_style_index_0_lang = ".testimonial .carousel__pagination-button:after{background-color:hsla(0,0%,85%,.5);border-radius:50%;height:10px;width:10px}.testimonial .carousel__pagination-button--active:after,.testimonial .carousel__pagination-button:hover:after{background-color:#d9d9d9}.testimonial .carousel__item{min-height:200px;width:100%}";

const indexStyles_y4ONXgtJ = [Banner_vue_vue_type_style_index_0_scoped_9d1a16a5_lang, Testimonials_vue_vue_type_style_index_0_lang];

export { indexStyles_y4ONXgtJ as default };
//# sourceMappingURL=index-styles.y4ONXgtJ.mjs.map
