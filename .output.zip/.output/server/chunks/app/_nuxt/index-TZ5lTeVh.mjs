import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { u as useShippingStore, _ as __nuxt_component_1$2, a as __nuxt_component_7, b as __nuxt_component_8 } from './shipping-_26UFRW3.mjs';
import { _ as __nuxt_component_6 } from './Center-HbcRsv6_.mjs';
import { mergeProps, useSSRContext, computed, ref, unref, provide, withCtx, createVNode, openBlock, createBlock, createCommentVNode, inject } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderClass } from 'vue/server-renderer';
import { c as confirmpurchase } from './cartservice-JuOkMZ9e.mjs';
import { _ as __nuxt_component_1$3 } from './AppIcon-D3CPABPP.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import { a as useHead, d as useAuthStore, e as useRouter, h as useRuntimeConfig } from '../server.mjs';
import { u as useCartStore } from './cart-fg4oswtQ.mjs';
import { _ as __unimport_currencyFormat } from './currencyFormat-ET0sIbrj.mjs';
import { toast } from 'vue3-toastify';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import './index-eSH9oSpY.mjs';
import '../../rollup/_vue.mjs';
import 'cleave.js';
import './index-mLIR32Vn.mjs';
import './ck-white-co8-jVxZ.mjs';
import 'vee-validate';
import 'yup';
import '@headlessui/vue';
import './retry-handling-kb1itlan.mjs';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$5 = {
  __name: "Select",
  __ssrInlineRender: true,
  setup(__props) {
    const shippingStore = useShippingStore();
    const detail = inject("detail");
    const type = inject("type");
    const isOpen = inject("isOpen");
    function handleEdit(val) {
      detail.value = val;
      type.value = "edit";
      isOpen.value = true;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CheckoutShippingAddress = __nuxt_component_1$2;
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(_attrs)}><h5 class="block text-[20px] font-bold mb-8 text-left"> Select shipping address </h5><div class="grid gap-y-6 mb-4 max-h-[600px] overflow-y-auto"><!--[-->`);
      ssrRenderList(unref(shippingStore).addressesData, (n) => {
        _push(`<div class="${ssrRenderClass([
          n.isDefault ? "border-[#91B3F8] bg-[#E3EBFD] " : "border-[#F3F3F3]",
          "rounded-[10px] py-3 px-[16px] border-2 cursor-pointer"
        ])}"><div>`);
        _push(ssrRenderComponent(_component_CheckoutShippingAddress, {
          detail: n,
          active: n.isDefault
        }, null, _parent));
        _push(`</div><div class="flex gap-x-5 mt-3">`);
        _push(ssrRenderComponent(_component_AppButton, {
          onClick: ($event) => handleEdit(n),
          text: "Edit",
          type: "button",
          icon: "iconamoon:edit",
          btnClass: " !px-0 0 !py-[0] text-xs sm:text-sm !font-normal",
          iconClass: "!text-base"
        }, null, _parent));
        _push(ssrRenderComponent(_component_AppButton, {
          text: "Delete",
          icon: "bx:trash",
          btnClass: " !px-0  !py-[0] text-xs sm:text-sm !font-normal",
          iconClass: "!text-base"
        }, null, _parent));
        _push(`</div></div>`);
      });
      _push(`<!--]--></div>`);
      _push(ssrRenderComponent(_component_AppButton, {
        onClick: ($event) => type.value = "form",
        text: "New shipping address",
        icon: "icon-park-outline:plus",
        btnClass: " !px-0 !sm:px-6 !py-[0px] text-xs sm:text-sm !text-[#2176FF]"
      }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Checkout/Select.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_5 = _sfc_main$5;
const _sfc_main$4 = {
  __name: "Shipping",
  __ssrInlineRender: true,
  setup(__props) {
    const shippingStore = useShippingStore();
    const type = ref("form");
    const detail = ref("detail");
    const isOpen = ref(false);
    function openModal(val) {
      type.value = val;
      isOpen.value = true;
    }
    provide("type", type);
    provide("isOpen", isOpen);
    provide("detail", detail);
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_CheckoutShippingAddress = __nuxt_component_1$2;
      const _component_AppButton = __nuxt_component_4;
      const _component_ModalCenter = __nuxt_component_6;
      const _component_CheckoutShippingForm = __nuxt_component_7;
      const _component_CheckoutShippingEditForm = __nuxt_component_8;
      const _component_CheckoutSelect = __nuxt_component_5;
      _push(`<!--[--><div class="bg-white rounded-[10px]"><h2 class="px-[30px] py-5 font-bold text-2xl border-b border-[#f3f3f3]"> Shipping Address </h2><div class="px-[30px] pt-6 pb-[30px]"><div class="mb-6">`);
      _push(ssrRenderComponent(_component_CheckoutShippingAddress, {
        detail: (_a = unref(shippingStore)) == null ? void 0 : _a.defaultAddress
      }, null, _parent));
      _push(`</div><div class="flex flex-col md:flex-row md:items-center gap-y-4 md:gap-y-0 md:gap-x-4">`);
      _push(ssrRenderComponent(_component_AppButton, {
        onClick: ($event) => openModal("form"),
        text: "New shipping address",
        icon: "icon-park-outline:plus",
        btnClass: "bg-primary-500  text-white !px-4\n      !sm:px-6 !py-[9px] text-xs sm:text-sm"
      }, null, _parent));
      _push(ssrRenderComponent(_component_AppButton, {
        onClick: ($event) => openModal("select"),
        text: "Change address",
        btnClass: "!px-4\n      !sm:px-6 !py-[0px] text-sm hover:underline"
      }, null, _parent));
      _push(`</div></div></div>`);
      _push(ssrRenderComponent(_component_ModalCenter, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="w-full max-w-[500px] p-6 md:py-9 md:px-10 z-[999] relative"${_scopeId}>`);
            if (unref(type) === "form") {
              _push2(ssrRenderComponent(_component_CheckoutShippingForm, null, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (unref(type) === "edit") {
              _push2(ssrRenderComponent(_component_CheckoutShippingEditForm, null, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (unref(type) === "select") {
              _push2(ssrRenderComponent(_component_CheckoutSelect, null, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "w-full max-w-[500px] p-6 md:py-9 md:px-10 z-[999] relative" }, [
                unref(type) === "form" ? (openBlock(), createBlock(_component_CheckoutShippingForm, { key: 0 })) : createCommentVNode("", true),
                unref(type) === "edit" ? (openBlock(), createBlock(_component_CheckoutShippingEditForm, { key: 1 })) : createCommentVNode("", true),
                unref(type) === "select" ? (openBlock(), createBlock(_component_CheckoutSelect, { key: 2 })) : createCommentVNode("", true)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Checkout/Shipping.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$4;
const _sfc_main$3 = {
  __name: "Payment",
  __ssrInlineRender: true,
  setup(__props) {
    const active = ref("card");
    const data = [
      {
        title: "Card / Bank Transfer",
        icon: "uil:credit-card",
        key: "card",
        url: ""
      },
      {
        title: "Matta Wallet",
        icon: "ion:wallet-outline",
        url: "",
        key: "matta"
      },
      {
        title: "Pay with Trade Finance",
        icon: "teenyicons:credit-card-outline",
        url: "",
        key: "finance"
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1$3;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white rounded-[10px]" }, _attrs))}><h2 class="px-[30px] py-5 font-bold text-2xl border-b border-[#f3f3f3]"> Payment Method </h2><div class="p-[30px]"><div class="flex flex-wrap gap-y-6 md:gap-y-0 gap-x-6"><!--[-->`);
      ssrRenderList(data, (n) => {
        _push(`<button${ssrIncludeBooleanAttr(n.key !== "card") ? " disabled" : ""} class="${ssrRenderClass(`${unref(active) === n.key ? "bg-[rgba(22,94,240,0.12)] border-[#165EF066]" : "border-[#E7E7E780]"} ${n.key === "card" ? "" : "opacity-50 cursor-not-allowed"} shadow-[0px_0px _4px_0px_rgba(0,0,0,0.11)] min-w-[180px] w-full md:max-w-[180px] rounded-[10px] py-6 px-[16px] flex flex-col justify-center items-center border-2`)}">`);
        _push(ssrRenderComponent(_component_AppIcon, {
          class: "text-4xl mb-2",
          icon: n.icon
        }, null, _parent));
        _push(`<p class="text-xs">${ssrInterpolate(n.title)}</p></button>`);
      });
      _push(`<!--]--></div></div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Checkout/Payment.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_1$1 = _sfc_main$3;
const _sfc_main$2 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_CheckoutShipping = __nuxt_component_0;
  const _component_CheckoutPayment = __nuxt_component_1$1;
  _push(`<div${ssrRenderAttrs(_attrs)}><div class="rounded-[10px]"><div class="flex flex-col gap-y-5">`);
  _push(ssrRenderComponent(_component_CheckoutShipping, null, null, _parent));
  _push(ssrRenderComponent(_component_CheckoutPayment, null, null, _parent));
  _push(`</div></div></div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Checkout/Content.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender]]);
function payWithMonnify(data, onModalClose, onSuccess) {
  const config = useRuntimeConfig();
  useCartStore();
  (void 0).MonnifySDK.initialize({
    amount: data.amount,
    currency: "NGN",
    reference: "" + Math.floor(Math.random() * 1e9 + 1),
    customerName: data.name,
    customerEmail: data.email,
    apiKey: config.public.APP_MONNIFYISTEST,
    contractCode: config.public.APP_MONNIFYCONTRACTCODE,
    paymentDescription: "Order payment",
    isTestMode: config.public.APP_MONNIFYISTESTMODE,
    metadata: {},
    paymentMethods: ["CARD", "ACCOUNT_TRANSFER", "USSD", "PHONE_NUMBER"],
    incomeSplitConfig: [],
    onComplete: function(response) {
      onSuccess(response);
    },
    onClose: function(data2) {
      if (data2.responseCode === "USER_CANCELLED") {
        onModalClose();
      }
      if (data2.status === "FAILED") {
        onModalClose();
      }
    }
  });
}
const _sfc_main$1 = {
  __name: "Side",
  __ssrInlineRender: true,
  setup(__props) {
    const cartTaxAmount = computed(
      () => (cartStore == null ? void 0 : cartStore.cartTotalAmount) * (cartStore == null ? void 0 : cartStore.tax) + (cartStore == null ? void 0 : cartStore.cartTotalAmount)
    );
    const shippingStore = useShippingStore();
    const authstore = useAuthStore();
    const loading = ref(false);
    const cartStore = useCartStore();
    useRouter();
    const data = ref(null);
    const status = ref("Confirm order");
    function onModalClose() {
      loading.value = false;
      toast.error("Payment cancelled");
      status.value = "Retry order";
      loading.value = false;
    }
    function confirmOrder() {
      var _a, _b, _c, _d;
      status.value = "Processing order...";
      loading.value = true;
      data.value = {
        shippingAddressId: shippingStore == null ? void 0 : shippingStore.defaultAddress.id,
        email: (_a = authstore.userInfo) == null ? void 0 : _a.email,
        name: `${(_b = authstore.userInfo) == null ? void 0 : _b.firstName} ${(_c = authstore.userInfo) == null ? void 0 : _c.lastName}`,
        amount: cartTaxAmount.value,
        phoneNumber: (_d = authstore.userInfo) == null ? void 0 : _d.phoneNumber
      };
      payWithMonnify(data.value, onModalClose, onSuccess);
    }
    function onSuccess() {
      confirmpurchase({ shippingAddressId: data.value.shippingAddressId }).then(
        (res) => {
          if (res.status === 200) {
            cartStore == null ? void 0 : cartStore.clearCart;
            (void 0).location.href = "/order-success";
          }
        }
      );
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i;
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-[#333] rounded-[10px] py-[30px] px-5 w-full lg:w-[300px] xl:w-[360px]" }, _attrs))}><div class="font-semibold text-2xl text-white pb-6">Order Details</div><div class="flex flex-col gap-y-5"><!--[-->`);
      ssrRenderList((_a = unref(cartStore)) == null ? void 0 : _a.cart, (item) => {
        _push(`<div class="flex justify-between"><div><p class="font-semibold text-sm text-white mb-[2px]">${ssrInterpolate(item.product)}</p><p class="text-xs text-[#959595]"> Qty: ${ssrInterpolate(item.quantity)} ${ssrInterpolate(item.selectedPackage)}</p></div><p class="font-medium text-sm text-white">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(item.packagePrice))}</p></div>`);
      });
      _push(`<!--]--></div><hr class="my-[20px] border-white/10"><div class="flex flex-col gap-y-3"><div class="flex justify-between"><p class="text-sm text-[#E1E1E1]">Sub-total</p><p class="text-white font-medium text-sm">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))((_b = unref(cartStore)) == null ? void 0 : _b.cartTotalAmount))}</p></div><div class="flex justify-between"><p class="text-sm text-[#E1E1E1]">Tax (7.5%)</p><p class="text-white text-sm font-medium">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(((_c = unref(cartStore)) == null ? void 0 : _c.cartTotalAmount) * ((_d = unref(cartStore)) == null ? void 0 : _d.tax)))}</p></div><div class="flex justify-between"><p class="text-sm text-[#E1E1E1]">Shipping &amp; Handling</p><p class="text-white font-medium text-sm">TBD</p></div></div><hr class="my-[20px] border-white/10"><div class="flex justify-between mb-[25px]"><p class="text-sm text-[#E1E1E1]">Total</p><p class="text-white font-bold">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(
        ((_e = unref(cartStore)) == null ? void 0 : _e.cartTotalAmount) * ((_f = unref(cartStore)) == null ? void 0 : _f.tax) + ((_g = unref(cartStore)) == null ? void 0 : _g.cartTotalAmount)
      ))}</p></div>`);
      _push(ssrRenderComponent(_component_AppButton, {
        isLoading: unref(loading),
        onClick: confirmOrder,
        isDisabled: !((_h = unref(cartStore)) == null ? void 0 : _h.cart) || !((_i = unref(cartStore)) == null ? void 0 : _i.cartTotalAmount) || unref(loading),
        text: unref(status),
        btnClass: "bg-primary-500  w-full text-white !px-4 !sm:px-6 !py-[13px] text-xs sm:text-sm mb-4"
      }, null, _parent));
      _push(`<p class="text-xs text-[#E1E1E1]"> After placing an order, our manager will contact you to clarify the price and other details of your order. </p></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Checkout/Side.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$1;
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Checkout | Matta",
      meta: [{ name: "description", content: "Checkout" }]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppButton = __nuxt_component_4;
      const _component_CheckoutContent = __nuxt_component_1;
      const _component_CheckoutSide = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container py-10 w-full" }, _attrs))}><div class="mb-6">`);
      _push(ssrRenderComponent(_component_AppButton, {
        link: "/cart",
        icon: "ion:arrow-back-sharp",
        text: "Back to cart",
        btnClass: "text-xs sm:text-sm !py-0 !px-0 !font-semibold"
      }, null, _parent));
      _push(`</div><div class="flex gap-x-5 w-full flex-col lg:flex-row gap-y-8 lg:gap-y-0"><div class="flex-1">`);
      _push(ssrRenderComponent(_component_CheckoutContent, null, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_CheckoutSide, null, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/checkout/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-TZ5lTeVh.mjs.map
