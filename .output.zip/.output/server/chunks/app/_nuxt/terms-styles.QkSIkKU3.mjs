const terms_vue_vue_type_style_index_0_scoped_73b47977_lang = "h2[data-v-73b47977]{font-size:18px;font-weight:600;margin-bottom:.8rem}h3[data-v-73b47977]{font-size:16px;margin-bottom:.7rem}h4[data-v-73b47977]{font-size:15px;margin-bottom:.5rem;padding-left:16px}p[data-v-73b47977]{font-size:14px;line-height:1.6;margin-bottom:1rem}article[data-v-73b47977]{margin-bottom:2rem}li[data-v-73b47977]{margin-bottom:10px}a[data-v-73b47977]{color:blue;font-size:14px;text-decoration:underline}";

const termsStyles_QkSIkKU3 = [terms_vue_vue_type_style_index_0_scoped_73b47977_lang, terms_vue_vue_type_style_index_0_scoped_73b47977_lang];

export { termsStyles_QkSIkKU3 as default };
//# sourceMappingURL=terms-styles.QkSIkKU3.mjs.map
