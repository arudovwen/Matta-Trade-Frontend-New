import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_4$1 } from './AppButton-rwP1M0KN.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-fc3HHrvA.mjs';
import { i as useImage, e as useRouter, u as useRoute, c as useMarketStore } from '../server.mjs';
import { mergeProps, unref, useSSRContext, computed, ref, withCtx, createVNode, toDisplayString, resolveComponent, openBlock, createBlock, Fragment, renderList } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrRenderAttr, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import { _ as __nuxt_component_1 } from './Board-3k2I8CZI.mjs';
import { _ as __nuxt_component_2$1 } from './Card-x8tysvFx.mjs';
import { _ as __nuxt_component_2$2 } from './Skelenton-oPDHwk9e.mjs';
import { _ as __nuxt_component_1$1 } from './nuxt-img-qJohECzX.mjs';
import { _ as __nuxt_component_1$2 } from './AppIcon-D3CPABPP.mjs';
import { Carousel, Pagination, Slide } from 'vue3-carousel';
import { _ as __nuxt_component_7 } from './Call-PMNbQp7f.mjs';
import { h as hotDeals } from './data-ZuhAAsy0.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';
import './currencyFormat-ET0sIbrj.mjs';
import '@iconify/vue';

const _sfc_main$6 = {
  __name: "Banner",
  __ssrInlineRender: true,
  setup(__props) {
    const nuxtImg = useImage();
    const backgroundStyles = computed(() => {
      const imgUrl = nuxtImg(`https://res.cloudinary.com/arudovwen-me/image/upload/f_webp/c_scale,h_600/xddierf8sf3w2gn1csau.jpg`, {
        sizes: { xl: "100vw", lg: "100vw", md: "100vw", sm: "100vw", xs: "100vw" }
      });
      return { backgroundImage: `url('${imgUrl}')` };
    });
    const router = useRouter();
    useRoute();
    const search = ref("");
    const frequentlySearched = [
      {
        name: "Ammonia Liquor"
      },
      {
        name: "Hydrogenated Oil"
      },
      {
        name: "Caustic Soda"
      }
    ];
    function handleSearch() {
      if (!search)
        return;
      router.push(`/market/${search.value}?search_query=${search.value}`);
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppButton = __nuxt_component_4$1;
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "relative w-full bg-black-400" }, _attrs))} data-v-9d1a16a5><div class="bg-cover bg-center min-h-[480px] md:min-h-[600px]" style="${ssrRenderStyle(unref(backgroundStyles))}" data-v-9d1a16a5><div class="absolute inset-0 bg-[rgba(0,0,0,0.72)]" data-v-9d1a16a5></div><div class="absolute inset-0 flex items-center justify-start text-white text-left container" data-v-9d1a16a5><div data-v-9d1a16a5><div class="max-w-[761px] mb-10" data-v-9d1a16a5><h1 class="text-3xl sm:text-4xl md:text-5xl lg:text-[56px] lg:leading-[67px] font-bold mb-6" data-v-9d1a16a5> Discover and buy chemicals and raw materials all in one place </h1><p class="text-sm sm:text-base md:text-xl lg:text-2xl" data-v-9d1a16a5> Search, compare, sample, quote and purchase from reliable and trustworthy suppliers </p></div><div class="max-w-[786px]" data-v-9d1a16a5><div class="relative flex p-1 w-full bg-white rounded-[5px] items-center mb-[6px] sm:mb-8" data-v-9d1a16a5><input placeholder="Search by product name or supplier" class="px-4 flex-1 h-9 placeholder:text-[rgba(156, 163, 175, 1)] text-xs sm:text-sm outline-none text-[#333]"${ssrRenderAttr("value", unref(search))} data-v-9d1a16a5>`);
      _push(ssrRenderComponent(_component_AppButton, {
        onClick: handleSearch,
        text: "Search",
        btnClass: "!px-10 btn-primary hidden sm:flex"
      }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_AppButton, {
        onClick: handleSearch,
        text: "Search",
        btnClass: "!px-4 !py-[10px] btn-primary sm:hidden w-full"
      }, null, _parent));
      _push(`<div class="hidden sm:flex gap-2 items-center flex-wrap" data-v-9d1a16a5><span class="whitespace-nowrap text-sm md:text-base" data-v-9d1a16a5>Frequently searched: </span><span class="flex gap-2 items-center flex-wrap" data-v-9d1a16a5><!--[-->`);
      ssrRenderList(frequentlySearched, (i) => {
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/market/${i.name}?search_query=${i.name}`,
          key: i.name
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="text-white border border-white rounded-full text-sm py-[5px] px-[10px]" data-v-9d1a16a5${_scopeId}>${ssrInterpolate(i.name)}</span>`);
            } else {
              return [
                createVNode("span", { class: "text-white border border-white rounded-full text-sm py-[5px] px-[10px]" }, toDisplayString(i.name), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></span></div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/landing/Banner.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__scopeId", "data-v-9d1a16a5"]]);
const _sfc_main$5 = {
  __name: "Hot",
  __ssrInlineRender: true,
  props: {
    title: {
      type: String,
      default: "Hot deals"
    },
    tag: {
      type: String,
      default: "hotdeals"
    }
  },
  setup(__props) {
    const isLoading = ref(true);
    const content = ref([]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      const _component_ProductCard = __nuxt_component_2$1;
      const _component_ProductSkelenton = __nuxt_component_2$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container mb-[30px]" }, _attrs))}>`);
      if (unref(content).length && !unref(isLoading)) {
        _push(`<div data-aos="fade-up" data-aos-once="true" class="flex justify-between items-center mb-4"><h2 class="text-xs sm:text-base lg:text-xl font-bold text-[#222] darks:text-white">${ssrInterpolate(__props.title)}</h2>`);
        _push(ssrRenderComponent(_component_router_link, {
          to: `/market/${encodeURIComponent(__props.title)}?tag=${__props.tag}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<button class="hover:border-b text-[10px] sm:text-sm lg:text-base border-[#333] darks:text-white darks:border-white leading-tight"${_scopeId}> See all items </button>`);
            } else {
              return [
                createVNode("button", { class: "hover:border-b text-[10px] sm:text-sm lg:text-base border-[#333] darks:text-white darks:border-white leading-tight" }, " See all items ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(content).length && !unref(isLoading)) {
        _push(`<div class="flex xl:grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-y-8 gap-x-4 md:gap-x-6 no-scrollbar hover:scrollbar overflow-x-auto pb-6"><!--[-->`);
        ssrRenderList(unref(content).slice(0, 5), (n, idx) => {
          _push(ssrRenderComponent(_component_ProductCard, {
            "data-aos": "fade-up",
            "data-aos-once": "true",
            key: idx,
            index: idx,
            detail: n
          }, null, _parent));
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isLoading)) {
        _push(`<div class="flex xl:grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-y-8 gap-x-4 md:gap-x-6 overflow-x-hidden hover:overflow-x-auto pb-6"><!--[-->`);
        ssrRenderList(5, (n) => {
          _push(`<div>`);
          _push(ssrRenderComponent(_component_ProductSkelenton, null, null, _parent));
          _push(`</div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/landing/Hot.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$5;
const GridImg = "/images/grid.svg";
const CheckImg = "/images/check.svg";
const FolderImg = "/images/folder.svg";
const LayerImg = "/images/layer.svg";
const _sfc_main$4 = {
  __name: "Info",
  __ssrInlineRender: true,
  setup(__props) {
    const content = [
      {
        title: "Streamlined Sourcing Made Easy",
        text: "Effortlessly connect with trusted suppliers for your chemical and raw material needs. Matta makes finding the right products simple and efficient",
        img: GridImg
      },
      {
        title: "Discover Diverse, Quality Selection",
        text: "Access a wide array of top-quality chemicals and materials. Matta\u2019s extensive product range meets diverse industrial demands with ease.",
        img: CheckImg
      },
      {
        title: "Quality Meets Competitive Pricing",
        text: "Experience superior quality at Matta's competitive prices. Our tailored approach ensures you get products of the highest quality at the best market rates.",
        img: FolderImg
      },
      {
        title: "Reliable Delivery, On Time Every Time",
        text: "Count on Matta for prompt deliveries. We ensure your production process remains uninterrupted with our fast and consistent supply chain.",
        img: LayerImg
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtImg = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-[#222] py-20" }, _attrs))}><div class="container grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4"><!--[-->`);
      ssrRenderList(content, (n) => {
        _push(`<div class="p-[30px] rounded-[16px] bg-[rgba(255,255,255,0.03)]" data-aos="fade-up" data-aos-once="true"><div><span class="bg-[rgba(255,255,255,0.08)] h-[60px] w-[60px] rounded-full flex items0center justify-center mb-[30px]">`);
        _push(ssrRenderComponent(_component_NuxtImg, {
          src: n.img,
          alt: n.title,
          width: "40",
          height: "40"
        }, null, _parent));
        _push(`</span><p class="mb-3 text-white text-lg md:text-xl max-w-[200px] leading-normal">${ssrInterpolate(n.title)}</p><p class="mb-2 text-white text-sm">${ssrInterpolate(n.text)}</p></div></div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/landing/Info.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$4;
const _sfc_main$3 = {
  __name: "Categories",
  __ssrInlineRender: true,
  setup(__props) {
    const store = useMarketStore();
    const content = [
      {
        title: "1000+",
        text: "Products"
      },
      {
        title: "200+",
        text: "Suppliers"
      },
      {
        title: "16",
        text: "Product categories"
      },
      {
        title: "5",
        text: "Countries served"
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_AppIcon = __nuxt_component_1$2;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="container py-10 md:py-20"><div class="flex flex-col md:flex-row gap-y-9 xl:gap-y-0 justify-between sm:mb-[90px] md:gap-x-10"><h1 data-aos="fade-up" data-aos-once="true" class="max-w-[633px] text-[#222] darks:text-white text-3xl xl:text-[49px] font-bold leading-[44.6px] xl:leading-[67.6px]"> Explore our wide range of solutions, designed for your specific business needs </h1><div class="grid grid-cols-2 gap-5 md:min-w-[300px]"><!--[-->`);
      ssrRenderList(content, (n) => {
        _push(`<div class="px-5 border-l-4 border-[rgba(81,32,11,0.05)]" data-aos="fade-up" data-aos-once="true"><span class="block font-bold text-[#2176FF] text-2xl xl:text-[44px] mb-2 xl:mb-[15px]">${ssrInterpolate(n.title)}</span><span class="block font-normal text-[#333] darks:text-white/80 text-sm xl:text-[20px]">${ssrInterpolate(n.text)}</span></div>`);
      });
      _push(`<!--]--></div></div><div data-aos="fade-up" data-aos-once="true" class="hidden lg:grid grid-cols-3 md:grid-cols-4 xl:grid-cols-8 gap-4 md:gap-5 justify-center max-h-[350px] overflow-y-auto no-scrollbar"><!--[-->`);
      ssrRenderList((_a = unref(store)) == null ? void 0 : _a.marketsData, (n, idx) => {
        _push(ssrRenderComponent(_component_NuxtLink, {
          key: idx,
          to: `/market/${encodeURIComponent(n.title.toLowerCase())}/${n.id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="mx-auto cursor-pointer px-5 flex flex-col w-[100px] md:w-[140px] h-[100px] md:h-[140px] border-2 border-[#EAEAEA] rounded-full items-center justify-center hover:border-[#777] hover:bg-[rgba(33,118,255,0.04)]"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_AppIcon, {
                icon: `fa6-solid:${n.imagePath}`,
                class: "text-base md:text-[40px] text-[#444444] darks:text-white/80 mb-[6px]"
              }, null, _parent2, _scopeId));
              _push2(`<span class="text-[10px] md:text-xs text-[#333] darks:text-white text-center"${_scopeId}>${ssrInterpolate(n.title)}</span></span>`);
            } else {
              return [
                createVNode("span", { class: "mx-auto cursor-pointer px-5 flex flex-col w-[100px] md:w-[140px] h-[100px] md:h-[140px] border-2 border-[#EAEAEA] rounded-full items-center justify-center hover:border-[#777] hover:bg-[rgba(33,118,255,0.04)]" }, [
                  createVNode(_component_AppIcon, {
                    icon: `fa6-solid:${n.imagePath}`,
                    class: "text-base md:text-[40px] text-[#444444] darks:text-white/80 mb-[6px]"
                  }, null, 8, ["icon"]),
                  createVNode("span", { class: "text-[10px] md:text-xs text-[#333] darks:text-white text-center" }, toDisplayString(n.title), 1)
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></div></div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/landing/Categories.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main$3;
const Brand1 = "/images/coke.png";
const Brand2 = "/images/cormart.png";
const Brand3 = "/images/honywell.png";
const Brand4 = "/images/basf.png";
const Brand5 = "/images/liquide.png";
const Brand6 = "/images/cargill.svg";
const _sfc_main$2 = {
  __name: "Brands",
  __ssrInlineRender: true,
  setup(__props) {
    const brands = [Brand1, Brand2, Brand3, Brand4, Brand5, Brand6];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtImg = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "py-10 container hidden lg:block" }, _attrs))}><h2 data-aos="fade-up" data-aos-once="true" class="text-xl font-semibold mb-10 text-center darks:text-white/80"> Trusted by Leading Global Customers &amp; Suppliers </h2><div class="grid grid-cols-3 lg:grid-cols-6 gap-6 justify-between items-center"><!--[-->`);
      ssrRenderList(brands, (n) => {
        _push(ssrRenderComponent(_component_NuxtImg, {
          "data-aos": "fade-up",
          "data-aos-once": "true",
          src: n,
          alt: n,
          width: "150",
          class: "mb-1 mx-auto w-100% h-auto"
        }, null, _parent));
      });
      _push(`<!--]--></div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/landing/Brands.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_5 = _sfc_main$2;
const Wrapper = "" + buildAssetsURL("wrapper.3V4OFfi4.png");
const _sfc_main$1 = {
  __name: "Testimonials",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container relative mt-10 md:helpersmt-[72px] pb-[100px] md:pb-[120px]" }, _attrs))}><div class="rounded-[6px] bg-cover lg:bg-contain bg-no-repeat pt-10 md:pt-[94px] pb-10 md:pb-[88px] relative h-full z-[3] mx-auto max-w-[1169px]" style="${ssrRenderStyle({ backgroundImage: `url('${unref(Wrapper)}')` })}"><div class="max-w-[937px] mx-auto text-center pl-6 pr-6">`);
      _push(ssrRenderComponent(unref(Carousel), { class: "max-w-[937px] mx-auto text-center testimonial" }, {
        addons: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Pagination), null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Pagination))
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(2, (slide) => {
              _push2(ssrRenderComponent(unref(Slide), { key: slide }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="carousel__item px-5"${_scopeId2}><p class="text-xs sm:text-sm lg:text-base xl:text-2xl text-white font-semibold mb-8"${_scopeId2}> \u201CEver since we discovered Matta, our production process has been more streamlined. From sourcing for materials, to logistics and delivery. Matta handles all aspects with exemplary proficiency and professionalism\u201D </p><p class="font-medium text-[11px] sm:text-xs md:text-sm xl:text-xl text-white mb-8"${_scopeId2}> James Orji - CEO, Mudally Nig. Ltd. </p></div>`);
                  } else {
                    return [
                      createVNode("div", { class: "carousel__item px-5" }, [
                        createVNode("p", { class: "text-xs sm:text-sm lg:text-base xl:text-2xl text-white font-semibold mb-8" }, " \u201CEver since we discovered Matta, our production process has been more streamlined. From sourcing for materials, to logistics and delivery. Matta handles all aspects with exemplary proficiency and professionalism\u201D "),
                        createVNode("p", { class: "font-medium text-[11px] sm:text-xs md:text-sm xl:text-xl text-white mb-8" }, " James Orji - CEO, Mudally Nig. Ltd. ")
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(), createBlock(Fragment, null, renderList(2, (slide) => {
                return createVNode(unref(Slide), { key: slide }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "carousel__item px-5" }, [
                      createVNode("p", { class: "text-xs sm:text-sm lg:text-base xl:text-2xl text-white font-semibold mb-8" }, " \u201CEver since we discovered Matta, our production process has been more streamlined. From sourcing for materials, to logistics and delivery. Matta handles all aspects with exemplary proficiency and professionalism\u201D "),
                      createVNode("p", { class: "font-medium text-[11px] sm:text-xs md:text-sm xl:text-xl text-white mb-8" }, " James Orji - CEO, Mudally Nig. Ltd. ")
                    ])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/landing/Testimonials.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_6 = _sfc_main$1;
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_LandingBanner = __nuxt_component_0;
      const _component_LandingBoard = __nuxt_component_1;
      const _component_LandingHot = __nuxt_component_2;
      const _component_LandingInfo = __nuxt_component_3;
      const _component_LandingCategories = __nuxt_component_4;
      const _component_LandingBrands = __nuxt_component_5;
      const _component_LandingTestimonials = __nuxt_component_6;
      const _component_LandingCall = __nuxt_component_7;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "min-h-screen mx-auto" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_LandingBanner, null, null, _parent));
      _push(`<div class="bg-[#F4F4F4] darks:bg-gray-700 pt-8 sm:pt-[60px]"><div class="hidden lg:block mb-6 sm:mb-10">`);
      _push(ssrRenderComponent(_component_LandingBoard, null, null, _parent));
      _push(`</div><div class="pb-8 xl:pb-[70px]">`);
      _push(ssrRenderComponent(_component_LandingHot, {
        content: "hotDeals" in _ctx ? _ctx.hotDeals : unref(hotDeals),
        tag: "hotdeals"
      }, null, _parent));
      _push(`<div class="lg:hidden mb-6 sm:mb-10">`);
      _push(ssrRenderComponent(_component_LandingBoard, null, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_LandingHot, {
        title: "Recommended",
        tag: "recommended"
      }, null, _parent));
      _push(ssrRenderComponent(_component_LandingHot, {
        title: "Best sellers",
        tag: "bestsellers"
      }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_LandingInfo, null, null, _parent));
      _push(`</div><div class="bg-white pt-6 md:pt-10">`);
      _push(ssrRenderComponent(_component_LandingCategories, null, null, _parent));
      _push(ssrRenderComponent(_component_LandingBrands, null, null, _parent));
      _push(ssrRenderComponent(_component_LandingTestimonials, null, null, _parent));
      _push(ssrRenderComponent(_component_LandingCall, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-wW2nfVKJ.mjs.map
