import { _ as __nuxt_component_1 } from './AppIcon-D3CPABPP.mjs';
import { useSSRContext, inject, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrIncludeBooleanAttr, ssrRenderClass, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';

const _sfc_main = {
  __name: "CartButton",
  __ssrInlineRender: true,
  props: ["iconClass", "btnClass", "textClass"],
  setup(__props) {
    const counter = inject("counter");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "overflow-hidden rounded h-full border border-[#E7E7E7] bg-white flex items-center" }, _attrs))}><button type="button"${ssrIncludeBooleanAttr(unref(counter) <= 1) ? " disabled" : ""} class="${ssrRenderClass([__props.btnClass, "h-full px-[15px] flex items-center justify-center bg-white disabled:opacity-60 border-r border-[#E7E7E7]"])}">`);
      _push(ssrRenderComponent(_component_AppIcon, {
        icon: "uiw:minus",
        class: `text-lg ${__props.iconClass}`
      }, null, _parent));
      _push(`</button><div class="flex-1 flex items-center"><input${ssrRenderAttr("value", unref(counter))} class="${ssrRenderClass([__props.textClass, "h-full bg-transparent rounded font-medium text-center outline-none w-full px-1 min-w-[50px]"])}"></div><button type="button" class="${ssrRenderClass([__props.btnClass, "h-full px-[15px] flex items-center justify-center bg-white border-l border-[#E7E7E7]"])}">`);
      _push(ssrRenderComponent(_component_AppIcon, {
        icon: "uiw:plus",
        class: `text-lg ${__props.iconClass}`
      }, null, _parent));
      _push(`</button></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CartButton.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_5 = _sfc_main;

export { __nuxt_component_5 as _ };
//# sourceMappingURL=CartButton-sf044Ti9.mjs.map
