import { t as store, r as urls, v as get } from '../server.mjs';
import { w as withRetryHandling } from './retry-handling-kb1itlan.mjs';

const config = {
  headers: { Authorization: `Bearer ${store.getters.accessToken}` }
};
const samplerequests = withRetryHandling(
  ({
    SortOrder,
    Search,
    PageNumber,
    PageSize,
    ProductId,
    ProducerId,
    RequestStatus
  }) => {
    return get(
      `${urls.SAMPLE_REQUESTS}?PageSize=${PageSize}&PageNumber=${PageNumber}&Search=${Search}&SortOrder=${SortOrder}
      &SupplierId=${store.getters.userId}&RequestStatus=${RequestStatus}&ProducerId=${ProducerId}&ProductId=${ProductId}`,
      config
    );
  }
);
const samplerequestdetails = withRetryHandling((requestId) => {
  return get(`${urls.SAMPLE_REQUEST_DETAILS}?requestId=${requestId}`, config);
});
const buyerdoc = withRetryHandling(
  ({
    SortOrder,
    Search,
    PageNumber,
    PageSize,
    ProductId,
    ProducerId,
    RequestStatus,
    SupplierId
  }) => {
    return get(
      `${urls.DOCUMENT_REQUESTS}?PageSize=${PageSize}&PageNumber=${PageNumber}&Search=${Search}&SortOrder=${SortOrder}
      &RequestStatus=${RequestStatus}&ProducerId=${ProducerId}&ProductId=${ProductId}&SupplierId=${SupplierId}`,
      config
    );
  }
);
const docdetails = withRetryHandling((requestId) => {
  return get(`${urls.DOCUMENT_REQUEST_DETAILS}?requestId=${requestId}`, config);
});
const sellerdoc = withRetryHandling(
  ({
    SortOrder,
    Search,
    PageNumber,
    PageSize,
    ProductId,
    ProducerId,
    RequestStatus,
    SupplierId
  }) => {
    return get(
      `${urls.SELLER_DOCUMENTS}?PageSize=${PageSize}&PageNumber=${PageNumber}&Search=${Search}&SortOrder=${SortOrder}
      &SupplierId=${store.getters.userId}&RequestStatus=${RequestStatus}&ProducerId=${ProducerId}&ProductId=${ProductId}&SupplierId=${SupplierId}`,
      config
    );
  }
);
const sellerdocdetails = withRetryHandling((requestId) => {
  return get(`${urls.SELLER_DOCUMENT_DETAILS}?requestId=${requestId}`, config);
});

export { sellerdocdetails as a, buyerdoc as b, samplerequestdetails as c, docdetails as d, samplerequests as e, sellerdoc as s };
//# sourceMappingURL=requestservice-VXAE2YqE.mjs.map
