import { _ as __nuxt_component_1$1 } from './AppIcon-D3CPABPP.mjs';
import { useSSRContext, inject, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderClass, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "Stepper",
  __ssrInlineRender: true,
  props: ["tabs"],
  setup(__props) {
    const active = inject("active");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex gap-x-20 justify-center items-center" }, _attrs))}><!--[-->`);
      ssrRenderList(__props.tabs, (tab) => {
        _push(`<div class="${ssrRenderClass([`${unref(active) > tab.value ? "after:border-primary-500" : "after:border-[#EAECF0]"}`, "relative after:content-[''] after:absolute after:border-b-2 after:border-[#EAECF0] after:w-24 after:top-1/2 after:translate-y-[-50%] after:left-[24px] after:last:content-none after:z-10"])}"><span class="flex flex-col justify-center gap-y-1 z-20 relative items-center">`);
        if (unref(active) > tab.value) {
          _push(`<span class="bg-white">`);
          _push(ssrRenderComponent(_component_AppIcon, {
            icon: "fa6-solid:circle-check",
            iconClass: "text-2xl text-primary-500"
          }, null, _parent));
          _push(`</span>`);
        } else {
          _push(`<!---->`);
        }
        if (unref(active) === tab.value) {
          _push(`<span class="rounded-full flex items-center relative justify-center"><span class="bg-[rgba(34,112,250,0.25)] rounded-full flex items-center h-[26px] w-[26px] justify-center absolute z-[1]"></span><span class="bg-white h-4 w-4 z-[2] absolute rounded-full"></span>`);
          _push(ssrRenderComponent(_component_AppIcon, {
            icon: "fa-solid:dot-circle",
            iconClass: "text-2xl text-primary-500 z-[3] relative"
          }, null, _parent));
          _push(`</span>`);
        } else {
          _push(`<!---->`);
        }
        if (unref(active) < tab.value) {
          _push(`<span class="bg-white">`);
          _push(ssrRenderComponent(_component_AppIcon, {
            icon: "fa-regular:dot-circle",
            iconClass: "text-2xl text-[#EAECF0]"
          }, null, _parent));
          _push(`</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<span class="${ssrRenderClass(`absolute -bottom-8 text-xs leading-5 block font-semibold whitespace-nowrap ${unref(active) >= tab.value ? "text-[#344054]" : "text-[#999]"}`)}">${ssrInterpolate(tab.name)}</span></span></div>`);
      });
      _push(`<!--]--></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Stepper.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main;

export { __nuxt_component_1 as _ };
//# sourceMappingURL=Stepper-MEQwgjWs.mjs.map
