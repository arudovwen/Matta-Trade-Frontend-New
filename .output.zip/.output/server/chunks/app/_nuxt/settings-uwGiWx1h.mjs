import { _ as __nuxt_component_0$1 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_1 } from './Stepper-MEQwgjWs.mjs';
import { _ as __nuxt_component_2, a as __nuxt_component_5, b as __nuxt_component_3 } from './Directors-g1CyZEEM.mjs';
import { useSSRContext, ref, provide, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import { a as useHead } from '../server.mjs';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './AppButton-rwP1M0KN.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import './nuxt-img-qJohECzX.mjs';
import './PhoneCodes-TGlMinMT.mjs';
import '@headlessui/vue';
import 'country-list-with-dial-code-and-flag';
import './SelectComponent-Q1jk_qng.mjs';
import '@heroicons/vue/24/solid';
import './countries-4zSrMx8v.mjs';
import './FileUpload-oHb-LYnL.mjs';
import 'vue-advanced-cropper';
import '@vuelidate/core';
import '@vuelidate/validators';
import './onboardingservices-NoJPITnD.mjs';
import 'vue-router';
import 'unhead';
import '@unhead/shared';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$1 = {
  __name: "CompanySettings",
  __ssrInlineRender: true,
  setup(__props) {
    const active = ref(1);
    const tabs = [
      {
        name: "Company details",
        value: 1
      },
      {
        name: "Documents",
        value: 2
      },
      {
        name: "Directors",
        value: 3
      }
    ];
    provide("active", active);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderComponent = __nuxt_component_0$1;
      const _component_Stepper = __nuxt_component_1;
      const _component_OnboardingCompanyInfo = __nuxt_component_2;
      const _component_OnboardingCompanyDocuments = __nuxt_component_5;
      const _component_OnboardingCompanyDirectors = __nuxt_component_3;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "gap-y-2 flex flex-col bg-white rounded-[10px] pb-10 border border-[#F4F7FE]" }, _attrs))} data-v-b515056d>`);
      _push(ssrRenderComponent(_component_HeaderComponent, { title: "Company settings" }, null, _parent));
      _push(`<div class="py-10" data-v-b515056d>`);
      _push(ssrRenderComponent(_component_Stepper, { tabs }, null, _parent));
      _push(`</div><div data-v-b515056d>`);
      if (unref(active) === 1) {
        _push(`<div data-v-b515056d>`);
        _push(ssrRenderComponent(_component_OnboardingCompanyInfo, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(active) === 2) {
        _push(`<div data-v-b515056d><div data-v-b515056d>`);
        _push(ssrRenderComponent(_component_OnboardingCompanyDocuments, null, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(active) === 3) {
        _push(`<div data-v-b515056d><div data-v-b515056d>`);
        _push(ssrRenderComponent(_component_OnboardingCompanyDirectors, null, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/CompanySettings.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-b515056d"]]);
const _sfc_main = {
  __name: "settings",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Company | Matta",
      meta: [{ name: "description", content: "Checkout" }]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierCompanySettings = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierCompanySettings, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/company/settings.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=settings-uwGiWx1h.mjs.map
