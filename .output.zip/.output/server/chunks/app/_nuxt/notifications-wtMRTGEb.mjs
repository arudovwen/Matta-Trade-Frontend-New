import { _ as __nuxt_component_0$1 } from './index-4NCxcAqd.mjs';
import { d as useAuthStore } from '../server.mjs';
import { useSSRContext, ref, mergeProps, unref, withCtx, createTextVNode, isRef, createVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderClass } from 'vue/server-renderer';
import { useRoute } from 'vue-router';
import { SwitchGroup, SwitchLabel, Switch } from '@headlessui/vue';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$1 = {
  __name: "NotificationComponent",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    const store = useAuthStore();
    const enabled = ref(false);
    useRoute();
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_Breadcrumbs = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "gap-y-2 flex flex-col" }, _attrs))} data-v-8e629152><div class="p-6 lg:p-8 bg-white rounded-lg bg-img" data-v-8e629152><div class="mb-12" data-v-8e629152>`);
      _push(ssrRenderComponent(_component_Breadcrumbs, null, null, _parent));
      _push(`</div><div class="grid grid-cols-3 justify-between items-end mb-4 lg:mb-10" data-v-8e629152><h1 class="text-3xl lg:text-[48px] lg:leading-[56px] text-matta-black col-span-1 font-medium capitalize" data-v-8e629152> Notifications </h1></div><div class="grid lg:grid-cols-2 justify-between items-end mb-10" data-v-8e629152><div class="lg:col-span-2" data-v-8e629152><div class="flex flex-col lg:flex-row gap-8 items-center" data-v-8e629152><p class="text-sm lg:text-base" data-v-8e629152> We may send important notifications about your Matta account to your email outside of your notification settings. </p><div data-v-8e629152><input class="rounded-lg px-[14px] py-[10px] h-11 w-[350px] border border-[#DCDEE6] text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" autofocus="on" placeholder="team@pharmazell.com"${ssrRenderAttr("value", (_a = unref(store).userInfo) == null ? void 0 : _a.email)} readonly disabled data-v-8e629152></div></div></div></div></div><div class="p-6 lg:p-8 rounded-lg bg-white" data-v-8e629152><div class="col-span-2" data-v-8e629152><div class="flex gap-x-16 justify-between items-center mb-8" data-v-8e629152><p class="text-sm lg:text-base" data-v-8e629152> Select the kind of notifications you would like to get about your Storefront, Procurements, Requests and Announcements. </p></div><div class="border p-6 lg:p-8 rounded-[20px]" data-v-8e629152><div class="flex justify-between mb-10" data-v-8e629152><h4 class="font-medium text-base" data-v-8e629152>Prevent all notifications?</h4><button class="button" data-v-8e629152>Disable All</button></div><div class="mb-6" data-v-8e629152>`);
      _push(ssrRenderComponent(unref(SwitchGroup), null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex items-center justify-between" data-v-8e629152${_scopeId}>`);
            _push2(ssrRenderComponent(unref(SwitchLabel), { class: "mr-4" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Storefront notifications`);
                } else {
                  return [
                    createTextVNode("Storefront notifications")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(Switch), {
              modelValue: unref(enabled),
              "onUpdate:modelValue": ($event) => isRef(enabled) ? enabled.value = $event : null,
              disabled: "",
              class: [unref(enabled) ? "bg-blue-600" : "bg-gray-200", "relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"]
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span class="${ssrRenderClass([unref(enabled) ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition-transform"])}" data-v-8e629152${_scopeId2}></span>`);
                } else {
                  return [
                    createVNode("span", {
                      class: [unref(enabled) ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition-transform"]
                    }, null, 2)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex items-center justify-between" }, [
                createVNode(unref(SwitchLabel), { class: "mr-4" }, {
                  default: withCtx(() => [
                    createTextVNode("Storefront notifications")
                  ]),
                  _: 1
                }),
                createVNode(unref(Switch), {
                  modelValue: unref(enabled),
                  "onUpdate:modelValue": ($event) => isRef(enabled) ? enabled.value = $event : null,
                  disabled: "",
                  class: [unref(enabled) ? "bg-blue-600" : "bg-gray-200", "relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"]
                }, {
                  default: withCtx(() => [
                    createVNode("span", {
                      class: [unref(enabled) ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition-transform"]
                    }, null, 2)
                  ]),
                  _: 1
                }, 8, ["modelValue", "onUpdate:modelValue", "class"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><hr class="my-4" data-v-8e629152><div class="mb-6" data-v-8e629152>`);
      _push(ssrRenderComponent(unref(SwitchGroup), null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex items-center justify-between" data-v-8e629152${_scopeId}>`);
            _push2(ssrRenderComponent(unref(SwitchLabel), { class: "mr-4" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Procurement Notifications`);
                } else {
                  return [
                    createTextVNode("Procurement Notifications")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(Switch), {
              disabled: "",
              modelValue: unref(enabled),
              "onUpdate:modelValue": ($event) => isRef(enabled) ? enabled.value = $event : null,
              class: [unref(enabled) ? "bg-blue-600" : "bg-gray-200", "relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"]
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span class="${ssrRenderClass([unref(enabled) ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition-transform"])}" data-v-8e629152${_scopeId2}></span>`);
                } else {
                  return [
                    createVNode("span", {
                      class: [unref(enabled) ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition-transform"]
                    }, null, 2)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex items-center justify-between" }, [
                createVNode(unref(SwitchLabel), { class: "mr-4" }, {
                  default: withCtx(() => [
                    createTextVNode("Procurement Notifications")
                  ]),
                  _: 1
                }),
                createVNode(unref(Switch), {
                  disabled: "",
                  modelValue: unref(enabled),
                  "onUpdate:modelValue": ($event) => isRef(enabled) ? enabled.value = $event : null,
                  class: [unref(enabled) ? "bg-blue-600" : "bg-gray-200", "relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"]
                }, {
                  default: withCtx(() => [
                    createVNode("span", {
                      class: [unref(enabled) ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition-transform"]
                    }, null, 2)
                  ]),
                  _: 1
                }, 8, ["modelValue", "onUpdate:modelValue", "class"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><hr class="my-4" data-v-8e629152><div class="mb-6" data-v-8e629152>`);
      _push(ssrRenderComponent(unref(SwitchGroup), null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex items-center justify-between" data-v-8e629152${_scopeId}>`);
            _push2(ssrRenderComponent(unref(SwitchLabel), { class: "mr-4" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Request Notifications`);
                } else {
                  return [
                    createTextVNode("Request Notifications")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(Switch), {
              disabled: "",
              modelValue: unref(enabled),
              "onUpdate:modelValue": ($event) => isRef(enabled) ? enabled.value = $event : null,
              class: [unref(enabled) ? "bg-blue-600" : "bg-gray-200", "relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"]
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span class="${ssrRenderClass([unref(enabled) ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition-transform"])}" data-v-8e629152${_scopeId2}></span>`);
                } else {
                  return [
                    createVNode("span", {
                      class: [unref(enabled) ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition-transform"]
                    }, null, 2)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex items-center justify-between" }, [
                createVNode(unref(SwitchLabel), { class: "mr-4" }, {
                  default: withCtx(() => [
                    createTextVNode("Request Notifications")
                  ]),
                  _: 1
                }),
                createVNode(unref(Switch), {
                  disabled: "",
                  modelValue: unref(enabled),
                  "onUpdate:modelValue": ($event) => isRef(enabled) ? enabled.value = $event : null,
                  class: [unref(enabled) ? "bg-blue-600" : "bg-gray-200", "relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"]
                }, {
                  default: withCtx(() => [
                    createVNode("span", {
                      class: [unref(enabled) ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition-transform"]
                    }, null, 2)
                  ]),
                  _: 1
                }, 8, ["modelValue", "onUpdate:modelValue", "class"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><hr class="my-4" data-v-8e629152><div class="" data-v-8e629152>`);
      _push(ssrRenderComponent(unref(SwitchGroup), null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex items-center justify-between" data-v-8e629152${_scopeId}>`);
            _push2(ssrRenderComponent(unref(SwitchLabel), { class: "mr-4" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Announcement Notifications`);
                } else {
                  return [
                    createTextVNode("Announcement Notifications")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(Switch), {
              disabled: "",
              modelValue: unref(enabled),
              "onUpdate:modelValue": ($event) => isRef(enabled) ? enabled.value = $event : null,
              class: [unref(enabled) ? "bg-blue-600" : "bg-gray-200", "relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"]
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span class="${ssrRenderClass([unref(enabled) ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition-transform"])}" data-v-8e629152${_scopeId2}></span>`);
                } else {
                  return [
                    createVNode("span", {
                      class: [unref(enabled) ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition-transform"]
                    }, null, 2)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex items-center justify-between" }, [
                createVNode(unref(SwitchLabel), { class: "mr-4" }, {
                  default: withCtx(() => [
                    createTextVNode("Announcement Notifications")
                  ]),
                  _: 1
                }),
                createVNode(unref(Switch), {
                  disabled: "",
                  modelValue: unref(enabled),
                  "onUpdate:modelValue": ($event) => isRef(enabled) ? enabled.value = $event : null,
                  class: [unref(enabled) ? "bg-blue-600" : "bg-gray-200", "relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"]
                }, {
                  default: withCtx(() => [
                    createVNode("span", {
                      class: [unref(enabled) ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition-transform"]
                    }, null, 2)
                  ]),
                  _: 1
                }, 8, ["modelValue", "onUpdate:modelValue", "class"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/NotificationComponent.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-8e629152"]]);
const _sfc_main = {
  __name: "notifications",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierNotificationComponent = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierNotificationComponent, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/account/notifications.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=notifications-wtMRTGEb.mjs.map
