import { _ as __nuxt_component_0$1 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_1 } from './AppTab-6UxOW17N.mjs';
import { _ as __nuxt_component_2 } from './SelectComponent-Q1jk_qng.mjs';
import { useSSRContext, reactive, ref, computed, watch, provide, resolveComponent, mergeProps, unref, withCtx, createVNode, createTextVNode, openBlock, createBlock, toDisplayString, withDirectives, isRef, vModelText, createCommentVNode, resolveDirective } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderClass, ssrGetDirectiveProps, ssrRenderSlot, ssrRenderStyle, ssrLooseEqual } from 'vue/server-renderer';
import { _ as __nuxt_component_1$1 } from './nuxt-img-qJohECzX.mjs';
import { _ as __nuxt_component_2$1 } from './EmptyData-RrNjecQG.mjs';
import { _ as __nuxt_component_1$2 } from './AppLoader-SkdFRsgH.mjs';
import { _ as __nuxt_component_4 } from './Simple-GRXlMUar.mjs';
import { _ as __nuxt_component_0$2 } from './IndexModal-vEF7RYpX.mjs';
import { useRouter, useRoute } from 'vue-router';
import { F as getSupplierProducts, G as deleteProduct } from '../server.mjs';
import moment from 'moment';
import { Popover, PopoverButton, PopoverPanel } from '@headlessui/vue';
import debounce from 'lodash/debounce.js';
import { toast } from 'vue3-toastify';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './AppButton-rwP1M0KN.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '@heroicons/vue/24/solid';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$2 = {
  __name: "SortFilter",
  __ssrInlineRender: true,
  emits: ["onGetData"],
  setup(__props, { emit: __emit }) {
    const isOpen = ref(false);
    const options = [
      {
        name: "newest"
      },
      {
        name: "price"
      },
      {
        name: "title"
      }
    ];
    const selectedoption = ref("");
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "hidden" }, _attrs, ssrGetDirectiveProps(
        _ctx,
        _directive_click_outside,
        () => {
          isOpen.value = false;
        }
      )))}><div><div class="relative w-full"><div>`);
      ssrRenderSlot(_ctx.$slots, "content", {}, null, _push, _parent);
      _push(`</div><div style="${ssrRenderStyle(isOpen.value ? null : { display: "none" })}"><div class="absolute mt-1 w-full min-w-[160px] right-0 z-40 rounded-lg bg-white py-4 px-6 text-xs shadow-lg ring-1 ring-black ring-opacity-5 outline-0 sm:text-[13px]"><div class="max-h-60 overflow-y-auto"><!--[-->`);
      ssrRenderList(options, (option) => {
        _push(`<ul${ssrRenderAttr("value", option.name)}><li class="${ssrRenderClass([
          "relative cursor-default select-none py-2 text-loft-black hover:bg-gray-50"
        ])}"><label class="flex items-center gap-x-2"><input type="radio"${ssrIncludeBooleanAttr(ssrLooseEqual(selectedoption.value, option.name)) ? " checked" : ""}${ssrRenderAttr("value", option.name)} class="accent-matta-black"><span class="text-sm capitalize">${ssrInterpolate(option.name)}</span></label></li></ul>`);
      });
      _push(`<!--]--></div><div class="mt-3"><button class="py-3 rounded-lg bg-primary-500 w-full text-white uppercase"> Save </button></div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/forms/SortFilter.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$2;
const _imports_0 = "data:image/svg+xml,%3csvg%20width='16'%20height='16'%20viewBox='0%200%2016%2016'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M7%2012L5%2014L3%2012'%20stroke='%232C2C2C'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M5%202V14'%20stroke='%232C2C2C'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M9%204L11%202L13%204'%20stroke='%232C2C2C'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M11%2014V2'%20stroke='%232C2C2C'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e";
const _sfc_main$1 = {
  __name: "ProductsComponent",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    const router = useRouter();
    const tabs = [
      {
        title: "published",
        key: "published"
      },
      {
        title: "hidden",
        key: "hidden"
      },
      {
        title: "archived",
        key: "archive"
      }
    ];
    const queryParams = reactive({
      MarketId: "",
      Search: "",
      PageSize: 10,
      PageNumber: 1,
      ShowSubMenu: true,
      Producer: "",
      pagecount: 0,
      totalCount: 0,
      Status: ""
    });
    const active = ref("published");
    const isLoading = ref(false);
    const counts = ref({ published: 0, archive: 0, hidden: 0 });
    const isPageLoading = ref(true);
    const producers = ref([]);
    const markets = ref([]);
    const id = ref(null);
    function onGetMarket(data) {
      queryParams.MarketId = data.id;
      getData();
    }
    function onGetProducer(data) {
      queryParams.Producer = data.id;
      getData();
    }
    const marketOptions = computed(() => {
      if (!markets.value.length)
        return [];
      return markets.value.map((i) => {
        i.name = i.title;
        return i;
      });
    });
    const producerOptions = computed(() => {
      if (!producers.value.length)
        return [];
      return producers.value.map((i) => {
        i.name = i.title;
        return i;
      });
    });
    function getData() {
      isPageLoading.value = true;
      getSupplierProducts(queryParams).then((res) => {
        products.value = res.data.data.data;
        queryParams.totalCount = res.data.data.totalCount;
        queryParams.pagecount = res.data.data.data.length;
        isPageLoading.value = false;
      }).catch(() => {
        isPageLoading.value = false;
      });
    }
    debounce(() => {
      getData();
    }, 1500);
    const deletetext = ref("");
    const text = ref("");
    const isOpen = ref(false);
    const products = ref([]);
    useRoute();
    const theads = ["product", "created", "views", "orders", ""];
    function close() {
      isOpen.value = false;
    }
    function isOpenModal(item) {
      text.value = `By deleting ${item.name.toUpperCase()}, you will delete all data. Please, type \u2018Delete\u2019  to confirm.`;
      id.value = item.id;
      isOpen.value = true;
    }
    function handleDelete() {
      isLoading.value = true;
      deleteProduct(id.value).then((res) => {
        if (res.status == 200) {
          isOpen.value = false;
          isLoading.value = false;
          getData();
          toast.success("Product removed");
        }
      }).catch((err) => {
        toast.success(err.response.data.message || err.response.data.Message);
        isLoading.value = false;
      });
    }
    watch(active, () => {
      queryParams.Status = active.value === "" ? "published" : active.value;
    });
    watch(
      () => [queryParams.PageNumber, queryParams.Status],
      () => {
        getData();
      }
    );
    provide("isPageLoading", isPageLoading);
    provide("active", active);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderComponent = __nuxt_component_0$1;
      const _component_AppTab = __nuxt_component_1;
      const _component_FormsSelectComponent = __nuxt_component_2;
      const _component_FormsSortFilter = __nuxt_component_3;
      const _component_NuxtImg = __nuxt_component_1$1;
      const _component_router_link = resolveComponent("router-link");
      const _component_EmptyData = __nuxt_component_2$1;
      const _component_AppLoader = __nuxt_component_1$2;
      const _component_PaginationSimple = __nuxt_component_4;
      const _component_IndexModal = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "mb-8 bg-white rounded-[10px] border border-[#F4F7FE]" }, _attrs))} data-v-648e148a><div class="gap-y-2 flex flex-col mb-4" data-v-648e148a>`);
      _push(ssrRenderComponent(_component_HeaderComponent, {
        title: "Products",
        className: "!px-5 !border-none",
        subtext: "List of all added storefront products.",
        btnText: "Add product",
        btnIcon: "humbleicons:plus",
        onOnClick: ($event) => unref(router).push("/storefront/products/add-product")
      }, null, _parent));
      _push(`<div class="rounded-lg bg-white" data-v-648e148a>`);
      _push(ssrRenderComponent(_component_AppTab, {
        tabs,
        count: unref(counts),
        className: "px-5"
      }, null, _parent));
      _push(`<div class="justify-between items-center mb-8 w-full hidden lg:flex px-5" data-v-648e148a><div class="flex gap-x-4 flex-1" data-v-648e148a><div class="relative flex items-center" data-v-648e148a><span class="absolute left-4 pointer-events-none text-[#667085]" data-v-648e148a><i class="uil uil-search" data-v-648e148a></i></span><input${ssrRenderAttr("value", unref(queryParams).Search)} placeholder="Search" class="border border-[#D0D5DD] focus:pr-3 pl-10 rounded-lg w-[280px] focus:outline-none py-[10px] transition ease-in-out duration-300" type="search" data-v-648e148a></div><div class="flex relative items-center" data-v-648e148a>`);
      _push(ssrRenderComponent(_component_FormsSelectComponent, {
        onOnGetData: onGetMarket,
        options: unref(marketOptions),
        showSearch: true,
        value: unref(queryParams).MarketId,
        placeholder: "Markets",
        classStyles: "border border-[#D0D5DD] rounded-lg min-w-[180px] py-[10px] px-[14px] focus:outline-none"
      }, null, _parent));
      _push(`</div><div class="flex relative items-center" data-v-648e148a>`);
      _push(ssrRenderComponent(_component_FormsSelectComponent, {
        onOnGetData: onGetProducer,
        options: unref(producerOptions),
        showSearch: true,
        value: unref(queryParams).Producer,
        placeholder: "Producers",
        classStyles: "border border-[#D0D5DD] rounded-lg min-w-[180px] py-[10px] px-[14px] focus:outline-none"
      }, null, _parent));
      _push(`</div></div><div class="flex gap-x-3 ml-2" data-v-648e148a>`);
      _push(ssrRenderComponent(_component_FormsSortFilter, null, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button class="w-[46px] h-[46px] rounded-full flex items-center justify-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black border border-[#ddd] shadow-sm" data-v-648e148a${_scopeId}><img${ssrRenderAttr("src", _imports_0)} alt="alt" data-v-648e148a${_scopeId}></button>`);
          } else {
            return [
              createVNode("button", { class: "w-[46px] h-[46px] rounded-full flex items-center justify-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black border border-[#ddd] shadow-sm" }, [
                createVNode("img", {
                  src: _imports_0,
                  alt: "alt"
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
      if (!unref(isPageLoading)) {
        _push(`<div data-v-648e148a>`);
        if (unref(products).length) {
          _push(`<div class="max-w-[80vw] lg:max-w-full" data-v-648e148a>`);
          if (unref(products).length) {
            _push(`<table class="w-full" data-v-648e148a><thead data-v-648e148a><tr data-v-648e148a><!--[-->`);
            ssrRenderList(theads, (item) => {
              _push(`<th class="capitalize text-[#475467] text-sm text-left font-medium border-b border-t py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-648e148a>${ssrInterpolate(item)}</th>`);
            });
            _push(`<!--]--></tr></thead><tbody data-v-648e148a><!--[-->`);
            ssrRenderList(unref(products), (item) => {
              _push(`<tr data-v-648e148a><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-648e148a><div class="flex items-center" data-v-648e148a>`);
              if (item.logo) {
                _push(`<span class="mr-3 h-10 w-10 rounded-full flex items-center justify-center border border-[#E7EBEE]" data-v-648e148a>`);
                _push(ssrRenderComponent(_component_NuxtImg, {
                  class: "w-full h-full object-cover rounded-full",
                  alt: "alt",
                  src: item.logo
                }, null, _parent));
                _push(`</span>`);
              } else {
                _push(`<i class="fas fa-image text-[40px] mr-3 text-gray-400" data-v-648e148a></i>`);
              }
              _push(`<span data-v-648e148a><span class="text-sm font-semibold" data-v-648e148a>${ssrInterpolate(item.name)}</span></span></div></td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-648e148a>${ssrInterpolate(unref(moment)(item.created).format("lll"))}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-648e148a>${ssrInterpolate(item.views)}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-648e148a>${ssrInterpolate(item.orders || 0)}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-6 px-3 border-[#E7EBEE] relative" data-v-648e148a>`);
              _push(ssrRenderComponent(unref(Popover), { class: "relative" }, {
                default: withCtx((_, _push2, _parent2, _scopeId) => {
                  if (_push2) {
                    _push2(ssrRenderComponent(unref(PopoverButton), { class: "outline-none" }, {
                      default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                        if (_push3) {
                          _push3(`<i class="uil uil-ellipsis-v text-lg" data-v-648e148a${_scopeId2}></i>`);
                        } else {
                          return [
                            createVNode("i", { class: "uil uil-ellipsis-v text-lg" })
                          ];
                        }
                      }),
                      _: 2
                    }, _parent2, _scopeId));
                    _push2(ssrRenderComponent(unref(PopoverPanel), { class: "absolute z-[99] bg-white shadow right-0 min-w-[150px] rounded-md overflow-hidden pt-4" }, {
                      default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                        if (_push3) {
                          _push3(`<ul class="grid grid-cols-1" data-v-648e148a${_scopeId2}>`);
                          _push3(ssrRenderComponent(_component_router_link, {
                            to: `/storefront/products/edit-product?id=${item.id}`
                          }, {
                            default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                              if (_push4) {
                                _push4(`<li class="px-6 text-sm text-[#333333] cursor-pointer group hover:text-primary py-2 whitespace-nowrap hover:bg-[#F9FAFB]" data-v-648e148a${_scopeId3}><i class="uil uil-pen text-[#666666] group-hover:text-primary" data-v-648e148a${_scopeId3}></i> Edit </li>`);
                              } else {
                                return [
                                  createVNode("li", { class: "px-6 text-sm text-[#333333] cursor-pointer group hover:text-primary py-2 whitespace-nowrap hover:bg-[#F9FAFB]" }, [
                                    createVNode("i", { class: "uil uil-pen text-[#666666] group-hover:text-primary" }),
                                    createTextVNode(" Edit ")
                                  ])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent3, _scopeId2));
                          _push3(`<li class="px-6 text-sm text-[#333333] cursor-pointer group hover:text-primary py-2 whitespace-nowrap hover:bg-[#F9FAFB]" data-v-648e148a${_scopeId2}><i class="uil uil-trash text-matta-black" data-v-648e148a${_scopeId2}></i> Remove </li></ul>`);
                        } else {
                          return [
                            createVNode("ul", { class: "grid grid-cols-1" }, [
                              createVNode(_component_router_link, {
                                to: `/storefront/products/edit-product?id=${item.id}`
                              }, {
                                default: withCtx(() => [
                                  createVNode("li", { class: "px-6 text-sm text-[#333333] cursor-pointer group hover:text-primary py-2 whitespace-nowrap hover:bg-[#F9FAFB]" }, [
                                    createVNode("i", { class: "uil uil-pen text-[#666666] group-hover:text-primary" }),
                                    createTextVNode(" Edit ")
                                  ])
                                ]),
                                _: 2
                              }, 1032, ["to"]),
                              createVNode("li", {
                                onClick: ($event) => isOpenModal(item),
                                class: "px-6 text-sm text-[#333333] cursor-pointer group hover:text-primary py-2 whitespace-nowrap hover:bg-[#F9FAFB]"
                              }, [
                                createVNode("i", { class: "uil uil-trash text-matta-black" }),
                                createTextVNode(" Remove ")
                              ], 8, ["onClick"])
                            ])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent2, _scopeId));
                  } else {
                    return [
                      createVNode(unref(PopoverButton), { class: "outline-none" }, {
                        default: withCtx(() => [
                          createVNode("i", { class: "uil uil-ellipsis-v text-lg" })
                        ]),
                        _: 1
                      }),
                      createVNode(unref(PopoverPanel), { class: "absolute z-[99] bg-white shadow right-0 min-w-[150px] rounded-md overflow-hidden pt-4" }, {
                        default: withCtx(() => [
                          createVNode("ul", { class: "grid grid-cols-1" }, [
                            createVNode(_component_router_link, {
                              to: `/storefront/products/edit-product?id=${item.id}`
                            }, {
                              default: withCtx(() => [
                                createVNode("li", { class: "px-6 text-sm text-[#333333] cursor-pointer group hover:text-primary py-2 whitespace-nowrap hover:bg-[#F9FAFB]" }, [
                                  createVNode("i", { class: "uil uil-pen text-[#666666] group-hover:text-primary" }),
                                  createTextVNode(" Edit ")
                                ])
                              ]),
                              _: 2
                            }, 1032, ["to"]),
                            createVNode("li", {
                              onClick: ($event) => isOpenModal(item),
                              class: "px-6 text-sm text-[#333333] cursor-pointer group hover:text-primary py-2 whitespace-nowrap hover:bg-[#F9FAFB]"
                            }, [
                              createVNode("i", { class: "uil uil-trash text-matta-black" }),
                              createTextVNode(" Remove ")
                            ], 8, ["onClick"])
                          ])
                        ]),
                        _: 2
                      }, 1024)
                    ];
                  }
                }),
                _: 2
              }, _parent));
              _push(`</td></tr>`);
            });
            _push(`<!--]--></tbody></table>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        } else {
          _push(ssrRenderComponent(_component_EmptyData, {
            title: " No product available",
            subtext: "We did not find the query you requested"
          }, null, _parent));
        }
        _push(`</div>`);
      } else {
        _push(`<div class="text-center p-6 lg:p-8 my-24" data-v-648e148a>`);
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
        _push(`</div>`);
      }
      _push(`</div></div><div class="p-5" data-v-648e148a>`);
      _push(ssrRenderComponent(_component_PaginationSimple, {
        total: unref(queryParams).totalCount,
        current: unref(queryParams).PageNumber,
        "per-page": unref(queryParams).PageSize,
        pageRange: 5,
        onPageChanged: ($event) => unref(queryParams).PageNumber = $event
      }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_IndexModal, {
        isOpen: unref(isOpen),
        onToggleModal: ($event) => isOpen.value = false
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(isOpen)) {
              _push2(`<div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 max-w-sm" data-v-648e148a${_scopeId}><div class="flex justify-between mb-5 items-center" data-v-648e148a${_scopeId}><h4 class="font-medium text-matta-black text-xl" data-v-648e148a${_scopeId}>${ssrInterpolate(__props.title)}</h4><i class="uil uil-times cursor-pointer text-lg" data-v-648e148a${_scopeId}></i></div><p class="text-sm text-matta-black mb-2" data-v-648e148a${_scopeId}>${ssrInterpolate(unref(text))}</p><input class="rounded-lg px-[14px] py-[10px] h-10 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"${ssrRenderAttr("value", unref(deletetext))} data-v-648e148a${_scopeId}><div class="flex justify-end gap-x-2 items-center mt-8" data-v-648e148a${_scopeId}><button type="button" class="appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase" data-v-648e148a${_scopeId}> Cancel </button><button type="button"${ssrIncludeBooleanAttr(unref(deletetext) != "Delete" || unref(isLoading)) ? " disabled" : ""} class="${ssrRenderClass([unref(deletetext) != "Delete" && "opacity-50", "appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:bg-priamry/70 text-[13px] uppercase"])}" data-v-648e148a${_scopeId}> Delete </button></div></div>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              unref(isOpen) ? (openBlock(), createBlock("div", {
                key: 0,
                class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 max-w-sm"
              }, [
                createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                  createVNode("h4", { class: "font-medium text-matta-black text-xl" }, toDisplayString(__props.title), 1),
                  createVNode("i", {
                    class: "uil uil-times cursor-pointer text-lg",
                    onClick: close
                  })
                ]),
                createVNode("p", { class: "text-sm text-matta-black mb-2" }, toDisplayString(unref(text)), 1),
                withDirectives(createVNode("input", {
                  class: "rounded-lg px-[14px] py-[10px] h-10 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
                  "onUpdate:modelValue": ($event) => isRef(deletetext) ? deletetext.value = $event : null
                }, null, 8, ["onUpdate:modelValue"]), [
                  [vModelText, unref(deletetext)]
                ]),
                createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                  createVNode("button", {
                    type: "button",
                    onClick: close,
                    class: "appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"
                  }, " Cancel "),
                  createVNode("button", {
                    type: "button",
                    onClick: handleDelete,
                    disabled: unref(deletetext) != "Delete" || unref(isLoading),
                    class: [unref(deletetext) != "Delete" && "opacity-50", "appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:bg-priamry/70 text-[13px] uppercase"]
                  }, " Delete ", 10, ["disabled"])
                ])
              ])) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/ProductsComponent.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-648e148a"]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierProductsComponent = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierProductsComponent, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/storefront/products/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-FgLDw1sm.mjs.map
