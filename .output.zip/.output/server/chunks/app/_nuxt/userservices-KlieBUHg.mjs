import { t as store, q as post, r as urls, v as get } from '../server.mjs';

const config = {
  headers: { Authorization: `Bearer ${store.getters.accessToken}` }
};
async function inviteUsers(data) {
  return await post(urls.INVITE_USERS, data, config);
}
async function deleteInvite(data) {
  return await post(
    `${urls.DELETE_INVITES}?invitationId=${data.invitationId}`,
    data,
    config
  );
}
async function resendInvite(data) {
  return await post(`${urls.RESEND_INVITE_USERS}`, data, config);
}
async function deleteUser(data) {
  return await post(`${urls.DELETE_USER}?email=${data.email}`, data, config);
}
async function getInvites({
  Status,
  PageNumber = 1,
  PageSize = 10,
  Role,
  Search = ""
}) {
  return await get(
    `${urls.GET_INVITES}?Search=${Search}&Status=${Status}&Role=${Role}&PageNumber=${PageNumber}&PageSize=${PageSize}`,
    config
  );
}
async function updateVendorInfo(data) {
  return await post(`${urls.UPDATE_VENDOR_STORE}`, data, config);
}
async function postStoreName(data) {
  return await get(`${urls.POST_VENDOR_STORE_NAME}?storename=${data}`, config);
}

export { deleteUser as a, deleteInvite as d, getInvites as g, inviteUsers as i, postStoreName as p, resendInvite as r, updateVendorInfo as u };
//# sourceMappingURL=userservices-KlieBUHg.mjs.map
