import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-fc3HHrvA.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { useSSRContext, mergeProps, unref, withCtx, createVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderComponent } from 'vue/server-renderer';

const CallBg = "" + buildAssetsURL("callbg.UMfoadiA.png");
const _sfc_main = {
  __name: "Call",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "relative w-full bg-black-400" }, _attrs))}><div class="bg-cover bg-center min-h-[386px]" style="${ssrRenderStyle({ backgroundImage: `url('${unref(CallBg)}')` })}"><div class="absolute inset-0 bg-[rgba(6,28,94,0.84)] ]"></div><div class="absolute inset-0 flex items-center justify-start text-white text-center container"><div class="mx-auto"><p data-aos="fade-up" data-aos-once="true" class="font-bold text-[#fff] text-3xl md:text-5xl xl:leading-[58px] mb-[23px]"> Ready to get started? </p><p class="font-medium text-[#fff] text-base lg:text-xl mb-9 max-w-[700px] mx-auto"> Effortlessly source your chemicals, raw materials, ingredients, and commodities on our platform. </p>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/auth/register" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_AppButton, {
              text: "Begin Your Journey with Matta",
              btnClass: "bg-white text-[#333] !px-10 !py-[10px] !normal-case !font-medium"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_AppButton, {
                text: "Begin Your Journey with Matta",
                btnClass: "bg-white text-[#333] !px-10 !py-[10px] !normal-case !font-medium"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/landing/Call.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_7 = _sfc_main;

export { __nuxt_component_7 as _ };
//# sourceMappingURL=Call-PMNbQp7f.mjs.map
