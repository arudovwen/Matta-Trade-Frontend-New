import { _ as __nuxt_component_0 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_1 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_2 } from './EmptyData-RrNjecQG.mjs';
import { _ as __nuxt_component_1$1 } from './AppLoader-SkdFRsgH.mjs';
import { _ as __nuxt_component_4 } from './Simple-GRXlMUar.mjs';
import { _ as __nuxt_component_6 } from './DeleteModal-8TLpuLoc.mjs';
import { useSSRContext, ref, reactive, watch, provide, unref, withCtx, createVNode } from 'vue';
import { u as useRoute } from '../server.mjs';
import { ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderClass } from 'vue/server-renderer';
import moment from 'moment';
import { Menu, MenuButton, MenuItems } from '@headlessui/vue';
import { s as sellerdoc, a as sellerdocdetails } from './requestservice-VXAE2YqE.mjs';
import debounce from 'lodash/debounce.js';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import './AppButton-rwP1M0KN.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '@iconify/vue';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';
import './retry-handling-kb1itlan.mjs';

const _sfc_main = {
  __name: "[id]",
  __ssrInlineRender: true,
  setup(__props) {
    const id = ref(null);
    const open = ref(false);
    useRoute();
    const theads = [
      "order id",
      "date",
      "email",
      "order value",
      "discount value",
      "status",
      ""
    ];
    const financeData = ref([]);
    const queryParams = reactive({
      SupplierId: "",
      RequestStatus: "",
      ProducerId: "",
      ProductId: "",
      Search: "",
      SortOrder: "",
      PageNumber: 1,
      PageSize: 10
    });
    const docLoading = ref(true);
    const isOpen = ref(false);
    function getFinanceData() {
      docLoading.value = true;
      sellerdoc(queryParams).then((res) => {
        docLoading.value = false;
      });
    }
    function openRequest(item) {
      sellerdocdetails(item.id).then((res) => {
        document.value = res.data.data;
        isOpen.value = true;
      });
    }
    function withdrawRequest(value) {
      id.value = value;
      open.value = true;
    }
    const document = ref({});
    const debounceSearch = debounce(() => {
      getFinanceData();
    }, 800);
    const handleDelete = () => {
    };
    watch(
      () => ({ ...queryParams }),
      () => {
        debounceSearch();
      }
    );
    provide("document", document);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderComponent = __nuxt_component_0;
      const _component_AppIcon = __nuxt_component_1;
      const _component_EmptyData = __nuxt_component_2;
      const _component_AppLoader = __nuxt_component_1$1;
      const _component_PaginationSimple = __nuxt_component_4;
      const _component_DeleteModal = __nuxt_component_6;
      _push(`<!--[--><div class="gap-y-2 flex flex-col bg-white rounded-[10px] border border-[#F4F7FE] pb-10" data-v-f85235cd>`);
      _push(ssrRenderComponent(_component_HeaderComponent, {
        title: "Transactions",
        canGoBack: true
      }, null, _parent));
      _push(`<div class="pt-5" data-v-f85235cd>`);
      if (!unref(docLoading)) {
        _push(`<div data-v-f85235cd><div class="flex justify-between items-center mb-8" data-v-f85235cd><div class="flex gap-x-4 px-[30px]" data-v-f85235cd><div class="relative flex items-center" data-v-f85235cd><span class="absolute left-4 pointer-events-none text-[#667085]" data-v-f85235cd><i class="uil uil-search" data-v-f85235cd></i></span><input${ssrRenderAttr("value", unref(queryParams).Search)} placeholder="Search" class="border border-[#E7E7E7] text-sm focus:pr-3 pl-10 rounded-lg w-[280px] focus:outline-none py-[10px] transition ease-in-out duration-300" type="search" data-v-f85235cd></div></div></div>`);
        if (unref(financeData).length) {
          _push(`<div data-v-f85235cd><table class="w-full" data-v-f85235cd><thead data-v-f85235cd><tr data-v-f85235cd><!--[-->`);
          ssrRenderList(theads, (item) => {
            _push(`<th class="capitalize text-[#475467] text-sm text-left font-medium border-t border-b py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-f85235cd>${ssrInterpolate(item)}</th>`);
          });
          _push(`<!--]--></tr></thead><tbody data-v-f85235cd><!--[-->`);
          ssrRenderList(unref(financeData), (item) => {
            _push(`<tr data-v-f85235cd><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-f85235cd><div class="flex items-center" data-v-f85235cd><span class="${ssrRenderClass(item.status == 3 ? "opacity-25" : "")}" data-v-f85235cd><span class="text-sm font-medium" data-v-f85235cd>${ssrInterpolate(item.productName)}</span><br data-v-f85235cd><span class="text-xs font-normal" data-v-f85235cd>${ssrInterpolate(item.producer)}</span></span></div></td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap max-w-[260px] truncate"])}" data-v-f85235cd>${ssrInterpolate(item.type)}</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-f85235cd>${ssrInterpolate(unref(moment)(item.created).format("l"))}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-f85235cd>`);
            if (item.requestStatus == 0) {
              _push(`<span class="px-[6px] py-[2px] text-xs rounded-full text-[#5925DC] border border-[#D9D6FE] bg-[#F4F3FF] flex gap-x-1 items-center max-w-max" data-v-f85235cd>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` New</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 1) {
              _push(`<span class="px-[6px] py-1 text-xs rounded-full border border-pink-100 bg-pink-50 text-pink-500 flex gap-x-1 items-center max-w-max" data-v-f85235cd>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` In progress</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 2) {
              _push(`<span class="px-[6px] py-1 text-xs rounded-full text-[#17B26A] border border-[#ABEFC6] bg-[#ECFDF3] flex gap-x-1 items-center max-w-max" data-v-f85235cd>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` Shipped</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 3) {
              _push(`<span class="px-[6px] py-1 text-xs rounded-lg text-[#17B26A] border border-[#ABEFC6] bg-[#ECFDF3] flex gap-x-1 items-center max-w-max" data-v-f85235cd>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` Completed</span>`);
            } else {
              _push(`<!---->`);
            }
            _push(`</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-f85235cd>`);
            _push(ssrRenderComponent(unref(Menu), {
              class: "relative",
              as: "div"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(ssrRenderComponent(unref(MenuButton), {
                    id: `${item.productName}+option`,
                    class: "outline-none"
                  }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<i class="uil uil-ellipsis-v" data-v-f85235cd${_scopeId2}></i>`);
                      } else {
                        return [
                          createVNode("i", { class: "uil uil-ellipsis-v" })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                  _push2(ssrRenderComponent(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[180px] rounded-xl overflow-hidden" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<div class="py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap" data-v-f85235cd${_scopeId2}> View request </div><div class="py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap" data-v-f85235cd${_scopeId2}> Edit request </div><div class="py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap" data-v-f85235cd${_scopeId2}> Withdraw request </div>`);
                      } else {
                        return [
                          createVNode("div", {
                            class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap",
                            onClick: ($event) => openRequest(item)
                          }, " View request ", 8, ["onClick"]),
                          createVNode("div", {
                            onClick: _ctx.cancelRequest,
                            class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                          }, " Edit request ", 8, ["onClick"]),
                          createVNode("div", {
                            onClick: ($event) => withdrawRequest(item.id),
                            class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                          }, " Withdraw request ", 8, ["onClick"])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                } else {
                  return [
                    createVNode(unref(MenuButton), {
                      id: `${item.productName}+option`,
                      class: "outline-none"
                    }, {
                      default: withCtx(() => [
                        createVNode("i", { class: "uil uil-ellipsis-v" })
                      ]),
                      _: 2
                    }, 1032, ["id"]),
                    createVNode(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[180px] rounded-xl overflow-hidden" }, {
                      default: withCtx(() => [
                        createVNode("div", {
                          class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap",
                          onClick: ($event) => openRequest(item)
                        }, " View request ", 8, ["onClick"]),
                        createVNode("div", {
                          onClick: _ctx.cancelRequest,
                          class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                        }, " Edit request ", 8, ["onClick"]),
                        createVNode("div", {
                          onClick: ($event) => withdrawRequest(item.id),
                          class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                        }, " Withdraw request ", 8, ["onClick"])
                      ]),
                      _: 2
                    }, 1024)
                  ];
                }
              }),
              _: 2
            }, _parent));
            _push(`</td></tr>`);
          });
          _push(`<!--]--></tbody></table></div>`);
        } else {
          _push(ssrRenderComponent(_component_EmptyData, {
            title: "No campaign has been created",
            type: "campaign"
          }, null, _parent));
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(docLoading)) {
        _push(`<div class="text-center p-6 lg:p-8 my-20" data-v-f85235cd>`);
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(financeData).length) {
        _push(`<div class="p-5" data-v-f85235cd>`);
        _push(ssrRenderComponent(_component_PaginationSimple, {
          total: unref(queryParams).totalCount,
          current: unref(queryParams).PageNumber,
          "per-page": unref(queryParams).PageSize,
          pageRange: 5,
          onPageChanged: ($event) => unref(queryParams).PageNumber = $event
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_DeleteModal, {
        onDeleteItem: handleDelete,
        onClose: ($event) => open.value = false,
        title: "Withdraw request",
        text: "Are you sure you want to withdraw this application? This action cannot be undone.",
        open: unref(open),
        btnText: "Withdraw request"
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/campaign/transactions/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _id_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-f85235cd"]]);

export { _id_ as default };
//# sourceMappingURL=_id_-p4Lj1sdp.mjs.map
