import { _ as __nuxt_component_0 } from './nuxt-link-fc3HHrvA.mjs';
import { _ as __nuxt_component_1 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_1$1 } from './nuxt-img-qJohECzX.mjs';
import { u as useRoute } from '../server.mjs';
import { _ as __unimport_currencyFormat } from './currencyFormat-ET0sIbrj.mjs';
import { useSSRContext, mergeProps, unref, withCtx, createVNode, openBlock, createBlock, toDisplayString, createCommentVNode } from 'vue';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "Card",
  __ssrInlineRender: true,
  props: ["index", "detail"],
  setup(__props) {
    const route = useRoute();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i;
      const _component_NuxtLink = __nuxt_component_0;
      const _component_AppIcon = __nuxt_component_1;
      const _component_NuxtImg = __nuxt_component_1$1;
      _push(ssrRenderComponent(_component_NuxtLink, mergeProps({
        to: `/product/${encodeURIComponent(__props.detail.title)}${((_b = (_a = unref(route)) == null ? void 0 : _a.params) == null ? void 0 : _b.title) ? `/${encodeURIComponent((_d = (_c = unref(route)) == null ? void 0 : _c.params) == null ? void 0 : _d.title)}` : ""}/${(_e = __props.detail) == null ? void 0 : _e.id}?categoryId=${((_g = (_f = unref(route)) == null ? void 0 : _f.params) == null ? void 0 : _g.id) ? (_i = (_h = unref(route)) == null ? void 0 : _h.params) == null ? void 0 : _i.id : ""}`,
        class: "w-full block"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="w-full min-w-[160px] sm:max-w-[160px] md:min-w-[200px] md:max-w-[200px] xl:max-w-[280px] bg-white darks:bg-gray-800 rounded-[10px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.05)] darks:shadow-[0px_2px_8px_0px_rgba(0,0,0,0.1)] overflow-hidden"${_scopeId}><div class="w-full h-[90px] sm:h-[120px] lg:h-[140px] xl:h-[160px] bg-gray-200 bg-cover bg-center relative"${_scopeId}><span class="absolute h-5 sm:h-[30px] w-5 sm:w-[30px] rounded-full right-[10px] top-[10px] bg-white/70 flex items-center justify-center"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_AppIcon, {
              icon: !__props.detail.liked ? "ph:heart" : "ph:heart-fill",
              class: "text-xs sm:text-sm md:text-base darks:text-white"
            }, null, _parent2, _scopeId));
            _push2(`</span>`);
            if (__props.detail.converPhoto) {
              _push2(ssrRenderComponent(_component_NuxtImg, {
                src: __props.detail.converPhoto,
                alt: "image",
                width: "276",
                height: "160",
                class: "w-full h-full object-cover",
                fit: "cover",
                loading: "lazy",
                crossorigin: ""
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<div class="w-full h-full bg-gray-200 bg-cover bg-center relative"${_scopeId}></div>`);
            }
            _push2(`</div><div class="w-full py-3 md:py-5 px-3 xl:px-5"${_scopeId}><span class="block mb-1 font-medium truncate max-w-max text-[12px] sm:text-sm xl:text-base darks:text-white leading-tight"${_scopeId}>${ssrInterpolate(__props.detail.title)}</span><span class="block mb-[14px] sm:mb-[25px] text-[10px] sm:text-[12px] xl:text-sm truncate max-w-max text-[#666] darks:text-white/80 leading-tight"${_scopeId}>${ssrInterpolate(__props.detail.manufacturer)}</span><div class="flex justify-between items-start md:items-center"${_scopeId}>`);
            if (__props.detail.hidePrice) {
              _push2(`<span class="font-semibold text-[12px] sm:text-sm xl:text-base text-[#2176FF] leading-tight"${_scopeId}>Request Quote</span>`);
            } else {
              _push2(`<span class="text-base flex flex-col md:flex-row gap-x-1 md:items-center"${_scopeId}><span class="gap-x-1 flex items-center"${_scopeId}>`);
              if (__props.detail.oldprice) {
                _push2(`<span class="line-through text-[#666] darks:text-white/80 text-[12px] sm:text-sm xl:text-base font-semibold leading-tight"${_scopeId}>${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(__props.detail.oldprice))}/${ssrInterpolate(__props.detail.unit)}</span>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`<span class="font-bold ml-[2px] text-[12px] sm:text-sm xl:text-base text-[#333] darks:text-white leading-tight"${_scopeId}>${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(__props.detail.price))}/${ssrInterpolate(__props.detail.unit)}</span></span></span>`);
            }
            _push2(`</div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "w-full min-w-[160px] sm:max-w-[160px] md:min-w-[200px] md:max-w-[200px] xl:max-w-[280px] bg-white darks:bg-gray-800 rounded-[10px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.05)] darks:shadow-[0px_2px_8px_0px_rgba(0,0,0,0.1)] overflow-hidden" }, [
                createVNode("div", { class: "w-full h-[90px] sm:h-[120px] lg:h-[140px] xl:h-[160px] bg-gray-200 bg-cover bg-center relative" }, [
                  createVNode("span", { class: "absolute h-5 sm:h-[30px] w-5 sm:w-[30px] rounded-full right-[10px] top-[10px] bg-white/70 flex items-center justify-center" }, [
                    createVNode(_component_AppIcon, {
                      icon: !__props.detail.liked ? "ph:heart" : "ph:heart-fill",
                      class: "text-xs sm:text-sm md:text-base darks:text-white"
                    }, null, 8, ["icon"])
                  ]),
                  __props.detail.converPhoto ? (openBlock(), createBlock(_component_NuxtImg, {
                    key: 0,
                    src: __props.detail.converPhoto,
                    alt: "image",
                    width: "276",
                    height: "160",
                    class: "w-full h-full object-cover",
                    fit: "cover",
                    loading: "lazy",
                    crossorigin: ""
                  }, null, 8, ["src"])) : (openBlock(), createBlock("div", {
                    key: 1,
                    class: "w-full h-full bg-gray-200 bg-cover bg-center relative"
                  }))
                ]),
                createVNode("div", { class: "w-full py-3 md:py-5 px-3 xl:px-5" }, [
                  createVNode("span", { class: "block mb-1 font-medium truncate max-w-max text-[12px] sm:text-sm xl:text-base darks:text-white leading-tight" }, toDisplayString(__props.detail.title), 1),
                  createVNode("span", { class: "block mb-[14px] sm:mb-[25px] text-[10px] sm:text-[12px] xl:text-sm truncate max-w-max text-[#666] darks:text-white/80 leading-tight" }, toDisplayString(__props.detail.manufacturer), 1),
                  createVNode("div", { class: "flex justify-between items-start md:items-center" }, [
                    __props.detail.hidePrice ? (openBlock(), createBlock("span", {
                      key: 0,
                      class: "font-semibold text-[12px] sm:text-sm xl:text-base text-[#2176FF] leading-tight"
                    }, "Request Quote")) : (openBlock(), createBlock("span", {
                      key: 1,
                      class: "text-base flex flex-col md:flex-row gap-x-1 md:items-center"
                    }, [
                      createVNode("span", { class: "gap-x-1 flex items-center" }, [
                        __props.detail.oldprice ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "line-through text-[#666] darks:text-white/80 text-[12px] sm:text-sm xl:text-base font-semibold leading-tight"
                        }, toDisplayString(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(__props.detail.oldprice)) + "/" + toDisplayString(__props.detail.unit), 1)) : createCommentVNode("", true),
                        createVNode("span", { class: "font-bold ml-[2px] text-[12px] sm:text-sm xl:text-base text-[#333] darks:text-white leading-tight" }, toDisplayString(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(__props.detail.price)) + "/" + toDisplayString(__props.detail.unit), 1)
                      ])
                    ]))
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/product/Card.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main;

export { __nuxt_component_2 as _ };
//# sourceMappingURL=Card-x8tysvFx.mjs.map
