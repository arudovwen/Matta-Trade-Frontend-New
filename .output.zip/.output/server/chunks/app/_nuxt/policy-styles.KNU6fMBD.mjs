const policy_vue_vue_type_style_index_0_scoped_e6b1b300_lang = "h2[data-v-e6b1b300]{font-size:18px;font-weight:600;margin-bottom:.8rem}h3[data-v-e6b1b300]{font-size:16px;margin-bottom:.7rem}h4[data-v-e6b1b300]{font-size:15px;margin-bottom:.5rem}p[data-v-e6b1b300]{font-size:14px;line-height:1.6;margin-bottom:1rem}article[data-v-e6b1b300]{margin-bottom:2rem}li[data-v-e6b1b300]{margin-bottom:10px}a[data-v-e6b1b300]{color:blue;font-size:14px;text-decoration:underline}";

const policyStyles_KNU6fMBD = [policy_vue_vue_type_style_index_0_scoped_e6b1b300_lang, policy_vue_vue_type_style_index_0_scoped_e6b1b300_lang];

export { policyStyles_KNU6fMBD as default };
//# sourceMappingURL=policy-styles.KNU6fMBD.mjs.map
