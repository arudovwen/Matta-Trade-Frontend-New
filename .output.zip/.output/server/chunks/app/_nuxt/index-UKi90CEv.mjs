import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { _ as __nuxt_component_1$1 } from './nuxt-img-qJohECzX.mjs';
import { _ as __nuxt_component_5 } from './CartButton-sf044Ti9.mjs';
import { u as useCartStore } from './cart-fg4oswtQ.mjs';
import { mergeProps, useSSRContext, unref, withCtx, createVNode, ref, watch, provide } from 'vue';
import { _ as __unimport_currencyFormat } from './currencyFormat-ET0sIbrj.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { _ as __nuxt_component_2$1 } from './EmptyData-RrNjecQG.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-fc3HHrvA.mjs';
import { a as useHead } from '../server.mjs';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './_plugin-vue_export-helper-yVxbj29m.mjs';
import './cartservice-JuOkMZ9e.mjs';
import './retry-handling-kb1itlan.mjs';
import 'vue3-toastify';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$3 = {
  __name: "Item",
  __ssrInlineRender: true,
  props: ["detail"],
  setup(__props) {
    const cartStore = useCartStore();
    const props = __props;
    const counter = ref(props.detail.quantity);
    watch(counter, () => {
      cartStore == null ? void 0 : cartStore.updateCart({ ...props.detail, quantity: counter.value });
    });
    provide("counter", counter);
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_NuxtImg = __nuxt_component_1$1;
      const _component_CartButton = __nuxt_component_5;
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col sm:flex-row justify-between p-5 sm:p-6 lg:p-[30px] gap-y-5 md:gap-y-0" }, _attrs))}><div class="flex gap-x-4 md:gap-x-6">`);
      _push(ssrRenderComponent(_component_NuxtImg, {
        src: __props.detail.productImg || "/images/imgplace.png",
        alt: "img",
        width: "117",
        height: "117",
        class: "bg-gray-100 w-12 md:w-[117px] h-11 md:h-[117px] rounded-[5px] bg-cover object-cover"
      }, null, _parent));
      _push(`<div class="w-full sm:w-auto sm:max-w-[350px]"><p class="font-bold text-xs md:text-base mb-[6px]md: mb-[9px]">${ssrInterpolate((_a = __props.detail) == null ? void 0 : _a.product)}</p><p class="text-[10px] md:text-xs mb-[10px]md: mb-[15px]"><span class="font-normal">Sold by:</span><span class="font-bold">${ssrInterpolate((_b = __props.detail) == null ? void 0 : _b.producer)}</span></p><div class="flex flex-col sm:flex-row gap-y-4 lg:gap-y-0 sm:gap-x-6"><div><p class="font-medium text-[10px] md:text-xs mb-1">Packaging</p><span class="text-sm rounded border border-[#E7E7E7] bg-white flex items-center h-8 px-[15px]">${ssrInterpolate(__props.detail.selectedPackage)}</span></div><div><p class="font-medium text-[10px] md:text-xs mb-1">Quantity</p><div class="h-8 sm:max-w-[115px]">`);
      _push(ssrRenderComponent(_component_CartButton, {
        textClass: "!text-[11px] md:!text-sm",
        iconClass: "!text-[10px] md:!text-xs",
        btnClass: "!px-[10px]"
      }, null, _parent));
      _push(`</div></div></div></div></div><div class="flex flex-col justify-center md:justify-between"><p class="font-bold text-center md:text-right">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(__props.detail.packagePrice * unref(counter)))}</p>`);
      _push(ssrRenderComponent(_component_AppButton, {
        onClick: ($event) => {
          var _a2;
          return (_a2 = unref(cartStore)) == null ? void 0 : _a2.removeFromCart(__props.detail.id);
        },
        text: "Remove item",
        icon: "bx:trash",
        btnClass: " !px-0  !py-[0] !text-[11px] sm:text-xs md:text-sm !font-normal",
        iconClass: "!text-[10px] md:!text-base !mr-1"
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Cart/Item.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "Content",
  __ssrInlineRender: true,
  setup(__props) {
    const cartStore = useCartStore();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c;
      const _component_CartItem = __nuxt_component_0;
      const _component_EmptyData = __nuxt_component_2$1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="bg-white rounded-[10px]"><div class="px-[30px] py-5 font-bold text-2xl border-b border-[#f3f3f3]"> Cart </div>`);
      if ((_b = (_a = unref(cartStore)) == null ? void 0 : _a.cart) == null ? void 0 : _b.length) {
        _push(`<div class="flex flex-col gap-y-5"><!--[-->`);
        ssrRenderList((_c = unref(cartStore)) == null ? void 0 : _c.cart, (item) => {
          _push(`<div class="border-b last:border-none border-[#f3f3f3]">`);
          _push(ssrRenderComponent(_component_CartItem, { detail: item }, null, _parent));
          _push(`</div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(ssrRenderComponent(_component_EmptyData, { title: "You have no item in your cart" }, null, _parent));
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Cart/Content.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "Side",
  __ssrInlineRender: true,
  setup(__props) {
    const cartStore = useCartStore();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-[#333] rounded-[10px] py-[30px] px-5 w-full lg:w-[300px] xl:w-[360px]" }, _attrs))}><div class="font-semibold text-2xl text-white pb-6">Order Summary</div><div class="flex flex-col gap-y-5"><!--[-->`);
      ssrRenderList((_a = unref(cartStore)) == null ? void 0 : _a.cart, (item) => {
        _push(`<div class="flex justify-between"><div><p class="font-semibold text-sm text-white mb-[2px]">${ssrInterpolate(item.product)}</p><p class="text-xs text-[#959595]"> Qty: ${ssrInterpolate(item.quantity)} ${ssrInterpolate(item.selectedPackage)}</p></div><p class="font-medium text-sm text-white">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(item.packagePrice))}</p></div>`);
      });
      _push(`<!--]--></div><hr class="my-[20px] border-white/10"><div class="flex flex-col gap-y-3"><div class="flex justify-between"><p class="text-sm text-[#E1E1E1]">Sub-total</p><p class="text-white font-medium text-sm">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))((_b = unref(cartStore)) == null ? void 0 : _b.cartTotalAmount))}</p></div><div class="flex justify-between"><p class="text-sm text-[#E1E1E1]">Tax (7.5%)</p><p class="text-white text-sm font-medium">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(((_c = unref(cartStore)) == null ? void 0 : _c.cartTotalAmount) * ((_d = unref(cartStore)) == null ? void 0 : _d.tax)))}</p></div><div class="flex justify-between"><p class="text-sm text-[#E1E1E1]">Shipping &amp; Handling</p><p class="text-white font-medium text-sm">TBD</p></div></div><hr class="my-[20px] border-white/10"><div class="flex justify-between mb-[25px]"><p class="text-sm text-[#E1E1E1]">Total</p><p class="text-white font-bold">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(
        ((_e = unref(cartStore)) == null ? void 0 : _e.cartTotalAmount) * ((_f = unref(cartStore)) == null ? void 0 : _f.tax) + ((_g = unref(cartStore)) == null ? void 0 : _g.cartTotalAmount)
      ))}</p></div>`);
      _push(ssrRenderComponent(_component_NuxtLink, { href: "/checkout" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2;
          if (_push2) {
            _push2(ssrRenderComponent(_component_AppButton, {
              icon: "bytesize:cart",
              isDisabled: !((_a2 = unref(cartStore)) == null ? void 0 : _a2.cart) || !((_b2 = unref(cartStore)) == null ? void 0 : _b2.cartTotalAmount),
              text: "Checkout",
              btnClass: "bg-primary-500  w-full text-white !px-4 !sm:px-6 !py-[13px] text-xs sm:text-sm"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_AppButton, {
                icon: "bytesize:cart",
                isDisabled: !((_c2 = unref(cartStore)) == null ? void 0 : _c2.cart) || !((_d2 = unref(cartStore)) == null ? void 0 : _d2.cartTotalAmount),
                text: "Checkout",
                btnClass: "bg-primary-500  w-full text-white !px-4 !sm:px-6 !py-[13px] text-xs sm:text-sm"
              }, null, 8, ["isDisabled"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Cart/Side.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$1;
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Cart | Matta",
      meta: [{ name: "description", content: "Cart" }]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppButton = __nuxt_component_4;
      const _component_CartContent = __nuxt_component_1;
      const _component_CartSide = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container py-10 w-full" }, _attrs))}><div class="mb-6">`);
      _push(ssrRenderComponent(_component_AppButton, {
        link: "/market/all products",
        icon: "ion:arrow-back-sharp",
        text: "Back to shopping",
        btnClass: "text-xs sm:text-sm !py-0 !px-0 !font-semibold"
      }, null, _parent));
      _push(`</div><div class="flex gap-x-5 w-full flex-col lg:flex-row gap-y-8 lg:gap-y-0"><div class="flex-1">`);
      _push(ssrRenderComponent(_component_CartContent, null, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_CartSide, null, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/cart/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-UKi90CEv.mjs.map
