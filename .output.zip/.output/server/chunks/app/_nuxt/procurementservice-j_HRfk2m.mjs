import { t as store, r as urls, v as get, q as post } from '../server.mjs';
import { w as withRetryHandling } from './retry-handling-kb1itlan.mjs';

const config = {
  headers: { Authorization: `Bearer ${store.getters.accessToken}` }
};
const procurementrequests = withRetryHandling(
  ({
    SortOrder,
    Search,
    PageNumber,
    PageSize,
    ProductId,
    ProducerId,
    RequestStatus,
    SupplierId
  }) => {
    return get(
      `${urls.PROCUREMENT_MYREQUESTS}?PageSize=${PageSize}&PageNumber=${PageNumber}&Search=${Search}&SortOrder=${SortOrder}
      &SupplierId=${SupplierId}&RequestStatus=${RequestStatus}&ProducerId=${ProducerId}&ProductId=${ProductId}`,
      config
    );
  }
);
const procurementrequestdetails = withRetryHandling((requestId) => {
  return get(
    `${urls.PROCUREMENT_MYREQUEST_DETAILS}?requestId=${requestId}`,
    config
  );
});
async function addrequest(data) {
  return await post(`${urls.ADD_SAMPLE_REQUEST}`, data, config);
}

export { procurementrequests as a, addrequest as b, procurementrequestdetails as p };
//# sourceMappingURL=procurementservice-j_HRfk2m.mjs.map
