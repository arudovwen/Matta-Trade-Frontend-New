import { _ as __nuxt_component_0$1 } from './index-4NCxcAqd.mjs';
import { _ as __nuxt_component_4 } from './index-RMKHVahR.mjs';
import { reactive, watch, provide, mergeProps, unref, useSSRContext, inject, ref, withCtx, isRef, createVNode } from 'vue';
import { s as storeToRefs, u as useRoute, a as useHead, g as getProductsByTag, b as getProducts, c as useMarketStore } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import { u as useProductStore, a as useSupplierStore } from './supplier-RTXftR8K.mjs';
import { u as ucFirst, _ as __nuxt_component_0$2 } from './ucFirst-myEoadyv.mjs';
import { _ as __nuxt_component_4$1 } from './AppButton-rwP1M0KN.mjs';
import { _ as __nuxt_component_2$1 } from './Card-x8tysvFx.mjs';
import { _ as __nuxt_component_2$2 } from './EmptyData-RrNjecQG.mjs';
import { _ as __nuxt_component_0$3 } from './IndexModal-vEF7RYpX.mjs';
import { _ as __nuxt_component_5$1 } from './VueSelect-yd8BMEUx.mjs';
import { _ as __nuxt_component_1$1 } from './AppLoader-SkdFRsgH.mjs';
import { _ as __nuxt_component_5 } from './index-auAvMvtw.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './_plugin-vue_export-helper-yVxbj29m.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';
import './ck-white-co8-jVxZ.mjs';
import './nuxt-img-qJohECzX.mjs';
import './currencyFormat-ET0sIbrj.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import '@heroicons/vue/24/solid';
import '@headlessui/vue';

const _sfc_main$3 = {
  __name: "Banner",
  __ssrInlineRender: true,
  setup(__props) {
    const query = inject("query");
    const store = useProductStore();
    const { total } = storeToRefs(store);
    const router = useRoute();
    const { title, id } = router.params;
    const links = [
      {
        title: "home",
        url: "/"
      },
      {
        title,
        url: "#"
      }
    ];
    const options = [
      {
        label: "Low to High",
        value: 0
      },
      {
        label: "High to Low",
        value: 1
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Breadcrumbs = __nuxt_component_0$1;
      const _component_Select = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-[#292D35]" }, _attrs))}><div class="container py-[35px] flex flex-col lg:flex-row lg:items-end justify-between"><div>`);
      _push(ssrRenderComponent(_component_Breadcrumbs, {
        links,
        className: "text-white"
      }, null, _parent));
      _push(`<h1 class="text-white text-[32px] font-bold mb-[10px] mt-9 capitalize">${ssrInterpolate(unref(title))}</h1><p class="text-base text-white mb-4 lg:mb-0"> We found ${ssrInterpolate(unref(total))} Products\u201D matching your search criteria </p></div><div class="hidden md:flex">`);
      _push(ssrRenderComponent(_component_Select, {
        modelValue: unref(query).sortOrder,
        "onUpdate:modelValue": ($event) => unref(query).sortOrder = $event,
        modelModifiers: { number: true },
        options,
        placeholder: "Sort prices by",
        classInput: "min-w-[180px] !bg-white !border-[#B9C0D4] !rounded-[4px] !text-[#5D6B98] !h-11 cursor-pointer"
      }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Market/Banner.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "SideBar",
  __ssrInlineRender: true,
  setup(__props) {
    const supplierStore = useSupplierStore();
    const marketStore = useMarketStore();
    const route = useRoute();
    const query = inject("query");
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d;
      const _component_SideTab = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white w-full pt-4 pb-2 rounded-[10px] sticky top-[120px]" }, _attrs))}><div class="flex justify-between items-center pb-2 px-[15px]"><span class="text-sm font-semibold"> Filter</span><span class="text-xs text-[#8D8D8D] cursor-pointer" as="button">Clear filter</span></div><hr class="border-[#EFEFEF] my-2">`);
      _push(ssrRenderComponent(_component_SideTab, {
        title: "Producers",
        lists: (_b = (_a = unref(supplierStore)) == null ? void 0 : _a.producersData) == null ? void 0 : _b.map((i) => ({ ...i, value: i.title })),
        modelValue: unref(query).producers,
        "onUpdate:modelValue": ($event) => unref(query).producers = $event
      }, null, _parent));
      if (unref(route).params.id) {
        _push(`<hr class="border-[#EFEFEF] my-[1px]">`);
      } else {
        _push(`<!---->`);
      }
      if (unref(route).params.id) {
        _push(ssrRenderComponent(_component_SideTab, {
          title: "Area of applications",
          lists: (_d = (_c = unref(marketStore)) == null ? void 0 : _c.marketMenuData) == null ? void 0 : _d.map((i) => ({ ...i, value: i.id })),
          modelValue: unref(query).applications,
          "onUpdate:modelValue": ($event) => unref(query).applications = $event
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Market/SideBar.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "Content",
  __ssrInlineRender: true,
  setup(__props) {
    const store = useProductStore();
    const supplierStore = useSupplierStore();
    const marketStore = useMarketStore();
    const { productsData, loading } = storeToRefs(store);
    const query = inject("query");
    const open = ref(false);
    const applications = ref([]);
    const producers = ref([]);
    const sortOrder = ref("");
    const options = [
      {
        label: "Low to High",
        value: 0
      },
      {
        label: "High to Low",
        value: 1
      }
    ];
    function togglePopup() {
      open.value = false;
    }
    function applyFilter() {
      query.producers = producers.value;
      query.applications = applications.value;
      query.sortOrder = sortOrder;
      open.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppButton = __nuxt_component_4$1;
      const _component_Select = __nuxt_component_4;
      const _component_ProductCard = __nuxt_component_2$1;
      const _component_EmptyData = __nuxt_component_2$2;
      const _component_IndexModal = __nuxt_component_0$3;
      const _component_SelectVueSelect = __nuxt_component_5$1;
      const _component_AppLoader = __nuxt_component_1$1;
      _push(`<!--[--><div class="flex md:hidden justify-between items-center">`);
      _push(ssrRenderComponent(_component_AppButton, {
        onClick: ($event) => open.value = true,
        text: "Filter",
        icon: "tabler:filter",
        btnClass: "border border-[#ECECEC] bg-white text-[#5D6B98] !text-xs",
        iconClass: "text-sm"
      }, null, _parent));
      _push(`<div>`);
      _push(ssrRenderComponent(_component_Select, {
        modelValue: unref(query).sortOrder,
        "onUpdate:modelValue": ($event) => unref(query).sortOrder = $event,
        modelModifiers: { number: true },
        options,
        placeholder: "Sort by",
        classInput: "!bg-white !border-[#ECECEC] !rounded-[4px] !text-[#5D6B98] !text-xs !h-7 md:!h-11 cursor-pointer !w-auto"
      }, null, _parent));
      _push(`</div></div>`);
      if (!unref(loading)) {
        _push(`<div>`);
        if (unref(productsData).length) {
          _push(`<div class="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-[30px]"><!--[-->`);
          ssrRenderList(unref(productsData), (n, idx) => {
            _push(ssrRenderComponent(_component_ProductCard, {
              key: idx,
              index: idx,
              detail: n
            }, null, _parent));
          });
          _push(`<!--]--></div>`);
        } else {
          _push(`<!---->`);
        }
        if (!unref(productsData).length) {
          _push(ssrRenderComponent(_component_EmptyData, null, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_IndexModal, {
        isOpen: unref(open),
        onTogglePopup: togglePopup
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d, _e, _f, _g, _h;
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 gap-y-[14px] w-full px-6 pt-6 pb-10 min-w-[300px] max-w-[320px]"${_scopeId}><p class="text-base text-[#18273AF0] font-bold"${_scopeId}>Filter</p>`);
            _push2(ssrRenderComponent(_component_SelectVueSelect, {
              label: "Price",
              options,
              modelValue: unref(sortOrder),
              "onUpdate:modelValue": ($event) => isRef(sortOrder) ? sortOrder.value = $event : null,
              modelModifiers: { number: true }
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_SelectVueSelect, {
              label: "Area of application",
              options: (_b = (_a = unref(marketStore)) == null ? void 0 : _a.marketMenuData) == null ? void 0 : _b.map((i) => ({
                ...i,
                value: i.id,
                label: i.title
              })),
              modelValue: unref(applications),
              "onUpdate:modelValue": ($event) => isRef(applications) ? applications.value = $event : null,
              multiple: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_SelectVueSelect, {
              label: "Producers",
              options: (_d = (_c = unref(supplierStore)) == null ? void 0 : _c.producersData) == null ? void 0 : _d.map((i) => ({
                ...i,
                value: i.title,
                label: i.title
              })),
              modelValue: unref(producers),
              "onUpdate:modelValue": ($event) => isRef(producers) ? producers.value = $event : null,
              multiple: ""
            }, null, _parent2, _scopeId));
            _push2(`<button class="appearance-none leading-none px-20 py-4 w-full lg:grid-cols-2 gap-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px]"${_scopeId}> Apply Filter </button></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 gap-y-[14px] w-full px-6 pt-6 pb-10 min-w-[300px] max-w-[320px]" }, [
                createVNode("p", { class: "text-base text-[#18273AF0] font-bold" }, "Filter"),
                createVNode(_component_SelectVueSelect, {
                  label: "Price",
                  options,
                  modelValue: unref(sortOrder),
                  "onUpdate:modelValue": ($event) => isRef(sortOrder) ? sortOrder.value = $event : null,
                  modelModifiers: { number: true }
                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode(_component_SelectVueSelect, {
                  label: "Area of application",
                  options: (_f = (_e = unref(marketStore)) == null ? void 0 : _e.marketMenuData) == null ? void 0 : _f.map((i) => ({
                    ...i,
                    value: i.id,
                    label: i.title
                  })),
                  modelValue: unref(applications),
                  "onUpdate:modelValue": ($event) => isRef(applications) ? applications.value = $event : null,
                  multiple: ""
                }, null, 8, ["options", "modelValue", "onUpdate:modelValue"]),
                createVNode(_component_SelectVueSelect, {
                  label: "Producers",
                  options: (_h = (_g = unref(supplierStore)) == null ? void 0 : _g.producersData) == null ? void 0 : _h.map((i) => ({
                    ...i,
                    value: i.title,
                    label: i.title
                  })),
                  modelValue: unref(producers),
                  "onUpdate:modelValue": ($event) => isRef(producers) ? producers.value = $event : null,
                  multiple: ""
                }, null, 8, ["options", "modelValue", "onUpdate:modelValue"]),
                createVNode("button", {
                  onClick: applyFilter,
                  class: "appearance-none leading-none px-20 py-4 w-full lg:grid-cols-2 gap-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px]"
                }, " Apply Filter ")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      if (unref(loading)) {
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Market/Content.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$1;
const pageRange = 5;
const _sfc_main = {
  __name: "[[id]]",
  __ssrInlineRender: true,
  setup(__props) {
    const store = useProductStore();
    const { productsData, loading } = storeToRefs(store);
    const route = useRoute();
    useHead({
      title: `${ucFirst(route.query.title || route.query.search_query || "Market")} | Matta`,
      meta: [
        {
          name: "description",
          content: `${ucFirst(route.query.title || route.query.search_query || "Market")}`
        }
      ]
    });
    const query = reactive({
      PageNumber: 1,
      PageSize: 20,
      searchParameter: route.query.search_query || "",
      MarketApplication: "",
      Status: "",
      MarketId: route.params.id,
      MarketSubApplication: "",
      productId: "",
      Search: route.query.search_query || "",
      ShowSubMenu: true,
      Producer: route.query.producer,
      producers: [],
      applications: [],
      pagecount: 0,
      totalData: 0,
      sortOrder: "",
      sortBy: 0
    });
    reactive({
      PageNumber: 1,
      PageSize: 20,
      tag: route.query.tag
    });
    function getAllProducts() {
      store.setLoader(true);
      if (route.query.tag) {
        getProductsByTag({
          PageNumber: 1,
          PageSize: 20,
          tag: route.query.tag,
          producers: query.producers
        }).then((res) => {
          if (res.status === 200) {
            store.setProducts(res.data.data);
            store.setLoader(false);
            query.totalData = res.data.data.totalCount;
          }
        }).catch(() => {
          store.setLoader(false);
        });
      } else {
        getProducts(query).then((res) => {
          if (res.status === 200) {
            store.setProducts(res.data);
            store.setLoader(false);
            query.totalData = res.data.totalCount;
          }
        }).catch(() => {
          store.setLoader(false);
        });
      }
    }
    function perPage({ currentPerPage }) {
      query.PageNumber = 1;
      query.PageSize = currentPerPage;
    }
    watch(
      () => [
        query.PageNumber,
        ,
        query.sortOrder,
        query.producers,
        query.sortBy,
        query.applications
      ],
      () => {
        getAllProducts();
      }
    );
    provide("query", query);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_MarketBanner = __nuxt_component_0;
      const _component_MarketSideBar = __nuxt_component_1;
      const _component_MarketContent = __nuxt_component_2;
      const _component_Pagination = __nuxt_component_5;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "" }, _attrs))}><div class="flex flex-col w-full h-full">`);
      _push(ssrRenderComponent(_component_MarketBanner, null, null, _parent));
      _push(`<div class="flex flex-1 container py-6 md:py-10 w-full gap-x-[22px]"><div class="max-w-[250px] w-full hidden lg:block">`);
      _push(ssrRenderComponent(_component_MarketSideBar, null, null, _parent));
      _push(`</div><div class="flex-1 flex flex-col gap-y-10 overflow-y-auto no-scrollbar">`);
      _push(ssrRenderComponent(_component_MarketContent, null, null, _parent));
      if (!unref(loading) && unref(productsData).length && unref(query).totalData > unref(query).PageSize) {
        _push(ssrRenderComponent(_component_Pagination, {
          total: unref(store).total,
          current: unref(query).PageNumber,
          "per-page": unref(query).PageSize,
          pageRange,
          onPageChanged: ($event) => unref(query).PageNumber = $event,
          perPageChanged: perPage
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/market/[[title]]/[[id]].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_id_-Dz1fRR9s.mjs.map
