import { _ as __nuxt_component_1 } from './AppIcon-D3CPABPP.mjs';
import { useSSRContext, inject, unref, mergeProps, withCtx, createVNode, renderSlot, openBlock, createBlock, createCommentVNode } from 'vue';
import { ssrRenderComponent, ssrRenderSlot } from 'vue/server-renderer';
import { TransitionRoot, Dialog, TransitionChild, DialogOverlay } from '@headlessui/vue';

const _sfc_main = {
  __name: "Center",
  __ssrInlineRender: true,
  props: {
    canClose: {
      default: true
    }
  },
  setup(__props) {
    const isOpen = inject("isOpen");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1;
      _push(ssrRenderComponent(unref(TransitionRoot), mergeProps({
        as: "template",
        show: unref(isOpen)
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Dialog), {
              as: "div",
              class: "fixed z-[999] inset-0 overflow-y-auto"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="flex items-center md:items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "div",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true"${_scopeId2}>\u200B</span>`);
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                    "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                    "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="inline-block relative align-bottom bg-white rounded-lg text-left invisible-scrollbar shadow-xl transform transition-all sm:my-8 sm:align-middle w-full max-w-[500px] max-h-[95vh] overflow-y-auto"${_scopeId3}>`);
                        ssrRenderSlot(_ctx.$slots, "default", {}, null, _push4, _parent4, _scopeId3);
                        if (__props.canClose) {
                          _push4(`<span class="cursor-pointer hover:border w-8 h-8 absolute top-[30px] right-[30px] rounded-full bg-[#F5F5F5] flex items-center justify-center z-[999]"${_scopeId3}>`);
                          _push4(ssrRenderComponent(_component_AppIcon, {
                            icon: "heroicons-solid:x",
                            class: "text-lg text-[#8C8C8C]",
                            "aria-hidden": "true"
                          }, null, _parent4, _scopeId3));
                          _push4(`</span>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(`</div>`);
                      } else {
                        return [
                          createVNode("div", { class: "inline-block relative align-bottom bg-white rounded-lg text-left invisible-scrollbar shadow-xl transform transition-all sm:my-8 sm:align-middle w-full max-w-[500px] max-h-[95vh] overflow-y-auto" }, [
                            renderSlot(_ctx.$slots, "default"),
                            __props.canClose ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "cursor-pointer hover:border w-8 h-8 absolute top-[30px] right-[30px] rounded-full bg-[#F5F5F5] flex items-center justify-center z-[999]",
                              onClick: ($event) => isOpen.value = false
                            }, [
                              createVNode(_component_AppIcon, {
                                icon: "heroicons-solid:x",
                                class: "text-lg text-[#8C8C8C]",
                                "aria-hidden": "true"
                              })
                            ], 8, ["onClick"])) : createCommentVNode("", true)
                          ])
                        ];
                      }
                    }),
                    _: 3
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "flex items-center md:items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0" }, [
                      createVNode(unref(TransitionChild), {
                        as: "div",
                        enter: "ease-out duration-300",
                        "enter-from": "opacity-0",
                        "enter-to": "opacity-100",
                        leave: "ease-in duration-200",
                        "leave-from": "opacity-100",
                        "leave-to": "opacity-0"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" })
                        ]),
                        _: 1
                      }),
                      createVNode("span", {
                        class: "hidden sm:inline-block sm:align-middle sm:h-screen",
                        "aria-hidden": "true"
                      }, "\u200B"),
                      createVNode(unref(TransitionChild), {
                        as: "template",
                        enter: "ease-out duration-300",
                        "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                        "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                        leave: "ease-in duration-200",
                        "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                        "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                      }, {
                        default: withCtx(() => [
                          createVNode("div", { class: "inline-block relative align-bottom bg-white rounded-lg text-left invisible-scrollbar shadow-xl transform transition-all sm:my-8 sm:align-middle w-full max-w-[500px] max-h-[95vh] overflow-y-auto" }, [
                            renderSlot(_ctx.$slots, "default"),
                            __props.canClose ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "cursor-pointer hover:border w-8 h-8 absolute top-[30px] right-[30px] rounded-full bg-[#F5F5F5] flex items-center justify-center z-[999]",
                              onClick: ($event) => isOpen.value = false
                            }, [
                              createVNode(_component_AppIcon, {
                                icon: "heroicons-solid:x",
                                class: "text-lg text-[#8C8C8C]",
                                "aria-hidden": "true"
                              })
                            ], 8, ["onClick"])) : createCommentVNode("", true)
                          ])
                        ]),
                        _: 3
                      })
                    ])
                  ];
                }
              }),
              _: 3
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Dialog), {
                as: "div",
                class: "fixed z-[999] inset-0 overflow-y-auto"
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "flex items-center md:items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0" }, [
                    createVNode(unref(TransitionChild), {
                      as: "div",
                      enter: "ease-out duration-300",
                      "enter-from": "opacity-0",
                      "enter-to": "opacity-100",
                      leave: "ease-in duration-200",
                      "leave-from": "opacity-100",
                      "leave-to": "opacity-0"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" })
                      ]),
                      _: 1
                    }),
                    createVNode("span", {
                      class: "hidden sm:inline-block sm:align-middle sm:h-screen",
                      "aria-hidden": "true"
                    }, "\u200B"),
                    createVNode(unref(TransitionChild), {
                      as: "template",
                      enter: "ease-out duration-300",
                      "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                      "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                      leave: "ease-in duration-200",
                      "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                      "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "inline-block relative align-bottom bg-white rounded-lg text-left invisible-scrollbar shadow-xl transform transition-all sm:my-8 sm:align-middle w-full max-w-[500px] max-h-[95vh] overflow-y-auto" }, [
                          renderSlot(_ctx.$slots, "default"),
                          __props.canClose ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "cursor-pointer hover:border w-8 h-8 absolute top-[30px] right-[30px] rounded-full bg-[#F5F5F5] flex items-center justify-center z-[999]",
                            onClick: ($event) => isOpen.value = false
                          }, [
                            createVNode(_component_AppIcon, {
                              icon: "heroicons-solid:x",
                              class: "text-lg text-[#8C8C8C]",
                              "aria-hidden": "true"
                            })
                          ], 8, ["onClick"])) : createCommentVNode("", true)
                        ])
                      ]),
                      _: 3
                    })
                  ])
                ]),
                _: 3
              })
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Modal/Center.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_6 = _sfc_main;

export { __nuxt_component_6 as _ };
//# sourceMappingURL=Center-HbcRsv6_.mjs.map
