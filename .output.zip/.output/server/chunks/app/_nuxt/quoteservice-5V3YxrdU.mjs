import { t as store, r as urls, v as get, q as post } from '../server.mjs';
import { w as withRetryHandling } from './retry-handling-kb1itlan.mjs';

const config = {
  headers: { Authorization: `Bearer ${store.getters.accessToken}` }
};
const sellerquotes = withRetryHandling(
  ({ Status, Search, PageNumber, PageSize, SortOrder }) => {
    return get(
      `${urls.SELLER_QUOTES}?PageSize=${PageSize}&PageNumber=${PageNumber}&Search=${Search}&SortOrder=${SortOrder}
      &Status=${Status}`,
      config
    );
  }
);
const sellerquotedetail = withRetryHandling((id) => {
  return get(`${urls.SELLER_QUOTE_DETAIL}?id=${id}`, config);
});
const buyerquotes = withRetryHandling(
  ({ Status, Search, PageNumber, PageSize, SortOrder }) => {
    return get(
      `${urls.BUYER_QUOTES}?PageSize=${PageSize}&PageNumber=${PageNumber}&Search=${Search}
       &Status=${Status}&SortOrder=${SortOrder}`,
      config
    );
  }
);
const buyerquotedetail = withRetryHandling((id) => {
  return get(`${urls.BUYER_QUOTE_DETAIL}?id=${id}`, config);
});
async function newquote(data) {
  return await post(`${urls.NEW_QUOTE}`, data, config);
}

export { buyerquotedetail as a, buyerquotes as b, sellerquotes as c, newquote as n, sellerquotedetail as s };
//# sourceMappingURL=quoteservice-5V3YxrdU.mjs.map
