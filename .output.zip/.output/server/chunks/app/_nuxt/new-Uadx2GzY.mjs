import { _ as __nuxt_component_0 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_1 } from './index-eSH9oSpY.mjs';
import { _ as __nuxt_component_0$1 } from './index-oCDvIFtd.mjs';
import { _ as __nuxt_component_4 } from './index-RMKHVahR.mjs';
import { C as CurrencyInput } from './CurrencyInput-krSh-4ij.mjs';
import { _ as __nuxt_component_4$1 } from './AppButton-rwP1M0KN.mjs';
import { useSSRContext, ref, reactive, mergeProps, unref, isRef, withCtx, createVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { useForm } from 'vee-validate';
import * as yup from 'yup';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';
import '../../rollup/_vue.mjs';
import 'cleave.js';
import 'vue-currency-input';
import './nuxt-link-fc3HHrvA.mjs';

const _sfc_main = {
  __name: "new",
  __ssrInlineRender: true,
  setup(__props) {
    const isLoading = ref(false);
    const formValues = reactive({
      amount: null,
      tenor: "",
      about: ""
    });
    const schema = yup.object({
      amount: yup.string().required("Amount is required"),
      tenor: yup.string().required("Tenor is required"),
      about: yup.string().required("About is required")
    });
    const { handleSubmit, defineField, errors, setFieldValue } = useForm({
      validationSchema: schema,
      initialValues: formValues
    });
    const [amount, amountAtt] = defineField("amount");
    const [tenor, tenorAtt] = defineField("tenor");
    const [about, aboutAtt] = defineField("about");
    handleSubmit((values) => {
      console.log("\u{1F680} ~ onSubmit ~ values:", values);
      active.value = 2;
    });
    const options = [
      {
        label: "1 month",
        value: 0
      },
      {
        label: "3 month",
        value: 1
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderComponent = __nuxt_component_0;
      const _component_Textinput = __nuxt_component_1;
      const _component_FormGroup = __nuxt_component_0$1;
      const _component_Select = __nuxt_component_4;
      const _component_CurrencyInput = CurrencyInput;
      const _component_AppButton = __nuxt_component_4$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "gap-y-2 flex flex-col bg-white rounded-[10px] pb-10 border border-[#F4F7FE]" }, _attrs))} data-v-5c71ba49>`);
      _push(ssrRenderComponent(_component_HeaderComponent, {
        title: "New Campaign",
        canGoback: true
      }, null, _parent));
      _push(`<div data-v-5c71ba49><div class="flex gap-x-[76px] pt-[30px] px-4 lg:px-[30px] flex-col lg:flex-row gap-y-7 lg:gap-y-" data-v-5c71ba49><div class="w-[300px]" data-v-5c71ba49><h2 class="text-sm text-[#101828] font-semibold" data-v-5c71ba49>Campaign Details</h2><p class="text-xs text-[#475467]" data-v-5c71ba49> Provide the required campaign information </p></div><form class="flex-1" data-v-5c71ba49><div class="grid grid-cols-2 gap-x-[25px] gap-y-4 mb-[50px]" data-v-5c71ba49>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Campaign Name",
        name: "about"
      }, unref(aboutAtt), {
        modelValue: unref(about),
        "onUpdate:modelValue": ($event) => isRef(about) ? about.value = $event : null,
        error: unref(errors).about
      }), null, _parent));
      _push(ssrRenderComponent(_component_FormGroup, {
        label: "Discount type",
        error: unref(errors).tenor,
        name: "tenor"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Select, {
              modelValue: unref(tenor),
              "onUpdate:modelValue": ($event) => isRef(tenor) ? tenor.value = $event : null,
              options,
              placeholder: "Select tenor",
              classInput: `min-w-[180px] !bg-white  !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).tenor ? "border-red-500" : "border-[#D0D5DD]"}`
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Select, {
                modelValue: unref(tenor),
                "onUpdate:modelValue": ($event) => isRef(tenor) ? tenor.value = $event : null,
                options,
                placeholder: "Select tenor",
                classInput: `min-w-[180px] !bg-white  !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).tenor ? "border-red-500" : "border-[#D0D5DD]"}`
              }, null, 8, ["modelValue", "onUpdate:modelValue", "classInput"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_FormGroup, {
        label: "Discount value",
        error: unref(errors).amount
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_CurrencyInput, {
              min: "1",
              class: `outline-none px-[14px] py-[10px] min-w-[180px] w-full !bg-white border !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).amount ? "border-red-500" : "border-[#D0D5DD]"}`,
              modelValue: unref(amount),
              "onUpdate:modelValue": ($event) => isRef(amount) ? amount.value = $event : null,
              options: {
                currency: "ngn",
                currencyDisplay: "hidden"
              }
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_CurrencyInput, {
                min: "1",
                class: `outline-none px-[14px] py-[10px] min-w-[180px] w-full !bg-white border !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).amount ? "border-red-500" : "border-[#D0D5DD]"}`,
                modelValue: unref(amount),
                "onUpdate:modelValue": ($event) => isRef(amount) ? amount.value = $event : null,
                options: {
                  currency: "ngn",
                  currencyDisplay: "hidden"
                }
              }, null, 8, ["class", "modelValue", "onUpdate:modelValue"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_FormGroup, {
        label: "Number of usage per user",
        error: unref(errors).amount
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_CurrencyInput, {
              min: "1",
              class: `outline-none px-[14px] py-[10px] min-w-[180px] w-full !bg-white border !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).amount ? "border-red-500" : "border-[#D0D5DD]"}`,
              modelValue: unref(amount),
              "onUpdate:modelValue": ($event) => isRef(amount) ? amount.value = $event : null,
              options: {
                currency: "ngn",
                currencyDisplay: "hidden"
              }
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_CurrencyInput, {
                min: "1",
                class: `outline-none px-[14px] py-[10px] min-w-[180px] w-full !bg-white border !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).amount ? "border-red-500" : "border-[#D0D5DD]"}`,
                modelValue: unref(amount),
                "onUpdate:modelValue": ($event) => isRef(amount) ? amount.value = $event : null,
                options: {
                  currency: "ngn",
                  currencyDisplay: "hidden"
                }
              }, null, 8, ["class", "modelValue", "onUpdate:modelValue"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Expiration Date",
        type: "date",
        name: "about"
      }, unref(aboutAtt), {
        modelValue: unref(about),
        "onUpdate:modelValue": ($event) => isRef(about) ? about.value = $event : null,
        error: unref(errors).about
      }), null, _parent));
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Code Use Limit (Optional)",
        name: "about"
      }, unref(aboutAtt), {
        modelValue: unref(about),
        "onUpdate:modelValue": ($event) => isRef(about) ? about.value = $event : null,
        error: unref(errors).about
      }), null, _parent));
      _push(`<div class="md:col-span-2" data-v-5c71ba49>`);
      _push(ssrRenderComponent(_component_FormGroup, {
        label: "User types",
        error: unref(errors).tenor,
        name: "tenor"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Select, {
              modelValue: unref(tenor),
              "onUpdate:modelValue": ($event) => isRef(tenor) ? tenor.value = $event : null,
              options,
              placeholder: "Select tenor",
              classInput: `min-w-[180px] !bg-white  !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).tenor ? "border-red-500" : "border-[#D0D5DD]"}`
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Select, {
                modelValue: unref(tenor),
                "onUpdate:modelValue": ($event) => isRef(tenor) ? tenor.value = $event : null,
                options,
                placeholder: "Select tenor",
                classInput: `min-w-[180px] !bg-white  !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).tenor ? "border-red-500" : "border-[#D0D5DD]"}`
              }, null, 8, ["modelValue", "onUpdate:modelValue", "classInput"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="flex gap-x-4 items-center justify-end" data-v-5c71ba49>`);
      _push(ssrRenderComponent(_component_AppButton, {
        disabled: unref(isLoading),
        isLoading: unref(isLoading),
        btnClass: "bg-primary-500 text-white !px-8  !text-sm !py-[10px] disabled:cursor-not-allowed",
        type: "submit",
        text: "Create campaign"
      }, null, _parent));
      _push(`</div></form></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/campaign/new.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _new = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-5c71ba49"]]);

export { _new as default };
//# sourceMappingURL=new-Uadx2GzY.mjs.map
