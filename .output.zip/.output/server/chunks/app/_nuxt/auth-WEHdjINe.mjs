import { H as defineNuxtRouteMiddleware, d as useAuthStore, n as navigateTo, I as abortNavigation } from '../server.mjs';
import 'vue';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'vue/server-renderer';
import 'axios';

const auth = defineNuxtRouteMiddleware((to, from) => {
  const authStore = useAuthStore();
  if (authStore.isLoggedIn && (to == null ? void 0 : to.name.includes("auth"))) {
    return navigateTo("/");
  }
  if (!authStore.isLoggedIn && !(to == null ? void 0 : to.name.includes("auth"))) {
    abortNavigation();
    return navigateTo(`/auth/login?redirected_from=${to.path}`);
  }
});

export { auth as default };
//# sourceMappingURL=auth-WEHdjINe.mjs.map
