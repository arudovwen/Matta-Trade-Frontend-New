import { _ as __nuxt_component_0$1 } from './TopBar-Q5W4PGYG.mjs';
import { useSSRContext, computed, ref, reactive, unref, withCtx, createVNode, watch, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr, ssrRenderClass, ssrIncludeBooleanAttr, ssrRenderStyle } from 'vue/server-renderer';
import { _ as __nuxt_component_2$1, b as __nuxt_component_3, a as __nuxt_component_5 } from './Directors-g1CyZEEM.mjs';
import { _ as __nuxt_component_1$1 } from './nuxt-img-qJohECzX.mjs';
import { _ as __nuxt_component_2 } from './SelectComponent-Q1jk_qng.mjs';
import { P as PhoneCodes } from './PhoneCodes-TGlMinMT.mjs';
import { d as useAuthStore, y as useStore } from '../server.mjs';
import CountryList from 'country-list-with-dial-code-and-flag';
import moment from 'moment-timezone';
import { TransitionRoot, Dialog, TransitionChild, DialogPanel } from '@headlessui/vue';
import { Cropper } from 'vue-advanced-cropper';
import { c as countries } from './countries-4zSrMx8v.mjs';
import useVuelidate from '@vuelidate/core';
import { required, helpers, email, maxLength, numeric } from '@vuelidate/validators';
import { u as uploadfile } from './onboardingservices-NoJPITnD.mjs';
import { useRouter, useRoute } from 'vue-router';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './FileUpload-oHb-LYnL.mjs';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './AppButton-rwP1M0KN.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '@heroicons/vue/24/solid';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$3 = {
  __name: "SideBar",
  __ssrInlineRender: true,
  props: ["active"],
  setup(__props) {
    const navigation = [
      "Profile",
      "Company info",
      "Company documents",
      "Directors"
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<aside${ssrRenderAttrs(mergeProps({ class: "rounded-lg bg-white p-6 lg:p-10" }, _attrs))}><ul><!--[-->`);
      ssrRenderList(navigation, (n, i) => {
        _push(`<li class="py-2"><div class="${ssrRenderClass([__props.active >= i + 1 ? "" : "opacity-50", "flex gap-x-4 items-center"])}"><span class="${ssrRenderClass([
          __props.active >= i + 1 ? "bg-matta-black ring-2 ring-matta-black text-white" : "ring-1 ring-gray-300",
          "rounded-full text-xs w-6 h-6 flex items-center justify-center leading-[normal]"
        ])}">${ssrInterpolate(i + 1)}</span><span class="leading-[normal]">${ssrInterpolate(n)}</span></div></li>`);
      });
      _push(`<!--]--></ul></aside>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/onboarding/company/SideBar.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "Profile",
  __ssrInlineRender: true,
  setup(__props) {
    useAuthStore();
    useStore();
    const validPhoneLength = (value) => form.code === "+234" ? value.length > 9 && value.length < 12 : true;
    const mystates = computed(() => {
      return states.value.map((item) => {
        return {
          id: item.code,
          name: item.name,
          value: item.name
        };
      });
    });
    function getCountry(data) {
      form.country = data.value;
    }
    function getState(data) {
      form.city = data.value;
    }
    const allcountries = computed(() => {
      return CountryList.map((item) => {
        return {
          id: "",
          name: `${item.name}`,
          value: item.name
        };
      });
    });
    useRouter();
    const open = ref(false);
    const img = ref("");
    const image = ref(null);
    const coordinate = ref(null);
    const cropper = ref(null);
    const zones = moment.tz.names();
    const form = reactive({
      code: "+234",
      photo: "",
      firstName: "",
      lastName: "",
      country: "",
      city: "",
      email: "",
      phone: "",
      timeZone: ""
    });
    const isLoading = ref(false);
    const abbrs = {
      EST: "Eastern Standard Time",
      EDT: "Eastern Daylight Time",
      CST: "Central Standard Time",
      CDT: "Central Daylight Time",
      MST: "Mountain Standard Time",
      MDT: "Mountain Daylight Time",
      PST: "Pacific Standard Time",
      PDT: "Pacific Daylight Time",
      GMT: "Greenwich Mean Time",
      CAT: "Central Africa Time",
      WAT: "Western Africa Time",
      EAT: "Eastern Africa Time",
      EET: "Eastern European Time"
    };
    moment.fn.zoneName = function() {
      var abbr = this.zoneAbbr();
      return abbrs[abbr] || abbr;
    };
    const states = computed(() => {
      if (!form.country)
        return [];
      return countries.find(
        (item) => item.name.toLowerCase() == form.country.toLowerCase()
      ).states;
    });
    function crop() {
      const { coordinates, canvas } = cropper.value.getResult();
      coordinate.value = coordinates;
      image.value = canvas.toDataURL();
      open.value = false;
      form.photo = canvas.toDataURL().replace("data:", "").replace(/^.+,/, "");
      uploadfile({
        base64: canvas.toDataURL().replace("data:", "").replace(/^.+,/, "")
      });
    }
    const rules = {
      email: {
        required,
        email: helpers.withMessage("Email is invalid", email),
        maxLength: maxLength(50)
      },
      firstName: {
        required,
        maxLength: maxLength(50)
      },
      lastName: {
        required,
        maxLength: maxLength(50)
      },
      country: {
        required,
        maxLength: maxLength(50)
      },
      city: {
        required,
        maxLength: maxLength(50)
      },
      phone: {
        numeric,
        required,
        validPhoneLength: helpers.withMessage(
          "Phone number must be between 10 0r 11 digits",
          validPhoneLength
        )
      },
      timeZone: {
        required,
        maxLength: maxLength(250)
      },
      photo: {}
    };
    ref(false);
    const v$ = useVuelidate(rules, form);
    computed(() => {
      return `${form.firstName} ${form.lastName}`;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtImg = __nuxt_component_1$1;
      const _component_FormsSelectComponent = __nuxt_component_2;
      const _component_FormsPhoneCodes = PhoneCodes;
      _push(`<!--[--><div class="gap-y-2 flex flex-col flex-1 p-6 lg:p-10 justify-center bg-white rounded-lg" data-v-e7a99423><div class="mb-5 text-center text-[13px]" data-v-e7a99423><p data-v-e7a99423>STEP 1/4</p></div><div class="md:max-w-[656px] mx-auto" data-v-e7a99423><div class="col-span-2" data-v-e7a99423><div class="mb-8" data-v-e7a99423><h1 class="text-3xl lg:text-[48px] leading-[56px] text-matta-black col-span-1 font-medium text-center mb-1 lg:mb-8" data-v-e7a99423> Set your personal profile </h1><p class="text-sm lg:text-base text-center" data-v-e7a99423> Recommended filling out your profile </p></div><div class="flex flex-col lg:flex-row lg:justify-between lg:items-center mb-10 gap-y-8" data-v-e7a99423><div class="flex items-center" data-v-e7a99423><span data-v-e7a99423>`);
      if (!image.value) {
        _push(`<span class="h-16 lg:h-24 w-16 lg:w-24 rounded-full flex items-center text-xs bg-[#F1F3F5] mr-4 justify-center" data-v-e7a99423>Photo</span>`);
      } else {
        _push(ssrRenderComponent(_component_NuxtImg, {
          src: image.value,
          class: "h-16 lg:h-24 w-16 lg:w-24 rounded-full flex items-center bg-[#F1F3F5] mr-4 justify-center"
        }, null, _parent));
      }
      _push(`</span><span data-v-e7a99423><p class="text-xs lg:text-sm font-medium mb-1" data-v-e7a99423>Your photo</p><p class="text-xs lg:text-sm font-normal" data-v-e7a99423> Recommended 200x200 px </p><!--[-->`);
      ssrRenderList(unref(v$).photo.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-e7a99423><div class="error-msg text-error text-xs font-semibold" data-v-e7a99423>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></span></div><div class="flex items-center justify-between gap-x-3" data-v-e7a99423><label for="upload" data-v-e7a99423><span class="text-primary border border-primary- rounded-lg px-4 lg:px-6 py-2 lg:py-3 text-xs lg:text-sm cursor-pointer" data-v-e7a99423> Upload photo </span><input type="file" accept="image/*" id="upload" class="hidden" data-v-e7a99423></label>`);
      if (image.value) {
        _push(`<i class="uil uil-times ring-1 flex items-center justify-center ring-[#F1F3F5] text-base lg:text-lg text-matta-black rounded-full w-[36px] lg:w-[46px] h-[36px] lg:h-[46px]" data-v-e7a99423></i>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><form data-v-e7a99423><div data-v-e7a99423><div class="grid grid-cols-1 lg:grid-cols-2 gap-4" data-v-e7a99423><div class="mb-6" data-v-e7a99423><label class="mb-2 font-normal text-xs block" data-v-e7a99423>First name <span class="text-red-500 pl-[.02rem]" data-v-e7a99423>*</span></label><input${ssrRenderAttr("value", unref(v$).firstName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).firstName.$error }, "rounded-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" data-v-e7a99423><!--[-->`);
      ssrRenderList(unref(v$).firstName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-e7a99423><div class="error-msg text-error text-xs font-semibold" data-v-e7a99423>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6" data-v-e7a99423><label class="mb-2 font-normal text-xs block" data-v-e7a99423>Last name <span class="text-red-500 pl-[.02rem]" data-v-e7a99423>*</span></label><input${ssrRenderAttr("value", unref(v$).lastName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).lastName.$error }, "rounded-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" data-v-e7a99423><!--[-->`);
      ssrRenderList(unref(v$).lastName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-e7a99423><div class="error-msg text-error text-xs font-semibold" data-v-e7a99423>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="grid grid-cols-1 lg:grid-cols-2 gap-4" data-v-e7a99423><div class="mb-6" data-v-e7a99423><label class="mb-2 font-normal text-xs block" data-v-e7a99423>Country <span class="text-red-500 pl-[.02rem]" data-v-e7a99423>*</span></label><div class="relative" data-v-e7a99423><div class="flex relative items-center w-full" data-v-e7a99423>`);
      _push(ssrRenderComponent(_component_FormsSelectComponent, {
        options: allcountries.value,
        showSearch: true,
        value: form.country,
        onOnGetData: getCountry,
        containerStyle: "w-full",
        classStyles: `${unref(v$).country.$error && "border-red-500"} rounded-lg appearance-none px-[14px] py-[10px] h-11 text-sm border w-full !bg-[#F1F3F5] placeholder:text-[#B6B7B9] focus:outline-matta-black/20`
      }, null, _parent));
      _push(`</div><!--[-->`);
      ssrRenderList(unref(v$).country.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-e7a99423><div class="error-msg text-error text-xs font-semibold" data-v-e7a99423>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="mb-6" data-v-e7a99423><label class="mb-2 font-normal text-xs block" data-v-e7a99423>State <span class="text-red-500 pl-[.02rem]" data-v-e7a99423>*</span></label>`);
      _push(ssrRenderComponent(_component_FormsSelectComponent, {
        options: mystates.value,
        showSearch: true,
        value: form.city,
        onOnGetData: getState,
        containerStyle: "w-full",
        classStyles: `${unref(v$).city.$error && "border-red-500"} rounded-lg appearance-none px-[14px] py-[10px] h-11 text-sm border w-full !bg-[#F1F3F5] placeholder:text-[#B6B7B9] focus:outline-matta-black/20`
      }, null, _parent));
      _push(`<!--[-->`);
      ssrRenderList(unref(v$).city.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-e7a99423><div class="error-msg text-error text-xs font-semibold" data-v-e7a99423>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="grid grid-cols-1 lg:grid-cols-2 gap-4" data-v-e7a99423><div class="mb-6" data-v-e7a99423><label class="mb-2 font-normal text-xs block" data-v-e7a99423>Phone number <span class="text-red-500 pl-[.02rem]" data-v-e7a99423>*</span></label><div class="flex relative rounded-lg h-11" data-v-e7a99423>`);
      _push(ssrRenderComponent(_component_FormsPhoneCodes, {
        modelValue: form.code,
        "onUpdate:modelValue": ($event) => form.code = $event
      }, null, _parent));
      _push(`<input class="${ssrRenderClass([{ "border-red-500": unref(v$).phone.$error }, "flex-1 rounded-r-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}"${ssrRenderAttr("value", unref(v$).phone.$model)} autocomplete="off" autofocus="on" placeholder="08160723884" type="tel" data-v-e7a99423></div><!--[-->`);
      ssrRenderList(unref(v$).phone.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-e7a99423><div class="error-msg text-error text-xs font-semibold" data-v-e7a99423>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6" data-v-e7a99423><label class="mb-2 font-normal text-xs block" data-v-e7a99423>E-mail <span class="text-red-500 pl-[.02rem]" data-v-e7a99423>*</span></label><div class="flex relative items-center" data-v-e7a99423><input class="${ssrRenderClass([{ "border-red-500": unref(v$).email.$error }, "rounded-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] text-matta-black/60 focus:outline-matta-black/20"])}"${ssrRenderAttr("value", form.email)} autocomplete="off" autofocus="on" disabled data-v-e7a99423><i class="uil uil-lock absolute right-4 text-gray-600" data-v-e7a99423></i></div><!--[-->`);
      ssrRenderList(unref(v$).email.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-e7a99423><div class="error-msg text-error text-xs font-semibold" data-v-e7a99423>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div></div><hr class="my-8" data-v-e7a99423><legend class="font-medium mb-4" data-v-e7a99423> Timezone <span class="text-red-500 pl-[.02rem]" data-v-e7a99423>*</span></legend><div class="mb-10" data-v-e7a99423><div class="flex relative items-center w-full" data-v-e7a99423><select class="${ssrRenderClass([{ "border-red-500": unref(v$).timeZone.$error }, "appearance-none rounded-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9]"])}" data-v-e7a99423><!--[-->`);
      ssrRenderList(unref(zones), (z) => {
        _push(`<option data-v-e7a99423> (${ssrInterpolate(unref(moment).tz(/* @__PURE__ */ new Date(), z).format("z - Z"))}) ${ssrInterpolate(unref(moment).tz(/* @__PURE__ */ new Date(), z).format("zz"))} ${ssrInterpolate(z)}</option>`);
      });
      _push(`<!--]--></select><i class="uil uil-sort absolute right-3 pointer-events-none" data-v-e7a99423></i></div><!--[-->`);
      ssrRenderList(unref(v$).timeZone.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-e7a99423><div class="error-msg text-error text-xs font-semibold" data-v-e7a99423>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="flex justify-center gap-x-4 items-center mt-16 w-full" data-v-e7a99423><span data-v-e7a99423></span><button${ssrIncludeBooleanAttr(unref(v$).$silentErrors.length || isLoading.value) ? " disabled" : ""} class="${ssrRenderClass([{
        "opacity-60 cursor-not-allowed": unref(v$).$silentErrors.length
      }, "appearance-none leading-none px-20 py-4 grid-cols-1 w-1/2 lg:w-auto lg:grid-cols-2 gap-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase"])}" data-v-e7a99423><i class="fa fa-spinner fa-spin" style="${ssrRenderStyle(isLoading.value ? null : { display: "none" })}" aria-hidden="true" data-v-e7a99423></i><span style="${ssrRenderStyle(!isLoading.value ? null : { display: "none" })}" data-v-e7a99423>Next</span></button></div></form></div></div></div><div data-v-e7a99423>`);
      _push(ssrRenderComponent(unref(TransitionRoot), {
        as: "template",
        show: open.value
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Dialog), {
              as: "div",
              class: "relative z-10",
              onClose: ($event) => open.value = false
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" data-v-e7a99423${_scopeId3}></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="fixed z-10 inset-0 overflow-y-auto" data-v-e7a99423${_scopeId2}><div class="flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0" data-v-e7a99423${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                    "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                    "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(DialogPanel), { class: "relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" data-v-e7a99423${_scopeId4}><div class="flex justify-between mb-5 items-center" data-v-e7a99423${_scopeId4}><h4 class="font-medium text-matta-black text-xl" data-v-e7a99423${_scopeId4}> Customize photo </h4><i class="uil uil-times cursor-pointer text-lg" data-v-e7a99423${_scopeId4}></i></div>`);
                              _push5(ssrRenderComponent(unref(Cropper), {
                                ref_key: "cropper",
                                ref: cropper,
                                class: "cropper",
                                src: img.value,
                                "stencil-component": _ctx.ImageStencil,
                                "stencil-size": {
                                  width: 200,
                                  height: 200
                                }
                              }, null, _parent5, _scopeId4));
                              _push5(`<div class="flex justify-end gap-x-2 items-center mt-8" data-v-e7a99423${_scopeId4}><button class="appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase" data-v-e7a99423${_scopeId4}> Cancel </button><button class="appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase" data-v-e7a99423${_scopeId4}> Save </button></div></div>`);
                            } else {
                              return [
                                createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" }, [
                                  createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                                    createVNode("h4", { class: "font-medium text-matta-black text-xl" }, " Customize photo "),
                                    createVNode("i", {
                                      class: "uil uil-times cursor-pointer text-lg",
                                      onClick: ($event) => open.value = false
                                    }, null, 8, ["onClick"])
                                  ]),
                                  createVNode(unref(Cropper), {
                                    ref_key: "cropper",
                                    ref: cropper,
                                    class: "cropper",
                                    src: img.value,
                                    "stencil-component": _ctx.ImageStencil,
                                    "stencil-size": {
                                      width: 200,
                                      height: 200
                                    }
                                  }, null, 8, ["src", "stencil-component"]),
                                  createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                                    createVNode("button", {
                                      onClick: ($event) => open.value = false,
                                      class: "appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"
                                    }, " Cancel ", 8, ["onClick"]),
                                    createVNode("button", {
                                      onClick: crop,
                                      class: "appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase"
                                    }, " Save ")
                                  ])
                                ])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(DialogPanel), { class: "relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full" }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" }, [
                                createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                                  createVNode("h4", { class: "font-medium text-matta-black text-xl" }, " Customize photo "),
                                  createVNode("i", {
                                    class: "uil uil-times cursor-pointer text-lg",
                                    onClick: ($event) => open.value = false
                                  }, null, 8, ["onClick"])
                                ]),
                                createVNode(unref(Cropper), {
                                  ref_key: "cropper",
                                  ref: cropper,
                                  class: "cropper",
                                  src: img.value,
                                  "stencil-component": _ctx.ImageStencil,
                                  "stencil-size": {
                                    width: 200,
                                    height: 200
                                  }
                                }, null, 8, ["src", "stencil-component"]),
                                createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                                  createVNode("button", {
                                    onClick: ($event) => open.value = false,
                                    class: "appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"
                                  }, " Cancel ", 8, ["onClick"]),
                                  createVNode("button", {
                                    onClick: crop,
                                    class: "appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase"
                                  }, " Save ")
                                ])
                              ])
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode(unref(TransitionChild), {
                      as: "template",
                      enter: "ease-out duration-300",
                      "enter-from": "opacity-0",
                      "enter-to": "opacity-100",
                      leave: "ease-in duration-200",
                      "leave-from": "opacity-100",
                      "leave-to": "opacity-0"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                      ]),
                      _: 1
                    }),
                    createVNode("div", { class: "fixed z-10 inset-0 overflow-y-auto" }, [
                      createVNode("div", { class: "flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0" }, [
                        createVNode(unref(TransitionChild), {
                          as: "template",
                          enter: "ease-out duration-300",
                          "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                          "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                          leave: "ease-in duration-200",
                          "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                          "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(DialogPanel), { class: "relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full" }, {
                              default: withCtx(() => [
                                createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" }, [
                                  createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                                    createVNode("h4", { class: "font-medium text-matta-black text-xl" }, " Customize photo "),
                                    createVNode("i", {
                                      class: "uil uil-times cursor-pointer text-lg",
                                      onClick: ($event) => open.value = false
                                    }, null, 8, ["onClick"])
                                  ]),
                                  createVNode(unref(Cropper), {
                                    ref_key: "cropper",
                                    ref: cropper,
                                    class: "cropper",
                                    src: img.value,
                                    "stencil-component": _ctx.ImageStencil,
                                    "stencil-size": {
                                      width: 200,
                                      height: 200
                                    }
                                  }, null, 8, ["src", "stencil-component"]),
                                  createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                                    createVNode("button", {
                                      onClick: ($event) => open.value = false,
                                      class: "appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"
                                    }, " Cancel ", 8, ["onClick"]),
                                    createVNode("button", {
                                      onClick: crop,
                                      class: "appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase"
                                    }, " Save ")
                                  ])
                                ])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Dialog), {
                as: "div",
                class: "relative z-10",
                onClose: ($event) => open.value = false
              }, {
                default: withCtx(() => [
                  createVNode(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                    ]),
                    _: 1
                  }),
                  createVNode("div", { class: "fixed z-10 inset-0 overflow-y-auto" }, [
                    createVNode("div", { class: "flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0" }, [
                      createVNode(unref(TransitionChild), {
                        as: "template",
                        enter: "ease-out duration-300",
                        "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                        "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                        leave: "ease-in duration-200",
                        "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                        "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(DialogPanel), { class: "relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full" }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" }, [
                                createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                                  createVNode("h4", { class: "font-medium text-matta-black text-xl" }, " Customize photo "),
                                  createVNode("i", {
                                    class: "uil uil-times cursor-pointer text-lg",
                                    onClick: ($event) => open.value = false
                                  }, null, 8, ["onClick"])
                                ]),
                                createVNode(unref(Cropper), {
                                  ref_key: "cropper",
                                  ref: cropper,
                                  class: "cropper",
                                  src: img.value,
                                  "stencil-component": _ctx.ImageStencil,
                                  "stencil-size": {
                                    width: 200,
                                    height: 200
                                  }
                                }, null, 8, ["src", "stencil-component"]),
                                createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                                  createVNode("button", {
                                    onClick: ($event) => open.value = false,
                                    class: "appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"
                                  }, " Cancel ", 8, ["onClick"]),
                                  createVNode("button", {
                                    onClick: crop,
                                    class: "appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase"
                                  }, " Save ")
                                ])
                              ])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              }, 8, ["onClose"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/onboarding/company/Profile.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-e7a99423"]]);
const _sfc_main$1 = {
  __name: "CompanyAccount",
  __ssrInlineRender: true,
  setup(__props) {
    const active = ref(1);
    const route = useRoute();
    watch(route, () => {
      active.value = route.query.onboarding_stage;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_OnboardingLayoutTopBar = __nuxt_component_0$1;
      const _component_OnboardingCompanySideBar = __nuxt_component_1;
      const _component_OnboardingCompanyInfo = __nuxt_component_2$1;
      const _component_OnboardingCompanyDirectors = __nuxt_component_3;
      const _component_OnboardingCompanyProfile = __nuxt_component_4;
      const _component_OnboardingCompanyDocuments = __nuxt_component_5;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-[#E7EBEE] p-4 lg:p-6 flex flex-col gap-y-2 min-h-screen" }, _attrs))} data-v-0ea57b4a>`);
      _push(ssrRenderComponent(_component_OnboardingLayoutTopBar, { active: unref(active) }, null, _parent));
      _push(`<div class="gap-x-2 flex flex-1 justify-center" data-v-0ea57b4a><div class="w-[25%] rounded-lg hidden lg:block" data-v-0ea57b4a>`);
      _push(ssrRenderComponent(_component_OnboardingCompanySideBar, { active: unref(active) }, null, _parent));
      _push(`</div><div class="w-full lg:w-[75%] bg-white rounded-lg" data-v-0ea57b4a>`);
      if (unref(active) == 2) {
        _push(ssrRenderComponent(_component_OnboardingCompanyInfo, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(active) == 4) {
        _push(ssrRenderComponent(_component_OnboardingCompanyDirectors, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(active) == 1) {
        _push(ssrRenderComponent(_component_OnboardingCompanyProfile, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(active) == 3) {
        _push(ssrRenderComponent(_component_OnboardingCompanyDocuments, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/onboarding/CompanyAccount.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-0ea57b4a"]]);
const _sfc_main = {
  __name: "company",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_OnboardingCompanyAccount = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_OnboardingCompanyAccount, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/onboarding/company.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=company-uoKo7MGi.mjs.map
