import { _ as __nuxt_component_0 } from './nuxt-link-fc3HHrvA.mjs';
import { _ as __nuxt_component_1$1 } from './nuxt-img-qJohECzX.mjs';
import { useSSRContext, mergeProps, withCtx, createVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';

const _sfc_main = {
  __name: "Board",
  __ssrInlineRender: true,
  props: {
    url: {
      default: "https://res.cloudinary.com/arudovwen-me/image/upload/c_scale,h_238/f_webp/ctgfxohrfifietzzvhrh.jpg"
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_NuxtImg = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container px-0" }, _attrs))}><div data-aos="fade-up" data-aos-once="true" class="rounded-[10px]">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/market/products",
        class: "h-full block"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_NuxtImg, {
              crossorigin: "",
              src: __props.url,
              alt: "image",
              class: "w-full min-h-[100px] max-h-[211px] h-full object-cover rounded-[10px] bg-gray-300"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_NuxtImg, {
                crossorigin: "",
                src: __props.url,
                alt: "image",
                class: "w-full min-h-[100px] max-h-[211px] h-full object-cover rounded-[10px] bg-gray-300"
              }, null, 8, ["src"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/landing/Board.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main;

export { __nuxt_component_1 as _ };
//# sourceMappingURL=Board-3k2I8CZI.mjs.map
