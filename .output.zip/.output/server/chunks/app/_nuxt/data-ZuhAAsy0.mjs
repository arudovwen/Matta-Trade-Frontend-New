const navigations = [
  {
    name: "Markets",
    key: "markets",
    url: null
  },
  {
    name: "Applications",
    key: "applications",
    url: null
  },
  {
    name: "Finance",
    key: "finance",
    url: "/finance"
  }
];
const mobileMenu = [
  {
    name: "Profile",
    key: "profile",
    icon: "bxs:user",
    url: "/account/settings"
  },
  {
    name: "My orders",
    key: "my-orders",
    icon: "solar:box-bold",
    url: "/procurement/my-orders"
  },
  {
    name: "My requests",
    key: "my-requests",
    icon: "gridicons:cart",
    url: "/procurement/my-requests"
  },
  {
    name: "Shipping address",
    key: "shipping-address",
    icon: "fa6-solid:address-book",
    url: "/procurement/shipping-addresses"
  },
  {
    name: "Wallet",
    key: "wallet",
    icon: "ion:wallet",
    url: "/wallet/home"
  },
  {
    name: "Saved items",
    key: "saved-items",
    icon: "ri:heart-fill",
    url: "/account/saved-searches"
  },
  {
    name: "Storefront",
    key: "storefront",
    icon: "fa6-solid:store",
    url: "/overview"
  },
  {
    name: "Company settings",
    key: "company-setting",
    icon: "clarity:building-solid",
    url: "/company/settings"
  },
  {
    name: "Sign out",
    key: "sign-out",
    icon: "fa-solid:sign-out-alt",
    url: "#"
  }
];
const financeMenu = [
  {
    title: "Trade Finance",
    key: "trade-finance",
    url: "#"
  },
  {
    title: "Supply Finance",
    key: "supply-finance",
    url: "#"
  },
  {
    title: "Import Finance",
    key: "import-finance",
    url: "#"
  },
  {
    title: "Export Finance",
    key: "export-finance",
    url: "#"
  },
  {
    title: "Cross-Border Payments",
    key: "cross-border-payments",
    url: "#"
  }
];
const hotDeals = [
  {
    title: "Ammonia Liquor",
    company: "A Huber Company",
    img: "/images/1.png",
    oldprice: "3300",
    newprice: "2500",
    type: "sale",
    id: 1,
    category: "Adhesive"
  },
  {
    title: "Hydrogenated Castor Oil",
    company: "Bisley International LLC",
    img: "/images/2.png",
    oldprice: "3300",
    newprice: "2500",
    type: "sale",
    id: 1,
    category: "Adhesive"
  },
  {
    title: "Hydrotint Black Paste",
    company: "GCP Applied Technologies Inc",
    img: "/images/3.png",
    oldprice: "",
    newprice: "3800",
    type: "sale",
    id: 1,
    category: "Adhesive"
  },
  {
    title: "IPEA (N,N-Diisopropylethylamine)",
    company: "SASOL Chemicals",
    img: "/images/4.png",
    oldprice: "",
    newprice: "",
    type: "request"
  }
];

export { financeMenu as f, hotDeals as h, mobileMenu as m, navigations as n };
//# sourceMappingURL=data-ZuhAAsy0.mjs.map
