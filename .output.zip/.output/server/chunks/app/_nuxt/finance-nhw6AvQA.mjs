import { _ as __nuxt_component_1 } from './nuxt-img-qJohECzX.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { _ as __nuxt_component_7 } from './Call-PMNbQp7f.mjs';
import { mergeProps, unref, useSSRContext } from 'vue';
import { F as FinancesOptions } from './constants-7QnerJ-N.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './_plugin-vue_export-helper-yVxbj29m.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = {
  __name: "finance",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtImg = __nuxt_component_1;
      const _component_AppButton = __nuxt_component_4;
      const _component_LandingCall = __nuxt_component_7;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "" }, _attrs))}><header class="h-[672px] bg-gray-600 mb-[70px]">`);
      _push(ssrRenderComponent(_component_NuxtImg, {
        src: "/images/financebanner.png",
        class: "w-full h-full object-cover"
      }, null, _parent));
      _push(`</header><div class="container pb-20"><h1 class="text-center font-semibold text-4xl mb-5 text-[#101828]"> All-in-one finance for any business </h1><p class="text-center text-xl text-[#475467] mb-[60px] max-w-[768px] mx-auto"> Get a deposit account, credit card, and spend management software\u2014in one refreshingly easy solution. No fees or minimums. </p><div class="grid grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-[50px]"><!--[-->`);
      ssrRenderList("FinancesOptions" in _ctx ? _ctx.FinancesOptions : unref(FinancesOptions), (n) => {
        _push(`<article class=""><div class="h-[240px] text-left mb-5">`);
        _push(ssrRenderComponent(_component_NuxtImg, {
          src: n.img,
          class: "w-full h-full object-cover rounded-[10px]"
        }, null, _parent));
        _push(`</div><div class="text-left"><h2 class="mb-2 text-[#101828] text-2xl capitalize font-semibold">${ssrInterpolate(n.title)}</h2><p class="text-[#475467] text-base mb-5">${ssrInterpolate(n.text)}</p>`);
        _push(ssrRenderComponent(_component_AppButton, {
          link: n.url,
          text: "Get started",
          btnClass: "text-primary-500 !px-0 !py-0 font-semibold"
        }, null, _parent));
        _push(`</div></article>`);
      });
      _push(`<!--]--></div></div>`);
      _push(ssrRenderComponent(_component_LandingCall, null, null, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/finance.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=finance-nhw6AvQA.mjs.map
