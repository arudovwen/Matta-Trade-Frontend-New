import { useSSRContext, inject, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderClass, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "AppTab",
  __ssrInlineRender: true,
  props: ["tabs", "className", "count"],
  setup(__props) {
    const active = inject("active");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["flex gap-x-4 mb-8 w-full overflow-x-auto border-b border-[#EAECF0]", __props.className]
      }, _attrs))}><!--[-->`);
      ssrRenderList(__props.tabs, (tab) => {
        _push(`<button class="${ssrRenderClass(`capitalize text-sm font-semibold pb-3 border-b-2 px-1 flex items-center gap-x-1 ${unref(active) === tab.title ? "border-primary-500 text-primary-500" : "border-transparent text-matta-black"} `)}"><span>${ssrInterpolate(tab.title)}</span>`);
        if (__props.count[tab.key]) {
          _push(`<span class="text-xs h-6 w-6 rounded-full flex justify-center items-center border border-[#EAECF0] bg-[#F9FAFB] text-[#344054]">${ssrInterpolate(__props.count[tab.key])}</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</button>`);
      });
      _push(`<!--]--></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/AppTab.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main;

export { __nuxt_component_1 as _ };
//# sourceMappingURL=AppTab-6UxOW17N.mjs.map
