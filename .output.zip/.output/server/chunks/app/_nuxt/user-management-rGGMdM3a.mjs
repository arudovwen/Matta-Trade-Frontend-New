import { _ as __nuxt_component_0$1 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_1 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_2 } from './EmptyData-RrNjecQG.mjs';
import { _ as __nuxt_component_1$1 } from './AppLoader-SkdFRsgH.mjs';
import { _ as __nuxt_component_4 } from './Simple-GRXlMUar.mjs';
import { _ as __nuxt_component_0$2 } from './IndexModal-vEF7RYpX.mjs';
import { useSSRContext, inject, reactive, ref, mergeProps, unref, withCtx, openBlock, createBlock, toDisplayString, createVNode, createCommentVNode, Fragment, renderList, Transition, provide, watch, createTextVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate, ssrRenderClass, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from 'vue/server-renderer';
import { toast } from 'vue3-toastify';
import { y as useStore } from '../server.mjs';
import { Listbox, ListboxButton, ListboxOptions, ListboxOption, Menu, MenuButton, MenuItems } from '@headlessui/vue';
import { ChevronDownIcon, CheckIcon } from '@heroicons/vue/24/solid';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import { useRoute } from 'vue-router';
import { d as deleteInvite, a as deleteUser, i as inviteUsers, r as resendInvite, g as getInvites } from './userservices-KlieBUHg.mjs';
import debounce from 'lodash/debounce.js';
import './AppButton-rwP1M0KN.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '@iconify/vue';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$3 = {
  __name: "InviteUser",
  __ssrInlineRender: true,
  emits: ["toggleBar"],
  setup(__props, { emit: __emit }) {
    useStore();
    const roles = inject("roles");
    inject("updateData");
    const form = reactive({
      users: [
        {
          email: "",
          role: "CompanyAdmin"
        }
      ]
    });
    const isLoading = ref(false);
    inject("inviteUsers");
    inject("togglePopup");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "" }, _attrs))} data-v-cf1f7c95><div class="mb-8" data-v-cf1f7c95><h1 class="text-2xl text-matta-black col-span-1 font-medium text-left mb-8" data-v-cf1f7c95> Invite user </h1></div><form data-v-cf1f7c95><div data-v-cf1f7c95><div class="" data-v-cf1f7c95><div class="grid gap-y-3 mb-4" data-v-cf1f7c95><!--[-->`);
      ssrRenderList(form.users, (n, i) => {
        _push(`<div class="flex gap-x-2 relative items-center" data-v-cf1f7c95><input${ssrRenderAttr("value", n.email)} class="flex-1 rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" autofocus="on" type="email" placeholder="kate.minchenko@gmailcom" data-v-cf1f7c95>`);
        _push(ssrRenderComponent(unref(Listbox), {
          modelValue: n.role,
          "onUpdate:modelValue": ($event) => n.role = $event
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="relative" data-v-cf1f7c95${_scopeId}>`);
              _push2(ssrRenderComponent(unref(ListboxButton), { class: "relative cursor-default rounded-lg min-w-[160px] h-11 border border-[#D0D5DD] bg-[#F1F3F5] py-2 px-[15px] text-left sm:text-sm" }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    if (n.role) {
                      _push3(`<span class="block text-[#101828] text-sm" data-v-cf1f7c95${_scopeId2}>${ssrInterpolate(n.role == "CompanyAdmin" ? "Company admin" : n.role == "CompanyUser" ? "Company member" : "Buyer")}</span>`);
                    } else {
                      _push3(`<span class="block text-[#8F8C9A] text-sm" data-v-cf1f7c95${_scopeId2}> Select role </span>`);
                    }
                    _push3(`<span class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" data-v-cf1f7c95${_scopeId2}>`);
                    _push3(ssrRenderComponent(unref(ChevronDownIcon), {
                      class: "h-5 w-5 text-gray-400",
                      "aria-hidden": "true"
                    }, null, _parent3, _scopeId2));
                    _push3(`</span>`);
                  } else {
                    return [
                      n.role ? (openBlock(), createBlock("span", {
                        key: 0,
                        class: "block text-[#101828] text-sm"
                      }, toDisplayString(n.role == "CompanyAdmin" ? "Company admin" : n.role == "CompanyUser" ? "Company member" : "Buyer"), 1)) : (openBlock(), createBlock("span", {
                        key: 1,
                        class: "block text-[#8F8C9A] text-sm"
                      }, " Select role ")),
                      createVNode("span", { class: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" }, [
                        createVNode(unref(ChevronDownIcon), {
                          class: "h-5 w-5 text-gray-400",
                          "aria-hidden": "true"
                        })
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(unref(ListboxOptions), { class: "absolute mt-1 max-h-60 w-[200px] z-40 overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 outline-0 sm:text-sm" }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<!--[-->`);
                    ssrRenderList(unref(roles).filter((i2) => i2 !== "Buyer"), (option) => {
                      _push3(ssrRenderComponent(unref(ListboxOption), {
                        key: option,
                        value: option,
                        as: "template"
                      }, {
                        default: withCtx(({ active, selected }, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(`<li class="${ssrRenderClass([
                              active ? "bg-blue-50 text-primary" : "",
                              "relative cursor-default select-none py-2 pl-[15px] pr-4  mb-1 text-loft-black hover:bg-gray-50"
                            ])}" data-v-cf1f7c95${_scopeId3}><span class="${ssrRenderClass([
                              selected ? "font-medium" : "font-normal",
                              "block"
                            ])}" data-v-cf1f7c95${_scopeId3}>${ssrInterpolate(option == "CompanyAdmin" ? "Company admin" : option == "CompanyUser" ? "Company member" : "Buyer")}</span>`);
                            if (selected) {
                              _push4(`<span class="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-700" data-v-cf1f7c95${_scopeId3}>`);
                              _push4(ssrRenderComponent(unref(CheckIcon), {
                                class: "h-4 w-4 tet-primary",
                                "aria-hidden": "true"
                              }, null, _parent4, _scopeId3));
                              _push4(`</span>`);
                            } else {
                              _push4(`<!---->`);
                            }
                            _push4(`</li>`);
                          } else {
                            return [
                              createVNode("li", {
                                class: [
                                  active ? "bg-blue-50 text-primary" : "",
                                  "relative cursor-default select-none py-2 pl-[15px] pr-4  mb-1 text-loft-black hover:bg-gray-50"
                                ]
                              }, [
                                createVNode("span", {
                                  class: [
                                    selected ? "font-medium" : "font-normal",
                                    "block"
                                  ]
                                }, toDisplayString(option == "CompanyAdmin" ? "Company admin" : option == "CompanyUser" ? "Company member" : "Buyer"), 3),
                                selected ? (openBlock(), createBlock("span", {
                                  key: 0,
                                  class: "absolute inset-y-0 right-0 flex items-center pr-3 text-gray-700"
                                }, [
                                  createVNode(unref(CheckIcon), {
                                    class: "h-4 w-4 tet-primary",
                                    "aria-hidden": "true"
                                  })
                                ])) : createCommentVNode("", true)
                              ], 2)
                            ];
                          }
                        }),
                        _: 2
                      }, _parent3, _scopeId2));
                    });
                    _push3(`<!--]-->`);
                  } else {
                    return [
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(roles).filter((i2) => i2 !== "Buyer"), (option) => {
                        return openBlock(), createBlock(unref(ListboxOption), {
                          key: option,
                          value: option,
                          as: "template"
                        }, {
                          default: withCtx(({ active, selected }) => [
                            createVNode("li", {
                              class: [
                                active ? "bg-blue-50 text-primary" : "",
                                "relative cursor-default select-none py-2 pl-[15px] pr-4  mb-1 text-loft-black hover:bg-gray-50"
                              ]
                            }, [
                              createVNode("span", {
                                class: [
                                  selected ? "font-medium" : "font-normal",
                                  "block"
                                ]
                              }, toDisplayString(option == "CompanyAdmin" ? "Company admin" : option == "CompanyUser" ? "Company member" : "Buyer"), 3),
                              selected ? (openBlock(), createBlock("span", {
                                key: 0,
                                class: "absolute inset-y-0 right-0 flex items-center pr-3 text-gray-700"
                              }, [
                                createVNode(unref(CheckIcon), {
                                  class: "h-4 w-4 tet-primary",
                                  "aria-hidden": "true"
                                })
                              ])) : createCommentVNode("", true)
                            ], 2)
                          ]),
                          _: 2
                        }, 1032, ["value"]);
                      }), 128))
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "relative" }, [
                  createVNode(unref(ListboxButton), { class: "relative cursor-default rounded-lg min-w-[160px] h-11 border border-[#D0D5DD] bg-[#F1F3F5] py-2 px-[15px] text-left sm:text-sm" }, {
                    default: withCtx(() => [
                      n.role ? (openBlock(), createBlock("span", {
                        key: 0,
                        class: "block text-[#101828] text-sm"
                      }, toDisplayString(n.role == "CompanyAdmin" ? "Company admin" : n.role == "CompanyUser" ? "Company member" : "Buyer"), 1)) : (openBlock(), createBlock("span", {
                        key: 1,
                        class: "block text-[#8F8C9A] text-sm"
                      }, " Select role ")),
                      createVNode("span", { class: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" }, [
                        createVNode(unref(ChevronDownIcon), {
                          class: "h-5 w-5 text-gray-400",
                          "aria-hidden": "true"
                        })
                      ])
                    ]),
                    _: 2
                  }, 1024),
                  createVNode(Transition, {
                    "leave-active-class": "transition duration-100 ease-in",
                    "leave-from-class": "opacity-100",
                    "leave-to-class": "opacity-0"
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(ListboxOptions), { class: "absolute mt-1 max-h-60 w-[200px] z-40 overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 outline-0 sm:text-sm" }, {
                        default: withCtx(() => [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(roles).filter((i2) => i2 !== "Buyer"), (option) => {
                            return openBlock(), createBlock(unref(ListboxOption), {
                              key: option,
                              value: option,
                              as: "template"
                            }, {
                              default: withCtx(({ active, selected }) => [
                                createVNode("li", {
                                  class: [
                                    active ? "bg-blue-50 text-primary" : "",
                                    "relative cursor-default select-none py-2 pl-[15px] pr-4  mb-1 text-loft-black hover:bg-gray-50"
                                  ]
                                }, [
                                  createVNode("span", {
                                    class: [
                                      selected ? "font-medium" : "font-normal",
                                      "block"
                                    ]
                                  }, toDisplayString(option == "CompanyAdmin" ? "Company admin" : option == "CompanyUser" ? "Company member" : "Buyer"), 3),
                                  selected ? (openBlock(), createBlock("span", {
                                    key: 0,
                                    class: "absolute inset-y-0 right-0 flex items-center pr-3 text-gray-700"
                                  }, [
                                    createVNode(unref(CheckIcon), {
                                      class: "h-4 w-4 tet-primary",
                                      "aria-hidden": "true"
                                    })
                                  ])) : createCommentVNode("", true)
                                ], 2)
                              ]),
                              _: 2
                            }, 1032, ["value"]);
                          }), 128))
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 2
                  }, 1024)
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<i class="uil uil-times text-xl hover:ring w-8 h-8 flex items-center justify-center hover:bg-[#F1F3F5] hover:ring-[#F1F3F5] rounded-full cursor-pointer" data-v-cf1f7c95></i></div>`);
      });
      _push(`<!--]--></div><button class="text-xs text-primary-500" type="button" data-v-cf1f7c95><i class="uil uil-plus" data-v-cf1f7c95></i> Add new member </button></div><div class="flex justify-end gap-x-4 items-center mt-12" data-v-cf1f7c95><button type="button" class="appearance-none leading-none px-10 py-4 rounded-lg text-matta-black bg-[#F1F3F5] hover:bg-gray-100 text-[13px] uppercase" data-v-cf1f7c95> Back </button><button type="submit"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} class="${ssrRenderClass([isLoading.value && "opacity-70", "appearance-none leading-none px-10 py-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase"])}" data-v-cf1f7c95> Send invite `);
      if (isLoading.value) {
        _push(`<i class="fa fa-spinner fa-spin text-white" aria-hidden="true" data-v-cf1f7c95></i>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</button></div></div></form></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/management/InviteUser.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-cf1f7c95"]]);
const _sfc_main$2 = {
  __name: "RemoveUser",
  __ssrInlineRender: true,
  setup(__props) {
    inject("togglePopup");
    inject("removeUser");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><h3 class="font-medium text-2xl mb-6">Remove user</h3><p class="mb-12">Are you sure you want to remove this user?</p><div class="flex items-center gap-x-4"><button type="button" class="text-[13px] uppercase text-matta-black px-2 py-2 hover:text-primary/80 w-full"> cancel </button><button type="button" class="border text-[13px] border-primary- uppercase w-full text-white bg-primary-500 rounded-lg px-2 py-3 hover:bg-primary/80"> remove </button></div><!--]-->`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/management/RemoveUser.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_7 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "UserManagement",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    ref([]);
    const showing = ref("");
    const isOpen = ref(false);
    const roles = ref(null);
    const isPageLoading = ref(true);
    const user = ref(null);
    function removeUser() {
      if (user.value.invitationStatusText == "Verified") {
        deleteUser({ email: user.value.email }).then(() => {
          updateData();
          togglePopup();
        });
      } else {
        deleteInvite({ invitationId: user.value.id }).then(() => {
          updateData();
          togglePopup();
        });
      }
    }
    function resendinvite(id) {
      resendInvite({ invitationId: id }).then((res) => {
        if (res.status === 200) {
          toast.info("Invite sent!");
        }
      }).catch((error) => {
        var _a, _b;
        toast.info((_b = (_a = error == null ? void 0 : error.response) == null ? void 0 : _a.data) == null ? void 0 : _b.Message);
      });
    }
    function openmodal(val, userdata = null) {
      showing.value = val;
      isOpen.value = true;
      user.value = userdata;
    }
    function togglePopup() {
      isOpen.value = !isOpen.value;
    }
    provide("togglePopup", togglePopup);
    provide("removeUser", removeUser);
    provide("openmodal", openmodal);
    useRoute();
    const isEmpty = ref(false);
    const queryParams = reactive({
      Status: "",
      Role: "",
      PageSize: 10,
      PageNumber: 1,
      pagecount: 0,
      totalCount: 0,
      Search: ""
    });
    function getAllInvites() {
      getInvites(queryParams).then((res) => {
        tdata.value = res.data.data;
        queryParams.totalCount = res.data.totalCount;
        queryParams.pagecount = res.data.data.length;
        isPageLoading.value = false;
        !res.data.data.length ? isEmpty.value = true : isEmpty.value = false;
      }).catch(() => {
        isPageLoading.value = false;
      });
    }
    function updateData() {
      getAllInvites();
    }
    watch(
      () => [queryParams.PageNumber],
      () => {
        getAllInvites();
      }
    );
    debounce(() => {
      getAllInvites();
    }, 1500);
    const theads = ["name", "email address", "role", "status", ""];
    const tdata = ref([]);
    provide("deleteInvite", deleteInvite);
    provide("deleteUser", deleteUser);
    provide("inviteUsers", inviteUsers);
    provide("roles", roles);
    provide("updateData", updateData);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderComponent = __nuxt_component_0$1;
      const _component_AppIcon = __nuxt_component_1;
      const _component_EmptyData = __nuxt_component_2;
      const _component_AppLoader = __nuxt_component_1$1;
      const _component_PaginationSimple = __nuxt_component_4;
      const _component_IndexModal = __nuxt_component_0$2;
      const _component_SupplierManagementInviteUser = __nuxt_component_6;
      const _component_SupplierManagementRemoveUser = __nuxt_component_7;
      _push(`<!--[--><div class="flex flex-col bg-white rounded-[10px] border border-[#F4F7FE]" data-v-751592e4>`);
      _push(ssrRenderComponent(_component_HeaderComponent, {
        title: "User management",
        subtext: "Invite and assign roles to your company users",
        btnText: "Add users",
        btnIcon: "humbleicons:plus",
        onOnClick: ($event) => openmodal("method"),
        className: "!border-[#EAECF0]"
      }, null, _parent));
      _push(`<div class="rounded-lg bg-white pt-4" data-v-751592e4><div class="flex justify-between items-center mb-4 px-6" data-v-751592e4><div class="flex gap-x-4" data-v-751592e4><div class="relative flex items-center" data-v-751592e4><span class="absolute left-4 peer-focus:right-3 pointer-events-none text-[#667085]" data-v-751592e4><i class="uil uil-search" data-v-751592e4></i></span><input${ssrRenderAttr("value", unref(queryParams).Search)} placeholder="Search" class="border border-[#D0D5DD] focus:pr-3 pl-10 rounded-lg w-[280px] focus:outline-none py-[10px] transition ease-in-out duration-300" type="search" data-v-751592e4></div><div class="flex relative items-center" data-v-751592e4><select class="appearance-none border border-[#D0D5DD] rounded-lg py-[10px] px-[14px] w-[180px] focus:outline-none" data-v-751592e4><option value="" data-v-751592e4${ssrIncludeBooleanAttr(Array.isArray(unref(queryParams).Role) ? ssrLooseContain(unref(queryParams).Role, "") : ssrLooseEqual(unref(queryParams).Role, "")) ? " selected" : ""}>Role</option><!--[-->`);
      ssrRenderList(unref(roles), (role) => {
        _push(`<option${ssrRenderAttr("value", role)} data-v-751592e4>${ssrInterpolate(role == "CompanyAdmin" ? "Company admin" : role == "CompanyUser" ? "Company user" : "Buyer")}</option>`);
      });
      _push(`<!--]--></select><i class="uil uil-angle-down absolute right-2 pointer-events-none" data-v-751592e4></i></div><div class="flex relative items-center" data-v-751592e4><select class="appearance-none border border-[#D0D5DD] rounded-lg py-[10px] px-[14px] w-[180px] focus:outline-none" data-v-751592e4><option value="" data-v-751592e4${ssrIncludeBooleanAttr(Array.isArray(unref(queryParams).Status) ? ssrLooseContain(unref(queryParams).Status, "") : ssrLooseEqual(unref(queryParams).Status, "")) ? " selected" : ""}>Status</option><option value="0" data-v-751592e4${ssrIncludeBooleanAttr(Array.isArray(unref(queryParams).Status) ? ssrLooseContain(unref(queryParams).Status, "0") : ssrLooseEqual(unref(queryParams).Status, "0")) ? " selected" : ""}>Unverified</option><option value="2" data-v-751592e4${ssrIncludeBooleanAttr(Array.isArray(unref(queryParams).Status) ? ssrLooseContain(unref(queryParams).Status, "2") : ssrLooseEqual(unref(queryParams).Status, "2")) ? " selected" : ""}>Verified</option></select><i class="uil uil-angle-down absolute right-2 pointer-events-none" data-v-751592e4></i></div></div></div>`);
      if (!unref(isPageLoading)) {
        _push(`<div data-v-751592e4>`);
        if (!unref(isEmpty)) {
          _push(`<div class="max-w-[80vw]" data-v-751592e4><table class="w-full" data-v-751592e4><thead data-v-751592e4><tr data-v-751592e4><!--[-->`);
          ssrRenderList(theads, (item) => {
            _push(`<th class="capitalize text-[#475467] text-sm text-left font-medium border-b border-t py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-751592e4>${ssrInterpolate(item)}</th>`);
          });
          _push(`<!--]--></tr></thead><tbody data-v-751592e4><!--[-->`);
          ssrRenderList(unref(tdata), (item) => {
            _push(`<tr data-v-751592e4><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-751592e4>${ssrInterpolate(item.fullName)}</td><td class="text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-751592e4>${ssrInterpolate(item.email)}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-751592e4><select${ssrRenderAttr("value", item.role)} class="outline-0 capitalize"${ssrIncludeBooleanAttr(!item.status) ? " disabled" : ""} data-v-751592e4><!--[-->`);
            ssrRenderList(unref(roles), (role) => {
              _push(`<option${ssrRenderAttr("value", role)} data-v-751592e4>${ssrInterpolate(role == "CompanyAdmin" ? "Company admin" : role == "CompanyUser" ? "Company user" : "Buyer")}</option>`);
            });
            _push(`<!--]--></select></td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-751592e4>`);
            if (item.invitationStatusText == "Expired") {
              _push(`<span class="px-2 py-1 text-xs rounded-full text-[#B42318] bg-[#FEF3F2] flex gap-x-1 items-center max-w-max border border-[#FECDCA]" data-v-751592e4>`);
              _push(ssrRenderComponent(_component_AppIcon, {
                icon: "octicon:dot-fill-24",
                iconClass: "text-[#B42318]"
              }, null, _parent));
              _push(` Suspended</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.invitationStatusText == "Invited") {
              _push(`<span class="px-2 py-1 text-xs rounded-full text-[#B54708] bg-[#FFFAEB] flex gap-x-1 items-center max-w-max border border-[#FEDF89]" data-v-751592e4>`);
              _push(ssrRenderComponent(_component_AppIcon, {
                icon: "octicon:dot-fill-24",
                iconClass: "text-[#B54708]"
              }, null, _parent));
              _push(` Pending</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.invitationStatusText == "Verified") {
              _push(`<span class="px-2 py-1 text-xs rounded-full text-[#067647] bg-[#ECFDF3] flex gap-x-1 items-center max-w-max border border-[#ABEFC6]" data-v-751592e4>`);
              _push(ssrRenderComponent(_component_AppIcon, {
                icon: "octicon:dot-fill-24",
                iconClass: "text-[#067647]"
              }, null, _parent));
              _push(` Active</span>`);
            } else {
              _push(`<!---->`);
            }
            _push(`</td><td class="uppercase text-matta-black text-sm font-normal border-b py-6 px-3 border-[#E7EBEE]" data-v-751592e4>`);
            _push(ssrRenderComponent(unref(Menu), {
              class: "relative",
              as: "div"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(ssrRenderComponent(unref(MenuButton), { class: "outline-none" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<i class="uil uil-ellipsis-v" data-v-751592e4${_scopeId2}></i>`);
                      } else {
                        return [
                          createVNode("i", { class: "uil uil-ellipsis-v" })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                  _push2(ssrRenderComponent(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[140px] rounded-xl overflow-hidden" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<div class="py-2 px-4 hover:bg-gray-50 text-matta-black text-sm whitespace-nowrap capitalize cursor-pointer" data-v-751592e4${_scopeId2}><i class="uil uil-trash-alt mr-1" data-v-751592e4${_scopeId2}></i> Remove </div>`);
                        if (item.invitationStatusText !== "Verified") {
                          _push3(`<div class="py-2 px-4 hover:bg-gray-50 text-matta-black text-sm whitespace-nowrap capitalize cursor-pointer" data-v-751592e4${_scopeId2}><i class="uil uil-envelope-redo mr-1" data-v-751592e4${_scopeId2}></i> Resend invite </div>`);
                        } else {
                          _push3(`<!---->`);
                        }
                      } else {
                        return [
                          createVNode("div", {
                            class: "py-2 px-4 hover:bg-gray-50 text-matta-black text-sm whitespace-nowrap capitalize cursor-pointer",
                            onClick: ($event) => openmodal("remove", item)
                          }, [
                            createVNode("i", { class: "uil uil-trash-alt mr-1" }),
                            createTextVNode(" Remove ")
                          ], 8, ["onClick"]),
                          item.invitationStatusText !== "Verified" ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "py-2 px-4 hover:bg-gray-50 text-matta-black text-sm whitespace-nowrap capitalize cursor-pointer",
                            onClick: ($event) => resendinvite(item.id)
                          }, [
                            createVNode("i", { class: "uil uil-envelope-redo mr-1" }),
                            createTextVNode(" Resend invite ")
                          ], 8, ["onClick"])) : createCommentVNode("", true)
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                } else {
                  return [
                    createVNode(unref(MenuButton), { class: "outline-none" }, {
                      default: withCtx(() => [
                        createVNode("i", { class: "uil uil-ellipsis-v" })
                      ]),
                      _: 1
                    }),
                    createVNode(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[140px] rounded-xl overflow-hidden" }, {
                      default: withCtx(() => [
                        createVNode("div", {
                          class: "py-2 px-4 hover:bg-gray-50 text-matta-black text-sm whitespace-nowrap capitalize cursor-pointer",
                          onClick: ($event) => openmodal("remove", item)
                        }, [
                          createVNode("i", { class: "uil uil-trash-alt mr-1" }),
                          createTextVNode(" Remove ")
                        ], 8, ["onClick"]),
                        item.invitationStatusText !== "Verified" ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "py-2 px-4 hover:bg-gray-50 text-matta-black text-sm whitespace-nowrap capitalize cursor-pointer",
                          onClick: ($event) => resendinvite(item.id)
                        }, [
                          createVNode("i", { class: "uil uil-envelope-redo mr-1" }),
                          createTextVNode(" Resend invite ")
                        ], 8, ["onClick"])) : createCommentVNode("", true)
                      ]),
                      _: 2
                    }, 1024)
                  ];
                }
              }),
              _: 2
            }, _parent));
            _push(`</td></tr>`);
          });
          _push(`<!--]--></tbody></table></div>`);
        } else {
          _push(ssrRenderComponent(_component_EmptyData, {
            onBtnFunction: ($event) => openmodal("method"),
            btnText: "New User",
            title: "No users found",
            subtext: "Your search \u201CStripe\u201D did not match any vendors. Please try again or create add a new vendor.",
            type: "user",
            btnIcon: "humbleicons:plus"
          }, null, _parent));
        }
        _push(`</div>`);
      } else {
        _push(`<div class="text-center p-6 lg:p-8 my-24" data-v-751592e4>`);
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
        _push(`</div>`);
      }
      _push(`</div><div class="px-5 py-4" data-v-751592e4>`);
      _push(ssrRenderComponent(_component_PaginationSimple, {
        total: unref(queryParams).totalCount,
        current: unref(queryParams).PageNumber,
        "per-page": unref(queryParams).PageSize,
        pageRange: 5,
        onPageChanged: ($event) => unref(queryParams).PageNumber = $event
      }, null, _parent));
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_IndexModal, {
        isOpen: unref(isOpen),
        onTogglePopup: ($event) => isOpen.value = false
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-white rounded-lg p-6 lg:p-8 relative w-[550px]" data-v-751592e4${_scopeId}><span class="hover:bg-gray-50 rounded-full h-6 w-6 flex items-center justify-center absolute top-4 right-4" data-v-751592e4${_scopeId}>`);
            _push2(ssrRenderComponent(_component_AppIcon, {
              icon: "heroicons-solid:x",
              class: "w-4 h-4"
            }, null, _parent2, _scopeId));
            _push2(`</span>`);
            if (unref(showing) === "method") {
              _push2(ssrRenderComponent(_component_SupplierManagementInviteUser, null, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (unref(showing) === "remove") {
              _push2(ssrRenderComponent(_component_SupplierManagementRemoveUser, null, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "bg-white rounded-lg p-6 lg:p-8 relative w-[550px]" }, [
                createVNode("span", {
                  onClick: ($event) => isOpen.value = false,
                  class: "hover:bg-gray-50 rounded-full h-6 w-6 flex items-center justify-center absolute top-4 right-4"
                }, [
                  createVNode(_component_AppIcon, {
                    icon: "heroicons-solid:x",
                    class: "w-4 h-4"
                  })
                ], 8, ["onClick"]),
                unref(showing) === "method" ? (openBlock(), createBlock(_component_SupplierManagementInviteUser, { key: 0 })) : createCommentVNode("", true),
                unref(showing) === "remove" ? (openBlock(), createBlock(_component_SupplierManagementRemoveUser, { key: 1 })) : createCommentVNode("", true)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/UserManagement.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-751592e4"]]);
const _sfc_main = {
  __name: "user-management",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierUserManagement = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierUserManagement, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user-management.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=user-management-rGGMdM3a.mjs.map
