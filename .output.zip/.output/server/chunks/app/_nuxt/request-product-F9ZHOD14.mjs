import { P as PhoneCodes } from './PhoneCodes-TGlMinMT.mjs';
import { mergeProps, useSSRContext, ref, reactive, provide, unref, inject } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderClass, ssrIncludeBooleanAttr, ssrLooseContain } from 'vue/server-renderer';
import { CheckCircleIcon } from '@heroicons/vue/24/outline';
import { m as measurements } from './constants-7QnerJ-N.mjs';
import { a as useHead, y as useStore } from '../server.mjs';
import useVuelidate from '@vuelidate/core';
import { required, helpers, email, numeric, sameAs } from '@vuelidate/validators';
import '@headlessui/vue';
import 'country-list-with-dial-code-and-flag';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$2 = {
  __name: "RequestComplete",
  __ssrInlineRender: true,
  setup(__props) {
    inject("isComplete");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-8 text-center mt-24" }, _attrs))}>`);
      _push(ssrRenderComponent(unref(CheckCircleIcon), { class: "h-20 w-20 text-green-400 mb-8 mx-auto" }, null, _parent));
      _push(`<p class="text-xl font-medium">Request has been sent</p><p class="text-xs mb-5"> We will notify you as soon as we receive your request. </p><button type="button" class="appearance-none border border-matta-black leading-none px-[14px] py-[10px] rounded-lg text-white bg-matta-black hover:opacity-70 text-[13px] uppercase"> Request another </button></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/catalog/productRequest/RequestComplete.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    var _a, _b;
    const isComplete = ref(false);
    const store = useStore();
    const form = reactive({
      fullName: "",
      businessName: "",
      email: ((_a = store.getters.loggedUser) == null ? void 0 : _a.email) || "",
      phone: ((_b = store.getters.loggedUser) == null ? void 0 : _b.phoneNumber) || "",
      address: "",
      uploadedDocumentUrl: "",
      chemicalName: "",
      quantity: "",
      confirm: false,
      unit: "",
      uploadedDocumentExtension: "",
      phoneCode: "+234"
    });
    const validPhoneLength = (value) => form.phoneCode === "+234" ? value.length > 9 && value.length < 12 : true;
    const isLoading = ref(false);
    const isUploading = ref(false);
    const myrules = {
      phone: {
        required,
        validPhoneLength: helpers.withMessage(
          "Phone number must be between 10 0r 11 digits",
          validPhoneLength
        )
      },
      businessName: { required },
      fullName: { required },
      uploadedDocumentUrl: {},
      email: { required, email },
      chemicalName: { required },
      quantity: { required, numeric },
      confirm: { sameAs: sameAs(true) },
      unit: { required }
    };
    const request$ = useVuelidate(myrules, form);
    provide("isComplete", isComplete);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormsPhoneCodes = PhoneCodes;
      const _component_CatalogProductRequestComplete = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white py-8 sm:py-10 px-4 xs:px-6 lg:px-10 rounded-lg flex-1" }, _attrs))}>`);
      if (!unref(isComplete)) {
        _push(`<form class="flex flex-col h-full max-w-[450px] mx-auto my-10 border p-6 rounded-lg"><div class="flex-1"><div class="flex justify-between items-center mb-6"><h4 class="text-2xl font-medium">Request a product</h4></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Full name</label><input class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" placeholder="Provide your full name" autocomplete="off" autofocus="on"${ssrRenderAttr("value", unref(request$).fullName.$model)}><!--[-->`);
        ssrRenderList(unref(request$).fullName.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Business name</label><input class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" placeholder="Provide your business name" autocomplete="off" autofocus="on"${ssrRenderAttr("value", unref(request$).businessName.$model)}><!--[-->`);
        ssrRenderList(unref(request$).businessName.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Phone number</label><div class="flex relative rounded-lg h-11">`);
        _push(ssrRenderComponent(_component_FormsPhoneCodes, {
          modelValue: unref(form).phoneCode,
          "onUpdate:modelValue": ($event) => unref(form).phoneCode = $event
        }, null, _parent));
        _push(`<input${ssrRenderAttr("value", unref(request$).phone.$model)} class="flex-1 rounded-r-lg text-[13px] px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" placeholder="08160723884" type="tel"></div><!--[-->`);
        ssrRenderList(unref(request$).phone.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">E-mail</label><input class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" placeholder="Provide your email address" autocomplete="off" type="email"${ssrRenderAttr("value", unref(request$).email.$model)}><!--[-->`);
        ssrRenderList(unref(request$).email.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Chemical name</label><input class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" placeholder="Provide chemical name" autocomplete="off" autofocus="on"${ssrRenderAttr("value", unref(request$).chemicalName.$model)}><!--[-->`);
        ssrRenderList(unref(request$).chemicalName.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="grid lg:grid-cols-2 lg:gap-x-6"><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Quantity</label><input class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" placeholder="Enter quantity needed" type=""${ssrRenderAttr("value", unref(request$).quantity.$model)}><!--[-->`);
        ssrRenderList(unref(request$).quantity.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Unit</label><select class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"><!--[-->`);
        ssrRenderList("measurements" in _ctx ? _ctx.measurements : unref(measurements), (n) => {
          _push(`<option${ssrRenderAttr("value", n.value)}>${ssrInterpolate(n.name)}</option>`);
        });
        _push(`<!--]--></select><!--[-->`);
        ssrRenderList(unref(request$).unit.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div></div><div class="mb-6"><label class="mb-2 font-normal text-xs block text-matta-black">Upload document</label><div class="relative flex items-center"><input class="flex-1 block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200" type="file" id="formFile" accept=".xls, .xlsx, .png, .jpg, .jpeg, .docx, .pdf">`);
        if (unref(isUploading)) {
          _push(`<div class="ml-2"><i class="fa fa-spinner fa-spin" aria-hidden="true"></i></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><!--[-->`);
        ssrRenderList(unref(request$).uploadedDocumentUrl.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="mb-6"><label class="${ssrRenderClass([unref(request$).confirm.$errors.length ? "text-red-600" : "", "flex items-center gap-x-2"])}"><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(request$).confirm.$model) ? ssrLooseContain(unref(request$).confirm.$model, null) : unref(request$).confirm.$model) ? " checked" : ""} class="${ssrRenderClass(unref(request$).confirm.$errors.length ? "outline-red-600" : "")}"><span>I confirm that I want to submit this request</span></label></div><div class="flex justify-center mt-8"><button type="submit"${ssrIncludeBooleanAttr(unref(isLoading)) ? " disabled" : ""} class="border text-[13px] mb-4 border-primary- uppercase text-white w-full lg:min-w-[150px] mx-auto bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11"><span>`);
        if (unref(isLoading) || unref(isUploading)) {
          _push(`<span class="flex gap-x-4 justify-center items-center"><span> Processing...</span>`);
          if (unref(isLoading)) {
            _push(`<i class="fa fa-spinner fa-spin text-white" aria-hidden="true"></i>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</span>`);
        } else {
          _push(`<span>Submit</span>`);
        }
        _push(`</span></button></div></div></form>`);
      } else {
        _push(ssrRenderComponent(_component_CatalogProductRequestComplete, null, null, _parent));
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/catalog/productRequest/index.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$1;
const _sfc_main = {
  __name: "request-product",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Request product | Matta"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CatalogProductRequest = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex-1 flex flex-col gap-y-3 border-b border-t" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_CatalogProductRequest, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/request-product.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=request-product-F9ZHOD14.mjs.map
