import { _ as __nuxt_component_0 } from './nuxt-link-fc3HHrvA.mjs';
import { _ as __nuxt_component_1 } from './index-eSH9oSpY.mjs';
import { _ as __nuxt_component_1$1 } from './index-mLIR32Vn.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { ref, mergeProps, withCtx, createTextVNode, unref, isRef, useSSRContext } from 'vue';
import { a as useHead, e as useRouter } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { useForm } from 'vee-validate';
import * as yup from 'yup';
import { toast } from 'vue3-toastify';
import { r as registerUser } from './authservices-pXd32gsl.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './_plugin-vue_export-helper-yVxbj29m.mjs';
import '../../rollup/_vue.mjs';
import 'cleave.js';
import './ck-white-co8-jVxZ.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main = {
  __name: "vendor-register",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Register vendor | Matta"
    });
    const agree = ref(false);
    const isLoading = ref(false);
    const formValues = {
      email: "",
      firstName: "",
      lastName: "",
      phone: "",
      password: "",
      confirmPassword: "",
      business_UserType: 1,
      companyName: ""
    };
    const schema = yup.object({
      email: yup.string().required("Email is required").email("Please enter a valid email address"),
      firstName: yup.string().required("First name is required"),
      companyName: yup.string().required("Company name is required"),
      lastName: yup.string().required("Last name is required"),
      phone: yup.string().required("Phone number is required"),
      password: yup.string().required("Password is required").min(8, "Password must be at least 8 characters").matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
        "Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character"
      ),
      confirmPassword: yup.string().required("Confirm Password is required").oneOf([yup.ref("password"), null], "Passwords must match")
    });
    const { handleSubmit, defineField, errors } = useForm({
      validationSchema: schema,
      initialValues: formValues
    });
    const [email, emailAtt] = defineField("email");
    const [password, passwordAtt] = defineField("password");
    const [firstName, firstNameAtt] = defineField("firstName");
    const [lastName, lastNameAtt] = defineField("lastName");
    const [phone, phoneAtt] = defineField("phone");
    const [confirmPassword, confirmPasswordAtt] = defineField("confirmPassword");
    const [companyName, companyNameAtt] = defineField("companyName");
    const router = useRouter();
    handleSubmit((values) => {
      isLoading.value = true;
      registerUser({ ...values, business_UserType: 1 }).then((res) => {
        if (res.status === 200) {
          toast.info(
            "Sign up successful, Complete registration via link sent to your email"
          );
          router.push("/auth/login");
        }
      }).catch((err) => {
        isLoading.value = false;
        if (err.response.data.message || err.response.data.Message) {
          toast.error(
            err.response.data.message || err.response.data.Message || "Something went wrong"
          );
        }
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_Textinput = __nuxt_component_1;
      const _component_Checkbox = __nuxt_component_1$1;
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col h-full gap-x-8" }, _attrs))}><div class="hidden lg:flex items-center text-center text-sm gap-x-1 justify-end"> Not a vendor? `);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/auth/register",
        class: "font-semibold text-[#2176FF]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Click here`);
          } else {
            return [
              createTextVNode("Click here")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex flex-col justify-center flex-1"><div class="w-full max-w-[650px] mx-auto py-2"><h1 class="text-[#333] darks:text-white mb-[10px] text-3xl font-bold"> Create a vendor account </h1><p class="mb-[31px] text-sm text-[#666] darks:text-white/80"> Enter your details to create an account. </p><form class="grid grid-cols-1 lg:grid-cols-2 gap-x-[18px] gap-y-5"><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "First name",
        type: "text",
        name: "firstName"
      }, unref(firstNameAtt), {
        modelValue: unref(firstName),
        "onUpdate:modelValue": ($event) => isRef(firstName) ? firstName.value = $event : null,
        error: unref(errors).firstName
      }), null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Last name",
        type: "text",
        name: "lasttName"
      }, unref(lastNameAtt), {
        modelValue: unref(lastName),
        "onUpdate:modelValue": ($event) => isRef(lastName) ? lastName.value = $event : null,
        error: unref(errors).lastName
      }), null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "Email address",
        label: "Email",
        type: "email",
        name: "email"
      }, unref(emailAtt), {
        modelValue: unref(email),
        "onUpdate:modelValue": ($event) => isRef(email) ? email.value = $event : null,
        error: unref(errors).email
      }), null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Phone number",
        type: "tel",
        name: "phone"
      }, unref(phoneAtt), {
        modelValue: unref(phone),
        "onUpdate:modelValue": ($event) => isRef(phone) ? phone.value = $event : null,
        error: unref(errors).phone
      }), null, _parent));
      _push(`</div><div class="lg:col-span-2">`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Company name",
        type: "text",
        name: "companyName"
      }, unref(companyNameAtt), {
        modelValue: unref(companyName),
        "onUpdate:modelValue": ($event) => isRef(companyName) ? companyName.value = $event : null,
        error: unref(errors).companyName
      }), null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Password",
        type: "password",
        name: "password"
      }, unref(passwordAtt), {
        modelValue: unref(password),
        "onUpdate:modelValue": ($event) => isRef(password) ? password.value = $event : null,
        error: unref(errors).password
      }), null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Confirm Password",
        type: "password",
        name: "confirmPassword"
      }, unref(confirmPasswordAtt), {
        modelValue: unref(confirmPassword),
        "onUpdate:modelValue": ($event) => isRef(confirmPassword) ? confirmPassword.value = $event : null,
        error: unref(errors).confirmPassword
      }), null, _parent));
      _push(`</div><div class="lg:col-span-2 flex items-center text-[#333] darks:text-slate-400 text-xs lg:text-sm gap-x-[2px]">`);
      _push(ssrRenderComponent(_component_Checkbox, {
        modelValue: unref(agree),
        "onUpdate:modelValue": ($event) => isRef(agree) ? agree.value = $event : null,
        modelModifiers: { value: true },
        label: "I agree to the ",
        labelClass: "text-xs lg:text-sm"
      }, null, _parent));
      _push(`<span>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/terms",
        class: "text-[#2176FF]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Terms `);
          } else {
            return [
              createTextVNode("Terms ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(` and `);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/policy",
        class: "text-[#2176FF]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Policy`);
          } else {
            return [
              createTextVNode("Policy")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(` of Matta Trade</span></div><div class="lg:col-span-2 grid gap-y-[22px] mb-9 mt-4">`);
      _push(ssrRenderComponent(_component_AppButton, {
        type: "submit",
        isLoading: unref(isLoading),
        text: "Create your account",
        btnClass: "normal-case btn-primary !py-3",
        isDisabled: !unref(agree) || unref(isLoading)
      }, null, _parent));
      _push(`</div><span class="lg:col-span-2 flex items-center text-center text-sm text-[#333] darks:text-white/80 gap-x-1 justify-center"> Already have an account? `);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/auth/login",
        class: "font-semibold text-[#2176FF]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Login`);
          } else {
            return [
              createTextVNode("Login")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</span></form></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/auth/vendor-register.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=vendor-register-n8f4L-Mg.mjs.map
