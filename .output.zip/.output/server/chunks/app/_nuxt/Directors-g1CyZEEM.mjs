import { _ as __nuxt_component_1$1 } from './nuxt-img-qJohECzX.mjs';
import { P as PhoneCodes } from './PhoneCodes-TGlMinMT.mjs';
import { _ as __nuxt_component_2$1 } from './SelectComponent-Q1jk_qng.mjs';
import { inject, ref, reactive, computed, unref, withCtx, createVNode, useSSRContext, provide, mergeProps, openBlock, createBlock, createCommentVNode } from 'vue';
import { d as useAuthStore, y as useStore } from '../server.mjs';
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr, ssrRenderClass, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderStyle, ssrRenderAttrs } from 'vue/server-renderer';
import CountryList from 'country-list-with-dial-code-and-flag';
import { c as countries } from './countries-4zSrMx8v.mjs';
import { s as sectors, _ as __nuxt_component_3$1 } from './FileUpload-oHb-LYnL.mjs';
import { TransitionRoot, Dialog, TransitionChild, DialogPanel } from '@headlessui/vue';
import { Cropper } from 'vue-advanced-cropper';
import useVuelidate from '@vuelidate/core';
import { required, helpers, email, maxLength, minLength, numeric } from '@vuelidate/validators';
import { u as uploadfile } from './onboardingservices-NoJPITnD.mjs';
import { useRouter } from 'vue-router';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import { _ as __nuxt_component_1$2 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';

const _sfc_main$4 = {
  __name: "Info",
  __ssrInlineRender: true,
  setup(__props) {
    const active = inject("active");
    useAuthStore();
    useRouter();
    const open = ref(false);
    const img = ref("");
    const image = ref(null);
    const coordinate = ref(null);
    const cropper = ref(null);
    const form = reactive({
      companyName: "",
      companyType: "",
      phone: "",
      email: "",
      website: "",
      fax: "",
      description: "",
      country: "",
      city: "",
      state: "",
      address: "",
      logo: "",
      code: "+234",
      registrationNo: "",
      tin: "",
      socials: [
        {
          name: "",
          link: ""
        }
      ]
    });
    const isLoading = ref(false);
    const validPhoneLength = (value) => form.code === "+234" ? value.length > 9 && value.length < 12 : true;
    const mystates = computed(() => {
      return states.value.map((item) => {
        return {
          id: item.code,
          name: item.name,
          value: item.name
        };
      });
    });
    function getCountry(data) {
      form.country = data.value;
    }
    function getState(data) {
      form.state = data.value;
    }
    const allcountries = computed(() => {
      return CountryList.map((item) => {
        return {
          id: "",
          name: `${item.name}`,
          value: item.name
        };
      });
    });
    const states = computed(() => {
      if (!form.country)
        return [];
      return countries.find(
        (item) => item.name.toLowerCase() == form.country.toLowerCase()
      ).states;
    });
    function crop() {
      const { coordinates, canvas } = cropper.value.getResult();
      coordinate.value = coordinates;
      image.value = canvas.toDataURL();
      open.value = false;
      form.logo = canvas.toDataURL().replace("data:", "").replace(/^.+,/, "");
      uploadfile({
        base64: canvas.toDataURL().replace("data:", "").replace(/^.+,/, "")
      }).then((res) => {
        form.logo = res.data.message;
      });
    }
    const rules = {
      email: {
        required,
        email: helpers.withMessage("Email is invalid", email),
        maxLength: maxLength(50)
      },
      companyName: {
        required,
        maxLength: maxLength(50)
      },
      website: {
        maxLength: maxLength(100)
      },
      country: {
        required,
        maxLength: maxLength(50)
      },
      city: {
        required,
        maxLength: maxLength(50)
      },
      address: {
        required,
        maxLength: maxLength(250)
      },
      tin: { required, minLength: minLength(7) },
      registrationNo: { required, minLength: minLength(14) },
      companyType: { required },
      state: {
        required,
        maxLength: maxLength(50)
      },
      phone: {
        numeric,
        required,
        validPhoneLength: helpers.withMessage(
          "Phone number must be between 10 0r 11 digits",
          validPhoneLength
        )
      },
      fax: {
        maxLength: maxLength(50)
      },
      description: {
        maxLength: maxLength(1e3)
      },
      logo: {}
    };
    ref(false);
    const v$ = useVuelidate(rules, form);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtImg = __nuxt_component_1$1;
      const _component_FormsPhoneCodes = PhoneCodes;
      const _component_FormsSelectComponent = __nuxt_component_2$1;
      _push(`<!--[-->`);
      if (unref(active) === 1) {
        _push(`<form class="px-4 lg:px-[30px]" data-v-17232159><div class="flex gap-x-[76px] pt-[30px] justify-between flex-col lg:flex-row gap-y-7 lg:gap-y-0" data-v-17232159><div class="w-[300px]" data-v-17232159><h2 class="text-sm text-[#101828] font-semibold" data-v-17232159> Company Information </h2><p class="text-xs text-[#475467]" data-v-17232159>Update your details here.</p></div><div class="" data-v-17232159><div class="md:max-w-[560px]" data-v-17232159><div class="" data-v-17232159><div class="flex flex-col lg:flex-row lg:justify-between lg:items-center mb-10 gap-y-8" data-v-17232159><div class="flex items-center gap-x-6" data-v-17232159><span data-v-17232159><label for="upload" data-v-17232159>`);
        if (!image.value) {
          _push(`<span class="h-[64px] w-[64px] rounded-full flex items-center text-xs bg-[#F1F3F5] justify-center" data-v-17232159><i class="uil uil-image text-4xl text-gray-400" data-v-17232159></i></span>`);
        } else {
          _push(ssrRenderComponent(_component_NuxtImg, {
            src: image.value,
            class: "h-[64px] w-[64px] rounded-full flex items-center bg-[#F1F3F5] justify-center"
          }, null, _parent));
        }
        _push(`<input type="file" accept="image/*" id="upload" class="hidden" data-v-17232159></label></span><span data-v-17232159><p class="text-xs lg:text-sm font-medium text-[#475467]" data-v-17232159> Upload Company logo </p><!--[-->`);
        ssrRenderList(unref(v$).logo.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-17232159><div class="error-msg text-error text-xs font-semibold" data-v-17232159>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></span></div></div><div data-v-17232159><div data-v-17232159><div class="grid grid-cols-1 lg:grid-cols-2 gap-4" data-v-17232159><div class="mb-6" data-v-17232159><label class="mb-2 font-medium text-sm text-[#344054] block" data-v-17232159> Company name <span class="text-red-500 pl-[.02rem]" data-v-17232159>*</span></label><input${ssrRenderAttr("value", unref(v$).companyName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).companyName.$error }, "rounded-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" placeholder="" data-v-17232159><!--[-->`);
        ssrRenderList(unref(v$).companyName.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-17232159><div class="error-msg text-error text-xs font-semibold" data-v-17232159>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="mb-6" data-v-17232159><label class="mb-2 font-medium text-sm text-[#344054] block" data-v-17232159>Company sector <span class="text-red-500 pl-[.02rem]" data-v-17232159>*</span></label><div class="flex relative items-center" data-v-17232159><select class="${ssrRenderClass([{ "border-red-500": unref(v$).companyType.$error }, "appearance-none rounded-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" data-v-17232159><option disabled value="" data-v-17232159${ssrIncludeBooleanAttr(Array.isArray(unref(v$).companyType.$model) ? ssrLooseContain(unref(v$).companyType.$model, "") : ssrLooseEqual(unref(v$).companyType.$model, "")) ? " selected" : ""}>Select sector</option><!--[-->`);
        ssrRenderList(unref(sectors), (item) => {
          _push(`<option${ssrRenderAttr("value", item.name)} data-v-17232159>${ssrInterpolate(item.name)}</option>`);
        });
        _push(`<!--]--></select><i class="uil uil-angle-down absolute right-2 pointer-events-none" data-v-17232159></i></div><!--[-->`);
        ssrRenderList(unref(v$).companyType.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-17232159><div class="error-msg text-error text-xs font-semibold" data-v-17232159>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div></div><div class="grid grid-cols-1 lg:grid-cols-2 gap-4" data-v-17232159><div class="mb-6" data-v-17232159><label class="mb-2 font-medium text-sm text-[#344054] block" data-v-17232159>E-mail <span class="text-red-500 pl-[.02rem]" data-v-17232159>*</span></label><input${ssrRenderAttr("value", unref(v$).email.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).email.$error }, "px-[14px] py-[10px] h-11 text-sm rounded-lg w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" data-v-17232159><!--[-->`);
        ssrRenderList(unref(v$).email.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-17232159><div class="error-msg text-error text-xs font-semibold" data-v-17232159>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="mb-6" data-v-17232159><label class="mb-2 font-medium text-sm text-[#344054] block" data-v-17232159>Phone number <span class="text-red-500 pl-[.02rem]" data-v-17232159>*</span></label><div class="flex relative rounded-lg h-11" data-v-17232159>`);
        _push(ssrRenderComponent(_component_FormsPhoneCodes, {
          modelValue: form.code,
          "onUpdate:modelValue": ($event) => form.code = $event
        }, null, _parent));
        _push(`<input class="${ssrRenderClass([{ "border-red-500": unref(v$).phone.$error }, "flex-1 rounded-r-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}"${ssrRenderAttr("value", unref(v$).phone.$model)} autocomplete="off" autofocus="on" placeholder="08160723884" type="tel" data-v-17232159></div><!--[-->`);
        ssrRenderList(unref(v$).phone.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-17232159><div class="error-msg text-error text-xs font-semibold" data-v-17232159>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div></div><div class="grid grid-cols-1 lg:grid-cols-2 gap-4" data-v-17232159><div class="mb-6" data-v-17232159><label class="mb-2 font-medium text-sm text-[#344054] block" data-v-17232159> Registration number <span class="text-red-500 pl-[.02rem]" data-v-17232159>*</span></label><input${ssrRenderAttr("value", unref(v$).registrationNo.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).registrationNo.$error }, "rounded-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" placeholder="" data-v-17232159><!--[-->`);
        ssrRenderList(unref(v$).registrationNo.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-17232159><div class="error-msg text-error text-xs font-semibold" data-v-17232159>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="mb-6" data-v-17232159><label class="mb-2 font-medium text-sm text-[#344054] block" data-v-17232159>TIN number <span class="text-red-500 pl-[.02rem]" data-v-17232159>*</span></label><input${ssrRenderAttr("value", unref(v$).tin.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).tin.$error }, "rounded-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" placeholder="" data-v-17232159><!--[-->`);
        ssrRenderList(unref(v$).tin.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-17232159><div class="error-msg text-error text-xs font-semibold" data-v-17232159>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div></div><div class="grid grid-cols-1 lg:grid-cols-2 gap-4" data-v-17232159><div class="mb-6 lg:col-span-2" data-v-17232159><label class="mb-2 font-medium text-sm text-[#344054] block" data-v-17232159>Company website</label><input${ssrRenderAttr("value", unref(v$).website.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).website.$error }, "rounded-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" placeholder="https://www.example.com" type="url" data-v-17232159><!--[-->`);
        ssrRenderList(unref(v$).website.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-17232159><div class="error-msg text-error text-xs font-semibold" data-v-17232159>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div></div><div class="mb-6" data-v-17232159><label class="mb-2 font-medium text-sm text-[#344054] block" data-v-17232159>Description</label><textarea class="${ssrRenderClass([{ "border-red-500": unref(v$).description.$error }, "rounded-lg px-[14px] py-[10px] w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" rows="4" placeholder="Company description" data-v-17232159>${ssrInterpolate(unref(v$).description.$model)}</textarea><!--[-->`);
        ssrRenderList(unref(v$).description.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-17232159><div class="error-msg text-error text-xs font-semibold" data-v-17232159>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="grid grid-cols-1 lg:grid-cols-2 gap-4" data-v-17232159><div class="mb-6" data-v-17232159><label class="mb-2 font-medium text-sm text-[#344054] block" data-v-17232159>Company Address <span class="text-red-500 pl-[.02rem]" data-v-17232159>*</span></label><input${ssrRenderAttr("value", unref(v$).address.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).address.$error }, "rounded-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" placeholder="Company address" data-v-17232159><!--[-->`);
        ssrRenderList(unref(v$).address.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-17232159><div class="error-msg text-error text-xs font-semibold" data-v-17232159>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="mb-6" data-v-17232159><label class="mb-2 font-medium text-sm text-[#344054] block" data-v-17232159>City <span class="text-red-500 pl-[.02rem]" data-v-17232159>*</span></label><input${ssrRenderAttr("value", unref(v$).city.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).city.$error }, "px-[14px] py-[10px] h-11 text-sm w-full border rounded-lg placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" placeholder="Company city" data-v-17232159><!--[-->`);
        ssrRenderList(unref(v$).city.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-17232159><div class="error-msg text-error text-xs font-semibold" data-v-17232159>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div></div><div class="grid grid-cols-1 lg:grid-cols-2 gap-4" data-v-17232159><div class="mb-6" data-v-17232159><label class="mb-2 font-medium text-sm text-[#344054] block" data-v-17232159>Country <span class="text-red-500 pl-[.02rem]" data-v-17232159>*</span></label><div class="relative" data-v-17232159>`);
        _push(ssrRenderComponent(_component_FormsSelectComponent, {
          options: allcountries.value,
          showSearch: true,
          value: form.country,
          onOnGetData: getCountry,
          containerStyle: "w-full",
          classStyles: `${unref(v$).country.$error && "border-red-500"} rounded-lg appearance-none px-[14px] py-[10px] h-11 text-sm border w-full ! placeholder:text-[#B6B7B9] focus:outline-matta-black/20`
        }, null, _parent));
        _push(`<!--[-->`);
        ssrRenderList(unref(v$).country.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-17232159><div class="error-msg text-error text-xs font-semibold" data-v-17232159>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div></div><div class="mb-6" data-v-17232159><label class="mb-2 font-medium text-sm text-[#344054] block" data-v-17232159>State <span class="text-red-500 pl-[.02rem]" data-v-17232159>*</span></label>`);
        _push(ssrRenderComponent(_component_FormsSelectComponent, {
          options: mystates.value,
          showSearch: true,
          value: form.state,
          onOnGetData: getState,
          containerStyle: "w-full",
          classStyles: `${unref(v$).state.$error && "border-red-500"} rounded-lg appearance-none px-[14px] py-[10px] h-11 text-sm border w-full ! placeholder:text-[#B6B7B9] focus:outline-matta-black/20`
        }, null, _parent));
        _push(`<!--[-->`);
        ssrRenderList(unref(v$).state.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-17232159><div class="error-msg text-error text-xs font-semibold" data-v-17232159>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div></div></div></div></div></div></div></div><div class="flex justify-between gap-x-4 items-center mt-16 pt-6 border-t border-[#EAECF0] w-full" data-v-17232159><span data-v-17232159></span><div class="flex justify-end gap-x-4 items-center" data-v-17232159><button type="button" class="appearance-none leading-none px-10 py-[14px] rounded-lg w-full lg:w-auto text-matta-black border border-[#E7EBEE] hover:bg-gray-100 text-[13px] capitalize" data-v-17232159> Cancel </button><button${ssrIncludeBooleanAttr(unref(v$).$silentErrors.length || isLoading.value) ? " disabled" : ""} class="${ssrRenderClass([{
          "opacity-60 cursor-not-allowed": unref(v$).$silentErrors.length
        }, "appearance-none leading-none px-10 py-4 grid-cols-1 lg:grid-cols-2 gap-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] capitalize"])}" data-v-17232159><i class="fa fa-spinner fa-spin" style="${ssrRenderStyle(isLoading.value ? null : { display: "none" })}" aria-hidden="true" data-v-17232159></i><span style="${ssrRenderStyle(!isLoading.value ? null : { display: "none" })}" data-v-17232159>Next</span></button></div></div></form>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div data-v-17232159>`);
      _push(ssrRenderComponent(unref(TransitionRoot), {
        as: "template",
        show: open.value
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Dialog), {
              as: "div",
              class: "relative z-10",
              onClose: ($event) => open.value = false
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" data-v-17232159${_scopeId3}></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="fixed z-10 inset-0 overflow-y-auto" data-v-17232159${_scopeId2}><div class="flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0" data-v-17232159${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                    "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                    "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(DialogPanel), { class: "relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" data-v-17232159${_scopeId4}><div class="flex justify-between mb-5 items-center" data-v-17232159${_scopeId4}><h4 class="font-medium text-matta-black text-xl" data-v-17232159${_scopeId4}> Customize logo </h4><i class="uil uil-times cursor-pointer text-lg" data-v-17232159${_scopeId4}></i></div>`);
                              _push5(ssrRenderComponent(unref(Cropper), {
                                ref_key: "cropper",
                                ref: cropper,
                                class: "cropper",
                                src: img.value,
                                "stencil-size": {
                                  width: 200,
                                  height: 200
                                }
                              }, null, _parent5, _scopeId4));
                              _push5(`<div class="flex justify-end gap-x-2 items-center mt-8" data-v-17232159${_scopeId4}><button class="appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] capitalize" data-v-17232159${_scopeId4}> Cancel </button><button class="appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] capitalize" data-v-17232159${_scopeId4}> Save </button></div></div>`);
                            } else {
                              return [
                                createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" }, [
                                  createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                                    createVNode("h4", { class: "font-medium text-matta-black text-xl" }, " Customize logo "),
                                    createVNode("i", {
                                      class: "uil uil-times cursor-pointer text-lg",
                                      onClick: ($event) => open.value = false
                                    }, null, 8, ["onClick"])
                                  ]),
                                  createVNode(unref(Cropper), {
                                    ref_key: "cropper",
                                    ref: cropper,
                                    class: "cropper",
                                    src: img.value,
                                    "stencil-size": {
                                      width: 200,
                                      height: 200
                                    }
                                  }, null, 8, ["src"]),
                                  createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                                    createVNode("button", {
                                      onClick: ($event) => open.value = false,
                                      class: "appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] capitalize"
                                    }, " Cancel ", 8, ["onClick"]),
                                    createVNode("button", {
                                      onClick: crop,
                                      class: "appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] capitalize"
                                    }, " Save ")
                                  ])
                                ])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(DialogPanel), { class: "relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full" }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" }, [
                                createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                                  createVNode("h4", { class: "font-medium text-matta-black text-xl" }, " Customize logo "),
                                  createVNode("i", {
                                    class: "uil uil-times cursor-pointer text-lg",
                                    onClick: ($event) => open.value = false
                                  }, null, 8, ["onClick"])
                                ]),
                                createVNode(unref(Cropper), {
                                  ref_key: "cropper",
                                  ref: cropper,
                                  class: "cropper",
                                  src: img.value,
                                  "stencil-size": {
                                    width: 200,
                                    height: 200
                                  }
                                }, null, 8, ["src"]),
                                createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                                  createVNode("button", {
                                    onClick: ($event) => open.value = false,
                                    class: "appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] capitalize"
                                  }, " Cancel ", 8, ["onClick"]),
                                  createVNode("button", {
                                    onClick: crop,
                                    class: "appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] capitalize"
                                  }, " Save ")
                                ])
                              ])
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode(unref(TransitionChild), {
                      as: "template",
                      enter: "ease-out duration-300",
                      "enter-from": "opacity-0",
                      "enter-to": "opacity-100",
                      leave: "ease-in duration-200",
                      "leave-from": "opacity-100",
                      "leave-to": "opacity-0"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                      ]),
                      _: 1
                    }),
                    createVNode("div", { class: "fixed z-10 inset-0 overflow-y-auto" }, [
                      createVNode("div", { class: "flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0" }, [
                        createVNode(unref(TransitionChild), {
                          as: "template",
                          enter: "ease-out duration-300",
                          "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                          "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                          leave: "ease-in duration-200",
                          "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                          "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(DialogPanel), { class: "relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full" }, {
                              default: withCtx(() => [
                                createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" }, [
                                  createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                                    createVNode("h4", { class: "font-medium text-matta-black text-xl" }, " Customize logo "),
                                    createVNode("i", {
                                      class: "uil uil-times cursor-pointer text-lg",
                                      onClick: ($event) => open.value = false
                                    }, null, 8, ["onClick"])
                                  ]),
                                  createVNode(unref(Cropper), {
                                    ref_key: "cropper",
                                    ref: cropper,
                                    class: "cropper",
                                    src: img.value,
                                    "stencil-size": {
                                      width: 200,
                                      height: 200
                                    }
                                  }, null, 8, ["src"]),
                                  createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                                    createVNode("button", {
                                      onClick: ($event) => open.value = false,
                                      class: "appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] capitalize"
                                    }, " Cancel ", 8, ["onClick"]),
                                    createVNode("button", {
                                      onClick: crop,
                                      class: "appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] capitalize"
                                    }, " Save ")
                                  ])
                                ])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Dialog), {
                as: "div",
                class: "relative z-10",
                onClose: ($event) => open.value = false
              }, {
                default: withCtx(() => [
                  createVNode(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                    ]),
                    _: 1
                  }),
                  createVNode("div", { class: "fixed z-10 inset-0 overflow-y-auto" }, [
                    createVNode("div", { class: "flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0" }, [
                      createVNode(unref(TransitionChild), {
                        as: "template",
                        enter: "ease-out duration-300",
                        "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                        "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                        leave: "ease-in duration-200",
                        "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                        "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(DialogPanel), { class: "relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full" }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" }, [
                                createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                                  createVNode("h4", { class: "font-medium text-matta-black text-xl" }, " Customize logo "),
                                  createVNode("i", {
                                    class: "uil uil-times cursor-pointer text-lg",
                                    onClick: ($event) => open.value = false
                                  }, null, 8, ["onClick"])
                                ]),
                                createVNode(unref(Cropper), {
                                  ref_key: "cropper",
                                  ref: cropper,
                                  class: "cropper",
                                  src: img.value,
                                  "stencil-size": {
                                    width: 200,
                                    height: 200
                                  }
                                }, null, 8, ["src"]),
                                createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                                  createVNode("button", {
                                    onClick: ($event) => open.value = false,
                                    class: "appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] capitalize"
                                  }, " Cancel ", 8, ["onClick"]),
                                  createVNode("button", {
                                    onClick: crop,
                                    class: "appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] capitalize"
                                  }, " Save ")
                                ])
                              ])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              }, 8, ["onClose"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/onboarding/company/Info.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-17232159"]]);
const _sfc_main$3 = {
  __name: "Documents",
  __ssrInlineRender: true,
  setup(__props) {
    useRouter();
    inject("active");
    const form = reactive({
      companyDocuments: [
        {
          url: "",
          documentType: 0
        },
        {
          url: "",
          documentType: 1
        },
        {
          url: "",
          documentType: 2
        }
      ]
    });
    const isLoading = ref(false);
    function handleChange(id, value) {
      form.companyDocuments.map((i) => {
        if (id === "incorporation" && i.documentType === 0) {
          i.url = value;
        }
        if (id === "mermat" && i.documentType === 1) {
          i.url = value;
        }
        if (id === "statusReport" && i.documentType === 2) {
          i.url = value;
        }
      });
    }
    ref(false);
    provide("handleChange", handleChange);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FileUpload = __nuxt_component_3$1;
      _push(`<form${ssrRenderAttrs(mergeProps({ class: "w-full px-4 lg:px-[30px]" }, _attrs))} data-v-f1bcacd9><div class="flex gap-x-[76px] pt-[30px] justify-between flex-col lg:flex-row gap-y-7 lg:gap-y-" data-v-f1bcacd9><div class="w-[300px]" data-v-f1bcacd9><h2 class="text-sm text-[#101828] font-semibold" data-v-f1bcacd9>Company Documents</h2><p class="text-xs text-[#475467]" data-v-f1bcacd9> Upload your company registration documents </p></div><div class="grid gap-y-6 max-w-[560px] w-full" data-v-f1bcacd9>`);
      _push(ssrRenderComponent(_component_FileUpload, {
        label: "Memorandum and Articles of Association",
        id: "mermat"
      }, null, _parent));
      _push(ssrRenderComponent(_component_FileUpload, {
        label: "Certificate of Incorporation",
        id: "incorporation"
      }, null, _parent));
      _push(ssrRenderComponent(_component_FileUpload, {
        label: "CAC Status Report",
        id: "statusReport"
      }, null, _parent));
      _push(`</div></div><div class="flex justify-end pt-6 border-t border-[#EAECF0] gap-x-4 items-center mt-16 w-full" data-v-f1bcacd9><button type="button" class="appearance-none leading-none px-10 py-[14px] rounded-lg w-full lg:w-auto text-matta-black border border-[#E7EBEE] hover:bg-gray-100 text-[13px] capitalize" data-v-f1bcacd9> Back </button><button${ssrIncludeBooleanAttr(form.companyDocuments.some((i) => i.url === "") || isLoading.value) ? " disabled" : ""} class="${ssrRenderClass([{
        "opacity-60 cursor-not-allowed": form.companyDocuments.some(
          (i) => i.url === ""
        )
      }, "appearance-none leading-none px-10 py-[14px] grid-cols-1 lg:grid-cols-2 gap-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] capitalize"])}" data-v-f1bcacd9><i class="fa fa-spinner fa-spin" style="${ssrRenderStyle(isLoading.value ? null : { display: "none" })}" aria-hidden="true" data-v-f1bcacd9></i><span style="${ssrRenderStyle(!isLoading.value ? null : { display: "none" })}" data-v-f1bcacd9>Next</span></button></div></form>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/onboarding/company/Documents.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-f1bcacd9"]]);
const _sfc_main$2 = {
  __name: "DirectorForm",
  __ssrInlineRender: true,
  setup(__props) {
    inject("open");
    inject("directors");
    const form = reactive({
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      bvn: "",
      dob: ""
    });
    const isLoading = ref(false);
    const rules = {
      firstName: {
        required,
        maxLength: maxLength(50)
      },
      lastName: {
        required
      },
      bvn: {
        required,
        minLength: minLength(10)
      },
      dob: {
        required
      },
      email: {
        required: helpers.withMessage("Email field cannot be empty", required),
        email: helpers.withMessage("Email is invalid", email),
        maxLength: maxLength(50)
      },
      phone: {
        numeric,
        required
      }
    };
    const v$ = useVuelidate(rules, form);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><h3 class="font-medium text-2xl mb-8">Add director</h3><form><div class="grid grid-cols-2 gap-x-4"><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">First name</label><input${ssrRenderAttr("value", unref(v$).firstName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).firstName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on"><!--[-->`);
      ssrRenderList(unref(v$).firstName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Last name</label><input${ssrRenderAttr("value", unref(v$).lastName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).lastName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on"><!--[-->`);
      ssrRenderList(unref(v$).lastName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="mb-6"><label for="email" class="mb-2 font-normal text-xs block">E-mail</label><input${ssrRenderAttr("value", unref(v$).email.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).email.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="E-mail" autocomplete="off" aria-autocomplete="none" type="email" id="email"><!--[-->`);
      ssrRenderList(unref(v$).email.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-normal text-xs block" for="phone">Phone number <span class="text-red-500 pl-[.02rem]">*</span></label><div class="flex relative rounded-lg h-11"><input class="${ssrRenderClass([{ "border-red-500": unref(v$).phone.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}"${ssrRenderAttr("value", unref(v$).phone.$model)} autocomplete="off" aria-autocomplete="none" placeholder="08160723884" role="presentation" id="phone"></div><!--[-->`);
      ssrRenderList(unref(v$).phone.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="grid grid-cols-2 gap-x-4"><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">BVN</label><input${ssrRenderAttr("value", unref(v$).bvn.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).bvn.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on"><!--[-->`);
      ssrRenderList(unref(v$).bvn.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Date of birth</label><input${ssrRenderAttr("value", unref(v$).dob.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).dob.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" type="date"><!--[-->`);
      ssrRenderList(unref(v$).dob.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="flex justify-end gap-x-4 mt-8 w-full"><button type="button" class="text-xs uppercase border border-gray-100 w-full px-5 py-4 rounded-lg"> Cancel </button><button type="submit"${ssrIncludeBooleanAttr(unref(isLoading)) ? " disabled" : ""} class="text-xs uppercase bg-primary-500 text-white px-5 py-4 rounded-lg hover:bg-primary/70 disabled:opacity-60 w-full"> Submit </button></div></form><!--]-->`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/onboarding/company/DirectorForm.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "DeleteModal",
  __ssrInlineRender: true,
  emits: ["delete", "close"],
  setup(__props, { emit: __emit }) {
    const emits = __emit;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1$2;
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white" }, _attrs))}><div class="flex justify-between items-center mb-6"><span class="h-11 w-11 rounded-full flex items-center justify-center bg-[#FEE4E2] text-[#D92D20]">`);
      _push(ssrRenderComponent(_component_AppIcon, { icon: "fa6-solid:trash-can" }, null, _parent));
      _push(`</span><span class="text-[#8C8C8C] bg-gray-100 rounded-full flex items-center justify-center h-6 w-6 text-sm">`);
      _push(ssrRenderComponent(_component_AppIcon, { icon: "bi:x-lg" }, null, _parent));
      _push(`</span></div><h3 class="text-lg text-[#101828] font-semibold">Delete Director</h3><p class="text-sm text-[#475467] mb-6"> Are you sure you want to delete this director? This action cannot be undone. </p><div class="grid grid-cols-1 gap-y-2">`);
      _push(ssrRenderComponent(_component_AppButton, {
        text: "Delete",
        btnClass: "bg-[#D92D20] text-white w-full border border-[#D92D20]",
        onClick: ($event) => emits("delete")
      }, null, _parent));
      _push(ssrRenderComponent(_component_AppButton, {
        text: "Cancel",
        btnClass: "border text-[#344054] w-full border-[#D0D5DD]",
        onClick: ($event) => emits("close")
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/onboarding/company/DeleteModal.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$1;
const _sfc_main = {
  __name: "Directors",
  __ssrInlineRender: true,
  setup(__props) {
    const id = ref(null);
    const action = ref("");
    useStore();
    useRouter();
    const open = ref(false);
    inject("active");
    const form = reactive({
      directors: []
    });
    const isLoading = ref(false);
    function onDelete() {
      form.directors.splice(id.value, 1);
      open.value = false;
    }
    provide("open", open);
    provide("directors", form.directors);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_OnboardingCompanyDirectorForm = __nuxt_component_0;
      const _component_OnboardingCompanyDeleteModal = __nuxt_component_1;
      _push(`<!--[--><div class="px-4 lg:px-[30px]" data-v-37034a78><div class="flex gap-x-[76px] pt-[30px] justify-between flex-col lg:flex-row gap-y-7 lg:gap-y-" data-v-37034a78><div class="w-[300px]" data-v-37034a78><h2 class="text-sm text-[#101828] font-semibold" data-v-37034a78>Company Directors</h2><p class="text-xs text-[#475467]" data-v-37034a78> Update your company director details here. </p></div><div class="md:max-w-[560px] w-full" data-v-37034a78><div class="" data-v-37034a78><div data-v-37034a78><button type="button" class="appearance-none leading-none px-[14px] py-[10px] grid-cols-1 lg:grid-cols-2 gap-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-xs mb-6" data-v-37034a78><span class="" data-v-37034a78> + Add director</span></button></div>`);
      if (form.directors.length) {
        _push(`<div class="w-full rounded-[10px] border border-[#EAECF0] overflow-hidden" data-v-37034a78><table class="w-full" data-v-37034a78><thead data-v-37034a78><tr data-v-37034a78><th class="capitalize text-[#475467] text-sm text-left font-medium border-b py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-37034a78> Name </th><th class="capitalize text-[#475467] text-sm text-left font-medium border-b py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-37034a78></th></tr></thead><tbody data-v-37034a78><!--[-->`);
        ssrRenderList(form.directors, (director, id2) => {
          _push(`<tr class="border-b last:border-none" data-v-37034a78><td class="text-matta-black text-sm font-normal py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-37034a78>${ssrInterpolate(director.firstName)} ${ssrInterpolate(director.lastName)}</td><td class="text-matta-black text-sm font-normal py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-37034a78><span class="flex gap-x-3 items-center justify-end" data-v-37034a78><span class="p-1" data-v-37034a78><i class="uil uil-pen" data-v-37034a78></i></span><span class="p-1" data-v-37034a78><i class="uil uil-trash text-red-500" data-v-37034a78></i></span></span></td></tr>`);
        });
        _push(`<!--]--></tbody></table></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div><div class="flex justify-end pt-6 border-t border-[#EAECF0] gap-x-4 items-center mt-16 w-full" data-v-37034a78><button type="button" class="appearance-none leading-none px-10 py-[14px] rounded-lg w-full lg:w-auto text-matta-black border border-[#E7EBEE] hover:bg-gray-100 text-[13px] capitalize" data-v-37034a78> Back </button><button${ssrIncludeBooleanAttr(!form.directors.length || isLoading.value) ? " disabled" : ""} class="${ssrRenderClass([{
        "opacity-60 cursor-not-allowed": !form.directors.length
      }, "appearance-none leading-none px-10 py-[14px] grid-cols-1 lg:grid-cols-2 gap-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] capitalize"])}" data-v-37034a78><i class="fa fa-spinner fa-spin" style="${ssrRenderStyle(isLoading.value ? null : { display: "none" })}" aria-hidden="true" data-v-37034a78></i><span style="${ssrRenderStyle(!isLoading.value ? null : { display: "none" })}" data-v-37034a78>Done</span></button></div></div><div data-v-37034a78>`);
      _push(ssrRenderComponent(unref(TransitionRoot), {
        as: "template",
        show: open.value
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Dialog), {
              as: "div",
              class: "relative z-10",
              onClose: () => {
              }
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" data-v-37034a78${_scopeId3}></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="fixed z-10 inset-0 overflow-y-auto" data-v-37034a78${_scopeId2}><div class="flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0" data-v-37034a78${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                    "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                    "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(DialogPanel), {
                          class: ["relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full", action.value == "add" ? "sm:max-w-lg" : "sm:max-w-[343px]"]
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<div class="p-6" data-v-37034a78${_scopeId4}>`);
                              if (action.value === "add") {
                                _push5(ssrRenderComponent(_component_OnboardingCompanyDirectorForm, null, null, _parent5, _scopeId4));
                              } else {
                                _push5(`<!---->`);
                              }
                              if (action.value === "delete") {
                                _push5(ssrRenderComponent(_component_OnboardingCompanyDeleteModal, {
                                  onDelete,
                                  onClose: ($event) => open.value = false
                                }, null, _parent5, _scopeId4));
                              } else {
                                _push5(`<!---->`);
                              }
                              _push5(`</div>`);
                            } else {
                              return [
                                createVNode("div", { class: "p-6" }, [
                                  action.value === "add" ? (openBlock(), createBlock(_component_OnboardingCompanyDirectorForm, { key: 0 })) : createCommentVNode("", true),
                                  action.value === "delete" ? (openBlock(), createBlock(_component_OnboardingCompanyDeleteModal, {
                                    key: 1,
                                    onDelete,
                                    onClose: ($event) => open.value = false
                                  }, null, 8, ["onClose"])) : createCommentVNode("", true)
                                ])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(DialogPanel), {
                            class: ["relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full", action.value == "add" ? "sm:max-w-lg" : "sm:max-w-[343px]"]
                          }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "p-6" }, [
                                action.value === "add" ? (openBlock(), createBlock(_component_OnboardingCompanyDirectorForm, { key: 0 })) : createCommentVNode("", true),
                                action.value === "delete" ? (openBlock(), createBlock(_component_OnboardingCompanyDeleteModal, {
                                  key: 1,
                                  onDelete,
                                  onClose: ($event) => open.value = false
                                }, null, 8, ["onClose"])) : createCommentVNode("", true)
                              ])
                            ]),
                            _: 1
                          }, 8, ["class"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode(unref(TransitionChild), {
                      as: "template",
                      enter: "ease-out duration-300",
                      "enter-from": "opacity-0",
                      "enter-to": "opacity-100",
                      leave: "ease-in duration-200",
                      "leave-from": "opacity-100",
                      "leave-to": "opacity-0"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                      ]),
                      _: 1
                    }),
                    createVNode("div", { class: "fixed z-10 inset-0 overflow-y-auto" }, [
                      createVNode("div", { class: "flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0" }, [
                        createVNode(unref(TransitionChild), {
                          as: "template",
                          enter: "ease-out duration-300",
                          "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                          "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                          leave: "ease-in duration-200",
                          "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                          "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(DialogPanel), {
                              class: ["relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full", action.value == "add" ? "sm:max-w-lg" : "sm:max-w-[343px]"]
                            }, {
                              default: withCtx(() => [
                                createVNode("div", { class: "p-6" }, [
                                  action.value === "add" ? (openBlock(), createBlock(_component_OnboardingCompanyDirectorForm, { key: 0 })) : createCommentVNode("", true),
                                  action.value === "delete" ? (openBlock(), createBlock(_component_OnboardingCompanyDeleteModal, {
                                    key: 1,
                                    onDelete,
                                    onClose: ($event) => open.value = false
                                  }, null, 8, ["onClose"])) : createCommentVNode("", true)
                                ])
                              ]),
                              _: 1
                            }, 8, ["class"])
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Dialog), {
                as: "div",
                class: "relative z-10",
                onClose: () => {
                }
              }, {
                default: withCtx(() => [
                  createVNode(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                    ]),
                    _: 1
                  }),
                  createVNode("div", { class: "fixed z-10 inset-0 overflow-y-auto" }, [
                    createVNode("div", { class: "flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0" }, [
                      createVNode(unref(TransitionChild), {
                        as: "template",
                        enter: "ease-out duration-300",
                        "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                        "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                        leave: "ease-in duration-200",
                        "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                        "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(DialogPanel), {
                            class: ["relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full", action.value == "add" ? "sm:max-w-lg" : "sm:max-w-[343px]"]
                          }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "p-6" }, [
                                action.value === "add" ? (openBlock(), createBlock(_component_OnboardingCompanyDirectorForm, { key: 0 })) : createCommentVNode("", true),
                                action.value === "delete" ? (openBlock(), createBlock(_component_OnboardingCompanyDeleteModal, {
                                  key: 1,
                                  onDelete,
                                  onClose: ($event) => open.value = false
                                }, null, 8, ["onClose"])) : createCommentVNode("", true)
                              ])
                            ]),
                            _: 1
                          }, 8, ["class"])
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              }, 8, ["onClose"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/onboarding/company/Directors.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-37034a78"]]);

export { __nuxt_component_2 as _, __nuxt_component_5 as a, __nuxt_component_3 as b };
//# sourceMappingURL=Directors-g1CyZEEM.mjs.map
