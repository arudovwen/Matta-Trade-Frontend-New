import { useCurrencyInput } from 'vue-currency-input';
import { watch, mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';

const _sfc_main = {
  name: "CurrencyInput",
  props: {
    modelValue: Number,
    // Vue 2: value
    options: Object,
    classInput: String
  },
  setup(props) {
    const { inputRef, setValue } = useCurrencyInput(props.options);
    watch(
      () => props.modelValue,
      // Vue 2: props.value
      (value) => {
        setValue(value);
      }
    );
    return { inputRef };
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<input${ssrRenderAttrs(mergeProps({
    ref: "inputRef",
    type: "text",
    class: $props.classInput
  }, _attrs))}>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CurrencyInput.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const CurrencyInput = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { CurrencyInput as C };
//# sourceMappingURL=CurrencyInput-krSh-4ij.mjs.map
