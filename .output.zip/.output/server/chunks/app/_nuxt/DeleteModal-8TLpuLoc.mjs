import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { unref, withCtx, createVNode, openBlock, createBlock, toDisplayString, createCommentVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import { TransitionRoot, Dialog, TransitionChild, DialogOverlay } from '@headlessui/vue';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';

const _imports_0 = "" + publicAssetsURL("images/delete.svg");
const _sfc_main = {
  __name: "DeleteModal",
  __ssrInlineRender: true,
  props: ["title", "text", "open", "btnText"],
  emits: ["deleteItem", "close"],
  setup(__props, { emit: __emit }) {
    const emits = __emit;
    function deleteItem() {
      emits("deleteItem");
    }
    function handleclose() {
      emits("close");
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-76605c9d>`);
      _push(ssrRenderComponent(unref(TransitionRoot), {
        as: "template",
        show: __props.open
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Dialog), {
              as: "div",
              class: "relative z-10",
              onClose: handleclose
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="fixed z-10 inset-0 overflow-y-auto" data-v-76605c9d${_scopeId2}><div class="flex items-center justify-center min-h-full p-4 text-center sm:p-0" data-v-76605c9d${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                    "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                    "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-sm sm:w-full" data-v-76605c9d${_scopeId3}><div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" data-v-76605c9d${_scopeId3}><div class="flex justify-between mb-5 items-center" data-v-76605c9d${_scopeId3}><div data-v-76605c9d${_scopeId3}><img${ssrRenderAttr("src", _imports_0)} data-v-76605c9d${_scopeId3}></div><span class="absolute top-3 right-3" data-v-76605c9d${_scopeId3}><i class="uil uil-times cursor-pointer text-lg text-[#98A2B3]" data-v-76605c9d${_scopeId3}></i></span></div>`);
                        if (__props.title) {
                          _push4(`<h4 class="font-semibold text-[#101828] text-lg" data-v-76605c9d${_scopeId3}>${ssrInterpolate(__props.title)}</h4>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        if (__props.text) {
                          _push4(`<p class="text-sm text-[#475467]" data-v-76605c9d${_scopeId3}>${ssrInterpolate(__props.text)}</p>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(`<div class="flex justify-end gap-x-3 items-center mt-8" data-v-76605c9d${_scopeId3}><button type="button" class="appearance-none leading-none px-4 py-[10px] rounded-lg text-matta-black hover:bg-gray-100 text-sm w-full border border-[#D0D5DD] font-medium" data-v-76605c9d${_scopeId3}> Cancel </button><button type="button" class="appearance-none leading-none px-4 py-[10px] rounded-lg text-white bg-[#D92D20] text-sm w-full border border-[#D92D20] font-medium" data-v-76605c9d${_scopeId3}>${ssrInterpolate(__props.btnText)}</button></div></div></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-sm sm:w-full" }, [
                            createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" }, [
                              createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                                createVNode("div", null, [
                                  createVNode("img", { src: _imports_0 })
                                ]),
                                createVNode("span", {
                                  onClick: handleclose,
                                  class: "absolute top-3 right-3"
                                }, [
                                  createVNode("i", { class: "uil uil-times cursor-pointer text-lg text-[#98A2B3]" })
                                ])
                              ]),
                              __props.title ? (openBlock(), createBlock("h4", {
                                key: 0,
                                class: "font-semibold text-[#101828] text-lg"
                              }, toDisplayString(__props.title), 1)) : createCommentVNode("", true),
                              __props.text ? (openBlock(), createBlock("p", {
                                key: 1,
                                class: "text-sm text-[#475467]"
                              }, toDisplayString(__props.text), 1)) : createCommentVNode("", true),
                              createVNode("div", { class: "flex justify-end gap-x-3 items-center mt-8" }, [
                                createVNode("button", {
                                  type: "button",
                                  onClick: handleclose,
                                  class: "appearance-none leading-none px-4 py-[10px] rounded-lg text-matta-black hover:bg-gray-100 text-sm w-full border border-[#D0D5DD] font-medium"
                                }, " Cancel "),
                                createVNode("button", {
                                  type: "button",
                                  onClick: deleteItem,
                                  class: "appearance-none leading-none px-4 py-[10px] rounded-lg text-white bg-[#D92D20] text-sm w-full border border-[#D92D20] font-medium"
                                }, toDisplayString(__props.btnText), 1)
                              ])
                            ])
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode(unref(TransitionChild), {
                      as: "template",
                      enter: "ease-out duration-300",
                      "enter-from": "opacity-0",
                      "enter-to": "opacity-100",
                      leave: "ease-in duration-200",
                      "leave-from": "opacity-100",
                      "leave-to": "opacity-0"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" })
                      ]),
                      _: 1
                    }),
                    createVNode("div", { class: "fixed z-10 inset-0 overflow-y-auto" }, [
                      createVNode("div", { class: "flex items-center justify-center min-h-full p-4 text-center sm:p-0" }, [
                        createVNode(unref(TransitionChild), {
                          as: "template",
                          enter: "ease-out duration-300",
                          "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                          "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                          leave: "ease-in duration-200",
                          "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                          "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                        }, {
                          default: withCtx(() => [
                            createVNode("div", { class: "relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-sm sm:w-full" }, [
                              createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" }, [
                                createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                                  createVNode("div", null, [
                                    createVNode("img", { src: _imports_0 })
                                  ]),
                                  createVNode("span", {
                                    onClick: handleclose,
                                    class: "absolute top-3 right-3"
                                  }, [
                                    createVNode("i", { class: "uil uil-times cursor-pointer text-lg text-[#98A2B3]" })
                                  ])
                                ]),
                                __props.title ? (openBlock(), createBlock("h4", {
                                  key: 0,
                                  class: "font-semibold text-[#101828] text-lg"
                                }, toDisplayString(__props.title), 1)) : createCommentVNode("", true),
                                __props.text ? (openBlock(), createBlock("p", {
                                  key: 1,
                                  class: "text-sm text-[#475467]"
                                }, toDisplayString(__props.text), 1)) : createCommentVNode("", true),
                                createVNode("div", { class: "flex justify-end gap-x-3 items-center mt-8" }, [
                                  createVNode("button", {
                                    type: "button",
                                    onClick: handleclose,
                                    class: "appearance-none leading-none px-4 py-[10px] rounded-lg text-matta-black hover:bg-gray-100 text-sm w-full border border-[#D0D5DD] font-medium"
                                  }, " Cancel "),
                                  createVNode("button", {
                                    type: "button",
                                    onClick: deleteItem,
                                    class: "appearance-none leading-none px-4 py-[10px] rounded-lg text-white bg-[#D92D20] text-sm w-full border border-[#D92D20] font-medium"
                                  }, toDisplayString(__props.btnText), 1)
                                ])
                              ])
                            ])
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Dialog), {
                as: "div",
                class: "relative z-10",
                onClose: handleclose
              }, {
                default: withCtx(() => [
                  createVNode(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" })
                    ]),
                    _: 1
                  }),
                  createVNode("div", { class: "fixed z-10 inset-0 overflow-y-auto" }, [
                    createVNode("div", { class: "flex items-center justify-center min-h-full p-4 text-center sm:p-0" }, [
                      createVNode(unref(TransitionChild), {
                        as: "template",
                        enter: "ease-out duration-300",
                        "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                        "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                        leave: "ease-in duration-200",
                        "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                        "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                      }, {
                        default: withCtx(() => [
                          createVNode("div", { class: "relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-sm sm:w-full" }, [
                            createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" }, [
                              createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                                createVNode("div", null, [
                                  createVNode("img", { src: _imports_0 })
                                ]),
                                createVNode("span", {
                                  onClick: handleclose,
                                  class: "absolute top-3 right-3"
                                }, [
                                  createVNode("i", { class: "uil uil-times cursor-pointer text-lg text-[#98A2B3]" })
                                ])
                              ]),
                              __props.title ? (openBlock(), createBlock("h4", {
                                key: 0,
                                class: "font-semibold text-[#101828] text-lg"
                              }, toDisplayString(__props.title), 1)) : createCommentVNode("", true),
                              __props.text ? (openBlock(), createBlock("p", {
                                key: 1,
                                class: "text-sm text-[#475467]"
                              }, toDisplayString(__props.text), 1)) : createCommentVNode("", true),
                              createVNode("div", { class: "flex justify-end gap-x-3 items-center mt-8" }, [
                                createVNode("button", {
                                  type: "button",
                                  onClick: handleclose,
                                  class: "appearance-none leading-none px-4 py-[10px] rounded-lg text-matta-black hover:bg-gray-100 text-sm w-full border border-[#D0D5DD] font-medium"
                                }, " Cancel "),
                                createVNode("button", {
                                  type: "button",
                                  onClick: deleteItem,
                                  class: "appearance-none leading-none px-4 py-[10px] rounded-lg text-white bg-[#D92D20] text-sm w-full border border-[#D92D20] font-medium"
                                }, toDisplayString(__props.btnText), 1)
                              ])
                            ])
                          ])
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/DeleteModal.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-76605c9d"]]);

export { __nuxt_component_6 as _ };
//# sourceMappingURL=DeleteModal-8TLpuLoc.mjs.map
