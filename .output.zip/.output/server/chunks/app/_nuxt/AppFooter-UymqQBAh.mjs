import { _ as __nuxt_component_0$1 } from './client-only-uY1C8Tgt.mjs';
import { _ as __nuxt_component_0$2 } from './nuxt-link-fc3HHrvA.mjs';
import { _ as __nuxt_component_1$1 } from './nuxt-img-qJohECzX.mjs';
import { _ as __nuxt_component_1$2 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { useSSRContext, ref, computed, watch, provide, withCtx, createVNode, unref, createTextVNode, toDisplayString, openBlock, createBlock, createCommentVNode, Fragment, renderList, Transition, resolveComponent, inject, mergeProps, reactive, withModifiers, withDirectives, vModelText } from 'vue';
import { d as useAuthStore, f as useApplicationStore, c as useMarketStore, e as useRouter } from '../server.mjs';
import { ssrRenderComponent, ssrRenderClass, ssrRenderList, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import { m as mobileMenu, n as navigations, f as financeMenu } from './data-ZuhAAsy0.mjs';
import { u as useCartStore } from './cart-fg4oswtQ.mjs';
import { Menu, MenuButton, MenuItems, MenuItem, TransitionRoot, Dialog, TransitionChild, DialogPanel } from '@headlessui/vue';
import { b as logOut, c as sendMessage } from './authservices-pXd32gsl.mjs';
import { _ as __nuxt_component_6 } from './Center-HbcRsv6_.mjs';
import { _ as __nuxt_component_0$3 } from './IndexModal-vEF7RYpX.mjs';
import useVuelidate from '@vuelidate/core';
import { helpers, required, email, maxLength } from '@vuelidate/validators';
import { toast } from 'vue3-toastify';

const _sfc_main$4 = {
  __name: "Mobile",
  __ssrInlineRender: true,
  setup(__props) {
    const activeKey = inject("activeKey");
    const appStore = useApplicationStore();
    const store = useMarketStore();
    function handleDropDown() {
      var _a, _b, _c;
      if (((_a = activeKey == null ? void 0 : activeKey.value) == null ? void 0 : _a.toLowerCase()) === "markets") {
        return store == null ? void 0 : store.marketsData;
      }
      if (((_b = activeKey == null ? void 0 : activeKey.value) == null ? void 0 : _b.toLowerCase()) === "applications") {
        return appStore == null ? void 0 : appStore.applicationsData;
      }
      if (((_c = activeKey == null ? void 0 : activeKey.value) == null ? void 0 : _c.toLowerCase()) === "finance") {
        return financeMenu;
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1$2;
      const _component_NuxtLink = __nuxt_component_0$2;
      _push(`<!--[-->`);
      if (!unref(activeKey)) {
        _push(`<ul class="grid gap-y-[10px]"><!--[-->`);
        ssrRenderList(unref(navigations), (n) => {
          _push(`<li class="flex gap-x-1 items-center group-hover:text-[#165EF0] justify-between text-sm font-medium text-[#333]">${ssrInterpolate(n.name)} `);
          _push(ssrRenderComponent(_component_AppIcon, { icon: "pepicons-pencil:angle-right" }, null, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--></ul>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(activeKey)) {
        _push(`<button class="flex gap-x-1 items-center text-xs mb-5">`);
        _push(ssrRenderComponent(_component_AppIcon, {
          icon: "pepicons-pencil:angle-left",
          class: "text-base"
        }, null, _parent));
        _push(` Back </button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<ul class="grid gap-y-5 pb-10"><!--[-->`);
      ssrRenderList(handleDropDown(), (cat) => {
        _push(`<li class="flex gap-x-1 items-center group-hover:text-[#165EF0] justify-between text-sm font-medium text-[#333]">`);
        if (unref(activeKey).toLowerCase() !== "finance") {
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: `/${unref(activeKey).toLowerCase() === "markets" ? "market" : "application"}/${encodeURIComponent(cat.title.toLowerCase())}/${cat.id}`
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<button class="${ssrRenderClass([
                  "group flex w-full items-center  text-sm  whitespace-nowrap gap-x-2 text-[#333]"
                ])}"${_scopeId}>`);
                if (cat.imagePath) {
                  _push2(ssrRenderComponent(_component_AppIcon, {
                    icon: `fa6-solid:${cat.imagePath}`
                  }, null, _parent2, _scopeId));
                } else {
                  _push2(`<!---->`);
                }
                _push2(` ${ssrInterpolate(cat.title)}</button>`);
              } else {
                return [
                  createVNode("button", { class: [
                    "group flex w-full items-center  text-sm  whitespace-nowrap gap-x-2 text-[#333]"
                  ] }, [
                    cat.imagePath ? (openBlock(), createBlock(_component_AppIcon, {
                      key: 0,
                      icon: `fa6-solid:${cat.imagePath}`
                    }, null, 8, ["icon"])) : createCommentVNode("", true),
                    createTextVNode(" " + toDisplayString(cat.title), 1)
                  ])
                ];
              }
            }),
            _: 2
          }, _parent));
        } else {
          _push(`<button class="${ssrRenderClass([
            "group flex w-full items-center  text-sm  whitespace-nowrap gap-x-2 text-[#333]"
          ])}">`);
          if (cat.imagePath) {
            _push(ssrRenderComponent(_component_AppIcon, {
              icon: `fa6-solid:${cat.imagePath}`
            }, null, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(` ${ssrInterpolate(cat.title)}</button>`);
        }
        _push(`</li>`);
      });
      _push(`<!--]--></ul><!--]-->`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Menu/Mobile.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$4;
const _sfc_main$3 = {
  __name: "AppSideMenu",
  __ssrInlineRender: true,
  setup(__props) {
    const activeKey = ref(null);
    useCartStore();
    const authStore = useAuthStore();
    ref(false);
    const open = inject("open");
    provide("activeKey", activeKey);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1$2;
      const _component_NuxtImg = __nuxt_component_1$1;
      const _component_AppButton = __nuxt_component_4;
      const _component_MenuMobile = __nuxt_component_3;
      const _component_NuxtLink = __nuxt_component_0$2;
      _push(ssrRenderComponent(unref(TransitionRoot), mergeProps({
        as: "template",
        show: unref(open)
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Dialog), {
              as: "div",
              class: "relative z-[999]",
              onClose: ($event) => open.value = false
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-in-out duration-500",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in-out duration-500",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="fixed inset-0 bg-[#333] transition-opacity"${_scopeId3}></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "fixed inset-0 bg-[#333] transition-opacity" })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="fixed inset-0 overflow-hidden"${_scopeId2}><div class="absolute inset-0 overflow-hidden"${_scopeId2}><div class="pointer-events-none fixed inset-y-0 left-0 flex max-w-full pr-16 md:pr-10"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "transform transition ease-in-out duration-500 sm:duration-700",
                    "enter-from": "-translate-x-full",
                    "enter-to": "-translate-x-0",
                    leave: "transform transition ease-in-out duration-500 sm:duration-700",
                    "leave-from": "-translate-x-0",
                    "leave-to": "-translate-x-full"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(DialogPanel), { class: "pointer-events-auto relative w-screen max-w-md" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            var _a, _b, _c, _d, _e, _f, _g, _h;
                            if (_push5) {
                              _push5(ssrRenderComponent(unref(TransitionChild), {
                                as: "template",
                                enter: "ease-in-out duration-500",
                                "enter-from": "opacity-0",
                                "enter-to": "opacity-100",
                                leave: "ease-in-out duration-500",
                                "leave-from": "opacity-100",
                                "leave-to": "opacity-0"
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`<div class="absolute top-0 right-0 -mr-11 flex pt-4"${_scopeId5}><button type="button" class="rounded-md text-gray-300 hover:text-white outline-none"${_scopeId5}><span class="sr-only"${_scopeId5}>Close</span>`);
                                    _push6(ssrRenderComponent(_component_AppIcon, {
                                      icon: "ph:x",
                                      class: "text-xl",
                                      "aria-hidden": "true"
                                    }, null, _parent6, _scopeId5));
                                    _push6(`</button></div>`);
                                  } else {
                                    return [
                                      createVNode("div", { class: "absolute top-0 right-0 -mr-11 flex pt-4" }, [
                                        createVNode("button", {
                                          type: "button",
                                          class: "rounded-md text-gray-300 hover:text-white outline-none",
                                          onClick: ($event) => open.value = false
                                        }, [
                                          createVNode("span", { class: "sr-only" }, "Close"),
                                          createVNode(_component_AppIcon, {
                                            icon: "ph:x",
                                            class: "text-xl",
                                            "aria-hidden": "true"
                                          })
                                        ], 8, ["onClick"])
                                      ])
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(`<div class="flex h-full flex-col overflow-y-scroll bg-white shadow-xl"${_scopeId4}><div class="relative flex-1 px-4 sm:px-6"${_scopeId4}><div class="absolute inset-0 pt-5"${_scopeId4}>`);
                              if (!unref(authStore).isLoggedIn) {
                                _push5(`<div class="px-5 pb-4"${_scopeId4}>`);
                                _push5(ssrRenderComponent(_component_NuxtImg, {
                                  src: "images/logo.png",
                                  width: "100",
                                  height: "26",
                                  alt: "Matta",
                                  class: "w-[100px] h-auto"
                                }, null, _parent5, _scopeId4));
                                _push5(`</div>`);
                              } else {
                                _push5(`<!---->`);
                              }
                              if (unref(authStore).isLoggedIn) {
                                _push5(`<div class="flex gap-x-2 px-5 pb-[1px]"${_scopeId4}><span class="h-10 w-10 rounded-full flex items-center justify-center text-white bg-[#f90] font-semibold"${_scopeId4}>${ssrInterpolate((_a = unref(authStore).userInfo) == null ? void 0 : _a.firstName.slice(0, 1))} ${ssrInterpolate((_b = unref(authStore).userInfo) == null ? void 0 : _b.lastName.slice(0, 1))}</span><div class="flex-1"${_scopeId4}>`);
                                if (unref(authStore).isLoggedIn) {
                                  _push5(`<span class="text-[#333] text-sm font-semibold block capitalize"${_scopeId4}>${ssrInterpolate((_c = unref(authStore).userInfo) == null ? void 0 : _c.fullName)}</span>`);
                                } else {
                                  _push5(`<!---->`);
                                }
                                if (unref(authStore).isLoggedIn) {
                                  _push5(`<span class="block text-xs text-[#666] mb-3"${_scopeId4}>${ssrInterpolate((_d = unref(authStore).userInfo) == null ? void 0 : _d.email)}</span>`);
                                } else {
                                  _push5(`<!---->`);
                                }
                                if (unref(authStore).isLoggedIn) {
                                  _push5(`<span class="flex gap-x-1 text-xs text-[#165EF0] font-medium"${_scopeId4}>`);
                                  _push5(ssrRenderComponent(_component_AppIcon, {
                                    icon: "octicon:sign-out-16",
                                    class: "text-sm"
                                  }, null, _parent5, _scopeId4));
                                  _push5(`Sign out</span>`);
                                } else {
                                  _push5(`<!---->`);
                                }
                                _push5(`</div></div>`);
                              } else {
                                _push5(`<!---->`);
                              }
                              if (!unref(authStore).isLoggedIn) {
                                _push5(`<div class="flex gap-x-3 w-full px-5"${_scopeId4}>`);
                                _push5(ssrRenderComponent(_component_AppButton, {
                                  link: "/auth/vendor-register",
                                  text: "Become a Supplier",
                                  btnClass: "text-white !text-[13px] !font-normal  !px-[10px] !py-[6px] !normal-case bg-[#f90] flex w-full"
                                }, null, _parent5, _scopeId4));
                                if (!unref(authStore).isLoggedIn) {
                                  _push5(ssrRenderComponent(_component_AppButton, {
                                    link: "/auth/login",
                                    text: "Sign In",
                                    btnClass: "bg-primary-500  text-white !px-4 !sm:px-6 !py-[6px] !text-[13px] sm:text-sm !font-normal w-full"
                                  }, null, _parent5, _scopeId4));
                                } else {
                                  _push5(`<!---->`);
                                }
                                _push5(`</div>`);
                              } else {
                                _push5(`<!---->`);
                              }
                              _push5(`<hr class="my-[14px] border-b border-[#F4F4F4]"${_scopeId4}><div class="px-5 pt-5"${_scopeId4}>`);
                              _push5(ssrRenderComponent(_component_MenuMobile, null, null, _parent5, _scopeId4));
                              if (unref(authStore).isLoggedIn && !activeKey.value) {
                                _push5(`<hr class="border-[#F4F4F4] my-4"${_scopeId4}>`);
                              } else {
                                _push5(`<!---->`);
                              }
                              if (unref(authStore).isLoggedIn && !activeKey.value) {
                                _push5(`<ul class="grid gap-y-5"${_scopeId4}><!--[-->`);
                                ssrRenderList(unref(mobileMenu).filter(
                                  (i) => i.key !== "sign-out"
                                ), (n) => {
                                  _push5(`<li${_scopeId4}>`);
                                  _push5(ssrRenderComponent(_component_NuxtLink, {
                                    to: n.url,
                                    class: "flex gap-x-3 items-center text-sm font-medium text-[#333]"
                                  }, {
                                    default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                      if (_push6) {
                                        _push6(ssrRenderComponent(_component_AppIcon, {
                                          icon: n.icon
                                        }, null, _parent6, _scopeId5));
                                        _push6(` ${ssrInterpolate(n.name)}`);
                                      } else {
                                        return [
                                          createVNode(_component_AppIcon, {
                                            icon: n.icon
                                          }, null, 8, ["icon"]),
                                          createTextVNode(" " + toDisplayString(n.name), 1)
                                        ];
                                      }
                                    }),
                                    _: 2
                                  }, _parent5, _scopeId4));
                                  _push5(`</li>`);
                                });
                                _push5(`<!--]--></ul>`);
                              } else {
                                _push5(`<!---->`);
                              }
                              _push5(`</div></div></div></div>`);
                            } else {
                              return [
                                createVNode(unref(TransitionChild), {
                                  as: "template",
                                  enter: "ease-in-out duration-500",
                                  "enter-from": "opacity-0",
                                  "enter-to": "opacity-100",
                                  leave: "ease-in-out duration-500",
                                  "leave-from": "opacity-100",
                                  "leave-to": "opacity-0"
                                }, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "absolute top-0 right-0 -mr-11 flex pt-4" }, [
                                      createVNode("button", {
                                        type: "button",
                                        class: "rounded-md text-gray-300 hover:text-white outline-none",
                                        onClick: ($event) => open.value = false
                                      }, [
                                        createVNode("span", { class: "sr-only" }, "Close"),
                                        createVNode(_component_AppIcon, {
                                          icon: "ph:x",
                                          class: "text-xl",
                                          "aria-hidden": "true"
                                        })
                                      ], 8, ["onClick"])
                                    ])
                                  ]),
                                  _: 1
                                }),
                                createVNode("div", { class: "flex h-full flex-col overflow-y-scroll bg-white shadow-xl" }, [
                                  createVNode("div", { class: "relative flex-1 px-4 sm:px-6" }, [
                                    createVNode("div", { class: "absolute inset-0 pt-5" }, [
                                      !unref(authStore).isLoggedIn ? (openBlock(), createBlock("div", {
                                        key: 0,
                                        class: "px-5 pb-4"
                                      }, [
                                        createVNode(_component_NuxtImg, {
                                          src: "images/logo.png",
                                          width: "100",
                                          height: "26",
                                          alt: "Matta",
                                          class: "w-[100px] h-auto"
                                        })
                                      ])) : createCommentVNode("", true),
                                      unref(authStore).isLoggedIn ? (openBlock(), createBlock("div", {
                                        key: 1,
                                        class: "flex gap-x-2 px-5 pb-[1px]"
                                      }, [
                                        createVNode("span", { class: "h-10 w-10 rounded-full flex items-center justify-center text-white bg-[#f90] font-semibold" }, toDisplayString((_e = unref(authStore).userInfo) == null ? void 0 : _e.firstName.slice(0, 1)) + " " + toDisplayString((_f = unref(authStore).userInfo) == null ? void 0 : _f.lastName.slice(0, 1)), 1),
                                        createVNode("div", { class: "flex-1" }, [
                                          unref(authStore).isLoggedIn ? (openBlock(), createBlock("span", {
                                            key: 0,
                                            class: "text-[#333] text-sm font-semibold block capitalize"
                                          }, toDisplayString((_g = unref(authStore).userInfo) == null ? void 0 : _g.fullName), 1)) : createCommentVNode("", true),
                                          unref(authStore).isLoggedIn ? (openBlock(), createBlock("span", {
                                            key: 1,
                                            class: "block text-xs text-[#666] mb-3"
                                          }, toDisplayString((_h = unref(authStore).userInfo) == null ? void 0 : _h.email), 1)) : createCommentVNode("", true),
                                          unref(authStore).isLoggedIn ? (openBlock(), createBlock("span", {
                                            key: 2,
                                            onClick: ($event) => unref(logOut)(),
                                            class: "flex gap-x-1 text-xs text-[#165EF0] font-medium"
                                          }, [
                                            createVNode(_component_AppIcon, {
                                              icon: "octicon:sign-out-16",
                                              class: "text-sm"
                                            }),
                                            createTextVNode("Sign out")
                                          ], 8, ["onClick"])) : createCommentVNode("", true)
                                        ])
                                      ])) : createCommentVNode("", true),
                                      !unref(authStore).isLoggedIn ? (openBlock(), createBlock("div", {
                                        key: 2,
                                        class: "flex gap-x-3 w-full px-5"
                                      }, [
                                        createVNode(_component_AppButton, {
                                          link: "/auth/vendor-register",
                                          text: "Become a Supplier",
                                          btnClass: "text-white !text-[13px] !font-normal  !px-[10px] !py-[6px] !normal-case bg-[#f90] flex w-full"
                                        }),
                                        !unref(authStore).isLoggedIn ? (openBlock(), createBlock(_component_AppButton, {
                                          key: 0,
                                          link: "/auth/login",
                                          text: "Sign In",
                                          btnClass: "bg-primary-500  text-white !px-4 !sm:px-6 !py-[6px] !text-[13px] sm:text-sm !font-normal w-full"
                                        })) : createCommentVNode("", true)
                                      ])) : createCommentVNode("", true),
                                      createVNode("hr", { class: "my-[14px] border-b border-[#F4F4F4]" }),
                                      createVNode("div", { class: "px-5 pt-5" }, [
                                        createVNode(_component_MenuMobile),
                                        unref(authStore).isLoggedIn && !activeKey.value ? (openBlock(), createBlock("hr", {
                                          key: 0,
                                          class: "border-[#F4F4F4] my-4"
                                        })) : createCommentVNode("", true),
                                        unref(authStore).isLoggedIn && !activeKey.value ? (openBlock(), createBlock("ul", {
                                          key: 1,
                                          class: "grid gap-y-5"
                                        }, [
                                          (openBlock(true), createBlock(Fragment, null, renderList(unref(mobileMenu).filter(
                                            (i) => i.key !== "sign-out"
                                          ), (n) => {
                                            return openBlock(), createBlock("li", {
                                              key: n.name
                                            }, [
                                              createVNode(_component_NuxtLink, {
                                                to: n.url,
                                                class: "flex gap-x-3 items-center text-sm font-medium text-[#333]"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_AppIcon, {
                                                    icon: n.icon
                                                  }, null, 8, ["icon"]),
                                                  createTextVNode(" " + toDisplayString(n.name), 1)
                                                ]),
                                                _: 2
                                              }, 1032, ["to"])
                                            ]);
                                          }), 128))
                                        ])) : createCommentVNode("", true)
                                      ])
                                    ])
                                  ])
                                ])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(DialogPanel), { class: "pointer-events-auto relative w-screen max-w-md" }, {
                            default: withCtx(() => {
                              var _a, _b, _c, _d;
                              return [
                                createVNode(unref(TransitionChild), {
                                  as: "template",
                                  enter: "ease-in-out duration-500",
                                  "enter-from": "opacity-0",
                                  "enter-to": "opacity-100",
                                  leave: "ease-in-out duration-500",
                                  "leave-from": "opacity-100",
                                  "leave-to": "opacity-0"
                                }, {
                                  default: withCtx(() => [
                                    createVNode("div", { class: "absolute top-0 right-0 -mr-11 flex pt-4" }, [
                                      createVNode("button", {
                                        type: "button",
                                        class: "rounded-md text-gray-300 hover:text-white outline-none",
                                        onClick: ($event) => open.value = false
                                      }, [
                                        createVNode("span", { class: "sr-only" }, "Close"),
                                        createVNode(_component_AppIcon, {
                                          icon: "ph:x",
                                          class: "text-xl",
                                          "aria-hidden": "true"
                                        })
                                      ], 8, ["onClick"])
                                    ])
                                  ]),
                                  _: 1
                                }),
                                createVNode("div", { class: "flex h-full flex-col overflow-y-scroll bg-white shadow-xl" }, [
                                  createVNode("div", { class: "relative flex-1 px-4 sm:px-6" }, [
                                    createVNode("div", { class: "absolute inset-0 pt-5" }, [
                                      !unref(authStore).isLoggedIn ? (openBlock(), createBlock("div", {
                                        key: 0,
                                        class: "px-5 pb-4"
                                      }, [
                                        createVNode(_component_NuxtImg, {
                                          src: "images/logo.png",
                                          width: "100",
                                          height: "26",
                                          alt: "Matta",
                                          class: "w-[100px] h-auto"
                                        })
                                      ])) : createCommentVNode("", true),
                                      unref(authStore).isLoggedIn ? (openBlock(), createBlock("div", {
                                        key: 1,
                                        class: "flex gap-x-2 px-5 pb-[1px]"
                                      }, [
                                        createVNode("span", { class: "h-10 w-10 rounded-full flex items-center justify-center text-white bg-[#f90] font-semibold" }, toDisplayString((_a = unref(authStore).userInfo) == null ? void 0 : _a.firstName.slice(0, 1)) + " " + toDisplayString((_b = unref(authStore).userInfo) == null ? void 0 : _b.lastName.slice(0, 1)), 1),
                                        createVNode("div", { class: "flex-1" }, [
                                          unref(authStore).isLoggedIn ? (openBlock(), createBlock("span", {
                                            key: 0,
                                            class: "text-[#333] text-sm font-semibold block capitalize"
                                          }, toDisplayString((_c = unref(authStore).userInfo) == null ? void 0 : _c.fullName), 1)) : createCommentVNode("", true),
                                          unref(authStore).isLoggedIn ? (openBlock(), createBlock("span", {
                                            key: 1,
                                            class: "block text-xs text-[#666] mb-3"
                                          }, toDisplayString((_d = unref(authStore).userInfo) == null ? void 0 : _d.email), 1)) : createCommentVNode("", true),
                                          unref(authStore).isLoggedIn ? (openBlock(), createBlock("span", {
                                            key: 2,
                                            onClick: ($event) => unref(logOut)(),
                                            class: "flex gap-x-1 text-xs text-[#165EF0] font-medium"
                                          }, [
                                            createVNode(_component_AppIcon, {
                                              icon: "octicon:sign-out-16",
                                              class: "text-sm"
                                            }),
                                            createTextVNode("Sign out")
                                          ], 8, ["onClick"])) : createCommentVNode("", true)
                                        ])
                                      ])) : createCommentVNode("", true),
                                      !unref(authStore).isLoggedIn ? (openBlock(), createBlock("div", {
                                        key: 2,
                                        class: "flex gap-x-3 w-full px-5"
                                      }, [
                                        createVNode(_component_AppButton, {
                                          link: "/auth/vendor-register",
                                          text: "Become a Supplier",
                                          btnClass: "text-white !text-[13px] !font-normal  !px-[10px] !py-[6px] !normal-case bg-[#f90] flex w-full"
                                        }),
                                        !unref(authStore).isLoggedIn ? (openBlock(), createBlock(_component_AppButton, {
                                          key: 0,
                                          link: "/auth/login",
                                          text: "Sign In",
                                          btnClass: "bg-primary-500  text-white !px-4 !sm:px-6 !py-[6px] !text-[13px] sm:text-sm !font-normal w-full"
                                        })) : createCommentVNode("", true)
                                      ])) : createCommentVNode("", true),
                                      createVNode("hr", { class: "my-[14px] border-b border-[#F4F4F4]" }),
                                      createVNode("div", { class: "px-5 pt-5" }, [
                                        createVNode(_component_MenuMobile),
                                        unref(authStore).isLoggedIn && !activeKey.value ? (openBlock(), createBlock("hr", {
                                          key: 0,
                                          class: "border-[#F4F4F4] my-4"
                                        })) : createCommentVNode("", true),
                                        unref(authStore).isLoggedIn && !activeKey.value ? (openBlock(), createBlock("ul", {
                                          key: 1,
                                          class: "grid gap-y-5"
                                        }, [
                                          (openBlock(true), createBlock(Fragment, null, renderList(unref(mobileMenu).filter(
                                            (i) => i.key !== "sign-out"
                                          ), (n) => {
                                            return openBlock(), createBlock("li", {
                                              key: n.name
                                            }, [
                                              createVNode(_component_NuxtLink, {
                                                to: n.url,
                                                class: "flex gap-x-3 items-center text-sm font-medium text-[#333]"
                                              }, {
                                                default: withCtx(() => [
                                                  createVNode(_component_AppIcon, {
                                                    icon: n.icon
                                                  }, null, 8, ["icon"]),
                                                  createTextVNode(" " + toDisplayString(n.name), 1)
                                                ]),
                                                _: 2
                                              }, 1032, ["to"])
                                            ]);
                                          }), 128))
                                        ])) : createCommentVNode("", true)
                                      ])
                                    ])
                                  ])
                                ])
                              ];
                            }),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div></div>`);
                } else {
                  return [
                    createVNode(unref(TransitionChild), {
                      as: "template",
                      enter: "ease-in-out duration-500",
                      "enter-from": "opacity-0",
                      "enter-to": "opacity-100",
                      leave: "ease-in-out duration-500",
                      "leave-from": "opacity-100",
                      "leave-to": "opacity-0"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "fixed inset-0 bg-[#333] transition-opacity" })
                      ]),
                      _: 1
                    }),
                    createVNode("div", { class: "fixed inset-0 overflow-hidden" }, [
                      createVNode("div", { class: "absolute inset-0 overflow-hidden" }, [
                        createVNode("div", { class: "pointer-events-none fixed inset-y-0 left-0 flex max-w-full pr-16 md:pr-10" }, [
                          createVNode(unref(TransitionChild), {
                            as: "template",
                            enter: "transform transition ease-in-out duration-500 sm:duration-700",
                            "enter-from": "-translate-x-full",
                            "enter-to": "-translate-x-0",
                            leave: "transform transition ease-in-out duration-500 sm:duration-700",
                            "leave-from": "-translate-x-0",
                            "leave-to": "-translate-x-full"
                          }, {
                            default: withCtx(() => [
                              createVNode(unref(DialogPanel), { class: "pointer-events-auto relative w-screen max-w-md" }, {
                                default: withCtx(() => {
                                  var _a, _b, _c, _d;
                                  return [
                                    createVNode(unref(TransitionChild), {
                                      as: "template",
                                      enter: "ease-in-out duration-500",
                                      "enter-from": "opacity-0",
                                      "enter-to": "opacity-100",
                                      leave: "ease-in-out duration-500",
                                      "leave-from": "opacity-100",
                                      "leave-to": "opacity-0"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode("div", { class: "absolute top-0 right-0 -mr-11 flex pt-4" }, [
                                          createVNode("button", {
                                            type: "button",
                                            class: "rounded-md text-gray-300 hover:text-white outline-none",
                                            onClick: ($event) => open.value = false
                                          }, [
                                            createVNode("span", { class: "sr-only" }, "Close"),
                                            createVNode(_component_AppIcon, {
                                              icon: "ph:x",
                                              class: "text-xl",
                                              "aria-hidden": "true"
                                            })
                                          ], 8, ["onClick"])
                                        ])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode("div", { class: "flex h-full flex-col overflow-y-scroll bg-white shadow-xl" }, [
                                      createVNode("div", { class: "relative flex-1 px-4 sm:px-6" }, [
                                        createVNode("div", { class: "absolute inset-0 pt-5" }, [
                                          !unref(authStore).isLoggedIn ? (openBlock(), createBlock("div", {
                                            key: 0,
                                            class: "px-5 pb-4"
                                          }, [
                                            createVNode(_component_NuxtImg, {
                                              src: "images/logo.png",
                                              width: "100",
                                              height: "26",
                                              alt: "Matta",
                                              class: "w-[100px] h-auto"
                                            })
                                          ])) : createCommentVNode("", true),
                                          unref(authStore).isLoggedIn ? (openBlock(), createBlock("div", {
                                            key: 1,
                                            class: "flex gap-x-2 px-5 pb-[1px]"
                                          }, [
                                            createVNode("span", { class: "h-10 w-10 rounded-full flex items-center justify-center text-white bg-[#f90] font-semibold" }, toDisplayString((_a = unref(authStore).userInfo) == null ? void 0 : _a.firstName.slice(0, 1)) + " " + toDisplayString((_b = unref(authStore).userInfo) == null ? void 0 : _b.lastName.slice(0, 1)), 1),
                                            createVNode("div", { class: "flex-1" }, [
                                              unref(authStore).isLoggedIn ? (openBlock(), createBlock("span", {
                                                key: 0,
                                                class: "text-[#333] text-sm font-semibold block capitalize"
                                              }, toDisplayString((_c = unref(authStore).userInfo) == null ? void 0 : _c.fullName), 1)) : createCommentVNode("", true),
                                              unref(authStore).isLoggedIn ? (openBlock(), createBlock("span", {
                                                key: 1,
                                                class: "block text-xs text-[#666] mb-3"
                                              }, toDisplayString((_d = unref(authStore).userInfo) == null ? void 0 : _d.email), 1)) : createCommentVNode("", true),
                                              unref(authStore).isLoggedIn ? (openBlock(), createBlock("span", {
                                                key: 2,
                                                onClick: ($event) => unref(logOut)(),
                                                class: "flex gap-x-1 text-xs text-[#165EF0] font-medium"
                                              }, [
                                                createVNode(_component_AppIcon, {
                                                  icon: "octicon:sign-out-16",
                                                  class: "text-sm"
                                                }),
                                                createTextVNode("Sign out")
                                              ], 8, ["onClick"])) : createCommentVNode("", true)
                                            ])
                                          ])) : createCommentVNode("", true),
                                          !unref(authStore).isLoggedIn ? (openBlock(), createBlock("div", {
                                            key: 2,
                                            class: "flex gap-x-3 w-full px-5"
                                          }, [
                                            createVNode(_component_AppButton, {
                                              link: "/auth/vendor-register",
                                              text: "Become a Supplier",
                                              btnClass: "text-white !text-[13px] !font-normal  !px-[10px] !py-[6px] !normal-case bg-[#f90] flex w-full"
                                            }),
                                            !unref(authStore).isLoggedIn ? (openBlock(), createBlock(_component_AppButton, {
                                              key: 0,
                                              link: "/auth/login",
                                              text: "Sign In",
                                              btnClass: "bg-primary-500  text-white !px-4 !sm:px-6 !py-[6px] !text-[13px] sm:text-sm !font-normal w-full"
                                            })) : createCommentVNode("", true)
                                          ])) : createCommentVNode("", true),
                                          createVNode("hr", { class: "my-[14px] border-b border-[#F4F4F4]" }),
                                          createVNode("div", { class: "px-5 pt-5" }, [
                                            createVNode(_component_MenuMobile),
                                            unref(authStore).isLoggedIn && !activeKey.value ? (openBlock(), createBlock("hr", {
                                              key: 0,
                                              class: "border-[#F4F4F4] my-4"
                                            })) : createCommentVNode("", true),
                                            unref(authStore).isLoggedIn && !activeKey.value ? (openBlock(), createBlock("ul", {
                                              key: 1,
                                              class: "grid gap-y-5"
                                            }, [
                                              (openBlock(true), createBlock(Fragment, null, renderList(unref(mobileMenu).filter(
                                                (i) => i.key !== "sign-out"
                                              ), (n) => {
                                                return openBlock(), createBlock("li", {
                                                  key: n.name
                                                }, [
                                                  createVNode(_component_NuxtLink, {
                                                    to: n.url,
                                                    class: "flex gap-x-3 items-center text-sm font-medium text-[#333]"
                                                  }, {
                                                    default: withCtx(() => [
                                                      createVNode(_component_AppIcon, {
                                                        icon: n.icon
                                                      }, null, 8, ["icon"]),
                                                      createTextVNode(" " + toDisplayString(n.name), 1)
                                                    ]),
                                                    _: 2
                                                  }, 1032, ["to"])
                                                ]);
                                              }), 128))
                                            ])) : createCommentVNode("", true)
                                          ])
                                        ])
                                      ])
                                    ])
                                  ];
                                }),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Dialog), {
                as: "div",
                class: "relative z-[999]",
                onClose: ($event) => open.value = false
              }, {
                default: withCtx(() => [
                  createVNode(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-in-out duration-500",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in-out duration-500",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "fixed inset-0 bg-[#333] transition-opacity" })
                    ]),
                    _: 1
                  }),
                  createVNode("div", { class: "fixed inset-0 overflow-hidden" }, [
                    createVNode("div", { class: "absolute inset-0 overflow-hidden" }, [
                      createVNode("div", { class: "pointer-events-none fixed inset-y-0 left-0 flex max-w-full pr-16 md:pr-10" }, [
                        createVNode(unref(TransitionChild), {
                          as: "template",
                          enter: "transform transition ease-in-out duration-500 sm:duration-700",
                          "enter-from": "-translate-x-full",
                          "enter-to": "-translate-x-0",
                          leave: "transform transition ease-in-out duration-500 sm:duration-700",
                          "leave-from": "-translate-x-0",
                          "leave-to": "-translate-x-full"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(DialogPanel), { class: "pointer-events-auto relative w-screen max-w-md" }, {
                              default: withCtx(() => {
                                var _a, _b, _c, _d;
                                return [
                                  createVNode(unref(TransitionChild), {
                                    as: "template",
                                    enter: "ease-in-out duration-500",
                                    "enter-from": "opacity-0",
                                    "enter-to": "opacity-100",
                                    leave: "ease-in-out duration-500",
                                    "leave-from": "opacity-100",
                                    "leave-to": "opacity-0"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("div", { class: "absolute top-0 right-0 -mr-11 flex pt-4" }, [
                                        createVNode("button", {
                                          type: "button",
                                          class: "rounded-md text-gray-300 hover:text-white outline-none",
                                          onClick: ($event) => open.value = false
                                        }, [
                                          createVNode("span", { class: "sr-only" }, "Close"),
                                          createVNode(_component_AppIcon, {
                                            icon: "ph:x",
                                            class: "text-xl",
                                            "aria-hidden": "true"
                                          })
                                        ], 8, ["onClick"])
                                      ])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode("div", { class: "flex h-full flex-col overflow-y-scroll bg-white shadow-xl" }, [
                                    createVNode("div", { class: "relative flex-1 px-4 sm:px-6" }, [
                                      createVNode("div", { class: "absolute inset-0 pt-5" }, [
                                        !unref(authStore).isLoggedIn ? (openBlock(), createBlock("div", {
                                          key: 0,
                                          class: "px-5 pb-4"
                                        }, [
                                          createVNode(_component_NuxtImg, {
                                            src: "images/logo.png",
                                            width: "100",
                                            height: "26",
                                            alt: "Matta",
                                            class: "w-[100px] h-auto"
                                          })
                                        ])) : createCommentVNode("", true),
                                        unref(authStore).isLoggedIn ? (openBlock(), createBlock("div", {
                                          key: 1,
                                          class: "flex gap-x-2 px-5 pb-[1px]"
                                        }, [
                                          createVNode("span", { class: "h-10 w-10 rounded-full flex items-center justify-center text-white bg-[#f90] font-semibold" }, toDisplayString((_a = unref(authStore).userInfo) == null ? void 0 : _a.firstName.slice(0, 1)) + " " + toDisplayString((_b = unref(authStore).userInfo) == null ? void 0 : _b.lastName.slice(0, 1)), 1),
                                          createVNode("div", { class: "flex-1" }, [
                                            unref(authStore).isLoggedIn ? (openBlock(), createBlock("span", {
                                              key: 0,
                                              class: "text-[#333] text-sm font-semibold block capitalize"
                                            }, toDisplayString((_c = unref(authStore).userInfo) == null ? void 0 : _c.fullName), 1)) : createCommentVNode("", true),
                                            unref(authStore).isLoggedIn ? (openBlock(), createBlock("span", {
                                              key: 1,
                                              class: "block text-xs text-[#666] mb-3"
                                            }, toDisplayString((_d = unref(authStore).userInfo) == null ? void 0 : _d.email), 1)) : createCommentVNode("", true),
                                            unref(authStore).isLoggedIn ? (openBlock(), createBlock("span", {
                                              key: 2,
                                              onClick: ($event) => unref(logOut)(),
                                              class: "flex gap-x-1 text-xs text-[#165EF0] font-medium"
                                            }, [
                                              createVNode(_component_AppIcon, {
                                                icon: "octicon:sign-out-16",
                                                class: "text-sm"
                                              }),
                                              createTextVNode("Sign out")
                                            ], 8, ["onClick"])) : createCommentVNode("", true)
                                          ])
                                        ])) : createCommentVNode("", true),
                                        !unref(authStore).isLoggedIn ? (openBlock(), createBlock("div", {
                                          key: 2,
                                          class: "flex gap-x-3 w-full px-5"
                                        }, [
                                          createVNode(_component_AppButton, {
                                            link: "/auth/vendor-register",
                                            text: "Become a Supplier",
                                            btnClass: "text-white !text-[13px] !font-normal  !px-[10px] !py-[6px] !normal-case bg-[#f90] flex w-full"
                                          }),
                                          !unref(authStore).isLoggedIn ? (openBlock(), createBlock(_component_AppButton, {
                                            key: 0,
                                            link: "/auth/login",
                                            text: "Sign In",
                                            btnClass: "bg-primary-500  text-white !px-4 !sm:px-6 !py-[6px] !text-[13px] sm:text-sm !font-normal w-full"
                                          })) : createCommentVNode("", true)
                                        ])) : createCommentVNode("", true),
                                        createVNode("hr", { class: "my-[14px] border-b border-[#F4F4F4]" }),
                                        createVNode("div", { class: "px-5 pt-5" }, [
                                          createVNode(_component_MenuMobile),
                                          unref(authStore).isLoggedIn && !activeKey.value ? (openBlock(), createBlock("hr", {
                                            key: 0,
                                            class: "border-[#F4F4F4] my-4"
                                          })) : createCommentVNode("", true),
                                          unref(authStore).isLoggedIn && !activeKey.value ? (openBlock(), createBlock("ul", {
                                            key: 1,
                                            class: "grid gap-y-5"
                                          }, [
                                            (openBlock(true), createBlock(Fragment, null, renderList(unref(mobileMenu).filter(
                                              (i) => i.key !== "sign-out"
                                            ), (n) => {
                                              return openBlock(), createBlock("li", {
                                                key: n.name
                                              }, [
                                                createVNode(_component_NuxtLink, {
                                                  to: n.url,
                                                  class: "flex gap-x-3 items-center text-sm font-medium text-[#333]"
                                                }, {
                                                  default: withCtx(() => [
                                                    createVNode(_component_AppIcon, {
                                                      icon: n.icon
                                                    }, null, 8, ["icon"]),
                                                    createTextVNode(" " + toDisplayString(n.name), 1)
                                                  ]),
                                                  _: 2
                                                }, 1032, ["to"])
                                              ]);
                                            }), 128))
                                          ])) : createCommentVNode("", true)
                                        ])
                                      ])
                                    ])
                                  ])
                                ];
                              }),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ])
                ]),
                _: 1
              }, 8, ["onClose"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/AppSideMenu.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_5 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "AppHeader",
  __ssrInlineRender: true,
  setup(__props) {
    const isSigniningOut = ref(false);
    const cartStore = useCartStore();
    const authStore = useAuthStore();
    const appStore = useApplicationStore();
    const store = useMarketStore();
    const router = useRouter();
    const { currentRoute } = router;
    const filteredMenu = computed(
      () => mobileMenu.filter(
        (i) => i.key === "profile" || i.key === "wallet" || i.key === "sign-out" || i.key === "my-orders"
      )
    );
    const view = ref({
      atTopOfPage: true
    });
    const open = ref(false);
    function handleDropDown(val) {
      if (val === "markets") {
        return store == null ? void 0 : store.marketsData;
      }
      if (val === "applications") {
        return appStore == null ? void 0 : appStore.applicationsData;
      }
      if (val === "finance") {
        return financeMenu;
      }
    }
    watch(currentRoute, () => {
      open.value = false;
    });
    provide("open", open);
    provide("isOpen", isSigniningOut);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_0$1;
      const _component_NuxtLink = __nuxt_component_0$2;
      const _component_NuxtImg = __nuxt_component_1$1;
      const _component_AppIcon = __nuxt_component_1$2;
      const _component_AppButton = __nuxt_component_4;
      const _component_AppSideMenu = __nuxt_component_5;
      const _component_ModalCenter = __nuxt_component_6;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`<nav class="${ssrRenderClass([{
        relative: view.value.atTopOfPage,
        "sticky top-0 opacity-95 fade-in-top pb-5 lg:pb-5 border-b border-[rgba(242, 242, 242, 1)] darks:border-gray-900": !view.value.atTopOfPage
      }, "relative pt-6 pb-6 w-full bg-white darks:bg-gray-800 z-[999] transition-all duration-500 ease-in-out"])}"><div class="container mx-auto"><div class="flex justify-between items-center gap-x-5"><div class="logo flex gap-x-10 items-center">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_NuxtImg, {
              src: "/images/logo.png",
              alt: "Matta",
              class: "w-20 md:w-[100px] h-auto object-contain"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_NuxtImg, {
                src: "/images/logo.png",
                alt: "Matta",
                class: "w-20 md:w-[100px] h-auto object-contain"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<ul class="lg:flex items-center gap-x-6 hidden"><!--[-->`);
      ssrRenderList(unref(navigations), (n) => {
        var _a, _b, _c;
        _push(`<li class="${ssrRenderClass([`${((_b = (_a = unref(currentRoute)) == null ? void 0 : _a.name) == null ? void 0 : _b.toLowerCase()) == ((_c = n == null ? void 0 : n.name) == null ? void 0 : _c.toLowerCase()) ? "border-[#165EF0]" : ""}`, "flex gap-x-[6px] items-center text-sm border-transparent group"])}">`);
        if (!n.url) {
          _push(ssrRenderComponent(unref(Menu), {
            as: "div",
            class: "relative inline-block text-left"
          }, {
            default: withCtx(({ open: open2 }, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(unref(MenuButton), {
                  id: n.name,
                  class: "flex gap-x-1 items-center group-hover:text-[#165EF0]"
                }, {
                  default: withCtx((_, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`${ssrInterpolate(n.name)} `);
                      _push3(ssrRenderComponent(_component_AppIcon, {
                        icon: open2 ? "pepicons-pencil:angle-up" : "pepicons-pencil:angle-down"
                      }, null, _parent3, _scopeId2));
                    } else {
                      return [
                        createTextVNode(toDisplayString(n.name) + " ", 1),
                        createVNode(_component_AppIcon, {
                          icon: open2 ? "pepicons-pencil:angle-up" : "pepicons-pencil:angle-down"
                        }, null, 8, ["icon"])
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(``);
                _push2(ssrRenderComponent(unref(MenuItems), { class: "z-[999] grid grid-cols-1 absolute left-0 mt-[22px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] w-[303px] origin-top-right bg-white darks:bg-gray-800 rounded-b-[10px] px-5 py-5 text-sm" }, {
                  default: withCtx((_, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<!--[-->`);
                      ssrRenderList(handleDropDown(n.key), (cat) => {
                        _push3(`<div class=""${_scopeId2}>`);
                        _push3(ssrRenderComponent(unref(MenuItem), null, {
                          default: withCtx(({ active }, _push4, _parent4, _scopeId3) => {
                            if (_push4) {
                              if (n.key !== "finance") {
                                _push4(ssrRenderComponent(_component_NuxtLink, {
                                  to: `/${n.key === "markets" ? "market" : "application"}/${encodeURIComponent(cat.title.toLowerCase())}/${cat.id}`
                                }, {
                                  default: withCtx((_2, _push5, _parent5, _scopeId4) => {
                                    if (_push5) {
                                      _push5(`<button class="${ssrRenderClass([
                                        "group flex w-full items-center rounded-md px-[14px] py-[11px] text-sm hover:bg-[rgba(22,94,240,0.09)] whitespace-nowrap gap-x-2 text-[#333] "
                                      ])}"${_scopeId4}>`);
                                      if (n.key === "markets" || n.key === "applications") {
                                        _push5(ssrRenderComponent(_component_AppIcon, {
                                          icon: `fa6-solid:${cat.imagePath}`
                                        }, null, _parent5, _scopeId4));
                                      } else {
                                        _push5(`<!---->`);
                                      }
                                      _push5(` ${ssrInterpolate(cat.title)}</button>`);
                                    } else {
                                      return [
                                        createVNode("button", { class: [
                                          "group flex w-full items-center rounded-md px-[14px] py-[11px] text-sm hover:bg-[rgba(22,94,240,0.09)] whitespace-nowrap gap-x-2 text-[#333] "
                                        ] }, [
                                          n.key === "markets" || n.key === "applications" ? (openBlock(), createBlock(_component_AppIcon, {
                                            key: 0,
                                            icon: `fa6-solid:${cat.imagePath}`
                                          }, null, 8, ["icon"])) : createCommentVNode("", true),
                                          createTextVNode(" " + toDisplayString(cat.title), 1)
                                        ], 2)
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent4, _scopeId3));
                              } else {
                                _push4(`<button class="${ssrRenderClass([
                                  "group flex w-full items-center rounded-md px-[14px] py-[11px] text-sm hover:bg-[rgba(22,94,240,0.09)] whitespace-nowrap gap-x-2 text-[#333] "
                                ])}"${_scopeId3}>`);
                                if (n.key === "markets" || n.key === "applications") {
                                  _push4(ssrRenderComponent(_component_AppIcon, {
                                    icon: `fa6-solid:${cat.imagePath}`
                                  }, null, _parent4, _scopeId3));
                                } else {
                                  _push4(`<!---->`);
                                }
                                _push4(` ${ssrInterpolate(cat.title)}</button>`);
                              }
                            } else {
                              return [
                                n.key !== "finance" ? (openBlock(), createBlock(_component_NuxtLink, {
                                  key: 0,
                                  to: `/${n.key === "markets" ? "market" : "application"}/${encodeURIComponent(cat.title.toLowerCase())}/${cat.id}`
                                }, {
                                  default: withCtx(() => [
                                    createVNode("button", { class: [
                                      "group flex w-full items-center rounded-md px-[14px] py-[11px] text-sm hover:bg-[rgba(22,94,240,0.09)] whitespace-nowrap gap-x-2 text-[#333] "
                                    ] }, [
                                      n.key === "markets" || n.key === "applications" ? (openBlock(), createBlock(_component_AppIcon, {
                                        key: 0,
                                        icon: `fa6-solid:${cat.imagePath}`
                                      }, null, 8, ["icon"])) : createCommentVNode("", true),
                                      createTextVNode(" " + toDisplayString(cat.title), 1)
                                    ], 2)
                                  ]),
                                  _: 2
                                }, 1032, ["to"])) : (openBlock(), createBlock("button", {
                                  key: 1,
                                  class: [
                                    "group flex w-full items-center rounded-md px-[14px] py-[11px] text-sm hover:bg-[rgba(22,94,240,0.09)] whitespace-nowrap gap-x-2 text-[#333] "
                                  ]
                                }, [
                                  n.key === "markets" || n.key === "applications" ? (openBlock(), createBlock(_component_AppIcon, {
                                    key: 0,
                                    icon: `fa6-solid:${cat.imagePath}`
                                  }, null, 8, ["icon"])) : createCommentVNode("", true),
                                  createTextVNode(" " + toDisplayString(cat.title), 1)
                                ], 2))
                              ];
                            }
                          }),
                          _: 2
                        }, _parent3, _scopeId2));
                        _push3(`</div>`);
                      });
                      _push3(`<!--]-->`);
                    } else {
                      return [
                        (openBlock(true), createBlock(Fragment, null, renderList(handleDropDown(n.key), (cat) => {
                          return openBlock(), createBlock("div", { class: "" }, [
                            createVNode(unref(MenuItem), null, {
                              default: withCtx(({ active }) => [
                                n.key !== "finance" ? (openBlock(), createBlock(_component_NuxtLink, {
                                  key: 0,
                                  to: `/${n.key === "markets" ? "market" : "application"}/${encodeURIComponent(cat.title.toLowerCase())}/${cat.id}`
                                }, {
                                  default: withCtx(() => [
                                    createVNode("button", { class: [
                                      "group flex w-full items-center rounded-md px-[14px] py-[11px] text-sm hover:bg-[rgba(22,94,240,0.09)] whitespace-nowrap gap-x-2 text-[#333] "
                                    ] }, [
                                      n.key === "markets" || n.key === "applications" ? (openBlock(), createBlock(_component_AppIcon, {
                                        key: 0,
                                        icon: `fa6-solid:${cat.imagePath}`
                                      }, null, 8, ["icon"])) : createCommentVNode("", true),
                                      createTextVNode(" " + toDisplayString(cat.title), 1)
                                    ], 2)
                                  ]),
                                  _: 2
                                }, 1032, ["to"])) : (openBlock(), createBlock("button", {
                                  key: 1,
                                  class: [
                                    "group flex w-full items-center rounded-md px-[14px] py-[11px] text-sm hover:bg-[rgba(22,94,240,0.09)] whitespace-nowrap gap-x-2 text-[#333] "
                                  ]
                                }, [
                                  n.key === "markets" || n.key === "applications" ? (openBlock(), createBlock(_component_AppIcon, {
                                    key: 0,
                                    icon: `fa6-solid:${cat.imagePath}`
                                  }, null, 8, ["icon"])) : createCommentVNode("", true),
                                  createTextVNode(" " + toDisplayString(cat.title), 1)
                                ], 2))
                              ]),
                              _: 2
                            }, 1024)
                          ]);
                        }), 256))
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              } else {
                return [
                  createVNode(unref(MenuButton), {
                    id: n.name,
                    class: "flex gap-x-1 items-center group-hover:text-[#165EF0]"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(n.name) + " ", 1),
                      createVNode(_component_AppIcon, {
                        icon: open2 ? "pepicons-pencil:angle-up" : "pepicons-pencil:angle-down"
                      }, null, 8, ["icon"])
                    ]),
                    _: 2
                  }, 1032, ["id"]),
                  createVNode(Transition, {
                    "enter-active-class": "transition duration-100 ease-out",
                    "enter-from-class": "transform scale-95 opacity-0",
                    "enter-to-class": "transform scale-100 opacity-100",
                    "leave-active-class": "transition duration-75 ease-in",
                    "leave-from-class": "transform scale-100 opacity-100",
                    "leave-to-class": "transform scale-95 opacity-0"
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(MenuItems), { class: "z-[999] grid grid-cols-1 absolute left-0 mt-[22px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] w-[303px] origin-top-right bg-white darks:bg-gray-800 rounded-b-[10px] px-5 py-5 text-sm" }, {
                        default: withCtx(() => [
                          (openBlock(true), createBlock(Fragment, null, renderList(handleDropDown(n.key), (cat) => {
                            return openBlock(), createBlock("div", { class: "" }, [
                              createVNode(unref(MenuItem), null, {
                                default: withCtx(({ active }) => [
                                  n.key !== "finance" ? (openBlock(), createBlock(_component_NuxtLink, {
                                    key: 0,
                                    to: `/${n.key === "markets" ? "market" : "application"}/${encodeURIComponent(cat.title.toLowerCase())}/${cat.id}`
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("button", { class: [
                                        "group flex w-full items-center rounded-md px-[14px] py-[11px] text-sm hover:bg-[rgba(22,94,240,0.09)] whitespace-nowrap gap-x-2 text-[#333] "
                                      ] }, [
                                        n.key === "markets" || n.key === "applications" ? (openBlock(), createBlock(_component_AppIcon, {
                                          key: 0,
                                          icon: `fa6-solid:${cat.imagePath}`
                                        }, null, 8, ["icon"])) : createCommentVNode("", true),
                                        createTextVNode(" " + toDisplayString(cat.title), 1)
                                      ], 2)
                                    ]),
                                    _: 2
                                  }, 1032, ["to"])) : (openBlock(), createBlock("button", {
                                    key: 1,
                                    class: [
                                      "group flex w-full items-center rounded-md px-[14px] py-[11px] text-sm hover:bg-[rgba(22,94,240,0.09)] whitespace-nowrap gap-x-2 text-[#333] "
                                    ]
                                  }, [
                                    n.key === "markets" || n.key === "applications" ? (openBlock(), createBlock(_component_AppIcon, {
                                      key: 0,
                                      icon: `fa6-solid:${cat.imagePath}`
                                    }, null, 8, ["icon"])) : createCommentVNode("", true),
                                    createTextVNode(" " + toDisplayString(cat.title), 1)
                                  ], 2))
                                ]),
                                _: 2
                              }, 1024)
                            ]);
                          }), 256))
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 2
                  }, 1024)
                ];
              }
            }),
            _: 2
          }, _parent));
        } else {
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: n.url
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<span class="cursor-pointer hover:text-[#165EF0]"${_scopeId}>${ssrInterpolate(n.name)}</span>`);
              } else {
                return [
                  createVNode("span", { class: "cursor-pointer hover:text-[#165EF0]" }, toDisplayString(n.name), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
        }
        _push(`</li>`);
      });
      _push(`<!--]--></ul></div><div class="flex items-center gap-x-4 smd:gap-x-6 text-sm">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/cart",
        class: "flex items-center relative"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="relative h-8 w-8 rounded-full bg-[#F7F7F7] flex items-center justify-center"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_AppIcon, {
              class: "text-lg text-[#484848]",
              icon: "akar-icons:search"
            }, null, _parent2, _scopeId));
            _push2(`</span>`);
          } else {
            return [
              createVNode("span", { class: "relative h-8 w-8 rounded-full bg-[#F7F7F7] flex items-center justify-center" }, [
                createVNode(_component_AppIcon, {
                  class: "text-lg text-[#484848]",
                  icon: "akar-icons:search"
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/cart",
        class: "flex items-center relative"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="relative h-8 w-8 rounded-full bg-[#F7F7F7] flex items-center justify-center"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_AppIcon, {
              class: "text-lg text-[#484848]",
              icon: "mingcute:message-2-line"
            }, null, _parent2, _scopeId));
            _push2(`</span>`);
          } else {
            return [
              createVNode("span", { class: "relative h-8 w-8 rounded-full bg-[#F7F7F7] flex items-center justify-center" }, [
                createVNode(_component_AppIcon, {
                  class: "text-lg text-[#484848]",
                  icon: "mingcute:message-2-line"
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/cart",
        class: "flex items-center relative"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d;
          if (_push2) {
            _push2(`<span class="relative h-8 w-8 rounded-full bg-[#F7F7F7] flex items-center justify-center"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_AppIcon, {
              class: "text-lg text-[#484848]",
              icon: "lucide:shopping-cart"
            }, null, _parent2, _scopeId));
            if (((_a = unref(cartStore)) == null ? void 0 : _a.cartTotal) > 0) {
              _push2(`<span class="w-3 h-3 rounded-full bg-[#16F046] text-[8px] flex items-center justify-center absolute top-[4px] right-[4px]"${_scopeId}>${ssrInterpolate((_b = unref(cartStore)) == null ? void 0 : _b.cartTotal)}</span>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</span>`);
          } else {
            return [
              createVNode("span", { class: "relative h-8 w-8 rounded-full bg-[#F7F7F7] flex items-center justify-center" }, [
                createVNode(_component_AppIcon, {
                  class: "text-lg text-[#484848]",
                  icon: "lucide:shopping-cart"
                }),
                ((_c = unref(cartStore)) == null ? void 0 : _c.cartTotal) > 0 ? (openBlock(), createBlock("span", {
                  key: 0,
                  class: "w-3 h-3 rounded-full bg-[#16F046] text-[8px] flex items-center justify-center absolute top-[4px] right-[4px]"
                }, toDisplayString((_d = unref(cartStore)) == null ? void 0 : _d.cartTotal), 1)) : createCommentVNode("", true)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="flex gap-x-3 ml-3">`);
      if (!unref(authStore).isLoggedIn) {
        _push(ssrRenderComponent(_component_AppButton, {
          link: "/auth/login",
          text: "Log in",
          btnClass: "text-[#475467] !px-4 !sm:px-6 !py-[6px] !font-semibold text-xs sm:!text-base hidden md:flex"
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (!unref(authStore).isLoggedIn) {
        _push(ssrRenderComponent(_component_AppButton, {
          link: "/auth/vendor-register",
          text: "Become a Supplier",
          btnClass: "!text-[12px] sm:!text-sm text-white  !font-semibold !px-[15px] !py-[6px] !normal-case bg-primary-500 flex"
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(authStore).isLoggedIn) {
        _push(ssrRenderComponent(unref(Menu), {
          as: "div",
          class: "relative hidden lg:inline-flex text-left"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div${_scopeId}>`);
              _push2(ssrRenderComponent(unref(MenuButton), {
                id: "myaccount",
                class: "bg-[#165EF0] text-white rounded-[5px] px-[24px] py-[9px] flex gap-x-1 items-center font-semibold"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` My account `);
                    _push3(ssrRenderComponent(_component_AppIcon, {
                      icon: "mdi:chevron-down",
                      class: "text-lg"
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createTextVNode(" My account "),
                      createVNode(_component_AppIcon, {
                        icon: "mdi:chevron-down",
                        class: "text-lg"
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`</div>`);
              _push2(ssrRenderComponent(unref(MenuItems), { class: "absolute right-0 mt-2 w-56 origin-top-right rounded-[5px] border border-[#F6F6F6] bg-white darks:bg-gray-800 z-[99] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.06)]" }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  var _a, _b, _c, _d, _e, _f, _g, _h;
                  if (_push3) {
                    _push3(`<div class="flex items-center gap-x-2 px-[15px] pt-3 pb-[14px] border-b border-[#F4F4F4]"${_scopeId2}><div class="h-8 w-8 rounded-full flex items-center justify-center text-sm text-white bg-[#f90] font-semibold"${_scopeId2}>${ssrInterpolate((_a = unref(authStore).userInfo) == null ? void 0 : _a.firstName.slice(0, 1))} ${ssrInterpolate((_b = unref(authStore).userInfo) == null ? void 0 : _b.lastName.slice(0, 1))}</div><div class="flex-1"${_scopeId2}><span class="text-[#333] text-[13px] font-semibold block capitalize"${_scopeId2}>${ssrInterpolate((_c = unref(authStore).userInfo) == null ? void 0 : _c.fullName)}</span><span class="block text-[11px] text-[#666] darks:text-white/70 truncate max-w-[151px]"${_scopeId2}>${ssrInterpolate((_d = unref(authStore).userInfo) == null ? void 0 : _d.email)}</span></div></div><div class="px-[15px] pt-[14px] pb-5 flex-1"${_scopeId2}><ul class="grid gap-y-3 text-[#555] darks:text-white/80"${_scopeId2}><!--[-->`);
                    ssrRenderList(unref(filteredMenu), (n) => {
                      _push3(`<li class=""${_scopeId2}>`);
                      _push3(ssrRenderComponent(unref(MenuItem), null, {
                        default: withCtx(({ active }, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            if (n.key !== "sign-out") {
                              _push4(ssrRenderComponent(_component_NuxtLink, {
                                to: n.url
                              }, {
                                default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                                  if (_push5) {
                                    _push5(`<button class="flex gap-x-3 items-center text-[13px] font-medium text-[#555]"${_scopeId4}>`);
                                    _push5(ssrRenderComponent(_component_AppIcon, {
                                      icon: n.icon
                                    }, null, _parent5, _scopeId4));
                                    _push5(` ${ssrInterpolate(n.name)}</button>`);
                                  } else {
                                    return [
                                      createVNode("button", { class: "flex gap-x-3 items-center text-[13px] font-medium text-[#555]" }, [
                                        createVNode(_component_AppIcon, {
                                          icon: n.icon
                                        }, null, 8, ["icon"]),
                                        createTextVNode(" " + toDisplayString(n.name), 1)
                                      ])
                                    ];
                                  }
                                }),
                                _: 2
                              }, _parent4, _scopeId3));
                            } else {
                              _push4(`<button class="flex gap-x-3 items-center text-[13px] font-medium"${_scopeId3}>`);
                              _push4(ssrRenderComponent(_component_AppIcon, {
                                icon: n.icon
                              }, null, _parent4, _scopeId3));
                              _push4(` ${ssrInterpolate(n.name)}</button>`);
                            }
                          } else {
                            return [
                              n.key !== "sign-out" ? (openBlock(), createBlock(_component_NuxtLink, {
                                key: 0,
                                to: n.url
                              }, {
                                default: withCtx(() => [
                                  createVNode("button", { class: "flex gap-x-3 items-center text-[13px] font-medium text-[#555]" }, [
                                    createVNode(_component_AppIcon, {
                                      icon: n.icon
                                    }, null, 8, ["icon"]),
                                    createTextVNode(" " + toDisplayString(n.name), 1)
                                  ])
                                ]),
                                _: 2
                              }, 1032, ["to"])) : (openBlock(), createBlock("button", {
                                key: 1,
                                onClick: ($event) => isSigniningOut.value = true,
                                class: "flex gap-x-3 items-center text-[13px] font-medium"
                              }, [
                                createVNode(_component_AppIcon, {
                                  icon: n.icon
                                }, null, 8, ["icon"]),
                                createTextVNode(" " + toDisplayString(n.name), 1)
                              ], 8, ["onClick"]))
                            ];
                          }
                        }),
                        _: 2
                      }, _parent3, _scopeId2));
                      _push3(`</li>`);
                    });
                    _push3(`<!--]--></ul></div>`);
                  } else {
                    return [
                      createVNode("div", { class: "flex items-center gap-x-2 px-[15px] pt-3 pb-[14px] border-b border-[#F4F4F4]" }, [
                        createVNode("div", { class: "h-8 w-8 rounded-full flex items-center justify-center text-sm text-white bg-[#f90] font-semibold" }, toDisplayString((_e = unref(authStore).userInfo) == null ? void 0 : _e.firstName.slice(0, 1)) + " " + toDisplayString((_f = unref(authStore).userInfo) == null ? void 0 : _f.lastName.slice(0, 1)), 1),
                        createVNode("div", { class: "flex-1" }, [
                          createVNode("span", { class: "text-[#333] text-[13px] font-semibold block capitalize" }, toDisplayString((_g = unref(authStore).userInfo) == null ? void 0 : _g.fullName), 1),
                          createVNode("span", { class: "block text-[11px] text-[#666] darks:text-white/70 truncate max-w-[151px]" }, toDisplayString((_h = unref(authStore).userInfo) == null ? void 0 : _h.email), 1)
                        ])
                      ]),
                      createVNode("div", { class: "px-[15px] pt-[14px] pb-5 flex-1" }, [
                        createVNode("ul", { class: "grid gap-y-3 text-[#555] darks:text-white/80" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(filteredMenu), (n) => {
                            return openBlock(), createBlock("li", {
                              key: n.name,
                              class: ""
                            }, [
                              createVNode(unref(MenuItem), null, {
                                default: withCtx(({ active }) => [
                                  n.key !== "sign-out" ? (openBlock(), createBlock(_component_NuxtLink, {
                                    key: 0,
                                    to: n.url
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("button", { class: "flex gap-x-3 items-center text-[13px] font-medium text-[#555]" }, [
                                        createVNode(_component_AppIcon, {
                                          icon: n.icon
                                        }, null, 8, ["icon"]),
                                        createTextVNode(" " + toDisplayString(n.name), 1)
                                      ])
                                    ]),
                                    _: 2
                                  }, 1032, ["to"])) : (openBlock(), createBlock("button", {
                                    key: 1,
                                    onClick: ($event) => isSigniningOut.value = true,
                                    class: "flex gap-x-3 items-center text-[13px] font-medium"
                                  }, [
                                    createVNode(_component_AppIcon, {
                                      icon: n.icon
                                    }, null, 8, ["icon"]),
                                    createTextVNode(" " + toDisplayString(n.name), 1)
                                  ], 8, ["onClick"]))
                                ]),
                                _: 2
                              }, 1024)
                            ]);
                          }), 128))
                        ])
                      ])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              return [
                createVNode("div", null, [
                  createVNode(unref(MenuButton), {
                    id: "myaccount",
                    class: "bg-[#165EF0] text-white rounded-[5px] px-[24px] py-[9px] flex gap-x-1 items-center font-semibold"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" My account "),
                      createVNode(_component_AppIcon, {
                        icon: "mdi:chevron-down",
                        class: "text-lg"
                      })
                    ]),
                    _: 1
                  })
                ]),
                createVNode(Transition, {
                  "enter-active-class": "transition duration-100 ease-out",
                  "enter-from-class": "transform scale-95 opacity-0",
                  "enter-to-class": "transform scale-100 opacity-100",
                  "leave-active-class": "transition duration-75 ease-in",
                  "leave-from-class": "transform scale-100 opacity-100",
                  "leave-to-class": "transform scale-95 opacity-0"
                }, {
                  default: withCtx(() => [
                    createVNode(unref(MenuItems), { class: "absolute right-0 mt-2 w-56 origin-top-right rounded-[5px] border border-[#F6F6F6] bg-white darks:bg-gray-800 z-[99] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.06)]" }, {
                      default: withCtx(() => {
                        var _a, _b, _c, _d;
                        return [
                          createVNode("div", { class: "flex items-center gap-x-2 px-[15px] pt-3 pb-[14px] border-b border-[#F4F4F4]" }, [
                            createVNode("div", { class: "h-8 w-8 rounded-full flex items-center justify-center text-sm text-white bg-[#f90] font-semibold" }, toDisplayString((_a = unref(authStore).userInfo) == null ? void 0 : _a.firstName.slice(0, 1)) + " " + toDisplayString((_b = unref(authStore).userInfo) == null ? void 0 : _b.lastName.slice(0, 1)), 1),
                            createVNode("div", { class: "flex-1" }, [
                              createVNode("span", { class: "text-[#333] text-[13px] font-semibold block capitalize" }, toDisplayString((_c = unref(authStore).userInfo) == null ? void 0 : _c.fullName), 1),
                              createVNode("span", { class: "block text-[11px] text-[#666] darks:text-white/70 truncate max-w-[151px]" }, toDisplayString((_d = unref(authStore).userInfo) == null ? void 0 : _d.email), 1)
                            ])
                          ]),
                          createVNode("div", { class: "px-[15px] pt-[14px] pb-5 flex-1" }, [
                            createVNode("ul", { class: "grid gap-y-3 text-[#555] darks:text-white/80" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(unref(filteredMenu), (n) => {
                                return openBlock(), createBlock("li", {
                                  key: n.name,
                                  class: ""
                                }, [
                                  createVNode(unref(MenuItem), null, {
                                    default: withCtx(({ active }) => [
                                      n.key !== "sign-out" ? (openBlock(), createBlock(_component_NuxtLink, {
                                        key: 0,
                                        to: n.url
                                      }, {
                                        default: withCtx(() => [
                                          createVNode("button", { class: "flex gap-x-3 items-center text-[13px] font-medium text-[#555]" }, [
                                            createVNode(_component_AppIcon, {
                                              icon: n.icon
                                            }, null, 8, ["icon"]),
                                            createTextVNode(" " + toDisplayString(n.name), 1)
                                          ])
                                        ]),
                                        _: 2
                                      }, 1032, ["to"])) : (openBlock(), createBlock("button", {
                                        key: 1,
                                        onClick: ($event) => isSigniningOut.value = true,
                                        class: "flex gap-x-3 items-center text-[13px] font-medium"
                                      }, [
                                        createVNode(_component_AppIcon, {
                                          icon: n.icon
                                        }, null, 8, ["icon"]),
                                        createTextVNode(" " + toDisplayString(n.name), 1)
                                      ], 8, ["onClick"]))
                                    ]),
                                    _: 2
                                  }, 1024)
                                ]);
                              }), 128))
                            ])
                          ])
                        ];
                      }),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<span class="lg:hidden">`);
      _push(ssrRenderComponent(_component_AppIcon, {
        icon: "ci:menu-alt-01",
        class: "text-[30px]"
      }, null, _parent));
      _push(`</span></div></div></div></div></nav>`);
      if (open.value) {
        _push(`<div class="z-[999]">`);
        _push(ssrRenderComponent(_component_AppSideMenu, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (isSigniningOut.value) {
        _push(ssrRenderComponent(_component_ModalCenter, null, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              if (isSigniningOut.value) {
                _push2(`<div class="bg-white p-6 lg:p-10 sm:p-6 sm:pb-4 rounded-lg"${_scopeId}><div class="flex justify-between mb-5 items-center"${_scopeId}><h4 class="font-medium text-matta-black text-xl"${_scopeId}>Sign Out</h4><i class="uil uil-times cursor-pointer text-lg"${_scopeId}></i></div><p class="text-sm text-matta-black mb-2"${_scopeId}> Are you sure you want to sign out? </p><div class="flex justify-between gap-x-2 items-center mt-8"${_scopeId}><button type="button" class="appearance-none border w-1/2 leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"${_scopeId}> Cancel </button><button type="button" class="appearance-none border w-1/2 border-primary-500 leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase"${_scopeId}> Yes </button></div></div>`);
              } else {
                _push2(`<!---->`);
              }
            } else {
              return [
                isSigniningOut.value ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "bg-white p-6 lg:p-10 sm:p-6 sm:pb-4 rounded-lg"
                }, [
                  createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                    createVNode("h4", { class: "font-medium text-matta-black text-xl" }, "Sign Out"),
                    createVNode("i", {
                      class: "uil uil-times cursor-pointer text-lg",
                      onClick: ($event) => isSigniningOut.value = false
                    }, null, 8, ["onClick"])
                  ]),
                  createVNode("p", { class: "text-sm text-matta-black mb-2" }, " Are you sure you want to sign out? "),
                  createVNode("div", { class: "flex justify-between gap-x-2 items-center mt-8" }, [
                    createVNode("button", {
                      type: "button",
                      onClick: ($event) => isSigniningOut.value = false,
                      class: "appearance-none border w-1/2 leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"
                    }, " Cancel ", 8, ["onClick"]),
                    createVNode("button", {
                      type: "button",
                      onClick: unref(logOut),
                      class: "appearance-none border w-1/2 border-primary-500 leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase"
                    }, " Yes ", 8, ["onClick"])
                  ])
                ])) : createCommentVNode("", true)
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/AppHeader.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "ContactForm",
  __ssrInlineRender: true,
  setup(__props) {
    const open = inject("open");
    const isLoading = ref(false);
    const togglePopup = inject("togglePopup");
    const form = reactive({
      fullName: "",
      email: "",
      message: "",
      phone: ""
    });
    const rules = {
      fullName: {
        required: helpers.withMessage("Please provide your full name", required)
      },
      message: {
        required: helpers.withMessage("Enter a message", required)
      },
      phone: {
        required: helpers.withMessage("Provide your phone  number", required)
      },
      email: {
        required: helpers.withMessage("Email field cannot be empty", required),
        email: helpers.withMessage("Email is invalid", email),
        maxLength: maxLength(50)
      }
    };
    const v$ = useVuelidate(rules, form);
    async function handleSubmit() {
      const validity = await v$.value.$validate();
      if (!validity)
        return;
      isLoading.value = true;
      sendMessage(form).then((res) => {
        if (res.status === 200) {
          toast.success("Message sent");
          isLoading.value = false;
          open.value = false;
        }
      }).catch(() => {
        toast.error("Message sending failed");
        isLoading.value = false;
      });
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_IndexModal = __nuxt_component_0$3;
      _push(ssrRenderComponent(_component_IndexModal, mergeProps({
        isOpen: unref(open),
        onTogglePopup: unref(togglePopup)
      }, _attrs), {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form class="bg-white w-[400px] p-6 rounded-lg block"${_scopeId}><legend class="block mb-7 font-bold text-center text-sm uppercase"${_scopeId}> Contact us form </legend><div class="mb-6"${_scopeId}><label class="mb-2 font-medium text-sm text-[#344054] block text-left"${_scopeId}>Full name</label><input${ssrRenderAttr("value", unref(v$).fullName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).fullName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Provide your full name"${_scopeId}><!--[-->`);
            ssrRenderList(unref(v$).fullName.$errors, (error) => {
              _push2(`<div class="text-red-500 mt-1"${_scopeId}><div class="error-msg text-error text-xs font-semibold"${_scopeId}>${ssrInterpolate(error.$message)}</div></div>`);
            });
            _push2(`<!--]--></div><div class="mb-6"${_scopeId}><label class="mb-2 font-medium text-sm text-[#344054] block text-left"${_scopeId}>Phone number</label><input${ssrRenderAttr("value", unref(v$).phone.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).phone.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Phone number"${_scopeId}><!--[-->`);
            ssrRenderList(unref(v$).phone.$errors, (error) => {
              _push2(`<div class="text-red-500 mt-1"${_scopeId}><div class="error-msg text-error text-xs font-semibold"${_scopeId}>${ssrInterpolate(error.$message)}</div></div>`);
            });
            _push2(`<!--]--></div><div class="mb-6"${_scopeId}><label class="mb-2 font-medium text-sm text-[#344054] block text-left"${_scopeId}>E-mail</label><input${ssrRenderAttr("value", unref(v$).email.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).email.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="E-mail"${_scopeId}><!--[-->`);
            ssrRenderList(unref(v$).email.$errors, (error) => {
              _push2(`<div class="text-red-500 mt-1"${_scopeId}><div class="error-msg text-error text-xs font-semibold"${_scopeId}>${ssrInterpolate(error.$message)}</div></div>`);
            });
            _push2(`<!--]--></div><div class="mb-6"${_scopeId}><label class="mb-2 font-medium text-sm text-[#344054] block text-left"${_scopeId}>Message</label><textarea class="${ssrRenderClass([{ "border-red-500": unref(v$).message.$error }, "rounded-lg px-[14px] py-[10px] w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Type here"${_scopeId}>${ssrInterpolate(unref(v$).message.$model)}</textarea><!--[-->`);
            ssrRenderList(unref(v$).message.$errors, (error) => {
              _push2(`<div class="text-red-500 mt-1"${_scopeId}><div class="error-msg text-error text-xs font-semibold"${_scopeId}>${ssrInterpolate(error.$message)}</div></div>`);
            });
            _push2(`<!--]--></div><div class="mb-6"${_scopeId}><button type="submit"${ssrIncludeBooleanAttr(unref(isLoading)) ? " disabled" : ""} class="border text-[13px] mb-4 border-primary- uppercase text-white lg:min-w-[120px] w-full bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11"${_scopeId}><span${_scopeId}>`);
            if (unref(isLoading)) {
              _push2(`<span class="flex gap-x-4 justify-center items-center"${_scopeId}><span${_scopeId}> Sending...</span>`);
              if (unref(isLoading)) {
                _push2(`<i class="fa fa-spinner fa-spin text-white" aria-hidden="true"${_scopeId}></i>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</span>`);
            } else {
              _push2(`<span${_scopeId}>Send message</span>`);
            }
            _push2(`</span></button></div></form>`);
          } else {
            return [
              createVNode("form", {
                class: "bg-white w-[400px] p-6 rounded-lg block",
                onSubmit: withModifiers(handleSubmit, ["prevent"])
              }, [
                createVNode("legend", { class: "block mb-7 font-bold text-center text-sm uppercase" }, " Contact us form "),
                createVNode("div", { class: "mb-6" }, [
                  createVNode("label", { class: "mb-2 font-medium text-sm text-[#344054] block text-left" }, "Full name"),
                  withDirectives(createVNode("input", {
                    "onUpdate:modelValue": ($event) => unref(v$).fullName.$model = $event,
                    class: [{ "border-red-500": unref(v$).fullName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                    placeholder: "Provide your full name"
                  }, null, 10, ["onUpdate:modelValue"]), [
                    [vModelText, unref(v$).fullName.$model]
                  ]),
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).fullName.$errors, (error) => {
                    return openBlock(), createBlock("div", {
                      class: "text-red-500 mt-1",
                      key: error.$uid
                    }, [
                      createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                    ]);
                  }), 128))
                ]),
                createVNode("div", { class: "mb-6" }, [
                  createVNode("label", { class: "mb-2 font-medium text-sm text-[#344054] block text-left" }, "Phone number"),
                  withDirectives(createVNode("input", {
                    "onUpdate:modelValue": ($event) => unref(v$).phone.$model = $event,
                    class: [{ "border-red-500": unref(v$).phone.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                    placeholder: "Phone number"
                  }, null, 10, ["onUpdate:modelValue"]), [
                    [vModelText, unref(v$).phone.$model]
                  ]),
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).phone.$errors, (error) => {
                    return openBlock(), createBlock("div", {
                      class: "text-red-500 mt-1",
                      key: error.$uid
                    }, [
                      createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                    ]);
                  }), 128))
                ]),
                createVNode("div", { class: "mb-6" }, [
                  createVNode("label", { class: "mb-2 font-medium text-sm text-[#344054] block text-left" }, "E-mail"),
                  withDirectives(createVNode("input", {
                    "onUpdate:modelValue": ($event) => unref(v$).email.$model = $event,
                    class: [{ "border-red-500": unref(v$).email.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                    placeholder: "E-mail"
                  }, null, 10, ["onUpdate:modelValue"]), [
                    [vModelText, unref(v$).email.$model]
                  ]),
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).email.$errors, (error) => {
                    return openBlock(), createBlock("div", {
                      class: "text-red-500 mt-1",
                      key: error.$uid
                    }, [
                      createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                    ]);
                  }), 128))
                ]),
                createVNode("div", { class: "mb-6" }, [
                  createVNode("label", { class: "mb-2 font-medium text-sm text-[#344054] block text-left" }, "Message"),
                  withDirectives(createVNode("textarea", {
                    "onUpdate:modelValue": ($event) => unref(v$).message.$model = $event,
                    class: [{ "border-red-500": unref(v$).message.$error }, "rounded-lg px-[14px] py-[10px] w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                    placeholder: "Type here"
                  }, null, 10, ["onUpdate:modelValue"]), [
                    [vModelText, unref(v$).message.$model]
                  ]),
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).message.$errors, (error) => {
                    return openBlock(), createBlock("div", {
                      class: "text-red-500 mt-1",
                      key: error.$uid
                    }, [
                      createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                    ]);
                  }), 128))
                ]),
                createVNode("div", { class: "mb-6" }, [
                  createVNode("button", {
                    type: "submit",
                    disabled: unref(isLoading),
                    class: "border text-[13px] mb-4 border-primary- uppercase text-white lg:min-w-[120px] w-full bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11"
                  }, [
                    createVNode("span", null, [
                      unref(isLoading) ? (openBlock(), createBlock("span", {
                        key: 0,
                        class: "flex gap-x-4 justify-center items-center"
                      }, [
                        createVNode("span", null, " Sending..."),
                        unref(isLoading) ? (openBlock(), createBlock("i", {
                          key: 0,
                          class: "fa fa-spinner fa-spin text-white",
                          "aria-hidden": "true"
                        })) : createCommentVNode("", true)
                      ])) : (openBlock(), createBlock("span", { key: 1 }, "Send message"))
                    ])
                  ], 8, ["disabled"])
                ])
              ], 32)
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ContactForm.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$1;
const _sfc_main = {
  __name: "AppFooter",
  __ssrInlineRender: true,
  setup(__props) {
    const open = ref(false);
    const navs = [
      {
        subject: "company",
        links: [
          {
            title: "About Us",
            url: "https://corporate.matta.trade/"
          },
          {
            title: "Careers",
            url: "https://corporate.matta.trade/"
          },
          {
            title: "Newsletter",
            url: "#"
          },
          {
            title: "Contact",
            url: ""
          }
        ]
      },
      {
        subject: "services",
        links: [
          {
            title: "Buy chemicals",
            url: "/market/all"
          },
          {
            title: "Sell chemicals",
            url: "/auth/vendor-register"
          },
          {
            title: "Logistics solutions",
            url: "#"
          },
          {
            title: "Financing solutions",
            url: "#"
          },
          {
            title: "Cross border payments",
            url: "#"
          },
          {
            title: "Local fulfillment partnerships",
            url: "#"
          }
        ]
      },
      {
        subject: "quick links",
        links: [
          {
            title: "Request product",
            url: "/request-product"
          },
          {
            title: "Become a Verified Supplier",
            url: "/auth/vendor-register"
          },
          {
            title: "Join agent network program",
            url: "#"
          }
        ]
      }
    ];
    const socials = [
      {
        title: "Facebook",
        icon: "ant-design:facebook-filled",
        link: "https://www.facebook.com/mattatrade"
      },
      {
        title: "Linkedin",
        icon: "akar-icons:linkedin-fill",
        link: "https://www.linkedin.com/company/matta-trade/"
      },
      {
        title: "X",
        icon: "line-md:twitter-x-alt",
        link: "https://twitter.com/matta_trade"
      },
      {
        title: "Instagram",
        icon: "fe:instagram",
        link: "https://www.instagram.com/matta.trade/"
      }
    ];
    function togglePopup() {
      open.value = !open.value;
    }
    provide("open", open);
    provide("togglePopup", togglePopup);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      const _component_NuxtImg = __nuxt_component_1$1;
      const _component_AppIcon = __nuxt_component_1$2;
      const _component_ContactForm = __nuxt_component_2;
      _push(`<!--[--><footer class="bg-white darks:bg-gray-800 pt-16 pb-8"><div class="rounded-lg container"><div class="grid text-center lg:text-left grid-cols-1 lg:grid-cols-4 gap-y-8 lg:gap-x-10 lg:pt-8 mb-14"><div class=""><div class="mb-[15px]">`);
      _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_NuxtImg, {
              src: "/images/logo.png",
              class: "w-[132px]",
              alt: "Matta",
              width: "132",
              height: "auto"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_NuxtImg, {
                src: "/images/logo.png",
                class: "w-[132px]",
                alt: "Matta",
                width: "132",
                height: "auto"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><p class="text-sm darks:text-white text-left mb-10"> Discover and buy chemicals, raw materials, ingredients, and commodities all in one place. </p><div class="flex gap-x-6"><!--[-->`);
      ssrRenderList(socials, (s) => {
        _push(`<a target="_blank"${ssrRenderAttr("href", s.link)}><span class="">`);
        _push(ssrRenderComponent(_component_AppIcon, {
          icon: s.icon,
          class: "cursor-pointer text-[#333]/80 darks:text-white/80 text-[28px]"
        }, null, _parent));
        _push(`</span></a>`);
      });
      _push(`<!--]--></div></div><div class="grid md:grid-cols-3 gap-y-8 md:gap-x-10 col-span-3 text-left"><!--[-->`);
      ssrRenderList(navs, (n) => {
        _push(`<div><span class="text-base capitalize text-[#333] darks:text-white font-bold mb-3 block">${ssrInterpolate(n.subject)}</span><ul><!--[-->`);
        ssrRenderList(n.links, (l) => {
          _push(`<li class="text-[14px] font-normal capitlize text-[#333]/80 darks:text-white mb-2">`);
          if (l.title.toLowerCase() !== "contact") {
            _push(`<a${ssrRenderAttr("href", l.url)} class="hover:underline">${ssrInterpolate(l.title)}</a>`);
          } else {
            _push(`<span class="hover:underline">${ssrInterpolate(l.title)}</span>`);
          }
          _push(`</li>`);
        });
        _push(`<!--]--></ul></div>`);
      });
      _push(`<!--]--></div></div><div class="flex flex-col-reverse lg:flex-row gap-4 lg:gap-0 justify-between lg:items-center"><div class="order-1 md:grid-cols-2 grid gap-y-3 lg:gap-y-6 md:gap-y-0 text-left md:gap-x-4 darks:text-white/80"><p class="order-2 lg:order-1 text-sm"> \xA9 ${ssrInterpolate((/* @__PURE__ */ new Date()).getFullYear())} Matta. All Rights Reserved. </p><div class="order-1 lg:order-2 flex gap-x-2 md:gap-x-4 items-center">`);
      _push(ssrRenderComponent(_component_router_link, {
        to: "/policy",
        class: "text-sm md:text-sm"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Privacy policy`);
          } else {
            return [
              createTextVNode("Privacy policy")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<span class="bg-[#333] darks:text-white/80 w-[2px] h-[2px] rounded-full"></span>`);
      _push(ssrRenderComponent(_component_router_link, {
        to: "/terms",
        class: "text-sm md:text-sm"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Terms of use`);
          } else {
            return [
              createTextVNode("Terms of use")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div></footer>`);
      _push(ssrRenderComponent(_component_ContactForm, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/AppFooter.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main;

export { __nuxt_component_0 as _, __nuxt_component_1 as a };
//# sourceMappingURL=AppFooter-UymqQBAh.mjs.map
