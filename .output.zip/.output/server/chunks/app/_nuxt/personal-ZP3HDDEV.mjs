import { _ as __nuxt_component_0$1 } from './TopBar-Q5W4PGYG.mjs';
import { _ as __nuxt_component_1 } from './nuxt-img-qJohECzX.mjs';
import { useSSRContext, ref, reactive, computed, unref, withCtx, createVNode } from 'vue';
import { y as useStore, d as useAuthStore } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr, ssrRenderClass, ssrIncludeBooleanAttr, ssrRenderStyle } from 'vue/server-renderer';
import { c as countries } from './countries-4zSrMx8v.mjs';
import moment from 'moment-timezone';
import { TransitionRoot, Dialog, TransitionChild, DialogPanel } from '@headlessui/vue';
import { Cropper } from 'vue-advanced-cropper';
import { P as PhoneCodes } from './PhoneCodes-TGlMinMT.mjs';
import { C as CountriesSelect } from './CountriesSelect-jqw8V4-X.mjs';
import { S as StatesSelect } from './StatesSelect-GYPQgjHx.mjs';
import useVuelidate from '@vuelidate/core';
import { required, helpers, email, maxLength, numeric } from '@vuelidate/validators';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';
import 'country-list-with-dial-code-and-flag';

const _sfc_main$1 = {
  __name: "PersonalAccount",
  __ssrInlineRender: true,
  setup(__props) {
    useStore();
    const open = ref(false);
    const img = ref("");
    const image = ref(null);
    const coordinate = ref(null);
    const cropper = ref(null);
    const zones = moment.tz.names();
    const form = reactive({
      code: "+234",
      photo: "",
      firstName: "",
      lastName: "",
      country: "",
      city: "",
      email: "",
      phone: "",
      timeZone: ""
    });
    const isLoading = ref(false);
    const validPhoneLength = (value) => form.code === "+234" ? value.length > 9 && value.length < 12 : true;
    const abbrs = {
      EST: "Eastern Standard Time",
      EDT: "Eastern Daylight Time",
      CST: "Central Standard Time",
      CDT: "Central Daylight Time",
      MST: "Mountain Standard Time",
      MDT: "Mountain Daylight Time",
      PST: "Pacific Standard Time",
      PDT: "Pacific Daylight Time",
      GMT: "Greenwich Mean Time",
      CAT: "Central Africa Time",
      WAT: "Western Africa Time",
      EAT: "Eastern Africa Time",
      EET: "Eastern European Time"
    };
    moment.fn.zoneName = function() {
      var abbr = this.zoneAbbr();
      return abbrs[abbr] || abbr;
    };
    const states = computed(() => {
      if (!form.country)
        return [];
      return countries.find(
        (item) => form.country.toLowerCase() === item.name.toLowerCase()
      ).states || [];
    });
    function crop() {
      const { coordinates, canvas } = cropper.value.getResult();
      coordinate.value = coordinates;
      image.value = canvas.toDataURL();
      open.value = false;
      form.photo = canvas.toDataURL().replace("data:", "").replace(/^.+,/, "");
    }
    const rules = {
      email: {
        required,
        email: helpers.withMessage("Email is invalid", email),
        maxLength: maxLength(50)
      },
      firstName: {
        required,
        maxLength: maxLength(50)
      },
      lastName: {
        required,
        maxLength: maxLength(50)
      },
      country: {
        required,
        maxLength: maxLength(50)
      },
      city: {
        required,
        maxLength: maxLength(50)
      },
      phone: {
        numeric,
        required,
        validPhoneLength: helpers.withMessage(
          "Phone number must be between 10 0r 11 digits",
          validPhoneLength
        )
      },
      timeZone: {
        required,
        maxLength: maxLength(250)
      },
      photo: {}
    };
    ref(false);
    const v$ = useVuelidate(rules, form);
    useAuthStore();
    computed(() => {
      return `${form.firstName} ${form.lastName}`;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_OnboardingLayoutTopBar = __nuxt_component_0$1;
      const _component_NuxtImg = __nuxt_component_1;
      _push(`<!--[--><div class="bg-[#E7EBEE] p-4 lg:p-6 flex flex-col gap-y-2 h-screen w-full overflow-y-auto" data-v-0496f9bf>`);
      _push(ssrRenderComponent(_component_OnboardingLayoutTopBar, null, null, _parent));
      _push(`<div class="gap-y-2 flex flex-col flex-1 p-6 lg:p-10 justify-center bg-white rounded-lg" data-v-0496f9bf><div class="md:max-w-[656px] mx-auto" data-v-0496f9bf><div class="col-span-2" data-v-0496f9bf><div class="mb-8" data-v-0496f9bf><h1 class="text-3xl lg:text-[48px] leading-[56px] text-matta-black col-span-1 font-medium text-center mb-4 lg:mb-8" data-v-0496f9bf> Set your personal profile </h1><p class="text-center text-sm lg:text-base" data-v-0496f9bf> Recommended filling out your profile </p></div><div class="flex flex-col lg:flex-row lg:justify-between lg:items-center mb-10 gap-y-8" data-v-0496f9bf><div class="flex items-center" data-v-0496f9bf><span data-v-0496f9bf>`);
      if (!unref(image)) {
        _push(`<span class="h-16 lg:h-24 w-16 lg:w-24 rounded-full flex items-center text-xs bg-[#F1F3F5] mr-4 justify-center" data-v-0496f9bf>Photo</span>`);
      } else {
        _push(ssrRenderComponent(_component_NuxtImg, {
          src: unref(image),
          class: "h-16 lg:h-24 w-16 lg:w-24 rounded-full flex items-center bg-[#F1F3F5] mr-4 justify-center"
        }, null, _parent));
      }
      _push(`</span><span data-v-0496f9bf><p class="text-xs lg:text-sm font-medium mb-1" data-v-0496f9bf>Your photo</p><p class="text-xs lg:text-sm font-normal" data-v-0496f9bf> Recommended 200x200 px </p><!--[-->`);
      ssrRenderList(unref(v$).photo.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-0496f9bf><div class="error-msg text-error text-xs font-semibold" data-v-0496f9bf>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></span></div><div class="flex items-center gap-x-3" data-v-0496f9bf><label for="upload" class="w-full lg:w-auto block lg:inline" data-v-0496f9bf><span class="text-primary border border-primary- rounded-lg w-full lg:w-auto px-4 lg:px-6 py-2 lg:py-3 text-xs lg:text-sm cursor-pointer" data-v-0496f9bf> Upload photo </span><input type="file" accept="image/*" id="upload" class="hidden" data-v-0496f9bf></label></div></div><form data-v-0496f9bf><div data-v-0496f9bf><div class="grid grid-cols-1 lg:grid-cols-2 gap-4" data-v-0496f9bf><div class="mb-6" data-v-0496f9bf><label class="mb-2 font-normal text-xs block" data-v-0496f9bf>First name <span class="text-red-500 pl-[.02rem]" data-v-0496f9bf>*</span></label><input${ssrRenderAttr("value", unref(v$).firstName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).firstName.$error }, "rounded-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" data-v-0496f9bf><!--[-->`);
      ssrRenderList(unref(v$).firstName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-0496f9bf><div class="error-msg text-error text-xs font-semibold" data-v-0496f9bf>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6" data-v-0496f9bf><label class="mb-2 font-normal text-xs block" data-v-0496f9bf>Last name <span class="text-red-500 pl-[.02rem]" data-v-0496f9bf>*</span></label><input${ssrRenderAttr("value", unref(v$).lastName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).lastName.$error }, "rounded-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" data-v-0496f9bf><!--[-->`);
      ssrRenderList(unref(v$).lastName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-0496f9bf><div class="error-msg text-error text-xs font-semibold" data-v-0496f9bf>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="grid grid-cols-1 lg:grid-cols-2 gap-4" data-v-0496f9bf><div class="mb-6" data-v-0496f9bf><label class="mb-2 font-normal text-xs block" data-v-0496f9bf>Country <span class="text-red-500 pl-[.02rem]" data-v-0496f9bf>*</span></label><div class="flex relative" data-v-0496f9bf>`);
      _push(ssrRenderComponent(unref(CountriesSelect), {
        modelValue: unref(v$).country.$model,
        "onUpdate:modelValue": ($event) => unref(v$).country.$model = $event
      }, null, _parent));
      _push(`<!--[-->`);
      ssrRenderList(unref(v$).country.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-0496f9bf><div class="error-msg text-error text-xs font-semibold" data-v-0496f9bf>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="mb-6" data-v-0496f9bf><label class="mb-2 font-normal text-xs block" data-v-0496f9bf>State <span class="text-red-500 pl-[.02rem]" data-v-0496f9bf>*</span></label>`);
      _push(ssrRenderComponent(unref(StatesSelect), {
        modelValue: unref(v$).city.$model,
        "onUpdate:modelValue": ($event) => unref(v$).city.$model = $event,
        states: unref(states)
      }, null, _parent));
      _push(`<!--[-->`);
      ssrRenderList(unref(v$).city.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-0496f9bf><div class="error-msg text-error text-xs font-semibold" data-v-0496f9bf>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="grid grid-cols-1 lg:grid-cols-2 gap-4" data-v-0496f9bf><div class="mb-6" data-v-0496f9bf><label class="mb-2 font-normal text-xs block" data-v-0496f9bf>Phone number <span class="text-red-500 pl-[.02rem]" data-v-0496f9bf>*</span></label><div class="flex relative rounded-lg h-11" data-v-0496f9bf>`);
      _push(ssrRenderComponent(unref(PhoneCodes), {
        modelValue: unref(form).code,
        "onUpdate:modelValue": ($event) => unref(form).code = $event
      }, null, _parent));
      _push(`<input class="${ssrRenderClass([{ "border-red-500": unref(v$).phone.$error }, "flex-1 rounded-r-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}"${ssrRenderAttr("value", unref(v$).phone.$model)} autocomplete="off" autofocus="on" placeholder="08160723884" type="tel" data-v-0496f9bf></div><!--[-->`);
      ssrRenderList(unref(v$).phone.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-0496f9bf><div class="error-msg text-error text-xs font-semibold" data-v-0496f9bf>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6" data-v-0496f9bf><label class="mb-2 font-normal text-xs block" data-v-0496f9bf>E-mail <span class="text-red-500 pl-[.02rem]" data-v-0496f9bf>*</span></label><div class="flex relative items-center" data-v-0496f9bf><input class="${ssrRenderClass([{ "border-red-500": unref(v$).email.$error }, "rounded-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}"${ssrRenderAttr("value", unref(form).email)} autocomplete="off" autofocus="on" disabled data-v-0496f9bf><i class="uil uil-lock absolute right-4 text-gray-300" data-v-0496f9bf></i></div><!--[-->`);
      ssrRenderList(unref(v$).email.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-0496f9bf><div class="error-msg text-error text-xs font-semibold" data-v-0496f9bf>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div></div><hr class="my-8" data-v-0496f9bf><legend class="font-medium mb-4" data-v-0496f9bf> Timezone <span class="text-red-500 pl-[.02rem]" data-v-0496f9bf>*</span></legend><div class="mb-10" data-v-0496f9bf><div class="flex relative items-center w-full" data-v-0496f9bf><select class="${ssrRenderClass([{ "border-red-500": unref(v$).timeZone.$error }, "appearance-none rounded-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9]"])}" data-v-0496f9bf><!--[-->`);
      ssrRenderList(unref(zones), (z) => {
        _push(`<option data-v-0496f9bf> (${ssrInterpolate(unref(moment).tz(/* @__PURE__ */ new Date(), z).format("z - Z"))}) ${ssrInterpolate(unref(moment).tz(/* @__PURE__ */ new Date(), z).format("zz"))} ${ssrInterpolate(z)}</option>`);
      });
      _push(`<!--]--></select><i class="uil uil-sort absolute right-3 pointer-events-none" data-v-0496f9bf></i></div><!--[-->`);
      ssrRenderList(unref(v$).timeZone.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-0496f9bf><div class="error-msg text-error text-xs font-semibold" data-v-0496f9bf>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="flex justify-center gap-x-4 items-center mt-8" data-v-0496f9bf><span data-v-0496f9bf></span><button${ssrIncludeBooleanAttr(unref(v$).$silentErrors.length) ? " disabled" : ""} class="${ssrRenderClass([{
        "bg-primary/40 border-primary/40 cursor-not-allowed": unref(v$).$silentErrors.length
      }, "appearance-none leading-none px-10 py-4 rounded-full text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase"])}" data-v-0496f9bf><i class="fa fa-spinner fa-spin" style="${ssrRenderStyle(unref(isLoading) ? null : { display: "none" })}" aria-hidden="true" data-v-0496f9bf></i><span style="${ssrRenderStyle(!unref(isLoading) ? null : { display: "none" })}" data-v-0496f9bf>Finish</span></button></div></form></div></div></div></div><div data-v-0496f9bf>`);
      _push(ssrRenderComponent(unref(TransitionRoot), {
        as: "template",
        show: unref(open)
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Dialog), {
              as: "div",
              class: "relative z-10",
              onClose: ($event) => open.value = false
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" data-v-0496f9bf${_scopeId3}></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="fixed z-10 inset-0 overflow-y-auto" data-v-0496f9bf${_scopeId2}><div class="flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0" data-v-0496f9bf${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                    "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                    "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(DialogPanel), { class: "relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" data-v-0496f9bf${_scopeId4}><div class="flex justify-between mb-5 items-center" data-v-0496f9bf${_scopeId4}><h4 class="font-medium text-matta-black text-xl" data-v-0496f9bf${_scopeId4}> Customize photo </h4><i class="uil uil-times cursor-pointer text-lg" data-v-0496f9bf${_scopeId4}></i></div>`);
                              _push5(ssrRenderComponent(unref(Cropper), {
                                ref_key: "cropper",
                                ref: cropper,
                                class: "cropper",
                                src: unref(img),
                                "stencil-component": _ctx.ImageStencil
                              }, null, _parent5, _scopeId4));
                              _push5(`<div class="flex justify-end gap-x-2 items-center mt-8" data-v-0496f9bf${_scopeId4}><button class="appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase" data-v-0496f9bf${_scopeId4}> Cancel </button><button class="appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase active:scale-95" data-v-0496f9bf${_scopeId4}> Save </button></div></div>`);
                            } else {
                              return [
                                createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" }, [
                                  createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                                    createVNode("h4", { class: "font-medium text-matta-black text-xl" }, " Customize photo "),
                                    createVNode("i", {
                                      class: "uil uil-times cursor-pointer text-lg",
                                      onClick: ($event) => open.value = false
                                    }, null, 8, ["onClick"])
                                  ]),
                                  createVNode(unref(Cropper), {
                                    ref_key: "cropper",
                                    ref: cropper,
                                    class: "cropper",
                                    src: unref(img),
                                    "stencil-component": _ctx.ImageStencil
                                  }, null, 8, ["src", "stencil-component"]),
                                  createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                                    createVNode("button", {
                                      onClick: ($event) => open.value = false,
                                      class: "appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"
                                    }, " Cancel ", 8, ["onClick"]),
                                    createVNode("button", {
                                      onClick: crop,
                                      class: "appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase active:scale-95"
                                    }, " Save ")
                                  ])
                                ])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(DialogPanel), { class: "relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full" }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" }, [
                                createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                                  createVNode("h4", { class: "font-medium text-matta-black text-xl" }, " Customize photo "),
                                  createVNode("i", {
                                    class: "uil uil-times cursor-pointer text-lg",
                                    onClick: ($event) => open.value = false
                                  }, null, 8, ["onClick"])
                                ]),
                                createVNode(unref(Cropper), {
                                  ref_key: "cropper",
                                  ref: cropper,
                                  class: "cropper",
                                  src: unref(img),
                                  "stencil-component": _ctx.ImageStencil
                                }, null, 8, ["src", "stencil-component"]),
                                createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                                  createVNode("button", {
                                    onClick: ($event) => open.value = false,
                                    class: "appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"
                                  }, " Cancel ", 8, ["onClick"]),
                                  createVNode("button", {
                                    onClick: crop,
                                    class: "appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase active:scale-95"
                                  }, " Save ")
                                ])
                              ])
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode(unref(TransitionChild), {
                      as: "template",
                      enter: "ease-out duration-300",
                      "enter-from": "opacity-0",
                      "enter-to": "opacity-100",
                      leave: "ease-in duration-200",
                      "leave-from": "opacity-100",
                      "leave-to": "opacity-0"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                      ]),
                      _: 1
                    }),
                    createVNode("div", { class: "fixed z-10 inset-0 overflow-y-auto" }, [
                      createVNode("div", { class: "flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0" }, [
                        createVNode(unref(TransitionChild), {
                          as: "template",
                          enter: "ease-out duration-300",
                          "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                          "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                          leave: "ease-in duration-200",
                          "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                          "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                        }, {
                          default: withCtx(() => [
                            createVNode(unref(DialogPanel), { class: "relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full" }, {
                              default: withCtx(() => [
                                createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" }, [
                                  createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                                    createVNode("h4", { class: "font-medium text-matta-black text-xl" }, " Customize photo "),
                                    createVNode("i", {
                                      class: "uil uil-times cursor-pointer text-lg",
                                      onClick: ($event) => open.value = false
                                    }, null, 8, ["onClick"])
                                  ]),
                                  createVNode(unref(Cropper), {
                                    ref_key: "cropper",
                                    ref: cropper,
                                    class: "cropper",
                                    src: unref(img),
                                    "stencil-component": _ctx.ImageStencil
                                  }, null, 8, ["src", "stencil-component"]),
                                  createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                                    createVNode("button", {
                                      onClick: ($event) => open.value = false,
                                      class: "appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"
                                    }, " Cancel ", 8, ["onClick"]),
                                    createVNode("button", {
                                      onClick: crop,
                                      class: "appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase active:scale-95"
                                    }, " Save ")
                                  ])
                                ])
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Dialog), {
                as: "div",
                class: "relative z-10",
                onClose: ($event) => open.value = false
              }, {
                default: withCtx(() => [
                  createVNode(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" })
                    ]),
                    _: 1
                  }),
                  createVNode("div", { class: "fixed z-10 inset-0 overflow-y-auto" }, [
                    createVNode("div", { class: "flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0" }, [
                      createVNode(unref(TransitionChild), {
                        as: "template",
                        enter: "ease-out duration-300",
                        "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                        "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                        leave: "ease-in duration-200",
                        "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                        "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(DialogPanel), { class: "relative bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:max-w-lg sm:w-full" }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4" }, [
                                createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                                  createVNode("h4", { class: "font-medium text-matta-black text-xl" }, " Customize photo "),
                                  createVNode("i", {
                                    class: "uil uil-times cursor-pointer text-lg",
                                    onClick: ($event) => open.value = false
                                  }, null, 8, ["onClick"])
                                ]),
                                createVNode(unref(Cropper), {
                                  ref_key: "cropper",
                                  ref: cropper,
                                  class: "cropper",
                                  src: unref(img),
                                  "stencil-component": _ctx.ImageStencil
                                }, null, 8, ["src", "stencil-component"]),
                                createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                                  createVNode("button", {
                                    onClick: ($event) => open.value = false,
                                    class: "appearance-none leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"
                                  }, " Cancel ", 8, ["onClick"]),
                                  createVNode("button", {
                                    onClick: crop,
                                    class: "appearance-none leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase active:scale-95"
                                  }, " Save ")
                                ])
                              ])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              }, 8, ["onClose"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/onboarding/PersonalAccount.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-0496f9bf"]]);
const _sfc_main = {
  __name: "personal",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_OnboardingPersonalAccount = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_OnboardingPersonalAccount, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/onboarding/personal.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=personal-ZP3HDDEV.mjs.map
