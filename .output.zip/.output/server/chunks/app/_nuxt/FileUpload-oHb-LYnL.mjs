import { ssrRenderAttrs, ssrInterpolate } from 'vue/server-renderer';
import { useSSRContext, inject, ref } from 'vue';

const sectors = [
  {
    name: "Home and Personal Care"
  },
  {
    name: "Adhesives and Sealants "
  },
  {
    name: "Agriculture and Animal Feed"
  },
  {
    name: "Automotive and Transportation"
  },
  {
    name: "Building and Construction"
  },
  {
    name: "Consumer Goods "
  },
  {
    name: "Electrical & Electronics"
  },
  {
    name: "Food and Nutrition"
  },
  {
    name: "Gases (Industrial and Medical)"
  },
  {
    name: "Healthcare and Pharmaceuticals"
  },
  {
    name: "Industrial "
  },
  {
    name: "Oil, Gas & Mininng"
  },
  {
    name: "Paints & Coatings"
  },
  {
    name: "Printing and Packaging "
  },
  {
    name: "Water Treatment"
  }
];
const _sfc_main = {
  __name: "FileUpload",
  __ssrInlineRender: true,
  props: ["label", "id", "btnText"],
  setup(__props) {
    inject("handleChange");
    ref(null);
    const title = ref("");
    const loading = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><label class="block text-sm mb-[10px] text-[#344054]">${ssrInterpolate(__props.label)}</label><div class="flex-1 rounded-lg py-1 pr-[14px] pl-2 h-11 text-sm w-full border border-[##EAECF0] placeholder:text-[#B6B7B9] bg-[#F9FAFB] focus:outline-matta-black/20 flex items-center"><input type="file" class="hidden" accept="pdf, doc,docx"><button type="button" class="text-xs text-white border border-[#98A2B3] bg-[#98A2B3] rounded px-5 py-[6px] active:scale-[.95] leading-normal flex justify-center">`);
      if (loading.value) {
        _push(`<div class="loader border-t-2 border-white border-solid rounded-full h-3 w-3 animate-spin whitespace-nowrap"></div>`);
      } else {
        _push(`<span>${ssrInterpolate(__props.btnText || "Select file")}</span>`);
      }
      _push(`</button> <div class="flex-1 px-4"><span class="max-w-max truncate text-[#999999]">${ssrInterpolate(title.value)}</span></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/FileUpload.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main;

export { __nuxt_component_3 as _, sectors as s };
//# sourceMappingURL=FileUpload-oHb-LYnL.mjs.map
