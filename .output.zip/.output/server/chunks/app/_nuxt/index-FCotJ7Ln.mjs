import { _ as __nuxt_component_0$1 } from './index-4NCxcAqd.mjs';
import { _ as __nuxt_component_1$1 } from './nuxt-img-qJohECzX.mjs';
import { _ as __nuxt_component_4 } from './index-RMKHVahR.mjs';
import { ref, reactive, watch, provide, mergeProps, unref, useSSRContext, inject, withCtx, isRef, createVNode } from 'vue';
import { s as storeToRefs, u as useRoute, a as useHead, g as getProductsByTag, b as getProducts, c as useMarketStore, n as navigateTo } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import { u as useProductStore, a as useSupplierStore } from './supplier-RTXftR8K.mjs';
import { u as ucFirst, _ as __nuxt_component_0$2 } from './ucFirst-myEoadyv.mjs';
import { _ as __nuxt_component_4$1 } from './AppButton-rwP1M0KN.mjs';
import { _ as __nuxt_component_1$2 } from './Board-3k2I8CZI.mjs';
import { _ as __nuxt_component_2$1 } from './Card-x8tysvFx.mjs';
import { _ as __nuxt_component_2$2 } from './EmptyData-RrNjecQG.mjs';
import { _ as __nuxt_component_0$3 } from './IndexModal-vEF7RYpX.mjs';
import { _ as __nuxt_component_5$1 } from './VueSelect-yd8BMEUx.mjs';
import { _ as __nuxt_component_1$3 } from './AppLoader-SkdFRsgH.mjs';
import { _ as __nuxt_component_5 } from './index-auAvMvtw.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './_plugin-vue_export-helper-yVxbj29m.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';
import './ck-white-co8-jVxZ.mjs';
import './currencyFormat-ET0sIbrj.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import '@heroicons/vue/24/solid';
import '@headlessui/vue';

const _sfc_main$3 = {
  __name: "Banner",
  __ssrInlineRender: true,
  setup(__props) {
    const query = inject("query");
    const store = useProductStore();
    const { total } = storeToRefs(store);
    const detail = ref(null);
    const router = useRoute();
    const { vendor, id } = router.params;
    const links = [
      {
        title: "Home",
        url: "/"
      },
      {
        title: vendor,
        url: "#"
      }
    ];
    const options = [
      {
        label: "Default",
        value: ""
      },
      {
        label: "Low to High",
        value: 0
      },
      {
        label: "High to Low",
        value: 1
      }
    ];
    const vendorInfo = inject("vendorInfo");
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_Breadcrumbs = __nuxt_component_0$1;
      const _component_NuxtImg = __nuxt_component_1$1;
      const _component_Select = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "" }, _attrs))}><div class="container pt-[35px] flex flex-col"><div class="mb-5">`);
      _push(ssrRenderComponent(_component_Breadcrumbs, { links }, null, _parent));
      _push(`</div><div class="bg-gray-400 rounded-[5px]"><div class="h-[160px] md:h-[210px] w-full">`);
      _push(ssrRenderComponent(_component_NuxtImg, {
        src: ((_a = unref(vendorInfo)) == null ? void 0 : _a.bannerUrl) ? unref(vendorInfo).bannerUrl : "/images/amosban.png",
        class: "w-full h-full rounded-t-[5px]"
      }, null, _parent));
      _push(`</div><div class="flex justify-between px-10 pt-[50px] pb-7 items-center bg-white rounded-[5px] relative"><div class="absolute w-20 h-20 rounded-[5px] overflow-hidden left-10 bg-white top-0 translate-y-[-60%] flex items-center justify-center border border-[#F5F5F5]"><img${ssrRenderAttr("src", ((_b = unref(detail)) == null ? void 0 : _b.logo) ? (_c = unref(detail)) == null ? void 0 : _c.logo : "/images/matta-icon.png")} class=""></div><div><h1 class="text-[#202939] text-xl font-bold capitalize mb-1">${ssrInterpolate(((_d = unref(vendorInfo)) == null ? void 0 : _d.storeName) || ((_e = unref(detail)) == null ? void 0 : _e.companyName))}</h1><p class="text-sm text-[#364152] font-medium">${ssrInterpolate(unref(total))} Products </p></div><div class="hidden md:flex">`);
      _push(ssrRenderComponent(_component_Select, {
        modelValue: unref(query).sortOrder,
        "onUpdate:modelValue": ($event) => unref(query).sortOrder = $event,
        modelModifiers: { number: true },
        options,
        placeholder: "Sort prices by",
        classInput: "min-w-[180px] !bg-white !border-[#B9C0D4] !rounded-[4px] !text-[#5D6B98] !h-11 cursor-pointer"
      }, null, _parent));
      _push(`</div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Storefront/Banner.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "SideBar",
  __ssrInlineRender: true,
  setup(__props) {
    const supplierStore = useSupplierStore();
    const marketStore = useMarketStore();
    const route = useRoute();
    const query = inject("query");
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d;
      const _component_SideTab = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white w-full pt-4 pb-2 rounded-[10px] sticky top-[120px]" }, _attrs))}><div class="flex justify-between items-center pb-2 px-[15px]"><span class="text-sm font-semibold"> Filter</span><span class="text-xs text-[#8D8D8D] cursor-pointer" as="button">Clear filter</span></div><hr class="border-[#EFEFEF] my-2">`);
      _push(ssrRenderComponent(_component_SideTab, {
        title: "Producers",
        lists: (_b = (_a = unref(supplierStore)) == null ? void 0 : _a.producersData) == null ? void 0 : _b.map((i) => ({ ...i, value: i.title })),
        modelValue: unref(query).producers,
        "onUpdate:modelValue": ($event) => unref(query).producers = $event
      }, null, _parent));
      if (unref(route).params.id) {
        _push(`<hr class="border-[#EFEFEF] my-[1px]">`);
      } else {
        _push(`<!---->`);
      }
      if (unref(route).params.id) {
        _push(ssrRenderComponent(_component_SideTab, {
          title: "Area of applications",
          lists: (_d = (_c = unref(marketStore)) == null ? void 0 : _c.marketMenuData) == null ? void 0 : _d.map((i) => ({ ...i, value: i.id })),
          modelValue: unref(query).applications,
          "onUpdate:modelValue": ($event) => unref(query).applications = $event
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Storefront/SideBar.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "Content",
  __ssrInlineRender: true,
  setup(__props) {
    const vendorInfo = inject("vendorInfo");
    const store = useProductStore();
    const supplierStore = useSupplierStore();
    const marketStore = useMarketStore();
    const { productsData, loading } = storeToRefs(store);
    const query = inject("query");
    const open = ref(false);
    const applications = ref([]);
    const producers = ref([]);
    const sortOrder = ref("");
    const options = [
      {
        label: "Low to High",
        value: 0
      },
      {
        label: "High to Low",
        value: 1
      }
    ];
    function togglePopup() {
      open.value = false;
    }
    function applyFilter() {
      query.producers = producers.value;
      query.applications = applications.value;
      query.sortOrder = sortOrder;
      open.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_AppButton = __nuxt_component_4$1;
      const _component_Select = __nuxt_component_4;
      const _component_LandingBoard = __nuxt_component_1$2;
      const _component_ProductCard = __nuxt_component_2$1;
      const _component_EmptyData = __nuxt_component_2$2;
      const _component_IndexModal = __nuxt_component_0$3;
      const _component_SelectVueSelect = __nuxt_component_5$1;
      const _component_AppLoader = __nuxt_component_1$3;
      _push(`<!--[--><div class="flex md:hidden justify-between items-center">`);
      _push(ssrRenderComponent(_component_AppButton, {
        onClick: ($event) => open.value = true,
        text: "Filter",
        icon: "tabler:filter",
        btnClass: "border border-[#ECECEC] bg-white text-[#5D6B98] !text-xs",
        iconClass: "text-sm"
      }, null, _parent));
      _push(`<div>`);
      _push(ssrRenderComponent(_component_Select, {
        modelValue: unref(query).sortOrder,
        "onUpdate:modelValue": ($event) => unref(query).sortOrder = $event,
        modelModifiers: { number: true },
        options,
        placeholder: "Sort by",
        classInput: "!bg-white !border-[#ECECEC] !rounded-[4px] !text-[#5D6B98] !text-xs !min-h-[34px] md:!h-11 cursor-pointer !w-auto !py-2"
      }, null, _parent));
      _push(`</div></div>`);
      if ((_a = unref(vendorInfo)) == null ? void 0 : _a.campaignBanner) {
        _push(`<div>`);
        _push(ssrRenderComponent(_component_LandingBoard, {
          url: (_b = unref(vendorInfo)) == null ? void 0 : _b.campaignBanner
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(loading)) {
        _push(`<div>`);
        if (unref(productsData).length) {
          _push(`<div class="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-[30px]"><!--[-->`);
          ssrRenderList(unref(productsData), (n, idx) => {
            _push(ssrRenderComponent(_component_ProductCard, {
              key: idx,
              index: idx,
              detail: n
            }, null, _parent));
          });
          _push(`<!--]--></div>`);
        } else {
          _push(`<!---->`);
        }
        if (!unref(productsData).length) {
          _push(ssrRenderComponent(_component_EmptyData, {
            title: "No product available",
            btnText: "New product",
            btnIcon: "humbleicons:plus",
            onBtnFunction: ($event) => ("navigateTo" in _ctx ? _ctx.navigateTo : unref(navigateTo))("/storefront/products/add-product")
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_IndexModal, {
        isOpen: unref(open),
        onTogglePopup: togglePopup
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c, _d, _e, _f, _g, _h;
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 gap-y-[14px] w-full px-6 pt-6 pb-10 min-w-[300px] max-w-[320px]"${_scopeId}><p class="text-base text-[#18273AF0] font-bold"${_scopeId}>Filter</p>`);
            _push2(ssrRenderComponent(_component_SelectVueSelect, {
              label: "Price",
              options,
              modelValue: unref(sortOrder),
              "onUpdate:modelValue": ($event) => isRef(sortOrder) ? sortOrder.value = $event : null,
              modelModifiers: { number: true }
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_SelectVueSelect, {
              label: "Area of application",
              options: (_b2 = (_a2 = unref(marketStore)) == null ? void 0 : _a2.marketMenuData) == null ? void 0 : _b2.map((i) => ({
                ...i,
                value: i.id,
                label: i.title
              })),
              modelValue: unref(applications),
              "onUpdate:modelValue": ($event) => isRef(applications) ? applications.value = $event : null,
              multiple: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_SelectVueSelect, {
              label: "Producers",
              options: (_d = (_c = unref(supplierStore)) == null ? void 0 : _c.producersData) == null ? void 0 : _d.map((i) => ({
                ...i,
                value: i.title,
                label: i.title
              })),
              modelValue: unref(producers),
              "onUpdate:modelValue": ($event) => isRef(producers) ? producers.value = $event : null,
              multiple: ""
            }, null, _parent2, _scopeId));
            _push2(`<button class="appearance-none leading-none px-20 py-4 w-full lg:grid-cols-2 gap-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px]"${_scopeId}> Apply Filter </button></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 gap-y-[14px] w-full px-6 pt-6 pb-10 min-w-[300px] max-w-[320px]" }, [
                createVNode("p", { class: "text-base text-[#18273AF0] font-bold" }, "Filter"),
                createVNode(_component_SelectVueSelect, {
                  label: "Price",
                  options,
                  modelValue: unref(sortOrder),
                  "onUpdate:modelValue": ($event) => isRef(sortOrder) ? sortOrder.value = $event : null,
                  modelModifiers: { number: true }
                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode(_component_SelectVueSelect, {
                  label: "Area of application",
                  options: (_f = (_e = unref(marketStore)) == null ? void 0 : _e.marketMenuData) == null ? void 0 : _f.map((i) => ({
                    ...i,
                    value: i.id,
                    label: i.title
                  })),
                  modelValue: unref(applications),
                  "onUpdate:modelValue": ($event) => isRef(applications) ? applications.value = $event : null,
                  multiple: ""
                }, null, 8, ["options", "modelValue", "onUpdate:modelValue"]),
                createVNode(_component_SelectVueSelect, {
                  label: "Producers",
                  options: (_h = (_g = unref(supplierStore)) == null ? void 0 : _g.producersData) == null ? void 0 : _h.map((i) => ({
                    ...i,
                    value: i.title,
                    label: i.title
                  })),
                  modelValue: unref(producers),
                  "onUpdate:modelValue": ($event) => isRef(producers) ? producers.value = $event : null,
                  multiple: ""
                }, null, 8, ["options", "modelValue", "onUpdate:modelValue"]),
                createVNode("button", {
                  onClick: applyFilter,
                  class: "appearance-none leading-none px-20 py-4 w-full lg:grid-cols-2 gap-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px]"
                }, " Apply Filter ")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      if (unref(loading)) {
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Storefront/Content.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$1;
const pageRange = 5;
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const store = useProductStore();
    const { productsData, loading } = storeToRefs(store);
    const route = useRoute();
    const { vendor, id } = route.params;
    useHead({
      title: `${ucFirst(vendor)} | Matta`,
      meta: [
        {
          name: "description",
          content: `${ucFirst(vendor)}`
        }
      ]
    });
    const vendorInfo = ref(null);
    const query = reactive({
      PageNumber: 1,
      PageSize: 20,
      searchParameter: route.query.search_query || "",
      MarketApplication: "",
      Status: "",
      MarketId: route.params.id,
      MarketSubApplication: "",
      productId: "",
      Search: route.query.search_query || "",
      ShowSubMenu: true,
      Producer: route.query.producer,
      producers: [],
      applications: [],
      pagecount: 0,
      totalData: 0,
      sortOrder: "",
      sortBy: 0,
      storelug: vendor
    });
    reactive({
      PageNumber: 1,
      PageSize: 20,
      tag: route.query.tag
    });
    function getAllProducts() {
      store.setLoader(true);
      if (route.query.tag) {
        getProductsByTag({
          PageNumber: 1,
          PageSize: 20,
          tag: route.query.tag,
          producers: query.producers
        }).then((res) => {
          if (res.status === 200) {
            store.setProducts(res.data.data);
            store.setLoader(false);
            query.totalData = res.data.data.totalCount;
          }
        }).catch(() => {
          store.setLoader(false);
        });
      } else {
        getProducts(query).then((res) => {
          if (res.status === 200) {
            store.setProducts(res.data);
            store.setLoader(false);
            query.totalData = res.data.totalCount;
          }
        }).catch(() => {
          store.setLoader(false);
        });
      }
    }
    function perPage({ currentPerPage }) {
      query.PageNumber = 1;
      query.PageSize = currentPerPage;
    }
    watch(
      () => [
        query.PageNumber,
        ,
        query.sortOrder,
        query.producers,
        query.sortBy,
        query.applications
      ],
      () => {
        getAllProducts();
      }
    );
    provide("query", query);
    provide("vendorInfo", vendorInfo);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_StorefrontBanner = __nuxt_component_0;
      const _component_StorefrontSideBar = __nuxt_component_1;
      const _component_StorefrontContent = __nuxt_component_2;
      const _component_Pagination = __nuxt_component_5;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "" }, _attrs))}><div class="flex flex-col w-full h-full">`);
      _push(ssrRenderComponent(_component_StorefrontBanner, null, null, _parent));
      _push(`<div class="flex flex-1 container py-6 w-full gap-x-[22px]"><div class="max-w-[250px] w-full hidden lg:block">`);
      _push(ssrRenderComponent(_component_StorefrontSideBar, null, null, _parent));
      _push(`</div><div class="flex-1 flex flex-col gap-y-6 overflow-y-auto no-scrollbar">`);
      _push(ssrRenderComponent(_component_StorefrontContent, null, null, _parent));
      if (!unref(loading) && unref(productsData).length && unref(query).totalData > unref(query).PageSize) {
        _push(ssrRenderComponent(_component_Pagination, {
          total: unref(store).total,
          current: unref(query).PageNumber,
          "per-page": unref(query).PageSize,
          pageRange,
          onPageChanged: ($event) => unref(query).PageNumber = $event,
          perPageChanged: perPage
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/[vendor]/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-FCotJ7Ln.mjs.map
