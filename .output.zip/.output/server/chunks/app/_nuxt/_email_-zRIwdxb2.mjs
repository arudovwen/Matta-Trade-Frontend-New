import { _ as __nuxt_component_0 } from './nuxt-link-fc3HHrvA.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { ref, reactive, mergeProps, unref, withCtx, createVNode, createTextVNode, useSSRContext } from 'vue';
import { u as useRoute } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import useVuelidate from '@vuelidate/core';
import { helpers, required, email, maxLength } from '@vuelidate/validators';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './_plugin-vue_export-helper-yVxbj29m.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main = {
  __name: "[email]",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const isSent = ref(false);
    const form = reactive({
      email: route.params.email
    });
    const isLoading = ref(false);
    const rules = {
      email: {
        required: helpers.withMessage("Email field cannot be empty", required),
        email: helpers.withMessage("Email is invalid", email),
        maxLength: maxLength(50)
      }
    };
    ref(false);
    useVuelidate(rules, form);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "max-w-[500px] mx-auto" }, _attrs))}><div>`);
      if (!unref(isSent)) {
        _push(`<h1 class="text-[#333] darks:text-white mb-[10px] text-[28px] font-bold text-left"> Resend verification </h1>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div>`);
      if (unref(isSent)) {
        _push(`<h1 class="text-[#333] darks:text-white mb-[10px] text-[28px] font-bold text-left"> Verification email sent! </h1>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isSent)) {
        _push(`<p class="font-normal mb-8 pb-3 rounded-lg text-sm lg:text-base"> You\u2019ll receive an email if you are registered on our system. </p>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isSent)) {
        _push(`<div class="grid gap-y-[22px] mb-9">`);
        _push(ssrRenderComponent(_component_NuxtLink, { to: "/auth/login" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_AppButton, {
                text: "Back to login",
                btnClass: "btn-primary !py-3 w-full"
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_AppButton, {
                  text: "Back to login",
                  btnClass: "btn-primary !py-3 w-full"
                })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if (!unref(isSent)) {
        _push(`<p class="mb-[28px] text-sm text-[#666] darks:text-white/80 text-left"> It appears your email hasn&#39;t been verified yet, resend a new verification link below. </p>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(isSent)) {
        _push(`<form>`);
        if (!unref(isSent)) {
          _push(`<div class="mb-10"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">E-mail</label><input${ssrRenderAttr("value", unref(route).params.email)} class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" placeholder="E-mail" autocomplete="off" autofocus="on" disabled readonly></div>`);
        } else {
          _push(`<!---->`);
        }
        if (!unref(isSent)) {
          _push(`<div class="grid gap-y-[22px] mb-9">`);
          _push(ssrRenderComponent(_component_AppButton, {
            type: "submit",
            isLoading: unref(isLoading),
            isDisabled: unref(isLoading),
            text: "Resend link",
            btnClass: "btn-primary !py-3"
          }, null, _parent));
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<span class="flex items-center text-center text-sm text-[#333] darks:text-white/80 gap-x-1 justify-center"> Have an account? `);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: "/auth/login",
          class: "font-semibold text-[#2176FF]"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Sign in`);
            } else {
              return [
                createTextVNode("Sign in")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</span></form>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/auth/resend-verification/[email].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_email_-zRIwdxb2.mjs.map
