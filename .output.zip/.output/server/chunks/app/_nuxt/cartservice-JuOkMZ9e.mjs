import { t as store, q as post, r as urls, v as get } from '../server.mjs';
import { w as withRetryHandling } from './retry-handling-kb1itlan.mjs';

const config = {
  headers: { Authorization: `Bearer ${store.getters.accessToken}` }
};
async function createcart(data) {
  return await post(urls.CREATE_CART, data, config);
}
async function updatecart(data) {
  return await post(urls.UPDATE_CART, data, config);
}
async function getcart() {
  return await get(urls.GET_CART, config);
}
async function removecartitem(data) {
  return await post(`${urls.REMOVE_CART}/${data}`, data, config);
}
async function addshipping(data) {
  return await post(urls.ADD_SHIPPING_ADDRESS, data, config);
}
async function editshipping(data) {
  return await post(urls.EDIT_SHIPPING_ADDRESS, data, config);
}
const getalladdress = withRetryHandling(() => {
  return get(`${urls.GET_SHIPPING_ADDRESS}`, config);
});
async function confirmpurchase(data) {
  return await post(`${urls.CONFIRM_PURCHASE}`, data, config);
}

export { createcart as a, addshipping as b, confirmpurchase as c, getalladdress as d, editshipping as e, getcart as g, removecartitem as r, updatecart as u };
//# sourceMappingURL=cartservice-JuOkMZ9e.mjs.map
