import { _ as __nuxt_component_0$1 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_1$1 } from './AppIcon-D3CPABPP.mjs';
import { useSSRContext, ref, reactive, computed, watch, mergeProps, unref, resolveComponent, withCtx, createVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrInterpolate } from 'vue/server-renderer';
import { useRoute } from 'vue-router';
import { t as store, v as get, r as urls, d as useAuthStore } from '../server.mjs';
import { _ as __nuxt_component_0$2 } from './client-only-uY1C8Tgt.mjs';
import { _ as __nuxt_component_1$2 } from './AppLoader-SkdFRsgH.mjs';
import { _ as __unimport_currencyFormat } from './currencyFormat-ET0sIbrj.mjs';
import moment from 'moment';
import { _ as __nuxt_component_2 } from './EmptyData-RrNjecQG.mjs';
import { w as withRetryHandling } from './retry-handling-kb1itlan.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import './AppButton-rwP1M0KN.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const config$1 = {
  headers: { Authorization: `Bearer ${store.getters.accessToken}` }
};
async function getCompanyProfile() {
  return await get(`${urls.GET_COMPANY_PROFILE}`, config$1);
}
async function getesfrontstats({ StartDate, EndDate }) {
  return await get(
    `${urls.STOREFRONT_STAT}?StartDate=${StartDate}&EndDate=${EndDate}`,
    config$1
  );
}
async function getstorefronttrending({ StartDate, EndDate, top }) {
  return await get(
    `${urls.STOREFRONT_TRENDING_PRODUCT}?StartDate=${StartDate}&EndDate=${EndDate}&top=${top}`,
    config$1
  );
}

const _sfc_main$2 = {
  __name: "VerificationBox",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const isOpen = ref(false);
    const detail = ref(null);
    function getData() {
      var _a, _b, _c;
      if (((_a = detail == null ? void 0 : detail.value) == null ? void 0 : _a.companyName) && ((_b = detail == null ? void 0 : detail.value) == null ? void 0 : _b.email) && ((_c = detail == null ? void 0 : detail.value) == null ? void 0 : _c.phone))
        return;
      getCompanyProfile().then((res) => {
        detail.value = res.data.data;
        if (!res.data.data.companyName || !res.data.data.email || !res.data.data.phone) {
          isOpen.value = true;
        }
      });
    }
    watch(route, () => {
      isOpen.value = false;
      getData();
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1$1;
      const _component_router_link = resolveComponent("router-link");
      if (unref(isOpen)) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "px-5 py-[14px] bg-[#333333] rounded-[5px] flex justify-between gap-x-40 relative mb-3" }, _attrs))}><div class="flex gap-x-4 items-center">`);
        _push(ssrRenderComponent(_component_AppIcon, {
          icon: "quill:info",
          iconClass: "text-white text-2xl"
        }, null, _parent));
        _push(`<p class="text-white text-sm max-w-[660px]"> To start selling on Matta, we are required to verify your company registration information. Kindly proceed t o provide your company details </p></div><div class="flex items-end">`);
        _push(ssrRenderComponent(_component_router_link, { to: "/company/settings" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<button class="px-8 py-[11px] rounded-[5px] bg-primary-500 hover:bg-primary/80 text-white text-sm whitespace-nowrap"${_scopeId}> Add Company details </button>`);
            } else {
              return [
                createVNode("button", { class: "px-8 py-[11px] rounded-[5px] bg-primary-500 hover:bg-primary/80 text-white text-sm whitespace-nowrap" }, " Add Company details ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/VerificationBox.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$2;
const config = {
  headers: { Authorization: `Bearer ${store.getters.accessToken}` }
};
const getorderchart = withRetryHandling(
  ({ StartDate = "", EndDate = "" }) => {
    return get(
      `${urls.ORDER_TREND}?EndDate=${EndDate}&StartDate=${StartDate}`,
      config
    );
  }
);
const getchart = withRetryHandling(
  ({ StartDate = "", EndDate = "" }) => {
    return get(
      `${urls.CHART_TREND}?EndDate=${EndDate}&StartDate=${StartDate}`,
      config
    );
  }
);
const _sfc_main$1 = {
  __name: "OverviewComponent",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    const auth = useAuthStore();
    const date = ref();
    const filters = [
      {
        title: "12 months",
        value: 12,
        duration: "months"
      },
      {
        title: "30 days",
        value: 30,
        duration: "days"
      },
      {
        title: "7 days",
        value: 7,
        duration: "days"
      },
      {
        title: "24 hours",
        value: 1,
        duration: "day"
      }
    ];
    const Statistics = [
      {
        title: "product views",
        key: "productViews",
        percent: "productViewPercentage"
      },
      {
        title: "confirmed orders",
        key: "confirmedOrders",
        percent: "confirmOrdersPecentage"
      },
      {
        title: "pending orders",
        key: "pendingOrder",
        percent: "pendingorderPercentage"
      }
    ];
    ref(new Date(moment(moment()).subtract(5, "months")));
    ref(/* @__PURE__ */ new Date());
    const query = reactive({
      StartDate: moment(moment()).subtract(5, "months").format("yyyy-MM-DD"),
      EndDate: moment().format("yyyy-MM-DD"),
      top: 10
    });
    const active = ref(null);
    const stats = ref(null);
    const trending = ref([]);
    const thisyear = ref([]);
    const thisyearseries = ref([]);
    const lastyearseries = ref([]);
    const showChart = ref(false);
    const viewmonth = ref([]);
    const viewseries = ref([]);
    const quotemonth = ref([]);
    const quoteseries = ref([]);
    const balancemonth = ref([]);
    const balanceseries = ref([]);
    const confirmmonth = ref([]);
    const confirmseries = ref([]);
    function getAllCharts() {
      getorderchart(query).then((res) => {
        var _a, _b;
        if (res.status === 200) {
          thisyear.value = (_a = res.data.data.data[0]) == null ? void 0 : _a.chartrecords.map(
            (item) => item.month
          );
          thisyearseries.value = (_b = res.data.data.data[1]) == null ? void 0 : _b.chartrecords.map(
            (item) => item.total
          );
          lastyearseries.value = res.data.data.data[0].chartrecords.map(
            (item) => item.total
          );
          showChart.value = true;
        }
      });
      getchart(query).then((res) => {
        if (res.status === 200) {
          viewmonth.value = res.data.data.viewTrends.data[0].chartrecords.map(
            (item) => item.month
          );
          viewseries.value = res.data.data.viewTrends.data[0].chartrecords.map(
            (item) => item.total
          );
          quotemonth.value = res.data.data.quoteTrend.data[0].chartrecords.map(
            (item) => item.month
          );
          quoteseries.value = res.data.data.quoteTrend.data[0].chartrecords.map(
            (item) => item.total
          );
          balancemonth.value = res.data.data.orderTotalTrend.data[0].chartrecords.map(
            (item) => item.month
          );
          balanceseries.value = res.data.data.orderTotalTrend.data[0].chartrecords.map(
            (item) => item.total
          );
          confirmmonth.value = res.data.data.orderTrend.data[0].chartrecords.map(
            (item) => item.month
          );
          confirmseries.value = res.data.data.orderTrend.data[0].chartrecords.map(
            (item) => item.total
          );
        }
      });
    }
    useRoute();
    computed(() => {
      return [
        {
          name: "This year",
          data: thisyearseries.value
        },
        {
          name: "Last year",
          data: lastyearseries.value
        }
      ];
    });
    computed(() => {
      return {
        colors: ["#165EF0", "#B6B7B9"],
        yaxis: {
          show: false
        },
        legend: {
          show: false
        },
        chart: {
          toolbar: {
            show: false
          }
        },
        grid: {
          show: false
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          curve: "smooth",
          width: 1
        },
        xaxis: {
          categories: thisyear.value
        },
        tooltip: {
          y: {
            format: "MM dd",
            formatter: (value) => __unimport_currencyFormat(value)
          }
        }
      };
    });
    computed(() => {
      return {
        colors: ["#165EF0"],
        yaxis: {
          show: false
        },
        legend: {
          show: false
        },
        toolbar: {
          show: false
        },
        grid: {
          show: false
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          curve: "smooth",
          width: 1
        },
        chart: {
          toolbar: {
            show: false
          }
        },
        xaxis: {
          categories: viewmonth.value,
          labels: {
            show: false
          },
          axisBorder: { show: false }
        }
      };
    });
    computed(() => {
      return [
        {
          name: "Total",
          data: viewseries.value
        }
      ];
    });
    computed(() => {
      return {
        colors: ["#165EF0"],
        yaxis: {
          show: false
        },
        legend: {
          show: false
        },
        toolbar: {
          show: false
        },
        grid: {
          show: false
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          curve: "smooth",
          width: 1
        },
        chart: {
          toolbar: {
            show: false
          }
        },
        xaxis: {
          categories: quotemonth.value,
          labels: {
            show: false
          },
          axisBorder: { show: false }
        }
      };
    });
    computed(() => {
      return [
        {
          name: "Total",
          data: quoteseries.value
        }
      ];
    });
    computed(() => {
      return {
        colors: ["#165EF0"],
        yaxis: {
          show: false
        },
        legend: {
          show: false
        },
        toolbar: {
          show: false
        },
        grid: {
          show: false
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          curve: "smooth",
          width: 1
        },
        chart: {
          toolbar: {
            show: false
          }
        },
        tooltip: {
          y: {
            format: "MM dd",
            formatter: (value) => __unimport_currencyFormat(value)
          }
        },
        xaxis: {
          categories: balancemonth.value,
          labels: {
            show: false
          },
          axisBorder: { show: false }
        }
      };
    });
    computed(() => {
      return [
        {
          name: "Total",
          data: balanceseries.value
        }
      ];
    });
    computed(() => {
      return {
        colors: ["#165EF0"],
        yaxis: {
          show: false
        },
        legend: {
          show: false
        },
        toolbar: {
          show: false
        },
        grid: {
          show: false
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          curve: "smooth",
          width: 1
        },
        chart: {
          toolbar: {
            show: false
          }
        },
        xaxis: {
          categories: confirmmonth.value,
          labels: {
            show: false
          },
          axisBorder: { show: false }
        }
      };
    });
    computed(() => {
      return [
        {
          name: "Total",
          data: confirmseries.value
        }
      ];
    });
    const theads = ["product", "created", "views", "orders"];
    watch(date, () => {
      if (date.value) {
        query.StartDate = date.value[0];
        query.EndDate = date.value[1];
        getesfrontstats(query).then((res) => {
          stats.value = res.data.data;
        });
        getstorefronttrending(query).then((res) => {
          trending.value = res.data.data.slice(0, 9);
        });
        getAllCharts();
      }
    });
    computed(() => {
      return new Date(moment(date.value.startDate).add(5, "months"));
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_HeaderComponent = __nuxt_component_0$1;
      const _component_VerificationBox = __nuxt_component_1;
      const _component_ClientOnly = __nuxt_component_0$2;
      const _component_AppIcon = __nuxt_component_1$1;
      const _component_client_only = __nuxt_component_0$2;
      const _component_AppLoader = __nuxt_component_1$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "gap-y-2 flex flex-col" }, _attrs))} data-v-d3204d59><div data-v-d3204d59>`);
      _push(ssrRenderComponent(_component_HeaderComponent, {
        welcome: `Welcome back, ${(_b = (_a = unref(auth)) == null ? void 0 : _a.userInfo) == null ? void 0 : _b.firstName}`,
        subtext: "Your current sales summary and activity.",
        className: "!px-0 !py-0 pb-6 !border-none mb-[15px]"
      }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_VerificationBox, null, null, _parent));
      if (unref(stats)) {
        _push(`<div class="pb-10" data-v-d3204d59><div class="p-6 rounded-[10px] bg-white mb-8 shadow-[0px_2px_4px_0px_rgba(0,0,0,0.04)]" data-v-d3204d59><div class="mb-10 flex justify-between items-center" data-v-d3204d59><div class="border border-[#D0D5DD] rounded-lg overflow-hidden text-sm text-[#344054] max-w-max" data-v-d3204d59><!--[-->`);
        ssrRenderList(filters, (n) => {
          _push(`<button class="${ssrRenderClass([unref(active) === n.value ? "bg-[#F9FAFB]" : "", "px-4 py-2 border-r border-[#D0D5DD] last:border-none font-semibold"])}" data-v-d3204d59>${ssrInterpolate(n.title)}</button>`);
        });
        _push(`<!--]--></div><div class="max-w-[200px]" data-v-d3204d59>`);
        _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
        _push(`</div></div><div class="flex gap-x-8 w-full" data-v-d3204d59><div class="flex-1" data-v-d3204d59><div class="" data-v-d3204d59><div class="flex justify-between" data-v-d3204d59><div data-v-d3204d59><span class="block text-sm text-[#475467] font-medium" data-v-d3204d59>Total Amount</span><div class="flex gap-x-1 items-start" data-v-d3204d59><span class="block text-[30px] font-bold" data-v-d3204d59><span class="block text-[30px] font-semibold text-[#101828]" data-v-d3204d59>${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(unref(stats).currentBalance))}</span></span><span class="text-xs flex gap-x-1 items-center text-[#17B26A]" data-v-d3204d59>`);
        _push(ssrRenderComponent(_component_AppIcon, {
          icon: "uil:arrow-growth",
          iconClass: "!text-[#17B26A]"
        }, null, _parent));
        _push(`<span data-v-d3204d59>${ssrInterpolate(unref(stats).currentBalancePecentage)}%</span></span></div></div></div>`);
        _push(ssrRenderComponent(_component_client_only, null, {}, _parent));
        _push(`</div></div><div class="w-[200px] flex flex-col gap-y-6" data-v-d3204d59><!--[-->`);
        ssrRenderList(Statistics, (n) => {
          _push(`<div class="leading-tight" data-v-d3204d59><span class="block text-[#475467] font-medium text-sm capitalize" data-v-d3204d59>${ssrInterpolate(n.title)}</span><div class="flex gap-x-1 items-start" data-v-d3204d59><span class="block text-[30px] font-bold" data-v-d3204d59>${ssrInterpolate(unref(stats)[n.key])}</span><span class="text-xs flex gap-x-1 items-center text-[#17B26A]" data-v-d3204d59>`);
          _push(ssrRenderComponent(_component_AppIcon, {
            icon: "uil:arrow-growth",
            iconClass: "!text-[#17B26A]"
          }, null, _parent));
          _push(`<span data-v-d3204d59>${ssrInterpolate(unref(stats)[n.percent])}%</span></span></div></div>`);
        });
        _push(`<!--]--></div></div></div><div class="rounded-[10px] bg-white border border-[#F4F7FE] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.04)]" data-v-d3204d59>`);
        _push(ssrRenderComponent(_component_HeaderComponent, {
          title: "Trending Products",
          className: "!px-5"
        }, null, _parent));
        _push(`<div data-v-d3204d59><div class="overflow-x-auto max-w-[80vw] lg:max-w-full" data-v-d3204d59>`);
        if (unref(trending).length) {
          _push(`<table class="w-full" data-v-d3204d59><thead data-v-d3204d59><tr data-v-d3204d59><!--[-->`);
          ssrRenderList(theads, (item) => {
            _push(`<th class="capitalize text-[#475467] text-sm text-left font-medium border-b py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-d3204d59>${ssrInterpolate(item)}</th>`);
          });
          _push(`<!--]--></tr></thead><tbody data-v-d3204d59><!--[-->`);
          ssrRenderList(unref(trending), (item) => {
            _push(`<tr data-v-d3204d59><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-d3204d59><span data-v-d3204d59><span class="text-sm font-medium" data-v-d3204d59>${ssrInterpolate(item.product)}</span><br data-v-d3204d59><span class="text-xs font-normal" data-v-d3204d59>${ssrInterpolate(item.manufacturer)}</span></span></td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-d3204d59>${ssrInterpolate(unref(moment)(item.created).format("lll"))}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-d3204d59>${ssrInterpolate(item.views)}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-d3204d59>${ssrInterpolate(item.orders)}</td></tr>`);
          });
          _push(`<!--]--></tbody></table>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
        if (!unref(trending).length) {
          _push(ssrRenderComponent(unref(__nuxt_component_2), {
            buttonText: "",
            text: "No orders yet"
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div></div>`);
      } else {
        _push(`<div class="text-center p-6 lg:p-8 my-24" data-v-d3204d59>`);
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
        _push(`</div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/OverviewComponent.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-d3204d59"]]);
const _sfc_main = {
  __name: "overview",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierOverviewComponent = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierOverviewComponent, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/overview.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=overview-tSSclW-l.mjs.map
