import { _ as __nuxt_component_0$1 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_1 } from './index-eSH9oSpY.mjs';
import { _ as __nuxt_component_0$2 } from './UploadComponent-Lr7bqIOL.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { a as useHead, d as useAuthStore } from '../server.mjs';
import { useSSRContext, ref, reactive, watch, resolveComponent, mergeProps, unref, isRef, withCtx, createVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import debounce from 'lodash/debounce.js';
import { useForm } from 'vee-validate';
import * as yup from 'yup';
import { toast } from 'vue3-toastify';
import { u as updateVendorInfo, p as postStoreName } from './userservices-KlieBUHg.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import '../../rollup/_vue.mjs';
import 'cleave.js';
import './nuxt-img-qJohECzX.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$1 = {
  __name: "Customization",
  __ssrInlineRender: true,
  setup(__props) {
    const authStore = useAuthStore();
    const isLoading = ref(false);
    const formValues = reactive({
      storeName: "",
      storeSlug: "",
      bannerUrl: "",
      campaignBanner: "",
      businessId: authStore.userId
    });
    const schema = yup.object({
      storeName: yup.string().required("Your store name is required")
    });
    const { handleSubmit, defineField, errors, setFieldValue, setValues } = useForm(
      {
        validationSchema: schema,
        initialValues: formValues
      }
    );
    const onGetBanner = (value) => {
      formValues.bannerUrl = value;
      setFieldValue("bannerUrl", value);
    };
    const onGetCampaign = (value) => {
      formValues.campaignBanner = value;
      setFieldValue("campaignBanner", value);
    };
    const removeFile = () => {
    };
    const [storeName, storeNameAtt] = defineField("storeName");
    ref(null);
    handleSubmit((values) => {
      isLoading.value = true;
      updateVendorInfo(values).then((res) => {
        if (res.status === 200) {
          toast.success("Information saved");
          isLoading.value = false;
        }
      }).catch((err) => {
        isLoading.value = false;
        if (err.response.data.message || err.response.data.Message) {
          toast.error(err.response.data.message || err.response.data.Message);
        }
      });
    });
    const getProfileData = debounce(() => {
      postStoreName(storeName.value).then((res) => {
        formValues.storeSlug = res.data.data;
        setFieldValue("storeSlug", res.data.data);
      });
    }, 1e3);
    watch(
      () => [storeName.value],
      () => {
        if (storeName.value.length > 3) {
          getProfileData();
        }
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderComponent = __nuxt_component_0$1;
      const _component_Textinput = __nuxt_component_1;
      const _component_UploadComponent = __nuxt_component_0$2;
      const _component_router_link = resolveComponent("router-link");
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "gap-y-2 flex flex-col bg-white rounded-[10px] pb-10 border border-[#F4F7FE]" }, _attrs))} data-v-229a9ac5>`);
      _push(ssrRenderComponent(_component_HeaderComponent, {
        title: "Customization",
        subtext: "Setup the look and feel of your store"
      }, null, _parent));
      _push(`<div class="p-[30px]" data-v-229a9ac5><form data-v-229a9ac5><div class="mb-6 grid grid-cols-1 xl:grid-cols-2 xl:gap-x-6 gap-y-5" data-v-229a9ac5>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Name of store",
        name: "storeName"
      }, unref(storeNameAtt), {
        modelValue: unref(storeName),
        "onUpdate:modelValue": ($event) => isRef(storeName) ? storeName.value = $event : null,
        error: unref(errors).storeName
      }), null, _parent));
      _push(ssrRenderComponent(_component_Textinput, {
        placeholder: "",
        label: "Store url",
        name: "storeSlug",
        modelValue: `https://matta.trade/${unref(formValues).storeSlug}`,
        disabled: "",
        isReadonly: ""
      }, null, _parent));
      _push(`</div><div class="mb-6" data-v-229a9ac5><label class="mb-2 font-medium text-sm block" data-v-229a9ac5>Storefront Banner <span class="text-[#B9B9B9]" data-v-229a9ac5>(Optional)</span></label>`);
      _push(ssrRenderComponent(_component_UploadComponent, {
        onOnGetFiles: onGetBanner,
        onRemoveFile: removeFile,
        support: "SVG, PNG, JPG (max. 800x400px)",
        "is-multiple": false,
        id: "bannerUrl",
        url: unref(formValues).bannerUrl
      }, null, _parent));
      _push(`</div><div class="mb-6" data-v-229a9ac5><label class="mb-1 font-medium text-sm block" data-v-229a9ac5>Campaign Banner <span class="text-[#B9B9B9]" data-v-229a9ac5>(Optional)</span></label><p class="mb-2 text-xs text-[#555555]" data-v-229a9ac5> Campaign bannerUrls can be used to show you\u2019re running a discount promotion </p>`);
      _push(ssrRenderComponent(_component_UploadComponent, {
        onOnGetFiles: onGetCampaign,
        onRemoveFile: removeFile,
        support: "SVG, PNG, JPG (max. 800x400px)",
        recommended: "Recommended size: 1000px by 150px",
        "is-multiple": false,
        id: "campaignBanner",
        url: unref(formValues).campaignBanner
      }, null, _parent));
      _push(`</div><div class="bg-white flex justify-between gap-x-10 items-center sticky bottom-0 pb-6" data-v-229a9ac5>`);
      _push(ssrRenderComponent(_component_router_link, { to: "/company/settings" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button type="button" class="appearance-none leading-none px-10 py-[10px] rounded-[6px] text-primary border-primary- border hover:bg-gray-50 text-sm" data-v-229a9ac5${_scopeId}> Cancel </button>`);
          } else {
            return [
              createVNode("button", {
                type: "button",
                class: "appearance-none leading-none px-10 py-[10px] rounded-[6px] text-primary border-primary- border hover:bg-gray-50 text-sm"
              }, " Cancel ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="flex gap-x-4 items-center" data-v-229a9ac5>`);
      _push(ssrRenderComponent(_component_AppButton, {
        disabled: unref(isLoading),
        isLoading: unref(isLoading),
        btnClass: "bg-primary-500 text-white !px-10  !text-sm !py-[10px] disabled:cursor-not-allowed",
        type: "submit",
        text: "Save"
      }, null, _parent));
      _push(`</div></div></form></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/Customization.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-229a9ac5"]]);
const _sfc_main = {
  __name: "customization",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Customization | Matta",
      meta: [{ name: "description", content: "Customization" }]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierCustomization = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierCustomization, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/company/customization.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=customization-H19P-KZu.mjs.map
