import { _ as __unimport_currencyFormat } from './currencyFormat-ET0sIbrj.mjs';
import { mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import moment from 'moment';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';

const _sfc_main = {
  __name: "OrderComponent",
  __ssrInlineRender: true,
  props: ["order", "timeline"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      if (__props.order) {
        _push(`<section${ssrRenderAttrs(mergeProps({ class: "flex flex-col gap-y-8" }, _attrs))} data-v-20518750><div class="grid grid-cols-2 gap-y-10 gap-x-4 mb-8" data-v-20518750><div data-v-20518750><p class="text-[12px] text-[#B6B7B9] mb-1 capitalize" data-v-20518750>status</p>`);
        if (__props.order.statusText == "invoiced") {
          _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#E0F7B0]" data-v-20518750> Completed</span>`);
        } else {
          _push(`<!---->`);
        }
        if (__props.order.statusText !== "invoiced") {
          _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#FDD0AF]" data-v-20518750> In progress</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><div data-v-20518750><p class="text-[12px] text-[#B6B7B9] mb-1 capitalize" data-v-20518750>created</p><span class="text-sm" data-v-20518750>${ssrInterpolate(unref(moment)(__props.order.orderDate).format("ll"))}</span></div><div data-v-20518750><p class="text-[12px] text-[#B6B7B9] mb-1 capitalize" data-v-20518750> scheduled pickup date </p><span class="text-sm" data-v-20518750>${ssrInterpolate(unref(moment)(__props.order.schedulePickupDate || "").format("ll"))}</span></div><div data-v-20518750><p class="text-[12px] text-[#B6B7B9] mb-1 capitalize" data-v-20518750> scheduled delivery date </p><span class="text-sm" data-v-20518750>${ssrInterpolate(unref(moment)(__props.order.scheduleDeliveryDate).format("ll"))}</span></div></div><div class="bg-[#182230] rounded-lg p-6 text-white" data-v-20518750><div class="flex justify-between mb-6" data-v-20518750><h3 class="text-lg font-medium" data-v-20518750>Order Summary</h3></div><!--[-->`);
        ssrRenderList(__props.order.orderDetails, (item, id) => {
          _push(`<div data-v-20518750><div class="flex justify-between items-end gap-x-2 mb-1" data-v-20518750><div class="text-[#E1E1E1] pt-1 flex items-end text-sm" data-v-20518750><span data-v-20518750><span class="text-sm font-medium" data-v-20518750>${ssrInterpolate(item.product)}</span><br data-v-20518750><span class="text-xs flex gap-x-3 text-[#98A2B3]" data-v-20518750><span data-v-20518750>${ssrInterpolate(item.selectedPackage)}</span><span data-v-20518750>x${ssrInterpolate(item.quantity)}</span></span></span></div><span class="text-right" data-v-20518750>${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(item.itemTotal))}</span></div><div class="flex justify-between items-end gap-x-2 border-b pb-6 border-[#ddd] mb-4" data-v-20518750><div class="text-matta-black pt-1 flex items-end text-sm" data-v-20518750><span class="flex gap-x-2" data-v-20518750><span class="text-xs text-[#98A2B3]" data-v-20518750>With Tax</span></span></div><span class="text-right" data-v-20518750>${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(item.itemTotal_with_tax))}</span></div></div>`);
        });
        _push(`<!--]--><div class="flex justify-between gap-x-2" data-v-20518750><div class="text-[#E1E1E1] text-sm" data-v-20518750>Item total</div><div class="text-right py-1" data-v-20518750>${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(__props.order.orderTotal))}</div></div><div class="flex justify-between gap-x-2" data-v-20518750><div class="text-sm text-[#E1E1E1]" data-v-20518750>Tax <span class="text-xs" data-v-20518750>(7.5%)</span></div><div class="text-right py-1" data-v-20518750>${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(__props.order.orderTotalwithTax - __props.order.orderTotal))}</div></div><div class="flex justify-between gap-x-2 border-b border-[#ddd] mb-6" data-v-20518750><div class="text-[#E1E1E1] pt-1 pb-6 flex items-center text-sm" data-v-20518750> Shipping &amp; handling <i class="uil uil-info-circle text-sm ml-1" data-v-20518750></i></div><div class="text-right pt-1 pb-6" data-v-20518750>TBD</div></div><div class="flex justify-between gap-x-2 mb-6" data-v-20518750><div class="text-[#E1E1E1]text-sm" data-v-20518750>Total</div><div class="text-xl text-right font-medium" data-v-20518750>${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(__props.order.orderTotalwithTax))}</div></div></div><div class="bg-[#F1F3F5] rounded-lg p-6 text-matta-black" data-v-20518750><div class="flex justify-between mb-6" data-v-20518750><h3 class="text-lg font-medium" data-v-20518750>Timeline</h3><span data-v-20518750><i class="uil uil-minusext-lg" data-v-20518750></i></span></div><ul class="grid grid-cols-1 gap-4" data-v-20518750><!--[-->`);
        ssrRenderList(__props.timeline, (item, id) => {
          _push(`<li class="group" data-v-20518750><div class="py-4 items-center hidden group-last:flex" data-v-20518750><span class="bg-matta-black h-[2px] rounded-l flex-1" data-v-20518750></span><span class="h-4 w-4 rounded-full bg-matta-black" data-v-20518750></span></div><div class="flex justify-start items-center gap-x-2 opacity-50 group-last:opacity-100" data-v-20518750><span class="group-last:bg-primary-500 group-last:text-white w-[46px] h-[46px] rounded-full flex items-center justify-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black border border-[#ddd] shadow-sm" data-v-20518750><i class="uil uil-check" data-v-20518750></i></span><span data-v-20518750><span class="text-xs text-[#ABABAB]" data-v-20518750>${ssrInterpolate(unref(moment)(item.activityDate).format("ll"))}, ${ssrInterpolate(item.activityTime)}</span><br data-v-20518750><span class="text-xs" data-v-20518750><span data-v-20518750>${ssrInterpolate(item.description)}</span></span></span></div></li>`);
        });
        _push(`<!--]--></ul></div></section>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/OrderComponent.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const OrderComponent = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-20518750"]]);

export { OrderComponent as O };
//# sourceMappingURL=OrderComponent--EOiqvJi.mjs.map
