import { _ as __nuxt_component_0$2 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_1$1 } from './AppLoader-SkdFRsgH.mjs';
import { useSSRContext, ref, reactive, resolveComponent, mergeProps, withCtx, createVNode, unref, openBlock, createBlock, createCommentVNode, inject, provide, resolveDirective, createTextVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr, ssrRenderClass, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrGetDirectiveProps } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import { _ as __nuxt_component_1$2 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_0$1 } from './IndexModal-vEF7RYpX.mjs';
import useVuelidate from '@vuelidate/core';
import { helpers, required, numeric, maxLength, minLength } from '@vuelidate/validators';
import { r as removeBeneficiary, g as getWalletDetails, a as getBeneficiaries } from './walletservice-pesZWM8C.mjs';
import { _ as __unimport_currencyFormat } from './currencyFormat-ET0sIbrj.mjs';
import { a as getDefaultExportFromCjs, r as require$$0 } from '../../rollup/_vue.mjs';
import { C as CurrencyInput } from './CurrencyInput-krSh-4ij.mjs';
import { P as PhoneCodes } from './PhoneCodes-TGlMinMT.mjs';
import { y as useStore } from '../server.mjs';
import { useRoute } from 'vue-router';
import './AppButton-rwP1M0KN.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '@iconify/vue';
import '@heroicons/vue/24/solid';
import '@headlessui/vue';
import 'vue-currency-input';
import 'country-list-with-dial-code-and-flag';
import 'unhead';
import '@unhead/shared';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';

var vue=require$$0;function _iterableToArrayLimit(arr, i) {
  var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
  if (null != _i) {
    var _s,
      _e,
      _x,
      _r,
      _arr = [],
      _n = !0,
      _d = !1;
    try {
      if (_x = (_i = _i.call(arr)).next, 0 === i) {
        if (Object(_i) !== _i) return;
        _n = !1;
      } else for (; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
    } catch (err) {
      _d = !0, _e = err;
    } finally {
      try {
        if (!_n && null != _i.return && (_r = _i.return(), Object(_r) !== _r)) return;
      } finally {
        if (_d) throw _e;
      }
    }
    return _arr;
  }
}
function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}
function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;
  for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
  return arr2;
}
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}var script$1 = vue.defineComponent({
  name: "SingleOtpInput",
  props: {
    inputType: {
      type: String,
      validator: function validator(value) {
        return ["number", "tel", "letter-numeric", "password"].includes(value);
      },
      default: "tel"
    },
    inputmode: {
      type: String,
      default: "numeric"
    },
    value: {
      type: [String, Number]
    },
    separator: {
      type: String
    },
    focus: {
      type: Boolean
    },
    inputClasses: {
      type: [String, Array]
    },
    conditionalClass: {
      type: String
    },
    shouldAutoFocus: {
      type: Boolean
    },
    isLastChild: {
      type: Boolean
    },
    placeholder: {
      type: String
    },
    isDisabled: {
      type: Boolean
    }
  },
  emits: ["on-change", "on-keydown", "on-paste", "on-focus", "on-blur"],
  setup: function setup(props, _ref) {
    var emit = _ref.emit;
    var model = vue.ref(props.value || "");
    var input = vue.ref(null);
    var handleOnChange = function handleOnChange() {
      model.value = model.value.toString();
      if (model.value.length > 1) {
        model.value = model.value.slice(0, 1);
      }
      return emit("on-change", model.value);
    };
    var isCodeLetter = function isCodeLetter(charCode) {
      return charCode >= 65 && charCode <= 90;
    };
    var isCodeNumeric = function isCodeNumeric(charCode) {
      return charCode >= 48 && charCode <= 57 || charCode >= 96 && charCode <= 105;
    };
    // numeric keys and numpad keys

    var handleOnKeyDown = function handleOnKeyDown(event) {
      if (props.isDisabled) {
        event.preventDefault();
      }
      // Only allow characters 0-9, DEL, Backspace, Enter, Right and Left Arrows, and Pasting
      var keyEvent = event || window.event;
      var charCode = keyEvent.which ? keyEvent.which : keyEvent.keyCode;
      if (isCodeNumeric(charCode) || props.inputType === "letter-numeric" && isCodeLetter(charCode) || [8, 9, 13, 37, 39, 46, 86].includes(charCode)) {
        emit("on-keydown", event);
      } else {
        keyEvent.preventDefault();
      }
    };
    var handleOnPaste = function handleOnPaste(event) {
      return emit("on-paste", event);
    };
    var handleOnFocus = function handleOnFocus() {
      input.value.select();
      return emit("on-focus");
    };
    var handleOnBlur = function handleOnBlur() {
      return emit("on-blur");
    };
    vue.watch(function () {
      return props.value;
    }, function (newValue, oldValue) {
      if (newValue !== oldValue) {
        model.value = newValue;
      }
    });
    vue.watch(function () {
      return props.focus;
    }, function (newFocusValue, oldFocusValue) {
      // Check if focusedInput changed
      // Prevent calling function if input already in focus
      if (oldFocusValue !== newFocusValue && input.value && props.focus) {
        input.value.focus();
        input.value.select();
      }
    });
    vue.onMounted(function () {
      if (input.value && props.focus && props.shouldAutoFocus) {
        input.value.focus();
        input.value.select();
      }
    });
    return {
      handleOnChange: handleOnChange,
      handleOnKeyDown: handleOnKeyDown,
      handleOnPaste: handleOnPaste,
      handleOnFocus: handleOnFocus,
      handleOnBlur: handleOnBlur,
      input: input,
      model: model,
      inputTypeValue: props.inputType === "letter-numeric" ? "text" : props.inputType
    };
  }
});var _hoisted_1$1 = {
  style: {
    "display": "flex",
    "align-items": "center"
  }
};
var _hoisted_2$1 = ["type", "inputmode", "placeholder", "disabled"];
var _hoisted_3 = {
  key: 0
};
var _hoisted_4 = ["innerHTML"];
function render$1(_ctx, _cache, $props, $setup, $data, $options) {
  return vue.openBlock(), vue.createElementBlock("div", _hoisted_1$1, [vue.withDirectives(vue.createElementVNode("input", {
    "data-test": "single-input",
    type: _ctx.inputTypeValue,
    inputmode: _ctx.inputmode,
    placeholder: _ctx.placeholder,
    disabled: _ctx.isDisabled,
    ref: "input",
    min: "0",
    max: "9",
    maxlength: "1",
    pattern: "[0-9]",
    "onUpdate:modelValue": _cache[0] || (_cache[0] = function ($event) {
      return _ctx.model = $event;
    }),
    class: vue.normalizeClass([_ctx.inputClasses, _ctx.conditionalClass, {
      'is-complete': _ctx.model
    }]),
    onInput: _cache[1] || (_cache[1] = function () {
      return _ctx.handleOnChange && _ctx.handleOnChange.apply(_ctx, arguments);
    }),
    onKeydown: _cache[2] || (_cache[2] = function () {
      return _ctx.handleOnKeyDown && _ctx.handleOnKeyDown.apply(_ctx, arguments);
    }),
    onPaste: _cache[3] || (_cache[3] = function () {
      return _ctx.handleOnPaste && _ctx.handleOnPaste.apply(_ctx, arguments);
    }),
    onFocus: _cache[4] || (_cache[4] = function () {
      return _ctx.handleOnFocus && _ctx.handleOnFocus.apply(_ctx, arguments);
    }),
    onBlur: _cache[5] || (_cache[5] = function () {
      return _ctx.handleOnBlur && _ctx.handleOnBlur.apply(_ctx, arguments);
    })
  }, null, 42, _hoisted_2$1), [[vue.vModelDynamic, _ctx.model]]), !_ctx.isLastChild && _ctx.separator ? (vue.openBlock(), vue.createElementBlock("span", _hoisted_3, [vue.createElementVNode("span", {
    innerHTML: _ctx.separator
  }, null, 8, _hoisted_4)])) : vue.createCommentVNode("", true)]);
}script$1.render = render$1;// keyCode constants
var BACKSPACE = 8;
var LEFT_ARROW = 37;
var RIGHT_ARROW = 39;
var DELETE = 46;
var script = /* #__PURE__ */vue.defineComponent({
  name: "Vue3OtpInput",
  // vue component name
  components: {
    SingleOtpInput: script$1
  },
  props: {
    value: {
      type: String,
      default: "",
      required: true
    },
    numInputs: {
      default: 4
    },
    separator: {
      type: String,
      default: "**"
    },
    inputClasses: {
      type: [String, Array]
    },
    conditionalClass: {
      type: Array,
      default: []
    },
    inputType: {
      type: String,
      validator: function validator(value) {
        return ["number", "tel", "letter-numeric", "password"].includes(value);
      }
    },
    inputmode: {
      type: String,
      validator: function validator(value) {
        return ["numeric", "text", "tel", "none"].includes(value);
      },
      default: "numeric"
    },
    shouldAutoFocus: {
      type: Boolean,
      default: false
    },
    placeholder: {
      type: Array,
      default: []
    },
    isDisabled: {
      type: Boolean,
      default: false
    }
  },
  setup: function setup(props, _ref) {
    var emit = _ref.emit;
    var activeInput = vue.ref(0);
    var otp = vue.ref([]);
    var oldOtp = vue.ref([]);
    vue.watch(function () {
      return props.value;
    }, function (val) {
      var fill = vue.unref(val).split("");
      otp.value = fill;
    }, {
      immediate: true
    });
    var handleOnFocus = function handleOnFocus(index) {
      activeInput.value = index;
    };
    var handleOnBlur = function handleOnBlur() {
      activeInput.value = -1;
    };

    // Helper to return OTP from input
    var checkFilledAllInputs = function checkFilledAllInputs() {
      if (otp.value.join("").length === props.numInputs) {
        emit("update:value", otp.value.join(""));
        return emit("on-complete", otp.value.join(""));
      }
      return "Wait until the user enters the required number of characters";
    };

    // Focus on input by index
    var focusInput = function focusInput(input) {
      activeInput.value = Math.max(Math.min(props.numInputs - 1, input), 0);
    };
    // Focus on next input
    var focusNextInput = function focusNextInput() {
      focusInput(activeInput.value + 1);
    };
    // Focus on previous input
    var focusPrevInput = function focusPrevInput() {
      focusInput(activeInput.value - 1);
    };

    // Change OTP value at focused input
    var changeCodeAtFocus = function changeCodeAtFocus(value) {
      oldOtp.value = Object.assign([], otp.value);

      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      otp.value[activeInput.value] = value;
      if (oldOtp.value.join("") !== otp.value.join("")) {
        emit("update:value", otp.value.join(""));
        emit("on-change", otp.value.join(""));
        checkFilledAllInputs();
      }
    };

    // Handle pasted OTP
    var handleOnPaste = function handleOnPaste(event) {
      event.preventDefault();
      var pastedData = event.clipboardData.getData("text/plain").slice(0, props.numInputs - activeInput.value).split("");
      if (props.inputType === "number" && !pastedData.join("").match(/^\d+$/)) {
        return "Invalid pasted data";
      }
      if (props.inputType === "letter-numeric" && !pastedData.join("").match(/^\w+$/)) {
        return "Invalid pasted data";
      }
      // Paste data from focused input onwards
      var currentCharsInOtp = otp.value.slice(0, activeInput.value);
      var combinedWithPastedData = currentCharsInOtp.concat(pastedData);
      combinedWithPastedData.slice(0, props.numInputs).forEach(function (value, i) {
        otp.value[i] = value;
      });
      focusInput(combinedWithPastedData.slice(0, props.numInputs).length);
      return checkFilledAllInputs();
    };
    var handleOnChange = function handleOnChange(value) {
      changeCodeAtFocus(value);
      focusNextInput();
    };
    var clearInput = function clearInput() {
      if (otp.value.length > 0) {
        emit("update:value", "");
        emit("on-change", "");
      }
      otp.value = [];
      activeInput.value = 0;
    };
    var fillInput = function fillInput(value) {
      var fill = value.split("");
      if (fill.length === props.numInputs) {
        otp.value = fill;
        emit("update:value", otp.value.join(""));
        emit("on-complete", otp.value.join(""));
      }
    };

    // Handle cases of backspace, delete, left arrow, right arrow
    var handleOnKeyDown = function handleOnKeyDown(event) {
      switch (event.keyCode) {
        case BACKSPACE:
          event.preventDefault();
          changeCodeAtFocus("");
          focusPrevInput();
          break;
        case DELETE:
          event.preventDefault();
          changeCodeAtFocus("");
          break;
        case LEFT_ARROW:
          event.preventDefault();
          focusPrevInput();
          break;
        case RIGHT_ARROW:
          event.preventDefault();
          focusNextInput();
          break;
      }
    };
    return {
      activeInput: activeInput,
      otp: otp,
      oldOtp: oldOtp,
      clearInput: clearInput,
      handleOnPaste: handleOnPaste,
      handleOnKeyDown: handleOnKeyDown,
      handleOnBlur: handleOnBlur,
      changeCodeAtFocus: changeCodeAtFocus,
      focusInput: focusInput,
      focusNextInput: focusNextInput,
      focusPrevInput: focusPrevInput,
      handleOnFocus: handleOnFocus,
      checkFilledAllInputs: checkFilledAllInputs,
      handleOnChange: handleOnChange,
      fillInput: fillInput
    };
  }
});var _hoisted_1 = {
  style: {
    "display": "flex"
  }
};
var _hoisted_2 = {
  key: 0,
  autocomplete: "off",
  name: "hidden",
  type: "text",
  style: {
    "display": "none"
  }
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  var _component_SingleOtpInput = vue.resolveComponent("SingleOtpInput");
  return vue.openBlock(), vue.createElementBlock("div", _hoisted_1, [_ctx.inputType === 'password' ? (vue.openBlock(), vue.createElementBlock("input", _hoisted_2)) : vue.createCommentVNode("", true), (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(_ctx.numInputs, function (_, i) {
    return vue.openBlock(), vue.createBlock(_component_SingleOtpInput, {
      key: i,
      focus: _ctx.activeInput === i,
      value: _ctx.otp[i],
      separator: _ctx.separator,
      "input-type": _ctx.inputType,
      inputmode: _ctx.inputmode,
      "input-classes": _ctx.inputClasses,
      conditionalClass: _ctx.conditionalClass[i],
      "is-last-child": i === _ctx.numInputs - 1,
      "should-auto-focus": _ctx.shouldAutoFocus,
      placeholder: _ctx.placeholder[i],
      "is-disabled": _ctx.isDisabled,
      onOnChange: _ctx.handleOnChange,
      onOnKeydown: _ctx.handleOnKeyDown,
      onOnPaste: _ctx.handleOnPaste,
      onOnFocus: function onOnFocus($event) {
        return _ctx.handleOnFocus(i);
      },
      onOnBlur: _ctx.handleOnBlur
    }, null, 8, ["focus", "value", "separator", "input-type", "inputmode", "input-classes", "conditionalClass", "is-last-child", "should-auto-focus", "placeholder", "is-disabled", "onOnChange", "onOnKeydown", "onOnPaste", "onOnFocus", "onOnBlur"]);
  }), 128))]);
}script.render = render;// Import vue component

// Define typescript interfaces for installable component

// Default export is installable instance of component.
// IIFE injects install function into component, allowing component
// to be registered via Vue.use() as well as Vue.component(),
var component = /*#__PURE__*/(function () {
  // Assign InstallableComponent type
  var installable = script;

  // Attach install function executed by Vue.use()
  installable.install = function (app) {
    app.component("Vue3OtpInput", installable);
  };
  return installable;
})();

// It's possible to expose named exports when writing components that can
// also be used as directives, etc. - eg. import { RollupDemoDirective } from 'rollup-demo';
// export const RollupDemoDirective = directive;
var namedExports=/*#__PURE__*/Object.freeze({__proto__:null,'default':component});// Attach named exports directly to component. IIFE/CJS will
// only expose one global var, with named exports exposed as properties of
// that global var (eg. plugin.namedExport)
Object.entries(namedExports).forEach(function (_ref) {
  var _ref2 = _slicedToArray(_ref, 2),
    exportName = _ref2[0],
    exported = _ref2[1];
  if (exportName !== 'default') component[exportName] = exported;
});var vue3OtpInput_ssr=component;

const VOtpInput = /*@__PURE__*/getDefaultExportFromCjs(vue3OtpInput_ssr);

const _sfc_main$a = {
  __name: "LastTransactions",
  __ssrInlineRender: true,
  setup(__props) {
    const theads = [
      "date",
      "transaction ID",
      "amount",
      "Payment method",
      "type",
      "merchant",
      "description"
    ];
    const tdata = [];
    const isEmpty = ref(true);
    const isPageLoading = ref(false);
    reactive({
      Status: "",
      Role: "",
      PageSize: 10,
      PageNumber: 1,
      pagecount: 0,
      totalCount: 0,
      Search: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      const _component_AppLoader = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "gap-y-2 flex flex-col" }, _attrs))} data-v-556d6b1f><div class="flex justify-between mb-6 items-center" data-v-556d6b1f><span class="block font-bold" data-v-556d6b1f>Last 7 transactions</span>`);
      _push(ssrRenderComponent(_component_router_link, { to: "/wallet/transactions" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button type="button" class="bg-primary-500 text-[12px] px-4 py-2 rounded-lg text-white hover:opacity-60" data-v-556d6b1f${_scopeId}> View all </button>`);
          } else {
            return [
              createVNode("button", {
                type: "button",
                class: "bg-primary-500 text-[12px] px-4 py-2 rounded-lg text-white hover:opacity-60"
              }, " View all ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      if (!isPageLoading.value) {
        _push(`<div data-v-556d6b1f>`);
        if (!isEmpty.value) {
          _push(`<div class="max-w-[80vw]" data-v-556d6b1f><table class="w-full" data-v-556d6b1f><thead data-v-556d6b1f><tr data-v-556d6b1f><!--[-->`);
          ssrRenderList(theads, (item) => {
            _push(`<th class="uppercase text-[#B6B7B9] text-[13px] text-left font-normal border-b py-6 px-3 border-[#E7EBEE]" data-v-556d6b1f>${ssrInterpolate(item)}</th>`);
          });
          _push(`<!--]--></tr></thead><tbody data-v-556d6b1f><!--[-->`);
          ssrRenderList(tdata, (item) => {
            _push(`<tr data-v-556d6b1f><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-556d6b1f></td><td class="text-matta-black text-sm font-normal border-b py-6 px-3 border-[#E7EBEE]" data-v-556d6b1f>${ssrInterpolate(item.email)}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-556d6b1f></td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-556d6b1f>`);
            if (item.invitationStatusText == "Expired") {
              _push(`<span class="px-2 py-2 text-xs rounded-lg border text-[#EE5C5C] border-[#EE5C5C]" data-v-556d6b1f>${ssrInterpolate(item.invitationStatusText)}</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.invitationStatusText == "Invited") {
              _push(`<span class="px-2 py-2 text-xs rounded-lg border text-primary border-primary" data-v-556d6b1f>${ssrInterpolate(item.invitationStatusText)}</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.invitationStatusText == "Verified") {
              _push(`<span class="px-2 py-2 text-xs rounded-lg text-white bg-[#59B221]" data-v-556d6b1f> Verified</span>`);
            } else {
              _push(`<!---->`);
            }
            _push(`</td></tr>`);
          });
          _push(`<!--]--></tbody></table></div>`);
        } else {
          _push(`<div class="h-[210px] rounded-lg w-full flex items-center justify-center bg-[#F1F3F5]" data-v-556d6b1f><div class="text-center max-w-sm mx-auto" data-v-556d6b1f><p class="text-matta-black font-medium" data-v-556d6b1f>No transaction available</p></div></div>`);
        }
        _push(`</div>`);
      } else {
        _push(`<div class="text-center p-6 lg:p-8 my-24" data-v-556d6b1f>`);
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
        _push(`</div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/wallet/LastTransactions.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["__scopeId", "data-v-556d6b1f"]]);
const _sfc_main$9 = {
  __name: "AddBeneficiary",
  __ssrInlineRender: true,
  emits: ["success"],
  setup(__props, { emit: __emit }) {
    const form = reactive({
      accountNo: "",
      bank: ""
    });
    const isLoading = ref(false);
    const rules = {
      accountNo: {
        required: helpers.withMessage("Account number is required", required),
        numeric,
        maxLength: maxLength(10),
        minLength: minLength(10)
      },
      bank: {
        required: helpers.withMessage("Bank name is required", required)
      }
    };
    const v$ = useVuelidate(rules, form);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "lg:min-w-[450px] w-full max-w-[800px] py-10 px-6" }, _attrs))} data-v-286031d0><h3 class="block text-2xl font-medium text-center mb-6" data-v-286031d0>Add Beneficiary</h3><form data-v-286031d0><div class="grid grid-cols-1 gap-6" data-v-286031d0><div class="mb-6" data-v-286031d0><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-286031d0>Bank name</label><div class="relative flex items-center" data-v-286031d0><input${ssrRenderAttr("value", unref(v$).bank.$model)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).bank.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Provide bank name" data-v-286031d0></div><!--[-->`);
      ssrRenderList(unref(v$).bank.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-286031d0><div class="error-msg text-error text-xs font-semibold" data-v-286031d0>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6" data-v-286031d0><label class="mb-2 font-normal text-xs block text-matta-black" data-v-286031d0>Account Number</label><div class="relative flex items-center" data-v-286031d0><input${ssrRenderAttr("value", unref(v$).accountNo.$model)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).accountNo.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Provide account number" data-v-286031d0></div><!--[-->`);
      ssrRenderList(unref(v$).accountNo.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-286031d0><div class="error-msg text-error text-xs font-semibold" data-v-286031d0>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="flex justify-center mt-8" data-v-286031d0><button type="submit"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} class="border text-[13px] mb-4 border-primary- uppercase text-white w-full lg:w-auto lg:min-w-[150px] mx-auto bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11" data-v-286031d0><span data-v-286031d0>`);
      if (isLoading.value) {
        _push(`<span class="flex gap-x-4 justify-center items-center" data-v-286031d0><span data-v-286031d0> Processing...</span>`);
        if (isLoading.value) {
          _push(`<i class="fa fa-spinner fa-spin text-white" aria-hidden="true" data-v-286031d0></i>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</span>`);
      } else {
        _push(`<span data-v-286031d0>Submit</span>`);
      }
      _push(`</span></button></div></form></div>`);
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/wallet/modals/AddBeneficiary.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["__scopeId", "data-v-286031d0"]]);
const _sfc_main$8 = {
  __name: "RemoveItem",
  __ssrInlineRender: true,
  props: ["data"],
  emits: ["remove", "cancel"],
  setup(__props, { emit: __emit }) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "min-w-[400px] p-6" }, _attrs))}><h3 class="font-medium text-2xl mb-6">Remove ${ssrInterpolate(__props.data)}</h3><p class="mb-12">Are you sure you want to remove this ${ssrInterpolate(__props.data)}?</p><div class="flex items-center gap-x-4"><button type="button" class="text-[13px] uppercase text-matta-black px-2 py-2 hover:text-primary/80 w-full"> cancel </button><button type="button" class="border text-[13px] border-primary- uppercase w-full text-white bg-primary-500 rounded-lg px-2 py-3 hover:bg-primary/80"> remove </button></div></div>`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/wallet/modals/RemoveItem.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main$8;
const _sfc_main$7 = {
  __name: "BeneficiaryPage",
  __ssrInlineRender: true,
  setup(__props) {
    const isAdd = ref(false);
    const isDelete = ref(false);
    const isOpen = ref(false);
    const theads = ["Account no", "bank"];
    const tdata = ref([]);
    const isEmpty = ref(true);
    const isPageLoading = ref(false);
    const id = ref(null);
    const queryParams = reactive({
      Search: "",
      discontinued: false,
      PageSize: 10,
      PageNumber: 1,
      pagecount: 0
    });
    function handleClose() {
      isOpen.value = isAdd.value = isDelete.value = false;
    }
    function getData() {
      getBeneficiaries(queryParams).then((res) => {
        if (res.status === 200) {
          if (res.data.data.data.length) {
            isEmpty.value = false;
            tdata.value = res.data.data.data;
          }
        }
      });
    }
    function handleUpdate() {
      getData();
      isOpen.value = false;
    }
    function remove() {
      removeBeneficiary({ id: id.value }).then((res) => {
        if (res.status === 200) {
          handleUpdate();
        }
      });
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1$2;
      const _component_AppLoader = __nuxt_component_1$1;
      const _component_IndexModal = __nuxt_component_0$1;
      const _component_SupplierWalletModalsAddBeneficiary = __nuxt_component_3;
      const _component_SupplierWalletModalsRemoveItem = __nuxt_component_4;
      _push(`<!--[--><div class="flex justify-between mb-6 items-center" data-v-c896cf2d><span class="block font-bold" data-v-c896cf2d>List of Beneficiaries</span><button type="button" class="bg-primary-500 text-[12px] px-4 py-2 rounded-lg text-white hover:opacity-60" data-v-c896cf2d> Add new </button></div><div class="gap-y-2 flex flex-col" data-v-c896cf2d><div class="bg-white rounded-lg" data-v-c896cf2d>`);
      if (!unref(isPageLoading)) {
        _push(`<div data-v-c896cf2d>`);
        if (!unref(isEmpty)) {
          _push(`<div class="border rounded-lg border-[#E7EBEE]" data-v-c896cf2d><table class="w-full" data-v-c896cf2d><thead data-v-c896cf2d><tr data-v-c896cf2d><!--[-->`);
          ssrRenderList(theads, (item) => {
            _push(`<th class="uppercase text-[#B6B7B9] text-[13px] text-left font-normal border-b py-4 px-3 border-[#E7EBEE]" data-v-c896cf2d>${ssrInterpolate(item)}</th>`);
          });
          _push(`<!--]--></tr></thead><tbody data-v-c896cf2d><!--[-->`);
          ssrRenderList(unref(tdata), (item) => {
            _push(`<tr data-v-c896cf2d><td class="text-matta-black text-sm font-normal border-b py-4 px-3 border-[#E7EBEE]" data-v-c896cf2d>${ssrInterpolate(item.accountNo)}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-3 border-[#E7EBEE]" data-v-c896cf2d>${ssrInterpolate(item.bank)}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-1 border-[#E7EBEE]" data-v-c896cf2d><span class="cursor-pointer" data-v-c896cf2d>`);
            _push(ssrRenderComponent(_component_AppIcon, {
              icon: "heroicons-solid:x",
              class: "w-4 h-4 text-matta-black z-10"
            }, null, _parent));
            _push(`</span></td></tr>`);
          });
          _push(`<!--]--></tbody></table></div>`);
        } else {
          _push(`<div class="h-[210px] rounded-lg w-full flex items-center justify-center bg-[#F1F3F5]" data-v-c896cf2d><div class="text-center max-w-sm mx-auto" data-v-c896cf2d><p class="text-matta-black font-medium" data-v-c896cf2d>No account available</p></div></div>`);
        }
        _push(`</div>`);
      } else {
        _push(`<div class="text-center p-6 lg:p-8 my-24" data-v-c896cf2d>`);
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
        _push(`</div>`);
      }
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_IndexModal, {
        isOpen: unref(isOpen),
        onTogglePopup: handleClose
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="max-w-md" data-v-c896cf2d${_scopeId}>`);
            if (unref(isAdd)) {
              _push2(ssrRenderComponent(_component_SupplierWalletModalsAddBeneficiary, { onSuccess: handleUpdate }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (unref(isDelete)) {
              _push2(ssrRenderComponent(_component_SupplierWalletModalsRemoveItem, {
                data: "beneficiary",
                onRemove: remove,
                onCancel: handleClose
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`<span class="cursor-pointer" data-v-c896cf2d${_scopeId}>`);
            _push2(ssrRenderComponent(_component_AppIcon, {
              icon: "heroicons-solid:x",
              class: "w-4 h-4 absolute top-4 right-3 text-matta-black z-10"
            }, null, _parent2, _scopeId));
            _push2(`</span></div>`);
          } else {
            return [
              createVNode("div", { class: "max-w-md" }, [
                unref(isAdd) ? (openBlock(), createBlock(_component_SupplierWalletModalsAddBeneficiary, {
                  key: 0,
                  onSuccess: handleUpdate
                })) : createCommentVNode("", true),
                unref(isDelete) ? (openBlock(), createBlock(_component_SupplierWalletModalsRemoveItem, {
                  key: 1,
                  data: "beneficiary",
                  onRemove: remove,
                  onCancel: handleClose
                })) : createCommentVNode("", true),
                createVNode("span", {
                  class: "cursor-pointer",
                  onClick: handleClose
                }, [
                  createVNode(_component_AppIcon, {
                    icon: "heroicons-solid:x",
                    class: "w-4 h-4 absolute top-4 right-3 text-matta-black z-10"
                  })
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/wallet/BeneficiaryPage.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["__scopeId", "data-v-c896cf2d"]]);
const _sfc_main$6 = {
  __name: "TopUp",
  __ssrInlineRender: true,
  props: ["details"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_clipboard = resolveDirective("clipboard");
      if (__props.details) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-6 lg:p-8 bg-white rounded-lg" }, _attrs))}><span class="block text-2xl font-medium text-center mb-2">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(__props.details.walletBalance))}</span><p class="mb-6 text-sm text-center font-base"> Add funds to your wallet account from <br> your Nigerian Bank App </p><div class="grid grid-cols-3 gap-x-4 mb-1"><span class="text-sm">Bank name :</span><span class="text-base font-medium col-span-2">${ssrInterpolate(__props.details.bankName)}</span></div><div class="grid grid-cols-3 gap-x-4 mb-1"><span class="text-sm">Account name :</span><span class="text-base font-medium col-span-2">${ssrInterpolate(__props.details.accountName)}</span></div><div class="grid grid-cols-3 gap-x-4"><span class="text-sm">Account no :</span><span class="text-base font-medium col-span-2"><span>${ssrInterpolate(__props.details.accountNumber)}</span><button${ssrRenderAttrs(mergeProps({ class: "cursor-pointer ml-2" }, ssrGetDirectiveProps(_ctx, _directive_clipboard, __props.details.accountNumber)))}><i class="uil uil-copy"></i></button></span></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/wallet/modals/TopUp.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_5 = _sfc_main$6;
const _sfc_main$5 = {
  __name: "OTP",
  __ssrInlineRender: true,
  emits: ["handleSubmit"],
  setup(__props, { emit: __emit }) {
    const otpInput = ref("");
    const handleOnComplete = (value) => {
      form.otp = value;
    };
    const handleOnChange = () => {
      v$.value.$reset();
    };
    const form = reactive({
      otp: ""
    });
    const isLoading = ref(false);
    const rules = {
      otp: { required, minLength: minLength(4), maxLength: maxLength(4) }
    };
    const v$ = useVuelidate(rules, form);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<form${ssrRenderAttrs(mergeProps({ class: "max-w-[300px] mx-auto" }, _attrs))} data-v-de7f40a3><span class="block text-2xl font-medium text-center mb-2" data-v-de7f40a3>Enter OTP</span><p class="mb-6 text-sm text-center font-base text-gray-500" data-v-de7f40a3> Provide 4 digit otp code sent to your email </p><div class="flex gap-x-2 justify-center mb-7" data-v-de7f40a3>`);
      _push(ssrRenderComponent(unref(VOtpInput), {
        ref_key: "otpInput",
        ref: otpInput,
        value: unref(v$).otp.$modal,
        "onUpdate:value": ($event) => unref(v$).otp.$modal = $event,
        "input-classes": `otp-input ${unref(v$).otp.$error ? "!border-red-500" : ""} w-8 h-8 flex items-center border border-matta-black/20 focus:border-matta-black/50 outline-none mx-1 rounded-md text-center text-sm `,
        separator: " ",
        "num-inputs": 4,
        "should-auto-focus": true,
        "input-type": "letter-numeric",
        conditionalClass: ["one", "two", "three", "four"],
        placeholder: ["", "", "", ""],
        onOnChange: handleOnChange,
        onOnComplete: handleOnComplete
      }, null, _parent));
      _push(`</div><div class="" data-v-de7f40a3><button type="submit"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} class="border text-[13px] border-primary- uppercase text-white lg:min-w-[100px] w-full bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11 active:scale-95" data-v-de7f40a3><span data-v-de7f40a3>`);
      if (isLoading.value) {
        _push(`<span class="flex gap-x-4 justify-center items-center" data-v-de7f40a3><span data-v-de7f40a3> Processing...</span>`);
        if (isLoading.value) {
          _push(`<i class="fa fa-spinner fa-spin text-white" aria-hidden="true" data-v-de7f40a3></i>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</span>`);
      } else {
        _push(`<span data-v-de7f40a3>Submit</span>`);
      }
      _push(`</span></button></div></form>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/wallet/modals/OTP.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const OTP = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-de7f40a3"]]);
const _sfc_main$4 = {
  __name: "WithdrawalModal",
  __ssrInlineRender: true,
  setup(__props) {
    const stage = ref(1);
    const details = inject("details");
    const form = reactive({
      bankName: "",
      accountName: "",
      pin: "",
      accountNo: "",
      amount: ""
    });
    const isLoading = ref(false);
    const rules = {
      bankName: required,
      accountName: required,
      accountNo: required,
      pin: required,
      amount: required
    };
    ref(false);
    const v$ = useVuelidate(rules, form);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "min-w-[400px] py-10 px-6" }, _attrs))} data-v-eefb9cc1>`);
      if (stage.value === 1) {
        _push(`<form data-v-eefb9cc1><span class="block text-2xl font-medium text-center mb-2" data-v-eefb9cc1>${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(unref(details).walletBalance))}</span><p class="mb-6 text-sm text-center font-base" data-v-eefb9cc1> Enter amount to withdraw into your <br data-v-eefb9cc1> bank account </p><div class="mb-6" data-v-eefb9cc1><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-eefb9cc1>Withdraw amount</label>`);
        _push(ssrRenderComponent(unref(CurrencyInput), {
          modelValue: unref(v$).amount.$model,
          "onUpdate:modelValue": ($event) => unref(v$).amount.$model = $event,
          class: [{ "border-red-500": unref(v$).amount.$error }, "rounded-lg px-5 text-sm py-3 h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
          placeholder: "",
          options: {
            currency: "ngn",
            currencyDisplay: "narrowSymbol"
          }
        }, null, _parent));
        _push(`<!--[-->`);
        ssrRenderList(unref(v$).amount.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-eefb9cc1><div class="error-msg text-error text-xs font-semibold" data-v-eefb9cc1>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="mb-6" data-v-eefb9cc1><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-eefb9cc1>Bank name</label><input${ssrRenderAttr("value", unref(v$).bankName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).bankName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Enter bank name" data-v-eefb9cc1><!--[-->`);
        ssrRenderList(unref(v$).bankName.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-eefb9cc1><div class="error-msg text-error text-xs font-semibold" data-v-eefb9cc1>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="mb-6" data-v-eefb9cc1><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-eefb9cc1>Account name</label><input${ssrRenderAttr("value", unref(v$).accountName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).accountName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Enter account name" data-v-eefb9cc1><!--[-->`);
        ssrRenderList(unref(v$).accountName.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-eefb9cc1><div class="error-msg text-error text-xs font-semibold" data-v-eefb9cc1>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="mb-6" data-v-eefb9cc1><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-eefb9cc1>Account number</label><input${ssrRenderAttr("value", unref(v$).accountNo.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).accountNo.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Enter account number" data-v-eefb9cc1><!--[-->`);
        ssrRenderList(unref(v$).accountNo.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-eefb9cc1><div class="error-msg text-error text-xs font-semibold" data-v-eefb9cc1>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="mb-6" data-v-eefb9cc1><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-eefb9cc1>Transaction pin</label><input${ssrRenderAttr("value", unref(v$).pin.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).pin.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Enter 4 digit pin" type="number" maxlength="4" data-v-eefb9cc1><!--[-->`);
        ssrRenderList(unref(v$).pin.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-eefb9cc1><div class="error-msg text-error text-xs font-semibold" data-v-eefb9cc1>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="" data-v-eefb9cc1><button type="submit"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} class="border text-[13px] border-primary- uppercase text-white lg:min-w-[120px] w-full bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11" data-v-eefb9cc1><span data-v-eefb9cc1>`);
        if (isLoading.value) {
          _push(`<span class="flex gap-x-4 justify-center items-center" data-v-eefb9cc1><span data-v-eefb9cc1> Processing...</span>`);
          if (isLoading.value) {
            _push(`<i class="fa fa-spinner fa-spin text-white" aria-hidden="true" data-v-eefb9cc1></i>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</span>`);
        } else {
          _push(`<span data-v-eefb9cc1>Submit</span>`);
        }
        _push(`</span></button></div></form>`);
      } else {
        _push(`<!---->`);
      }
      if (stage.value === 2) {
        _push(`<div data-v-eefb9cc1>`);
        _push(ssrRenderComponent(OTP, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/wallet/modals/WithdrawalModal.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-eefb9cc1"]]);
const _sfc_main$3 = {
  __name: "CreateWallet",
  __ssrInlineRender: true,
  emits: ["success"],
  setup(__props, { emit: __emit }) {
    const form = reactive({
      customerName: "",
      phoneCode: "+234",
      phoneNumber: ""
    });
    const isLoading = ref(false);
    const validPhoneLength = (value) => form.phoneCode === "+234" ? value.length > 9 && value.length < 12 : true;
    const rules = {
      customerName: {
        required: helpers.withMessage("Name field cannot be empty", required)
      },
      phoneNumber: {
        numeric,
        required,
        validPhoneLength: helpers.withMessage(
          "Phone number must be between 10 0r 11 digits",
          validPhoneLength
        )
      }
    };
    const v$ = useVuelidate(rules, form);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "lg:min-w-[450px] w-full max-w-[800px] py-10 px-6" }, _attrs))} data-v-e4f8cd0e><h3 class="block text-2xl font-medium text-center mb-6" data-v-e4f8cd0e>Create wallet</h3><form data-v-e4f8cd0e><div class="grid grid-cols-1 gap-6" data-v-e4f8cd0e><div class="mb-6" data-v-e4f8cd0e><label class="mb-2 font-normal text-xs block text-matta-black" data-v-e4f8cd0e>Full name</label><div class="relative flex items-center" data-v-e4f8cd0e><input${ssrRenderAttr("value", unref(v$).customerName.$model)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).customerName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Enter your name" data-v-e4f8cd0e></div><!--[-->`);
      ssrRenderList(unref(v$).customerName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-e4f8cd0e><div class="error-msg text-error text-xs font-semibold" data-v-e4f8cd0e>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6" data-v-e4f8cd0e><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-e4f8cd0e>Phone number</label><div class="flex relative rounded-lg" data-v-e4f8cd0e>`);
      _push(ssrRenderComponent(unref(PhoneCodes), {
        modelValue: form.phoneCode,
        "onUpdate:modelValue": ($event) => form.phoneCode = $event
      }, null, _parent));
      _push(`<input class="${ssrRenderClass([{ "border-red-500": unref(v$).phoneNumber.$error }, "flex-1 rounded-r-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}"${ssrRenderAttr("value", unref(v$).phoneNumber.$model)} autofocus="on" placeholder="08160723884" type="tel" data-v-e4f8cd0e></div><!--[-->`);
      ssrRenderList(unref(v$).phoneNumber.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-e4f8cd0e><div class="error-msg text-error text-xs font-semibold" data-v-e4f8cd0e>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="flex justify-center mt-8" data-v-e4f8cd0e><button type="submit"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} class="border text-[13px] mb-4 border-primary- uppercase text-white w-full lg:w-auto lg:min-w-[150px] mx-auto bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11" data-v-e4f8cd0e><span data-v-e4f8cd0e>`);
      if (isLoading.value) {
        _push(`<span class="flex gap-x-4 justify-center items-center" data-v-e4f8cd0e><span data-v-e4f8cd0e> Processing...</span>`);
        if (isLoading.value) {
          _push(`<i class="fa fa-spinner fa-spin text-white" aria-hidden="true" data-v-e4f8cd0e></i>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</span>`);
      } else {
        _push(`<span data-v-e4f8cd0e>Submit</span>`);
      }
      _push(`</span></button></div></form></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/wallet/modals/CreateWallet.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_7 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-e4f8cd0e"]]);
const _sfc_main$2 = {
  __name: "CreateKyc",
  __ssrInlineRender: true,
  emits: ["success"],
  setup(__props, { emit: __emit }) {
    var _a, _b;
    const store = useStore();
    const sectors = ["RC", "BN", "IT", "LL", "LLP"];
    const isCacError = ref(false);
    const isNinError = ref(false);
    const isBvnError = ref(false);
    const company = ref(null);
    const form = reactive({
      fullName: store.getters.loggedUser.fullName,
      phoneCode: "+234",
      phone: store.getters.loggedUser.phoneNumber,
      bvn: "",
      cac: "",
      nin: "",
      utilityBilly: "",
      address: ((_a = company == null ? void 0 : company.value) == null ? void 0 : _a.address) || "",
      companyType: "",
      companyName: ((_b = company == null ? void 0 : company.value) == null ? void 0 : _b.companyName) || "",
      directorsInfos: [
        {
          name: "",
          title: "",
          address: ""
        }
      ]
    });
    const isLoading = ref(false);
    const rules = {
      cac: {
        required: helpers.withMessage("CAC field cannot be empty", required),
        // minLength: minLength(14),
        maxLength: maxLength(14)
      },
      utilityBilly: { required },
      directorsInfos: {
        $each: helpers.forEach({
          name: { required },
          title: { required },
          address: { required }
        })
      },
      companyType: { required },
      companyName: { required },
      bvn: {
        required: helpers.withMessage("BVN field cannot be empty", required),
        minLength: minLength(11),
        maxLength: maxLength(11)
      },
      nin: {
        required: helpers.withMessage("NIN field cannot be empty", required),
        minLength: minLength(11),
        maxLength: maxLength(11)
      }
    };
    const v$ = useVuelidate(rules, form);
    const isUploading = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "sm:min-w-[650px] w-full max-w-[800px] py-10 px-6" }, _attrs))} data-v-a7cf6080><h3 class="block text-2xl font-medium text-center mb-6" data-v-a7cf6080> Complete your KYC </h3><form data-v-a7cf6080><div class="grid lg:grid-cols-2 lg:gap-6" data-v-a7cf6080><div class="mb-6" data-v-a7cf6080><label class="mb-2 font-normal text-xs block text-matta-black" data-v-a7cf6080>BVN</label><div class="relative flex items-center" data-v-a7cf6080><input${ssrRenderAttr("value", unref(v$).bvn.$model)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).bvn.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Provide your bvn" data-v-a7cf6080></div>`);
      if (isBvnError.value) {
        _push(`<div class="text-red-500 mt-1" data-v-a7cf6080><div class="error-msg text-error text-xs font-semibold" data-v-a7cf6080> Invalid BVN number </div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--[-->`);
      ssrRenderList(unref(v$).bvn.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-a7cf6080><div class="error-msg text-error text-xs font-semibold" data-v-a7cf6080>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6" data-v-a7cf6080><label class="mb-2 font-normal text-xs block text-matta-black" data-v-a7cf6080>NIN</label><div class="relative flex items-center" data-v-a7cf6080><input${ssrRenderAttr("value", unref(v$).nin.$model)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).nin.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Provide your NIN" data-v-a7cf6080></div><!--[-->`);
      ssrRenderList(unref(v$).nin.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-a7cf6080><div class="error-msg text-error text-xs font-semibold" data-v-a7cf6080>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]-->`);
      if (isNinError.value) {
        _push(`<div class="text-red-500 mt-1" data-v-a7cf6080><div class="error-msg text-error text-xs font-semibold" data-v-a7cf6080> Invalid NIN number </div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="mb-6" data-v-a7cf6080><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-a7cf6080>Company name</label><div class="flex relative items-center" data-v-a7cf6080><input${ssrRenderAttr("value", unref(v$).companyName.$model)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).companyName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" readonly data-v-a7cf6080></div><!--[-->`);
      ssrRenderList(unref(v$).companyName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-a7cf6080><div class="error-msg text-error text-xs font-semibold" data-v-a7cf6080>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="grid lg:grid-cols-2 lg:gap-6" data-v-a7cf6080><div class="mb-6" data-v-a7cf6080><label class="mb-2 font-normal text-xs block text-matta-black" data-v-a7cf6080>Company type </label><div class="flex relative items-center" data-v-a7cf6080><select class="${ssrRenderClass([{ "border-red-500": unref(v$).companyType.$error }, "appearance-none rounded-lg px-[14px] py-[10px] h-11 text-sm w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" data-v-a7cf6080><option disabled value="" data-v-a7cf6080${ssrIncludeBooleanAttr(Array.isArray(unref(v$).companyType.$model) ? ssrLooseContain(unref(v$).companyType.$model, "") : ssrLooseEqual(unref(v$).companyType.$model, "")) ? " selected" : ""}>Select sector</option><!--[-->`);
      ssrRenderList(sectors, (item) => {
        _push(`<option${ssrRenderAttr("value", item)} data-v-a7cf6080>${ssrInterpolate(item)}</option>`);
      });
      _push(`<!--]--></select><i class="uil uil-angle-down absolute right-2 pointer-events-none" data-v-a7cf6080></i></div><!--[-->`);
      ssrRenderList(unref(v$).companyType.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-a7cf6080><div class="error-msg text-error text-xs font-semibold" data-v-a7cf6080>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6" data-v-a7cf6080><label class="mb-2 font-normal text-xs block text-matta-black" data-v-a7cf6080>CAC</label><div class="relative flex items-center" data-v-a7cf6080><input${ssrRenderAttr("value", unref(v$).cac.$model)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).cac.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Provide your CAC" data-v-a7cf6080></div><!--[-->`);
      ssrRenderList(unref(v$).cac.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-a7cf6080><div class="error-msg text-error text-xs font-semibold" data-v-a7cf6080>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]-->`);
      if (isCacError.value) {
        _push(`<div class="text-red-500 mt-1" data-v-a7cf6080><div class="error-msg text-error text-xs font-semibold" data-v-a7cf6080> Invalid CAC number </div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="mb-6" data-v-a7cf6080><label class="mb-2 font-normal text-xs block text-matta-black" data-v-a7cf6080>Company Utility Bill</label><div class="relative flex items-center" data-v-a7cf6080><input class="flex-1 block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200" type="file" id="formFile" data-v-a7cf6080><div class="flex gap-x-3" data-v-a7cf6080>`);
      if (isUploading.value) {
        _push(`<i class="fa fa-spinner fa-spin" aria-hidden="true" data-v-a7cf6080></i>`);
      } else {
        _push(`<!---->`);
      }
      if (form.utilityBilly) {
        _push(`<button class="text-blue-700 text-sm" data-v-a7cf6080> View </button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div><div class="mb-6" data-v-a7cf6080><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-a7cf6080>Address</label><div class="flex relative items-center" data-v-a7cf6080><input${ssrRenderAttr("value", form.address)} class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" readonly data-v-a7cf6080><i class="uil uil-home absolute right-4 text-gray-600" data-v-a7cf6080></i></div></div><div class="mb-6" data-v-a7cf6080><p class="mb-4 font-bold text-sm block text-matta-black" data-v-a7cf6080> Directors Details </p><!--[-->`);
      ssrRenderList(form.directorsInfos, (director, index) => {
        _push(`<div class="py-2 mb-4 relative gap-x-3 flex items-start" data-v-a7cf6080><div class="grid lg:grid-cols-2 gap-6 flex-1" data-v-a7cf6080><div class="" data-v-a7cf6080><label class="mb-2 font-normal text-xs block text-matta-black" data-v-a7cf6080>Full Name</label><div class="relative flex items-center" data-v-a7cf6080><input${ssrRenderAttr("value", director.name)} class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" placeholder="Enter director&#39;s name" data-v-a7cf6080></div><!--[-->`);
        ssrRenderList(unref(v$).directorsInfos.$each.$response.$errors[index].name, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-a7cf6080><div class="error-msg text-error text-xs font-semibold" data-v-a7cf6080>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div data-v-a7cf6080><label class="mb-2 font-normal text-xs block text-matta-black" data-v-a7cf6080>Title</label><div class="relative flex items-center" data-v-a7cf6080><input${ssrRenderAttr("value", director.title)} class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" placeholder="Enter director&#39;s title" data-v-a7cf6080></div><!--[-->`);
        ssrRenderList(unref(v$).directorsInfos.$each.$response.$errors[index].title, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-a7cf6080><div class="error-msg text-error text-xs font-semibold" data-v-a7cf6080>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="col-span-2" data-v-a7cf6080><label class="mb-2 font-normal text-xs block text-matta-black" data-v-a7cf6080>Address</label><div class="relative flex items-center" data-v-a7cf6080><input${ssrRenderAttr("value", director.address)} class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" placeholder="Enter director&#39;s address" data-v-a7cf6080></div><!--[-->`);
        ssrRenderList(unref(v$).directorsInfos.$each.$response.$errors[index].address, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-a7cf6080><div class="error-msg text-error text-xs font-semibold" data-v-a7cf6080>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div></div><div class="" data-v-a7cf6080><button type="button" data-v-a7cf6080> x </button></div></div>`);
      });
      _push(`<!--]--><div data-v-a7cf6080><button type="button" class="text-xs" data-v-a7cf6080> + Add director </button></div></div><div class="flex justify-center mt-8" data-v-a7cf6080><button type="submit"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} class="border text-[13px] mb-4 border-primary- uppercase text-white w-full lg:w-auto lg:min-w-[150px] mx-auto bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11" data-v-a7cf6080><span data-v-a7cf6080>`);
      if (isLoading.value) {
        _push(`<span class="flex gap-x-4 justify-center items-center" data-v-a7cf6080><span data-v-a7cf6080> Processing...</span>`);
        if (isLoading.value) {
          _push(`<i class="fa fa-spinner fa-spin text-white" aria-hidden="true" data-v-a7cf6080></i>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</span>`);
      } else {
        _push(`<span data-v-a7cf6080>Submit</span>`);
      }
      _push(`</span></button></div></form></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/wallet/modals/CreateKyc.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_8 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-a7cf6080"]]);
const _sfc_main$1 = {
  __name: "WalletPage",
  __ssrInlineRender: true,
  setup(__props) {
    const isOpen = ref(false);
    useRoute();
    const isTopup = ref(false);
    const isLoading = ref(true);
    const isWithdraw = ref(false);
    const hasWallet = ref(false);
    const isCreatingWallet = ref(false);
    const isAddingKyc = ref(false);
    const details = ref(null);
    function handleClose() {
      isWithdraw.value = isTopup.value = isCreatingWallet.value = isAddingKyc.value = isOpen.value = false;
    }
    function handleWalletCreation() {
      isLoading.value = true;
      handleClose();
      handleWalletDetails();
    }
    function handleWalletDetails() {
      getWalletDetails().then((res) => {
        details.value = res.data.data;
        hasWallet.value = true;
        isLoading.value = false;
      }).catch(() => {
        hasWallet.value = false;
        isLoading.value = false;
      });
    }
    provide("details", details);
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_HeaderComponent = __nuxt_component_0$2;
      const _component_SupplierWalletLastTransactions = __nuxt_component_1;
      const _component_SupplierWalletBeneficiaryPage = __nuxt_component_2;
      const _component_AppLoader = __nuxt_component_1$1;
      const _component_IndexModal = __nuxt_component_0$1;
      const _component_SupplierWalletModalsTopUp = __nuxt_component_5;
      const _component_SupplierWalletModalsWithdrawalModal = __nuxt_component_6;
      const _component_SupplierWalletModalsCreateWallet = __nuxt_component_7;
      const _component_SupplierWalletModalsCreateKyc = __nuxt_component_8;
      const _component_AppIcon = __nuxt_component_1$2;
      const _directive_clipboard = resolveDirective("clipboard");
      _push(`<!--[--><div class="gap-y-2 flex flex-col bg-white rounded-[10px] pb-10" data-v-f11a027a>`);
      _push(ssrRenderComponent(_component_HeaderComponent, { title: "Wallet" }, {
        button: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex justify-end gap-x-4" data-v-f11a027a${_scopeId}><button${ssrIncludeBooleanAttr(!unref(hasWallet)) ? " disabled" : ""} class="w-full sm:w-auto border border-matta-black py-[10px] text-xs md:text-[13px] px-3 sm:px-6 flex justify-center text-matta-black rounded-lg items-center hover:bg-matta-black/80 capitalize font-normal leading-[normal] gap-x-1 disabled:opacity-60 disabled:cursor-not-allowed" data-v-f11a027a${_scopeId}><i class="uil uil-top-arrow-to-top" data-v-f11a027a${_scopeId}></i> Top up </button><button${ssrIncludeBooleanAttr(!unref(hasWallet)) ? " disabled" : ""} class="w-full sm:w-auto border border-matta-black bg-matta-black py-[10px] text-xs md:text-[13px] px-3 sm:px-6 flex justify-center text-white rounded-lg items-center hover:bg-matta-black/80 capitalize font-normal leading-[normal] gap-x-1 disabled:opacity-60 disabled:cursor-not-allowed" data-v-f11a027a${_scopeId}><i class="uil uil-arrow-to-bottom text-white" data-v-f11a027a${_scopeId}></i> Withdraw </button></div>`);
          } else {
            return [
              createVNode("div", { class: "flex justify-end gap-x-4" }, [
                createVNode("button", {
                  onClick: () => {
                    isAddingKyc.value = isCreatingWallet.value = isWithdraw.value = false;
                    isTopup.value = isOpen.value = true;
                  },
                  disabled: !unref(hasWallet),
                  class: "w-full sm:w-auto border border-matta-black py-[10px] text-xs md:text-[13px] px-3 sm:px-6 flex justify-center text-matta-black rounded-lg items-center hover:bg-matta-black/80 capitalize font-normal leading-[normal] gap-x-1 disabled:opacity-60 disabled:cursor-not-allowed"
                }, [
                  createVNode("i", { class: "uil uil-top-arrow-to-top" }),
                  createTextVNode(" Top up ")
                ], 8, ["onClick", "disabled"]),
                createVNode("button", {
                  onClick: () => {
                    isAddingKyc.value = isCreatingWallet.value = isTopup.value = false;
                    isWithdraw.value = isOpen.value = true;
                  },
                  disabled: !unref(hasWallet),
                  class: "w-full sm:w-auto border border-matta-black bg-matta-black py-[10px] text-xs md:text-[13px] px-3 sm:px-6 flex justify-center text-white rounded-lg items-center hover:bg-matta-black/80 capitalize font-normal leading-[normal] gap-x-1 disabled:opacity-60 disabled:cursor-not-allowed"
                }, [
                  createVNode("i", { class: "uil uil-arrow-to-bottom text-white" }),
                  createTextVNode(" Withdraw ")
                ], 8, ["onClick", "disabled"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="py-[30px]" data-v-f11a027a><div data-v-f11a027a><div class="flex justify-between flex-col gap-y-4 sm:flex-row" data-v-f11a027a><div class="w-full sm:w-auto" data-v-f11a027a>`);
      if (unref(hasWallet) && !((_a = unref(details)) == null ? void 0 : _a.kycCompleted)) {
        _push(`<button${ssrIncludeBooleanAttr(!unref(hasWallet)) ? " disabled" : ""} class="w-full sm:w-auto border border-matta-black py-3 text-xs md:text-[13px] px-6 flex justify-center text-matta-black rounded-lg items-center hover:bg-matta-black/80 capitalize font-normal leading-[normal] gap-x-1 disabled:opacity-60 disabled:cursor-not-allowed" data-v-f11a027a><i class="uil uil-plus" data-v-f11a027a></i> Update KYC </button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
      if (unref(hasWallet) && !unref(isLoading)) {
        _push(`<div class="grid sm:grid-cols-2 lg:grid-cols-2 gap-2" data-v-f11a027a><div class="p-6 lg:p-8 bg-white rounded-lg" data-v-f11a027a><span class="font-medium text-sm block mb-4" data-v-f11a027a>Wallet Balance</span><span class="font-bold block text-4xl" data-v-f11a027a>${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(unref(details).walletBalance))}</span></div><div class="p-6 lg:p-8 bg-white rounded-lg" data-v-f11a027a><span class="font-bold text-[15px] block mb-3" data-v-f11a027a>Wallet details</span><div class="grid grid-cols-2 mb-1 gap-x-4" data-v-f11a027a><span class="text-sm font-medium" data-v-f11a027a>Bank name :</span><span class="text-base" data-v-f11a027a>${ssrInterpolate(unref(details).bankName)}</span></div><div class="grid grid-cols-2 mb-1 gap-x-4" data-v-f11a027a><span class="text-sm font-medium" data-v-f11a027a>Account name :</span><span class="text-base" data-v-f11a027a>${ssrInterpolate(unref(details).accountName)}</span></div><div class="grid grid-cols-2 gap-x-4" data-v-f11a027a><span class="text-sm font-medium" data-v-f11a027a>Account number :</span><span class="text-base" data-v-f11a027a><span data-v-f11a027a>${ssrInterpolate(unref(details).accountNumber)}</span><button${ssrRenderAttrs(mergeProps({ class: "cursor-pointer ml-2" }, ssrGetDirectiveProps(_ctx, _directive_clipboard, unref(details).accountNumber)))} data-v-f11a027a><i class="uil uil-copy" data-v-f11a027a></i></button></span></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(hasWallet) && !unref(isLoading)) {
        _push(`<div class="grid lg:grid-cols-2 gap-x-2" data-v-f11a027a><div class="p-6 lg:p-8 bg-white rounded-lg" data-v-f11a027a>`);
        _push(ssrRenderComponent(_component_SupplierWalletLastTransactions, null, null, _parent));
        _push(`</div><div class="p-6 lg:p-8 bg-white rounded-lg" data-v-f11a027a>`);
        _push(ssrRenderComponent(_component_SupplierWalletBeneficiaryPage, null, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(hasWallet) && !unref(isLoading)) {
        _push(`<div class="flex justify-center flex-col items-center p-8 min-h-[30vh]" data-v-f11a027a><p class="mb-3 text-lg" data-v-f11a027a>You don&#39;t have an active wallet</p><button class="border border-matta-black bg-matta-black py-3 text-xs md:text-[13px] px-6 flex justify-center text-white rounded-lg items-center hover:bg-matta-black/80 capitalize font-normal gap-x-1" data-v-f11a027a> Create your wallet </button></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isLoading)) {
        _push(`<div class="text-center p-6 lg:p-8 my-24" data-v-f11a027a>`);
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_IndexModal, {
        isOpen: unref(isOpen),
        onTogglePopup: handleClose
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="max-w-[800px]" data-v-f11a027a${_scopeId}>`);
            if (unref(isTopup)) {
              _push2(ssrRenderComponent(_component_SupplierWalletModalsTopUp, { details: unref(details) }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (unref(isWithdraw)) {
              _push2(ssrRenderComponent(_component_SupplierWalletModalsWithdrawalModal, null, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (unref(isCreatingWallet)) {
              _push2(ssrRenderComponent(_component_SupplierWalletModalsCreateWallet, { onSuccess: handleWalletCreation }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (unref(isAddingKyc)) {
              _push2(ssrRenderComponent(_component_SupplierWalletModalsCreateKyc, { onSuccess: handleWalletCreation }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`<span class="cursor-pointer" data-v-f11a027a${_scopeId}>`);
            _push2(ssrRenderComponent(_component_AppIcon, {
              icon: "heroicons-solid:x",
              class: "w-4 h-4 absolute top-4 right-3 text-matta-black z-10"
            }, null, _parent2, _scopeId));
            _push2(`</span></div>`);
          } else {
            return [
              createVNode("div", { class: "max-w-[800px]" }, [
                unref(isTopup) ? (openBlock(), createBlock(_component_SupplierWalletModalsTopUp, {
                  key: 0,
                  details: unref(details)
                }, null, 8, ["details"])) : createCommentVNode("", true),
                unref(isWithdraw) ? (openBlock(), createBlock(_component_SupplierWalletModalsWithdrawalModal, { key: 1 })) : createCommentVNode("", true),
                unref(isCreatingWallet) ? (openBlock(), createBlock(_component_SupplierWalletModalsCreateWallet, {
                  key: 2,
                  onSuccess: handleWalletCreation
                })) : createCommentVNode("", true),
                unref(isAddingKyc) ? (openBlock(), createBlock(_component_SupplierWalletModalsCreateKyc, {
                  key: 3,
                  onSuccess: handleWalletCreation
                })) : createCommentVNode("", true),
                createVNode("span", {
                  class: "cursor-pointer",
                  onClick: handleClose
                }, [
                  createVNode(_component_AppIcon, {
                    icon: "heroicons-solid:x",
                    class: "w-4 h-4 absolute top-4 right-3 text-matta-black z-10"
                  })
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/WalletPage.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-f11a027a"]]);
const _sfc_main = {
  __name: "home",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierWalletPage = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierWalletPage, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/wallet/home.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=home-_Y00gKbk.mjs.map
