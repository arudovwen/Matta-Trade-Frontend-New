import { _ as __nuxt_component_0$1 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { _ as __nuxt_component_2 } from './EmptyData-RrNjecQG.mjs';
import { _ as __nuxt_component_1 } from './AppLoader-SkdFRsgH.mjs';
import { _ as __nuxt_component_4$1 } from './Simple-GRXlMUar.mjs';
import { _ as __nuxt_component_5 } from './SideModal-MJCox7bt.mjs';
import { useSSRContext, ref, reactive, watch, unref, withCtx, createVNode, createTextVNode, toDisplayString } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { useRoute } from 'vue-router';
import { O as OrderComponent } from './OrderComponent--EOiqvJi.mjs';
import { Menu, MenuButton, MenuItems } from '@headlessui/vue';
import debounce from 'lodash/debounce.js';
import { t as store, r as urls, v as get } from '../server.mjs';
import { w as withRetryHandling } from './retry-handling-kb1itlan.mjs';
import moment from 'moment';
import { toast } from 'vue3-toastify';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './currencyFormat-ET0sIbrj.mjs';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';

const config = {
  headers: { Authorization: `Bearer ${store.getters.accessToken}` }
};
const storefrontorders = withRetryHandling(
  ({ Status, SortOrder, Search, PageNumber, PageSize }) => {
    return get(
      `${urls.STOREFRONT_ORDERS}?PageSize=${PageSize}&PageNumber=${PageNumber}&Search=${Search}&SortOrder=${SortOrder}&Status=${Status}`,
      config
    );
  }
);
const storefrontorderdetails = withRetryHandling((orderId) => {
  return get(`${urls.STOREFRONT_ORDER_DETAILS}?orderId=${orderId}`, config);
});
const _sfc_main$1 = {
  __name: "OrdersComponent",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    const orders = ref([]);
    const queryParams = reactive({
      Status: "",
      SortOrder: "",
      Role: "",
      PageSize: 10,
      PageNumber: 1,
      pagecount: 0,
      totalCount: 0,
      Search: ""
    });
    const isLoading = ref(true);
    function getData() {
      isLoading.value = true;
      storefrontorders(queryParams).then((res) => {
        if (res.status) {
          orders.value = res.data.data;
          queryParams.totalCount = res.data.totalCount;
          isLoading.value = false;
        }
      }).catch((err) => {
        isLoading.value = false;
        toast.error(err.response.data.message || err.response.data.Message);
      });
    }
    useRoute();
    const order = ref(null);
    const isOpen = ref(false);
    function openOrder(val) {
      storefrontorderdetails(val.id).then((res) => {
        order.value = { ...res.data, orderId: val.orderNumber };
        isOpen.value = true;
      }).catch((err) => {
        isLoading.value = false;
        toast.error(err.response.data.message || err.response.data.Message);
      });
    }
    function openModal() {
      isOpen.value = !isOpen.value;
    }
    const theads = [
      "order id",
      "customer name",
      "created",
      "amount",
      "status",
      "scheduled delivery",
      ""
    ];
    debounce(() => {
      getData();
    }, 800);
    watch(
      () => [queryParams.PageNumber, queryParams.PageSize, queryParams.Status],
      () => {
        getData();
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderComponent = __nuxt_component_0$1;
      const _component_AppButton = __nuxt_component_4;
      const _component_EmptyData = __nuxt_component_2;
      const _component_AppLoader = __nuxt_component_1;
      const _component_PaginationSimple = __nuxt_component_4$1;
      const _component_SideModal = __nuxt_component_5;
      _push(`<!--[--><div class="mb-8 bg-white rounded-[10px] border border-[#F4F7FE]" data-v-a57c9889>`);
      _push(ssrRenderComponent(_component_HeaderComponent, {
        title: "Store Orders",
        subtext: " List of orders received by your storefront.",
        btnText: "Create order",
        btnIcon: "humbleicons:plus",
        onOnClick: ($event) => _ctx.router.push("/markets")
      }, null, _parent));
      _push(`<div class="py-8 rounded-lg bg-white" data-v-a57c9889><div class="hidden lg:flex justify-between items-center mb-8 px-5" data-v-a57c9889><div class="flex gap-x-4" data-v-a57c9889><div class="relative flex items-center" data-v-a57c9889><span class="absolute left-4 pointer-events-none text-[#667085]" data-v-a57c9889><i class="uil uil-search" data-v-a57c9889></i></span><input${ssrRenderAttr("value", unref(queryParams).Search)} placeholder="Search" class="border border-[#E7E7E7] focus:pr-3 pl-10 rounded-lg w-[280px] text-sm focus:outline-none py-[10px] transition ease-in-out duration-300" type="search" data-v-a57c9889></div><div class="flex relative items-center" data-v-a57c9889><select class="appearance-none border border-[#E7E7E7] rounded-lg w-[150px] text-sm py-[10px] px-[14px] focus:outline-matta-black/20" data-v-a57c9889><option value="" data-v-a57c9889${ssrIncludeBooleanAttr(Array.isArray(unref(queryParams).Status) ? ssrLooseContain(unref(queryParams).Status, "") : ssrLooseEqual(unref(queryParams).Status, "")) ? " selected" : ""}>Status</option><option value="0" data-v-a57c9889${ssrIncludeBooleanAttr(Array.isArray(unref(queryParams).Status) ? ssrLooseContain(unref(queryParams).Status, "0") : ssrLooseEqual(unref(queryParams).Status, "0")) ? " selected" : ""}>Pending</option><option value="1" data-v-a57c9889${ssrIncludeBooleanAttr(Array.isArray(unref(queryParams).Status) ? ssrLooseContain(unref(queryParams).Status, "1") : ssrLooseEqual(unref(queryParams).Status, "1")) ? " selected" : ""}>Completed</option></select><i class="uil uil-angle-down absolute right-2 pointer-events-none" data-v-a57c9889></i></div>`);
      _push(ssrRenderComponent(_component_AppButton, {
        onClick: ($event) => unref(queryParams).Status = "",
        text: "Clear filter",
        btnClass: "text-xs text-[#98A2B3] font-normal"
      }, null, _parent));
      _push(`</div></div>`);
      if (!unref(isLoading)) {
        _push(`<div data-v-a57c9889>`);
        if (unref(orders).length) {
          _push(`<div class="overflow-x-auto max-w-[80vw] lg:max-w-full" data-v-a57c9889>`);
          if (unref(orders).length) {
            _push(`<table class="w-full" data-v-a57c9889><thead data-v-a57c9889><tr data-v-a57c9889><!--[-->`);
            ssrRenderList(theads, (item) => {
              _push(`<th class="capitalize text-[#475467] text-sm text-left font-medium border-b border-t py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-a57c9889>${ssrInterpolate(item)}</th>`);
            });
            _push(`<!--]--></tr></thead><tbody data-v-a57c9889><!--[-->`);
            ssrRenderList(unref(orders), (item) => {
              var _a, _b;
              _push(`<tr data-v-a57c9889><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-a57c9889>${ssrInterpolate(item.orderNumber)}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-a57c9889></td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-a57c9889>${ssrInterpolate(unref(moment)(item.orderDate).format("lll"))}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-a57c9889></td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-a57c9889>`);
              if (item.statusText == "invoiced") {
                _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#E0F7B0]" data-v-a57c9889> Completed</span>`);
              } else {
                _push(`<!---->`);
              }
              if (item.statusText !== "invoiced") {
                _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#FDD0AF]" data-v-a57c9889> In progress</span>`);
              } else {
                _push(`<!---->`);
              }
              _push(`</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-a57c9889>${ssrInterpolate(item.scheduleDeilverDate ? (_a = unref(moment)(item.scheduleDeilverDate)) == null ? void 0 : _a.format("lll") : (_b = unref(moment)()) == null ? void 0 : _b.format("lll"))}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-a57c9889>`);
              _push(ssrRenderComponent(unref(Menu), {
                class: "relative",
                as: "div"
              }, {
                default: withCtx((_, _push2, _parent2, _scopeId) => {
                  if (_push2) {
                    _push2(ssrRenderComponent(unref(MenuButton), { class: "outline-none" }, {
                      default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                        if (_push3) {
                          _push3(`<i class="uil uil-ellipsis-v" data-v-a57c9889${_scopeId2}></i>`);
                        } else {
                          return [
                            createVNode("i", { class: "uil uil-ellipsis-v" })
                          ];
                        }
                      }),
                      _: 2
                    }, _parent2, _scopeId));
                    _push2(ssrRenderComponent(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[140px] rounded-xl overflow-hidden" }, {
                      default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                        if (_push3) {
                          _push3(`<div class="py-2 px-4 hover:bg-gray-50 text-sm whitespace-nowrap" data-v-a57c9889${_scopeId2}><i class="uil uil-box mr-2" data-v-a57c9889${_scopeId2}></i> Open order </div>`);
                        } else {
                          return [
                            createVNode("div", {
                              class: "py-2 px-4 hover:bg-gray-50 text-sm whitespace-nowrap",
                              onClick: ($event) => openOrder(item)
                            }, [
                              createVNode("i", { class: "uil uil-box mr-2" }),
                              createTextVNode(" Open order ")
                            ], 8, ["onClick"])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent2, _scopeId));
                  } else {
                    return [
                      createVNode(unref(MenuButton), { class: "outline-none" }, {
                        default: withCtx(() => [
                          createVNode("i", { class: "uil uil-ellipsis-v" })
                        ]),
                        _: 1
                      }),
                      createVNode(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[140px] rounded-xl overflow-hidden" }, {
                        default: withCtx(() => [
                          createVNode("div", {
                            class: "py-2 px-4 hover:bg-gray-50 text-sm whitespace-nowrap",
                            onClick: ($event) => openOrder(item)
                          }, [
                            createVNode("i", { class: "uil uil-box mr-2" }),
                            createTextVNode(" Open order ")
                          ], 8, ["onClick"])
                        ]),
                        _: 2
                      }, 1024)
                    ];
                  }
                }),
                _: 2
              }, _parent));
              _push(`</td></tr>`);
            });
            _push(`<!--]--></tbody></table>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        if (!unref(orders).length) {
          _push(ssrRenderComponent(_component_EmptyData, {
            url: "/market",
            buttonText: "go to catalog",
            text: "No orders have been placed"
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if (unref(isLoading)) {
        _push(`<div class="text-center p-6 lg:p-8 my-20" data-v-a57c9889>`);
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="p-5" data-v-a57c9889>`);
      _push(ssrRenderComponent(_component_PaginationSimple, {
        total: unref(queryParams).totalCount,
        current: unref(queryParams).PageNumber,
        "per-page": unref(queryParams).PageSize,
        pageRange: 5,
        onPageChanged: ($event) => unref(queryParams).PageNumber = $event
      }, null, _parent));
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_SideModal, {
        isOpen: unref(isOpen),
        onTogglePopup: openModal
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="h-full w-full bg-white rounded-lg p-6 lg:p-8 overflow-auto max-h-full" data-v-a57c9889${_scopeId}><div class="mb-3" data-v-a57c9889${_scopeId}><p class="text-[13px] text-[#B6B7B9] mb-2" data-v-a57c9889${_scopeId}>Order ID</p><h2 class="font-medium text-2xl" data-v-a57c9889${_scopeId}>#${ssrInterpolate(unref(order).orderId)}</h2></div><hr class="my-3 border-gray-200" data-v-a57c9889${_scopeId}>`);
            _push2(ssrRenderComponent(unref(OrderComponent), { order: unref(order) }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "h-full w-full bg-white rounded-lg p-6 lg:p-8 overflow-auto max-h-full" }, [
                createVNode("div", { class: "mb-3" }, [
                  createVNode("p", { class: "text-[13px] text-[#B6B7B9] mb-2" }, "Order ID"),
                  createVNode("h2", { class: "font-medium text-2xl" }, "#" + toDisplayString(unref(order).orderId), 1)
                ]),
                createVNode("hr", { class: "my-3 border-gray-200" }),
                createVNode(unref(OrderComponent), { order: unref(order) }, null, 8, ["order"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/OrdersComponent.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-a57c9889"]]);
const _sfc_main = {
  __name: "orders",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierOrdersComponent = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierOrdersComponent, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/storefront/orders.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=orders-xPLBA6Ji.mjs.map
