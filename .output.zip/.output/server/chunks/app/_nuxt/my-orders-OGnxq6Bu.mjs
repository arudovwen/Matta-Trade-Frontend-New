import { _ as __nuxt_component_0$1 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { _ as __nuxt_component_1$1 } from './nuxt-img-qJohECzX.mjs';
import { _ as __unimport_currencyFormat } from './currencyFormat-ET0sIbrj.mjs';
import { useSSRContext, ref, reactive, watch, resolveComponent, unref, withCtx, createVNode, createTextVNode, openBlock, createBlock, toDisplayString, createCommentVNode, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrInterpolate, ssrRenderClass } from 'vue/server-renderer';
import moment from 'moment';
import { _ as __nuxt_component_2$1 } from './EmptyData-RrNjecQG.mjs';
import { _ as __nuxt_component_1 } from './AppLoader-SkdFRsgH.mjs';
import { _ as __nuxt_component_5 } from './index-auAvMvtw.mjs';
import { _ as __nuxt_component_5$1 } from './SideModal-MJCox7bt.mjs';
import { O as OrderComponent } from './OrderComponent--EOiqvJi.mjs';
import { useRoute } from 'vue-router';
import { Menu, MenuButton, MenuItems } from '@headlessui/vue';
import debounce from 'lodash/debounce.js';
import { t as store, r as urls, v as get } from '../server.mjs';
import { w as withRetryHandling } from './retry-handling-kb1itlan.mjs';
import { toast } from 'vue3-toastify';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$2 = {
  __name: "Single",
  __ssrInlineRender: true,
  props: ["order"],
  emits: ["onClick"],
  setup(__props, { emit: __emit }) {
    const emits = __emit;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtImg = __nuxt_component_1$1;
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "py-[30px] border-b border-[#F4F7FE] flex gap-x-6" }, _attrs))}><div class="h-[100px] w-[100px] bg-gray-50 rounded-[10px] overflow-hidden">`);
      _push(ssrRenderComponent(_component_NuxtImg, {
        src: "/images/2.png",
        class: "w-full h-full",
        alt: "image"
      }, null, _parent));
      _push(`</div><div class="flex-1 flex justify-between"><div class="w-[236px]"><h6 class="text-sm mb-2 text-[#333] font-bold"> Acrypol 600(Styrene Acrylic) </h6><p class="text-xs mb-2 text-[#666666]"> Sold by: <span class="font-medium">A Huber Company</span></p><p class="text-xs mb-4 text-[#666666]"> Amount paid: <span class="font-medium text-[#333]">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(155e3))}</span></p><p class="text-xs mb-2 text-[#333333] font-semibold">Shipped to:</p><p class="text-xs mb-2 text-[#666666]">John Doe</p><p class="text-xs text-[#666666]"> 15th Floor, Elephant House, Marina, Lagos., Lagos Island, Lagos </p></div><div class="w-[130px] text-right"><div class="mb-2 leading-[150%]"><span class="text-xs text-[#333] font-semibold">Order date:</span><br><span class="text-xs text-[#666666]">${ssrInterpolate(unref(moment)(__props.order.orderDate).format("ll"))}</span></div><div class="leading-[150%]"><span class="text-xs text-[#333] font-semibold">Invoice No:</span><br><span class="text-xs text-[#666666]">205-6693055-4285164</span></div>`);
      _push(ssrRenderComponent(_component_AppButton, {
        onClick: ($event) => emits("onClick", __props.order),
        text: "View Details",
        btnClass: "text-primary-500 !px-0 font-semibold !text-xs"
      }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/orders/Single.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$2;
const config = {
  headers: { Authorization: `Bearer ${store.getters.accessToken}` }
};
const procurementorders = withRetryHandling(
  ({ Status, SortOrder, Search, PageNumber, PageSize }) => {
    return get(
      `${urls.PROCUREMENT_ORDERS}?PageSize=${PageSize}&PageNumber=${PageNumber}&Search=${Search}&SortOrder=${SortOrder}&Status=${Status}`,
      config
    );
  }
);
const buyerordertimeline = withRetryHandling((salesorderId) => {
  return get(
    `${urls.BUYER_ORDER_TIMELINE}?salesorderId=${salesorderId}`,
    config
  );
});
const procurementorderdetails = withRetryHandling((orderId) => {
  return get(`${urls.PROCUREMENT_ORDER_DETAILS}?orderNo=${orderId}`, config);
});
const _sfc_main$1 = {
  __name: "MyOrders",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    const isShowing = ref("all");
    const pendingCheckout = ref({});
    const timeline = ref([]);
    const orders = ref([]);
    const queryParams = reactive({
      Status: "",
      SortOrder: "",
      Role: "",
      PageSize: 10,
      PageNumber: 1,
      pagecount: 0,
      totalCount: 0,
      Search: ""
    });
    const isLoading = ref(true);
    function getData() {
      isLoading.value = true;
      procurementorders(queryParams).then((res) => {
        if (res.status) {
          orders.value = res.data.data;
          queryParams.totalCount = res.data.totalCount;
          isLoading.value = false;
        }
      }).catch((err) => {
        isLoading.value = false;
        toast.error(err.response.data.message || err.response.data.Message);
      });
    }
    useRoute();
    const order = ref(null);
    const isOpen = ref(false);
    function openOrder(val) {
      procurementorderdetails(val.salesorderId).then((res) => {
        order.value = { ...res.data, orderId: val.orderNumber };
        isOpen.value = true;
      }).catch((err) => {
        isLoading.value = false;
        toast.error(err.response.data.message || err.response.data.Message);
      });
      buyerordertimeline(val.salesorderId).then((res) => {
        timeline.value = res.data.data.reverse();
        isOpen.value = true;
      }).catch((err) => {
        isLoading.value = false;
        toast.error(err.response.data.message || err.response.data.Message);
      });
    }
    function openModal() {
      isOpen.value = !isOpen.value;
    }
    const theads = ["order id", "created", "status", "scheduled delivery date", ""];
    debounce(() => {
      getData();
    }, 800);
    watch(
      () => [queryParams.PageNumber, queryParams.Status, queryParams.PageSiz],
      () => {
        getData();
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f;
      const _component_HeaderComponent = __nuxt_component_0$1;
      const _component_AppButton = __nuxt_component_4;
      const _component_SupplierOrdersSingle = __nuxt_component_2;
      const _component_EmptyData = __nuxt_component_2$1;
      const _component_router_link = resolveComponent("router-link");
      const _component_AppLoader = __nuxt_component_1;
      const _component_Pagination = __nuxt_component_5;
      const _component_SideModal = __nuxt_component_5$1;
      const _component_SupplierOrderComponent = OrderComponent;
      _push(`<!--[--><div class="gap-y-2 flex flex-col mb-4 bg-white rounded-[10px] pb-10" data-v-916e017d>`);
      _push(ssrRenderComponent(_component_HeaderComponent, { title: "My  Orders" }, null, _parent));
      _push(`<div class="p-6 lg:p-8 rounded-lg bg-white" data-v-916e017d>`);
      if (unref(isShowing) === "all") {
        _push(`<div data-v-916e017d><div class="hidden lg:flex justify-between items-center mb-8" v="!isEmpty" data-v-916e017d><div class="flex gap-x-4" data-v-916e017d><div class="relative flex items-center" data-v-916e017d><span class="absolute left-4 pointer-events-none text-[#667085]" data-v-916e017d><i class="uil uil-search" data-v-916e017d></i></span><input${ssrRenderAttr("value", unref(queryParams).Search)} placeholder="Search" class="border border-[#E7E7E7] text-sm focus:pr-3 pl-10 rounded-lg w-[280px] focus:outline-none py-[10px] transition ease-in-out duration-300" type="search" data-v-916e017d></div><div class="flex relative items-center" data-v-916e017d><select class="appearance-none border border-[#E7E7E7] text-sm rounded-lg w-[180px] py-[10px] px-[14px] focus:outline-matta-black/20" data-v-916e017d><option value="" data-v-916e017d${ssrIncludeBooleanAttr(Array.isArray(unref(queryParams).Status) ? ssrLooseContain(unref(queryParams).Status, "") : ssrLooseEqual(unref(queryParams).Status, "")) ? " selected" : ""}>Status</option><option value="0" data-v-916e017d${ssrIncludeBooleanAttr(Array.isArray(unref(queryParams).Status) ? ssrLooseContain(unref(queryParams).Status, "0") : ssrLooseEqual(unref(queryParams).Status, "0")) ? " selected" : ""}>Pending</option><option value="1" data-v-916e017d${ssrIncludeBooleanAttr(Array.isArray(unref(queryParams).Status) ? ssrLooseContain(unref(queryParams).Status, "1") : ssrLooseEqual(unref(queryParams).Status, "1")) ? " selected" : ""}>Completed</option></select><i class="uil uil-angle-down absolute right-2 pointer-events-none" data-v-916e017d></i></div>`);
        _push(ssrRenderComponent(_component_AppButton, {
          onClick: ($event) => unref(queryParams).Status = "",
          text: "Clear filter",
          btnClass: "text-xs text-[#98A2B3] font-normal"
        }, null, _parent));
        _push(`</div></div><div data-v-916e017d><!--[-->`);
        ssrRenderList(unref(orders), (item) => {
          _push(ssrRenderComponent(_component_SupplierOrdersSingle, {
            key: item,
            order: item,
            onOnClick: ($event) => openOrder(item)
          }, null, _parent));
        });
        _push(`<!--]--></div>`);
        if (!unref(isLoading)) {
          _push(`<div class="hidden" data-v-916e017d>`);
          if (unref(orders).length) {
            _push(`<div class="overflow-x-auto max-w-[80vw] lg:max-w-full" data-v-916e017d>`);
            if (unref(orders).length) {
              _push(`<table class="w-full" data-v-916e017d><thead data-v-916e017d><tr data-v-916e017d><!--[-->`);
              ssrRenderList(theads, (item) => {
                _push(`<th class="uppercase text-[#B6B7B9] text-[13px] text-left font-normal border-b py-6 px-3 border-[#E7EBEE] whitespace-nowrap" data-v-916e017d>${ssrInterpolate(item)}</th>`);
              });
              _push(`<!--]--></tr></thead><tbody data-v-916e017d><!--[-->`);
              ssrRenderList(unref(orders), (item) => {
                var _a2, _b2;
                _push(`<tr data-v-916e017d><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-916e017d>${ssrInterpolate(item.orderNumber)}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-916e017d>${ssrInterpolate(unref(moment)(item.orderDate).format("lll"))}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-916e017d>`);
                if (item.statusText == "invoiced") {
                  _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#E0F7B0]" data-v-916e017d> Completed</span>`);
                } else {
                  _push(`<!---->`);
                }
                if (item.statusText !== "invoiced") {
                  _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#FDD0AF]" data-v-916e017d> In progress</span>`);
                } else {
                  _push(`<!---->`);
                }
                _push(`</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-916e017d>${ssrInterpolate(item.scheduleDeilverDate ? (_a2 = unref(moment)(item.scheduleDeilverDate)) == null ? void 0 : _a2.format("lll") : (_b2 = unref(moment)()) == null ? void 0 : _b2.format("lll"))}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-916e017d>`);
                _push(ssrRenderComponent(unref(Menu), {
                  class: "relative",
                  as: "div"
                }, {
                  default: withCtx((_, _push2, _parent2, _scopeId) => {
                    if (_push2) {
                      _push2(ssrRenderComponent(unref(MenuButton), { class: "outline-none" }, {
                        default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                          if (_push3) {
                            _push3(`<i class="uil uil-ellipsis-v" data-v-916e017d${_scopeId2}></i>`);
                          } else {
                            return [
                              createVNode("i", { class: "uil uil-ellipsis-v" })
                            ];
                          }
                        }),
                        _: 2
                      }, _parent2, _scopeId));
                      _push2(ssrRenderComponent(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[140px] rounded-xl overflow-hidden" }, {
                        default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                          if (_push3) {
                            _push3(`<div class="py-2 px-4 hover:bg-gray-50 text-sm whitespace-nowrap" data-v-916e017d${_scopeId2}><i class="uil uil-box mr-2" data-v-916e017d${_scopeId2}></i> Open order </div>`);
                          } else {
                            return [
                              createVNode("div", {
                                class: "py-2 px-4 hover:bg-gray-50 text-sm whitespace-nowrap",
                                onClick: ($event) => openOrder(item)
                              }, [
                                createVNode("i", { class: "uil uil-box mr-2" }),
                                createTextVNode(" Open order ")
                              ], 8, ["onClick"])
                            ];
                          }
                        }),
                        _: 2
                      }, _parent2, _scopeId));
                    } else {
                      return [
                        createVNode(unref(MenuButton), { class: "outline-none" }, {
                          default: withCtx(() => [
                            createVNode("i", { class: "uil uil-ellipsis-v" })
                          ]),
                          _: 1
                        }),
                        createVNode(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[140px] rounded-xl overflow-hidden" }, {
                          default: withCtx(() => [
                            createVNode("div", {
                              class: "py-2 px-4 hover:bg-gray-50 text-sm whitespace-nowrap",
                              onClick: ($event) => openOrder(item)
                            }, [
                              createVNode("i", { class: "uil uil-box mr-2" }),
                              createTextVNode(" Open order ")
                            ], 8, ["onClick"])
                          ]),
                          _: 2
                        }, 1024)
                      ];
                    }
                  }),
                  _: 2
                }, _parent));
                _push(`</td></tr>`);
              });
              _push(`<!--]--></tbody></table>`);
            } else {
              _push(`<!---->`);
            }
            _push(`</div>`);
          } else {
            _push(`<!---->`);
          }
          if (!unref(orders).length) {
            _push(ssrRenderComponent(_component_EmptyData, {
              url: "/markets",
              buttonText: "go to catalog",
              text: "No orders have been placed"
            }, null, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isShowing) === "pending") {
        _push(`<div data-v-916e017d><!--[-->`);
        ssrRenderList(unref(pendingCheckout).items, (item, idx) => {
          _push(`<div class="p-6 relative rounded-lg bg-white border mb-4" data-v-916e017d><p class="mb-1 text-[13px] uppercase" data-v-916e017d>${ssrInterpolate(item.producer)}</p><p class="mb-2 text-lg lg:text-xl font-medium" data-v-916e017d>${ssrInterpolate(item.product)}</p><span class="top-3 right-3 absolute cursor-pointer" data-v-916e017d><i class="uil uil-times text-2xl text-matta-black" data-v-916e017d></i></span><div class="flex flex-col lg:flex-row items-center gap-3 mb-4 w-full" data-v-916e017d><div class="flex items-center bg-[#F1F3F5] rounded-lg relative flex-1 w-full lg:w-auto pr-4" data-v-916e017d><div class="relative w-full flex justify-between items-center" data-v-916e017d><div class="py-4 text-[13px] px-6 bg-transparent capitlize md:uppercase text-matta-black w-full text-left" data-v-916e017d><span class="text-[#101828] text-[13px]" data-v-916e017d>${ssrInterpolate(item.selectedPackage)}</span></div><div class="${ssrRenderClass([
            "relative text-matta-black flex items-center justify-between py-4 gap-x-4"
          ])}" data-v-916e017d><span class="text-gray-700 whitespace-nowrap" data-v-916e017d><span class="text-[13px] whitespace-nowrap" data-v-916e017d>${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(item.packagePrice))}</span></span></div></div></div><div class="flex flex-col lg:flex-row gap-3 items-center w-full lg:w-auto" data-v-916e017d><div class="flex items-center justify-between lg:w-[250px] lg:justify-center gap-x-8 lg:gap-x-16 w-full rounded-lg bg-[#F1F3F5] relative py-4 text-[13px] px-6 uppercase text-matta-black" data-v-916e017d><div class="w-[50px] text-center" data-v-916e017d>x ${ssrInterpolate(item.quantity)}</div></div><div class="font-medium text-xl text-center lg:text-right whitespace-nowrap w-[200px]" data-v-916e017d>${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(item.subTotal))}</div></div></div></div>`);
        });
        _push(`<!--]-->`);
        if ((_b = (_a = unref(pendingCheckout)) == null ? void 0 : _a.items) == null ? void 0 : _b.length) {
          _push(`<div class="flex justify-end gap-x-10 mb-10 items-center" data-v-916e017d><div class="text-[#ABABAB] text-sm uppercase" data-v-916e017d>Item total</div><div class="text-2xl text-right font-medium" data-v-916e017d>${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(unref(pendingCheckout).cartTotal))}</div></div>`);
        } else {
          _push(`<!---->`);
        }
        if ((_d = (_c = unref(pendingCheckout)) == null ? void 0 : _c.items) == null ? void 0 : _d.length) {
          _push(`<div class="flex justify-end mt-4" data-v-916e017d>`);
          _push(ssrRenderComponent(_component_router_link, { to: "/checkout" }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<button class="uppercase text-white bg-primary-500 py-4 px-6 rounded-lg text-[13px] mb-6 disabled:bg-gray-400 disabled:text-white disabled:cursor-not-allowed" data-v-916e017d${_scopeId}> Proceed to checkout </button>`);
              } else {
                return [
                  createVNode("button", { class: "uppercase text-white bg-primary-500 py-4 px-6 rounded-lg text-[13px] mb-6 disabled:bg-gray-400 disabled:text-white disabled:cursor-not-allowed" }, " Proceed to checkout ")
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        if (!((_f = (_e = unref(pendingCheckout)) == null ? void 0 : _e.items) == null ? void 0 : _f.length)) {
          _push(`<div class="text-center py-20 text-lg" data-v-916e017d> No pending checkout </div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if (unref(isLoading)) {
        _push(`<div class="text-center p-6 lg:p-8 my-20" data-v-916e017d>`);
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="p-5" data-v-916e017d>`);
      _push(ssrRenderComponent(_component_Pagination, {
        total: unref(queryParams).totalCount,
        current: unref(queryParams).PageNumber,
        "per-page": unref(queryParams).PageSize,
        pageRange: 5,
        onPageChanged: ($event) => unref(queryParams).PageNumber = $event
      }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_SideModal, {
        isOpen: unref(isOpen),
        onTogglePopup: openModal
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="h-full w-full bg-white rounded-lg p-6 lg:p-8 overflow-auto max-h-full" data-v-916e017d${_scopeId}><div class="mb-3" data-v-916e017d${_scopeId}><p class="text-[13px] text-[#B6B7B9] mb-2" data-v-916e017d${_scopeId}>Order ID</p>`);
            if (unref(order)) {
              _push2(`<h2 class="font-medium text-2xl" data-v-916e017d${_scopeId}> #${ssrInterpolate(unref(order).orderId)}</h2>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><hr class="my-3 border-gray-200" data-v-916e017d${_scopeId}>`);
            _push2(ssrRenderComponent(_component_SupplierOrderComponent, {
              order: unref(order),
              timeline: unref(timeline)
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "h-full w-full bg-white rounded-lg p-6 lg:p-8 overflow-auto max-h-full" }, [
                createVNode("div", { class: "mb-3" }, [
                  createVNode("p", { class: "text-[13px] text-[#B6B7B9] mb-2" }, "Order ID"),
                  unref(order) ? (openBlock(), createBlock("h2", {
                    key: 0,
                    class: "font-medium text-2xl"
                  }, " #" + toDisplayString(unref(order).orderId), 1)) : createCommentVNode("", true)
                ]),
                createVNode("hr", { class: "my-3 border-gray-200" }),
                createVNode(_component_SupplierOrderComponent, {
                  order: unref(order),
                  timeline: unref(timeline)
                }, null, 8, ["order", "timeline"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/MyOrders.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-916e017d"]]);
const _sfc_main = {
  __name: "my-orders",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierMyOrders = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierMyOrders, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/procurement/my-orders.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=my-orders-OGnxq6Bu.mjs.map
