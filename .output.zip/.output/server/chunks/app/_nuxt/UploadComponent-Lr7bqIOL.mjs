import { _ as __nuxt_component_1 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_1$1 } from './nuxt-img-qJohECzX.mjs';
import { useSSRContext, ref, computed } from 'vue';
import { ssrRenderClass, ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderList } from 'vue/server-renderer';

const _sfc_main = {
  __name: "UploadComponent",
  __ssrInlineRender: true,
  props: {
    isMultiple: { default: true },
    type: { default: "image" },
    gallery: { default: [] },
    support: {
      default: ""
    },
    recommended: {
      default: ""
    },
    id: {
      default: "file"
    },
    url: {
      default: ""
    }
  },
  emits: ["onGetFiles", "removeFile"],
  setup(__props, { emit: __emit }) {
    ref([]);
    const image = ref("");
    ref([]);
    const props = __props;
    const isLoading = ref(false);
    const accepts = computed(() => {
      let val;
      switch (props.type) {
        case "image":
          val = ".png, .jpg, .jpeg";
          break;
        case "doc":
          val = ".pdf";
          break;
      }
      return val;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1;
      const _component_NuxtImg = __nuxt_component_1$1;
      _push(`<!--[--><div class="border mb-6 flex-1 border-[#EAECF0] rounded-[12px] px-6 py-10 flex items-center justify-center text-center relative group overflow-hidden min-h-[190px]"><div class="${ssrRenderClass(`relative z-20 ${!__props.isMultiple && (image.value || __props.url) ? "invisible group-hover:visible" : "visible"}`)}"><div class="text-center mb-3 h-10 w-10 flex mx-auto items-center justify-center rounded-[10px] border border-primary">`);
      _push(ssrRenderComponent(_component_AppIcon, {
        icon: "bytesize:upload",
        iconClass: "text-xl text-[#344054]"
      }, null, _parent));
      _push(`</div><p class="text-sm mb-2"><label${ssrRenderAttr("for", __props.id)} class="!text-primary-500 font-medium cursor-pointer ml-1">Click to upload</label> or Drag &amp; Drop Files </p>`);
      if (__props.support) {
        _push(`<p class="text-xs text-[#ABABAB] mb-1">${ssrInterpolate(__props.support)}</p>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.recommended) {
        _push(`<p class="text-xs text-[#ABABAB]">${ssrInterpolate(__props.recommended)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if (!__props.isMultiple && (image.value || __props.url)) {
        _push(`<img${ssrRenderAttr("src", image.value || __props.url)} class="w-full h-full object-cover absolute z-10 group-hover:opacity-10 backdrop-blur-sm">`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><input type="file"${ssrRenderAttr("id", __props.id)} class="hidden"${ssrRenderAttr("accept", accepts.value)}${ssrIncludeBooleanAttr(__props.isMultiple) ? " multiple" : ""}>`);
      if (__props.type === "image" && __props.isMultiple && __props.gallery.length) {
        _push(`<div class="bg-white flex flex-wrap gap-2 max-h-full overflow-y-auto rounded-lg"><!--[-->`);
        ssrRenderList(__props.gallery, (n, i) => {
          _push(`<span><span class="h-24 w-24 rounded-lg bg-white flex items-center justify-center border relative border-[#E7EBEE]">`);
          _push(ssrRenderComponent(_component_NuxtImg, {
            src: n,
            alt: "logo",
            class: "w-full h-full rounded-lg"
          }, null, _parent));
          _push(`<span class="bg-white text-matta-black h-5 w-5 flex items-center justify-center absolute -top-1 -right-2"><i class="uil uil-times"></i></span></span></span>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<span>`);
      if (isLoading.value) {
        _push(`<i class="fa fa-spinner fa-spin text-6xl text-matta-black" aria-hidden="true"></i>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</span><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UploadComponent.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=UploadComponent-Lr7bqIOL.mjs.map
