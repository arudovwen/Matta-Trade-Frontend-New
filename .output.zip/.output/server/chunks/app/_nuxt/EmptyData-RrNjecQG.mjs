import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_1 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';

const _imports_0 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFwAAABeCAYAAACuJ3NTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAnDSURBVHgB7Z1pbFTXFcf/576ZeTPj8QI2jtkdIGBsoyzGQU1IQwgyBJSQBoESAhRoRTEESihVG1Jatx9AaYVQCl0gobRCikKlJChFUCDdIwIKhLAGBAazKUAajLGxZ3v39jynUCir38ydGfD7fRh53rx5y//dOffec+45BlxcXFxcXFxcXFxcUg0hDXSetj2Y39KhlAz0lZbRQZBlKghLSnkBZO23GuT+g++XNCIBlrxXn+cNZvWTZPUXinIEwQOFmII6F48ZB+qzvPtqnqAwUkzKBO8/oa6zYajJUGqEAg0mKHGT3RXvs4v32YxIfNXeNX0/w22w4s+RMsvAC1JRFR+i8mb78o1H+fVjRXhHSmvtrOGBo0gB2gUve7G2kgxaqAAWGX44Y5clZM1nv++z9ppPlKKlm5pHE3lf5QdUAWf3JPlbGxCP/3TmU1kfQyPaBO/3/IEuXp9nCSDGIVkQfRqTkecOri5pbY3LuEULQcvZTDyKJMGCrCblm1c9nM5CA1oELx9f+xx5aCW36jwknwhf9Y+mv9DVB0HzuVVnIcmwKJ/HpDXnuyOCf0SSSbrgAyYdXsAd4M+gmfv7Z6Py/hC8HgEtEMWg5Cszq/yLkUSSKnj5xNqFfKGvIEV0KzLx9JMFWnsiPvTCGVXmq0gSSWse5S8e+V4qxbY5eTqCLZ9csIc02uBDz1+6MTwLSSIpbaN8Qt0jEDyEgwoiDQyuzMOAfkk35VcjxNCZw7x/Q4Ik3MJ7P3+4O0iuTpfYNtt2NuBCUxxakertmvdPJXyPCQtu+sR0/p30QhqJxRX+se089KIKC/0FCdvyhExK6cTaHoLEAb6YANIM8Z2MeqIA3buY0EjYNHwl336SjsEhCbVwFnt+JohtY3ecuw80QTP+SCwyAwngWPCKacrLtzkaGcSJz8Nsyy1ohTDFdifAIY4FjzTX2dPpImQQdis/fkqzA5Co07LN8aFwiGPBpbCeRQZyqK4ZulHSqoJDHAsuIB5EBtLQGOdRi4ROhCEq4RDnnSYhIwVvCUs0t+gVnKQapBzacUeCPzD5aB7PebORobSE9XacLHXwNx8684Q6ElxJj+Z5dGI0t2h0rvyXeByONHAkeDQe8yCDUUq/4KI5bMABjgSXMhpDBuP1avKRXwHBisABjq4slJOt23GREKYX2gkGsxxp4EjwHSu68mCXTiEDsX0qwaB2i3d0isMlFs5/e0puRQaSk+1BKOjIvLaFA3CIc8EFfYQMpDDf29rKdSKI/gSHJNC7eNYiAynupt95GYvJTXCIY8H3/qFHLXfVWhfNtJWA30Cv7k7XGt0mCjtmj/TXwiEJjZ8k1OvIIHr3DHDoUbM9IfUGEiAhwQOm/z1u5buRAZimwAP9Q9CKwqEvtpjpE/yr4aGajwzAFjs7pHd0Igxjbk0NJeQZSzyIbNZvkqA1SCN5OR48WKbXl8aG6u3qYZ51SJCEBd+xYmDM44vPU6QOIQ0E/ALDv95R61BQQR0LS99MJIGkOB12v3nfSUOq59hndAYphFjlqsc6omOevrm8vbDTsNSQuSPoHJJA0rw8u1f32RuFeILbQz1SgMGjkccezkWXe3Qui1BnFFnjqp8K1CFJJH/17JRjvaRlbeAD94U2qP6ZYR0buxb5e0AXCgeFlCOSKbZN0v2Ye1b1PBKDdyg/ypXQAD/IbaB4ZVGBGsom5QPogPA7j/ANSrbYXx1aI2XfPPyoUsYvBNTXkDDqhFT44f7Vvd+6cuuyjeFq9m28zCGH+5AgBNopYX3/parAX6AJ/UlVNUqU1B171ivVTO7t276eg+hTwFolZGjl7tVFF6+3y/LNKlciNkZKNZfvqAxtg0OU9E9JYkmWx9g4RXNmW0rTBkvH7u1o+LOe4ZnD4wRZxmfvzJeQy3fsI4U4P5BGtp3nePsuJdXfDWl9sOetfkfaco6lG9W9RLGRLOIQHqoWc7ytO99kNv8CDD6Hna7SyCG484LEv3j7loiIbpozLJSy0VVa8jQvUVGx3dvywD3ZKmKZXopb5wrONp5c8kgLksgv1yvTjCO7OY8jb1FE5f7DTbNn3+coPObi4uLi4uKSQhIepXQbuyWQYxY+TkJ042hLgZKUz1GREEmlZzUOH9XjEQGflxA0RTgU8qpOHDju1cOPvNzk+cN5CMkBLfCIib6EkmcVUd3FsLn1B6MpoSoXjgS38+h9fnOStNRIEniYL0xrYs3tYvvF+xQH0IdDbR1ytXgQLR7DbxVCrLGktc5JBYo2CV465eggYckpPPsbn8mrZ223bXE3E+V9s9Cts7agcphP8y5J36Lq4bT3dr90W4KXTDqZ76HoayzyVKR5stRWirv68cjAXORm61yNRctbYtaieaMCt8xuu6V4pROOPGMIvMFT40LcoZg+QsWAnNZsZV1RfTu9iF+rX6ryr7/Zfjc8+5AhyvNF9yML2CexwHaj4S6gF9v2IYPy7GRe6IL9QYtZ9Hk3+vyGQpZOrP01uz2rcZfRtchsjYHqFJ1l/a0V986ZPZKu8dlce9aaGlE+8cibd6PYNqdOR7D+r18iEtWZB6SmG57Yz6/3yTWCl9VO/Am3+2/hLub0v6OtZT/ils5MCTX7VxvCL///1qtMSvmkum8oJd+hu8Rm34pUlP0wlKqaPty/+dL7yy18QPWxDoBc0l7EtvnokwbUX9CbPWMRrXjtQ3V5znJZcNUUs0tT9EQ7wmKTsmV7A6TeHKzi0MXIjy+9aW3NJZOPFnsk9qWzyEw6GTU0Hz26aF3mbPFTLZk5wn+4tYUblpzXXsW22blPe9kPQxmYa/9B/aYeyPZZvhNKIRftmLEjC1HQUWf6mzobCZnFwoz7hrd3sW0Oa69CQYXepvAYwVPRqXBB7fEwLM29JynxFAsuHoYLGi/G0XRRb1EEAXqaO02VD5fWakL1DXpL8SlS2fqT0u8gGnXXPoSG1bN3MucuuIKnlGhUbyUhG1fwK1D69XYFvxJPCsruuIJfQVGB/tUePDQk/YX+7hA65fugEx56XhBSWkvggh5d/bBXcOmEzclyEag/b//Llzq0Y+waWYMrNLuTCCei4dhisWPdwGbplU/bIQi0Ux6rzEVujtYeswlxGjNndOjM5XBa6aS6BwnyXd5QjHaCvVRiMIvd916NoQClznriNOw7o8w99tur4pcDxh/rYHnlLJJqBsc278FdiscglPQOthZECGXpqUDBZvo8a/i6FTu+aPbI/+UUXTdgXDFtu7elJf8hIeRDpAytNY08wvKRh7RXBbPxGRTv2T0YGzggF1kagvVStgp6EcrY06nh4PZx48qjcHFxcXFxcXFxcXFJO/8BYmkinKLM/mQAAAAASUVORK5CYII=";
const _imports_1 = "" + publicAssetsURL("images/campaign.png");
const _imports_2 = "data:image/svg+xml,%3csvg%20width='180'%20height='136'%20viewBox='0%200%20180%20136'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3ccircle%20cx='90'%20cy='64'%20r='64'%20fill='%23EAECF0'/%3e%3ccircle%20cx='24'%20cy='20'%20r='6'%20fill='%23F2F4F7'/%3e%3ccircle%20cx='21'%20cy='112'%20r='8'%20fill='%23F2F4F7'/%3e%3ccircle%20cx='164'%20cy='36'%20r='8'%20fill='%23F2F4F7'/%3e%3ccircle%20cx='153'%20cy='9'%20r='5'%20fill='%23F2F4F7'/%3e%3cg%20filter='url(%23filter0_dd_660_6067)'%3e%3cpath%20d='M92%2016C78.534%2016%2066.6222%2022.6541%2059.3733%2032.8536C57.0062%2032.2954%2054.5376%2032%2052%2032C34.3269%2032%2020%2046.3269%2020%2064C20%2081.6731%2034.3269%2096%2052%2096H132C147.464%2096%20160%2083.464%20160%2068C160%2052.536%20147.464%2040%20132%2040C130.902%2040%20129.818%2040.0633%20128.752%2040.1863C122.623%2025.9596%20108.475%2016%2092%2016Z'%20fill='%23F9FAFB'/%3e%3ccircle%20cx='52'%20cy='64'%20r='32'%20fill='url(%23paint0_linear_660_6067)'/%3e%3ccircle%20cx='92'%20cy='56'%20r='40'%20fill='url(%23paint1_linear_660_6067)'/%3e%3ccircle%20cx='132'%20cy='68'%20r='28'%20fill='url(%23paint2_linear_660_6067)'/%3e%3c/g%3e%3cg%20filter='url(%23filter1_b_660_6067)'%3e%3cpath%20d='M62%2088C62%2072.536%2074.536%2060%2090%2060C105.464%2060%20118%2072.536%20118%2088C118%20103.464%20105.464%20116%2090%20116C74.536%20116%2062%20103.464%2062%2088Z'%20fill='%23344054'%20fill-opacity='0.4'/%3e%3cpath%20d='M100.5%2098.5L96.4168%2094.4167M99.3333%2087.4167C99.3333%2092.8935%2094.8935%2097.3333%2089.4167%2097.3333C83.9398%2097.3333%2079.5%2092.8935%2079.5%2087.4167C79.5%2081.9398%2083.9398%2077.5%2089.4167%2077.5C94.8935%2077.5%2099.3333%2081.9398%2099.3333%2087.4167Z'%20stroke='white'%20stroke-width='2'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/g%3e%3cdefs%3e%3cfilter%20id='filter0_dd_660_6067'%20x='0'%20y='16'%20width='180'%20height='120'%20filterUnits='userSpaceOnUse'%20color-interpolation-filters='sRGB'%3e%3cfeFlood%20flood-opacity='0'%20result='BackgroundImageFix'/%3e%3cfeColorMatrix%20in='SourceAlpha'%20type='matrix'%20values='0%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%20127%200'%20result='hardAlpha'/%3e%3cfeMorphology%20radius='4'%20operator='erode'%20in='SourceAlpha'%20result='effect1_dropShadow_660_6067'/%3e%3cfeOffset%20dy='8'/%3e%3cfeGaussianBlur%20stdDeviation='4'/%3e%3cfeComposite%20in2='hardAlpha'%20operator='out'/%3e%3cfeColorMatrix%20type='matrix'%20values='0%200%200%200%200.0627451%200%200%200%200%200.0941176%200%200%200%200%200.156863%200%200%200%200.03%200'/%3e%3cfeBlend%20mode='normal'%20in2='BackgroundImageFix'%20result='effect1_dropShadow_660_6067'/%3e%3cfeColorMatrix%20in='SourceAlpha'%20type='matrix'%20values='0%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%200%20127%200'%20result='hardAlpha'/%3e%3cfeMorphology%20radius='4'%20operator='erode'%20in='SourceAlpha'%20result='effect2_dropShadow_660_6067'/%3e%3cfeOffset%20dy='20'/%3e%3cfeGaussianBlur%20stdDeviation='12'/%3e%3cfeComposite%20in2='hardAlpha'%20operator='out'/%3e%3cfeColorMatrix%20type='matrix'%20values='0%200%200%200%200.0627451%200%200%200%200%200.0941176%200%200%200%200%200.156863%200%200%200%200.08%200'/%3e%3cfeBlend%20mode='normal'%20in2='effect1_dropShadow_660_6067'%20result='effect2_dropShadow_660_6067'/%3e%3cfeBlend%20mode='normal'%20in='SourceGraphic'%20in2='effect2_dropShadow_660_6067'%20result='shape'/%3e%3c/filter%3e%3cfilter%20id='filter1_b_660_6067'%20x='54'%20y='52'%20width='72'%20height='72'%20filterUnits='userSpaceOnUse'%20color-interpolation-filters='sRGB'%3e%3cfeFlood%20flood-opacity='0'%20result='BackgroundImageFix'/%3e%3cfeGaussianBlur%20in='BackgroundImageFix'%20stdDeviation='4'/%3e%3cfeComposite%20in2='SourceAlpha'%20operator='in'%20result='effect1_backgroundBlur_660_6067'/%3e%3cfeBlend%20mode='normal'%20in='SourceGraphic'%20in2='effect1_backgroundBlur_660_6067'%20result='shape'/%3e%3c/filter%3e%3clinearGradient%20id='paint0_linear_660_6067'%20x1='27.4286'%20y1='42.8571'%20x2='84'%20y2='96'%20gradientUnits='userSpaceOnUse'%3e%3cstop%20stop-color='%23D0D5DD'/%3e%3cstop%20offset='0.350715'%20stop-color='white'%20stop-opacity='0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='paint1_linear_660_6067'%20x1='61.2857'%20y1='29.5714'%20x2='132'%20y2='95.9999'%20gradientUnits='userSpaceOnUse'%3e%3cstop%20stop-color='%23D0D5DD'/%3e%3cstop%20offset='0.350715'%20stop-color='white'%20stop-opacity='0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='paint2_linear_660_6067'%20x1='110.5'%20y1='49.5'%20x2='160'%20y2='96'%20gradientUnits='userSpaceOnUse'%3e%3cstop%20stop-color='%23D0D5DD'/%3e%3cstop%20offset='0.350715'%20stop-color='white'%20stop-opacity='0'/%3e%3c/linearGradient%3e%3c/defs%3e%3c/svg%3e";
const _sfc_main = {
  __name: "EmptyData",
  __ssrInlineRender: true,
  props: ["title", "subtext", "btnText", "url", "type", "btnIcon"],
  emits: ["btnFunction"],
  setup(__props, { emit: __emit }) {
    const emits = __emit;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1;
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col items-center justify-center p-4 h-[300px] text-gray-400 text-center" }, _attrs))}><div class="mb-6 flex justify-center">`);
      if (__props.type == "shipping") {
        _push(ssrRenderComponent(_component_AppIcon, {
          icon: "fa6-solid:truck",
          iconClass: "text-6xl text-[#E8E8E8]"
        }, null, _parent));
      } else if (__props.type == "user") {
        _push(`<img${ssrRenderAttr("src", _imports_0)}>`);
      } else if (__props.type == "campaign") {
        _push(`<img${ssrRenderAttr("src", _imports_1)}>`);
      } else {
        _push(`<img${ssrRenderAttr("src", _imports_2)}>`);
      }
      _push(`</div><p class="text-lg text-[#101828] font-semibold mb-2">${ssrInterpolate(__props.title || "No data available")}</p>`);
      if (__props.subtext) {
        _push(`<p class="text-sm text-[#475467] max-w-[352px] mx-auto text-center">${ssrInterpolate(__props.subtext)}</p>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.btnText) {
        _push(ssrRenderComponent(_component_AppButton, {
          onClick: ($event) => emits("btnFunction"),
          text: __props.btnText,
          btnClass: "!py-[10px] bg-primary-500 text-white mt-3 !rounded-lg",
          icon: __props.btnIcon
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/EmptyData.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main;

export { __nuxt_component_2 as _ };
//# sourceMappingURL=EmptyData-RrNjecQG.mjs.map
