import { _ as __nuxt_component_0 } from './TopBar-Q5W4PGYG.mjs';
import { _ as __nuxt_component_1 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-fc3HHrvA.mjs';
import { ref, mergeProps, unref, withCtx, createVNode, useSSRContext } from 'vue';
import { useRouter } from 'vue-router';
import { d as useAuthStore, y as useStore } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderStyle } from 'vue/server-renderer';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './_plugin-vue_export-helper-yVxbj29m.mjs';
import '@iconify/vue';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main = {
  __name: "account",
  __ssrInlineRender: true,
  setup(__props) {
    useAuthStore();
    useRouter();
    useStore();
    const isLoading = ref(false);
    const content = [
      {
        title: "Personal",
        sub: "Create an account on your behalf",
        type: 1,
        icon: "la:user"
      },
      {
        title: "Company",
        sub: "Create an account on behalf of the company",
        type: 0,
        icon: "la:users"
      }
    ];
    const type = ref(null);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_OnboardingLayoutTopBar = __nuxt_component_0;
      const _component_AppIcon = __nuxt_component_1;
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-[#E7EBEE] p-3 md:p-6 flex flex-col gap-y-2 min-h-screen w-full" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_OnboardingLayoutTopBar, null, null, _parent));
      _push(`<div class="flex items-center flex-1 bg-white rounded-lg"><div class="px-10 py-10 relative text-center bg-white flex-1 container"><h3 class="font-bold text-2xl md:text-4xl mb-12 text-matta-black"> Select account type </h3><div class="grid grid-cols-1 md:grid-cols-2 gap-x-6 text-left mt-12 md:w-[80%] mx-auto mb-24"><!--[-->`);
      ssrRenderList(content, (i) => {
        _push(`<div class="${ssrRenderClass([unref(type) == i.type ? "bg-matta-black" : "", "py-12 px-10 border border-[#E7EBEE] rounded-[20px] shadow-sm hover:shadow-lg group hover:bg-matta-black/80 text-center cursor-pointer"])}"><div class="${ssrRenderClass([unref(type) == i.type ? "border-gray-200" : "border-matta-black", "mb-4 w-16 h-16 rounded-full border group-hover:border-gray-200 flex items-center justify-center mx-auto"])}">`);
        _push(ssrRenderComponent(_component_AppIcon, {
          icon: i.icon,
          class: [unref(type) == i.type ? "text-white" : "", "group-hover:text-white text-matta-black text-4xl"]
        }, null, _parent));
        _push(`</div><p class="${ssrRenderClass([unref(type) == i.type ? "text-white" : "", "font-semibold text-matta-black text-xl group-hover:text-white"])}">${ssrInterpolate(i.title)} Account </p><p class="${ssrRenderClass([unref(type) == i.type ? "text-white" : "", "text-matta-black group-hover:text-white text-sm lg:text-base"])}">${ssrInterpolate(i.sub)}</p></div>`);
      });
      _push(`<!--]--></div><div class="flex justify-center gap-x-4 items-center">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/auth/login" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button class="appearance-none leading-none px-10 py-4 rounded-full text-matta-black bg-[#F1F3F5] hover:bg-gray-100 text-[13px] uppercase"${_scopeId}> Back </button>`);
          } else {
            return [
              createVNode("button", { class: "appearance-none leading-none px-10 py-4 rounded-full text-matta-black bg-[#F1F3F5] hover:bg-gray-100 text-[13px] uppercase" }, " Back ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<button${ssrIncludeBooleanAttr(unref(type) === null || unref(isLoading)) ? " disabled" : ""} class="appearance-none leading-none px-10 py-4 rounded-full text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase disabled:opacity-60"><i class="fa fa-spinner fa-spin" style="${ssrRenderStyle(unref(isLoading) ? null : { display: "none" })}" aria-hidden="true"></i><span style="${ssrRenderStyle(!unref(isLoading) ? null : { display: "none" })}">Next</span></button></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/onboarding/account.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=account-B6Q7qJ2u.mjs.map
