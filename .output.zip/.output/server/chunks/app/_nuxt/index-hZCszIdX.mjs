import { _ as __nuxt_component_0 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { _ as __nuxt_component_1 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_2 } from './EmptyData-RrNjecQG.mjs';
import { _ as __nuxt_component_1$1 } from './AppLoader-SkdFRsgH.mjs';
import { _ as __nuxt_component_4$1 } from './Simple-GRXlMUar.mjs';
import { _ as __nuxt_component_6 } from './DeleteModal-8TLpuLoc.mjs';
import { useSSRContext, ref, reactive, watch, provide, unref, withCtx, createVNode } from 'vue';
import { u as useRoute, n as navigateTo } from '../server.mjs';
import { ssrRenderComponent, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual, ssrRenderList, ssrInterpolate, ssrRenderClass } from 'vue/server-renderer';
import moment from 'moment';
import { Menu, MenuButton, MenuItems } from '@headlessui/vue';
import { s as sellerdoc, a as sellerdocdetails } from './requestservice-VXAE2YqE.mjs';
import debounce from 'lodash/debounce.js';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '@iconify/vue';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';
import './retry-handling-kb1itlan.mjs';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const id = ref(null);
    const open = ref(false);
    useRoute();
    const theads = [
      "campaign name",
      "cmpaign code",
      "discount value",
      "expiration",
      "status",
      ""
    ];
    const financeData = ref([]);
    const queryParams = reactive({
      SupplierId: "",
      RequestStatus: "",
      ProducerId: "",
      ProductId: "",
      Search: "",
      SortOrder: "",
      PageNumber: 1,
      PageSize: 10
    });
    const docLoading = ref(true);
    const isOpen = ref(false);
    function getFinanceData() {
      docLoading.value = true;
      sellerdoc(queryParams).then((res) => {
        docLoading.value = false;
      });
    }
    function openRequest(item) {
      sellerdocdetails(item.id).then((res) => {
        document.value = res.data.data;
        isOpen.value = true;
      });
    }
    function withdrawRequest(value) {
      id.value = value;
      open.value = true;
    }
    const document = ref({});
    const debounceSearch = debounce(() => {
      getFinanceData();
    }, 800);
    const handleDelete = () => {
    };
    watch(
      () => ({ ...queryParams }),
      () => {
        debounceSearch();
      }
    );
    provide("document", document);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderComponent = __nuxt_component_0;
      const _component_AppButton = __nuxt_component_4;
      const _component_AppIcon = __nuxt_component_1;
      const _component_EmptyData = __nuxt_component_2;
      const _component_AppLoader = __nuxt_component_1$1;
      const _component_PaginationSimple = __nuxt_component_4$1;
      const _component_DeleteModal = __nuxt_component_6;
      _push(`<!--[--><div class="gap-y-2 flex flex-col bg-white rounded-[10px] border border-[#F4F7FE] pb-10" data-v-68039cc4>`);
      _push(ssrRenderComponent(_component_HeaderComponent, {
        title: "Campaign Management",
        subtext: "Manage all marketing and sales campaign",
        btnText: "New campaign",
        btnIcon: "humbleicons:plus",
        onOnClick: ($event) => ("navigateTo" in _ctx ? _ctx.navigateTo : unref(navigateTo))("/campaign/new")
      }, null, _parent));
      _push(`<div class="pt-5" data-v-68039cc4>`);
      if (!unref(docLoading)) {
        _push(`<div data-v-68039cc4><div class="flex justify-between items-center mb-8" data-v-68039cc4><div class="flex gap-x-4 px-[30px]" data-v-68039cc4><div class="relative flex items-center" data-v-68039cc4><span class="absolute left-4 pointer-events-none text-[#667085]" data-v-68039cc4><i class="uil uil-search" data-v-68039cc4></i></span><input${ssrRenderAttr("value", unref(queryParams).Search)} placeholder="Search" class="border border-[#E7E7E7] text-sm focus:pr-3 pl-10 rounded-lg w-[280px] focus:outline-none py-[10px] transition ease-in-out duration-300" type="search" data-v-68039cc4></div><div class="flex relative items-center" data-v-68039cc4><select class="appearance-none border border-[#E7E7E7] rounded-lg w-[150px] text-sm py-[10px] px-[14px] focus:outline-matta-black/20" data-v-68039cc4><option value="" data-v-68039cc4${ssrIncludeBooleanAttr(Array.isArray(unref(queryParams).Status) ? ssrLooseContain(unref(queryParams).Status, "") : ssrLooseEqual(unref(queryParams).Status, "")) ? " selected" : ""}>Status</option><option value="0" data-v-68039cc4${ssrIncludeBooleanAttr(Array.isArray(unref(queryParams).Status) ? ssrLooseContain(unref(queryParams).Status, "0") : ssrLooseEqual(unref(queryParams).Status, "0")) ? " selected" : ""}>Pending</option><option value="1" data-v-68039cc4${ssrIncludeBooleanAttr(Array.isArray(unref(queryParams).Status) ? ssrLooseContain(unref(queryParams).Status, "1") : ssrLooseEqual(unref(queryParams).Status, "1")) ? " selected" : ""}>Completed</option></select><i class="uil uil-angle-down absolute right-2 pointer-events-none" data-v-68039cc4></i></div>`);
        _push(ssrRenderComponent(_component_AppButton, {
          onClick: ($event) => unref(queryParams).Search = unref(queryParams).Status = "",
          text: "Clear filter",
          btnClass: "text-xs text-[#98A2B3] font-normal"
        }, null, _parent));
        _push(`</div></div>`);
        if (unref(financeData).length) {
          _push(`<div data-v-68039cc4><table class="w-full" data-v-68039cc4><thead data-v-68039cc4><tr data-v-68039cc4><!--[-->`);
          ssrRenderList(theads, (item) => {
            _push(`<th class="capitalize text-[#475467] text-sm text-left font-medium border-t border-b py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-68039cc4>${ssrInterpolate(item)}</th>`);
          });
          _push(`<!--]--></tr></thead><tbody data-v-68039cc4><!--[-->`);
          ssrRenderList(unref(financeData), (item) => {
            _push(`<tr data-v-68039cc4><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-68039cc4><div class="flex items-center" data-v-68039cc4><span class="${ssrRenderClass(item.status == 3 ? "opacity-25" : "")}" data-v-68039cc4><span class="text-sm font-medium" data-v-68039cc4>${ssrInterpolate(item.productName)}</span><br data-v-68039cc4><span class="text-xs font-normal" data-v-68039cc4>${ssrInterpolate(item.producer)}</span></span></div></td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap max-w-[260px] truncate"])}" data-v-68039cc4>${ssrInterpolate(item.type)}</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-68039cc4>${ssrInterpolate(unref(moment)(item.created).format("l"))}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-68039cc4>`);
            if (item.requestStatus == 0) {
              _push(`<span class="px-[6px] py-[2px] text-xs rounded-full text-[#5925DC] border border-[#D9D6FE] bg-[#F4F3FF] flex gap-x-1 items-center max-w-max" data-v-68039cc4>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` New</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 1) {
              _push(`<span class="px-[6px] py-1 text-xs rounded-full border border-pink-100 bg-pink-50 text-pink-500 flex gap-x-1 items-center max-w-max" data-v-68039cc4>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` In progress</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 2) {
              _push(`<span class="px-[6px] py-1 text-xs rounded-full text-[#17B26A] border border-[#ABEFC6] bg-[#ECFDF3] flex gap-x-1 items-center max-w-max" data-v-68039cc4>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` Shipped</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 3) {
              _push(`<span class="px-[6px] py-1 text-xs rounded-lg text-[#17B26A] border border-[#ABEFC6] bg-[#ECFDF3] flex gap-x-1 items-center max-w-max" data-v-68039cc4>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` Completed</span>`);
            } else {
              _push(`<!---->`);
            }
            _push(`</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-68039cc4>`);
            _push(ssrRenderComponent(unref(Menu), {
              class: "relative",
              as: "div"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(ssrRenderComponent(unref(MenuButton), {
                    id: `${item.productName}+option`,
                    class: "outline-none"
                  }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<i class="uil uil-ellipsis-v" data-v-68039cc4${_scopeId2}></i>`);
                      } else {
                        return [
                          createVNode("i", { class: "uil uil-ellipsis-v" })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                  _push2(ssrRenderComponent(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[180px] rounded-xl overflow-hidden" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<div class="py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap" data-v-68039cc4${_scopeId2}> View transaction </div><div class="py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap" data-v-68039cc4${_scopeId2}> Edit campaign </div><div class="py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap" data-v-68039cc4${_scopeId2}> Delete campaign </div><div class="py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap" data-v-68039cc4${_scopeId2}> Activate campaign </div><div class="py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap" data-v-68039cc4${_scopeId2}> Deactivate campaign </div>`);
                      } else {
                        return [
                          createVNode("div", {
                            class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap",
                            onClick: ($event) => openRequest(item)
                          }, " View transaction ", 8, ["onClick"]),
                          createVNode("div", {
                            onClick: _ctx.cancelRequest,
                            class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                          }, " Edit campaign ", 8, ["onClick"]),
                          createVNode("div", {
                            onClick: ($event) => withdrawRequest(item.id),
                            class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                          }, " Delete campaign ", 8, ["onClick"]),
                          createVNode("div", {
                            onClick: ($event) => withdrawRequest(item.id),
                            class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                          }, " Activate campaign ", 8, ["onClick"]),
                          createVNode("div", {
                            onClick: ($event) => withdrawRequest(item.id),
                            class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                          }, " Deactivate campaign ", 8, ["onClick"])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                } else {
                  return [
                    createVNode(unref(MenuButton), {
                      id: `${item.productName}+option`,
                      class: "outline-none"
                    }, {
                      default: withCtx(() => [
                        createVNode("i", { class: "uil uil-ellipsis-v" })
                      ]),
                      _: 2
                    }, 1032, ["id"]),
                    createVNode(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[180px] rounded-xl overflow-hidden" }, {
                      default: withCtx(() => [
                        createVNode("div", {
                          class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap",
                          onClick: ($event) => openRequest(item)
                        }, " View transaction ", 8, ["onClick"]),
                        createVNode("div", {
                          onClick: _ctx.cancelRequest,
                          class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                        }, " Edit campaign ", 8, ["onClick"]),
                        createVNode("div", {
                          onClick: ($event) => withdrawRequest(item.id),
                          class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                        }, " Delete campaign ", 8, ["onClick"]),
                        createVNode("div", {
                          onClick: ($event) => withdrawRequest(item.id),
                          class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                        }, " Activate campaign ", 8, ["onClick"]),
                        createVNode("div", {
                          onClick: ($event) => withdrawRequest(item.id),
                          class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                        }, " Deactivate campaign ", 8, ["onClick"])
                      ]),
                      _: 2
                    }, 1024)
                  ];
                }
              }),
              _: 2
            }, _parent));
            _push(`</td></tr>`);
          });
          _push(`<!--]--></tbody></table></div>`);
        } else {
          _push(ssrRenderComponent(_component_EmptyData, {
            title: "No campaign has been created",
            type: "campaign",
            btnText: "New campaign",
            btnIcon: "humbleicons:plus",
            onBtnFunction: ($event) => ("navigateTo" in _ctx ? _ctx.navigateTo : unref(navigateTo))("/campaign/new")
          }, null, _parent));
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(docLoading)) {
        _push(`<div class="text-center p-6 lg:p-8 my-20" data-v-68039cc4>`);
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(financeData).length) {
        _push(`<div class="p-5" data-v-68039cc4>`);
        _push(ssrRenderComponent(_component_PaginationSimple, {
          total: unref(queryParams).totalCount,
          current: unref(queryParams).PageNumber,
          "per-page": unref(queryParams).PageSize,
          pageRange: 5,
          onPageChanged: ($event) => unref(queryParams).PageNumber = $event
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_DeleteModal, {
        onDeleteItem: handleDelete,
        onClose: ($event) => open.value = false,
        title: "Delete campaign",
        text: "Are you sure you want to withdraw this application? This action cannot be undone.",
        open: unref(open),
        btnText: "Delete campaign"
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/campaign/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-68039cc4"]]);

export { index as default };
//# sourceMappingURL=index-hZCszIdX.mjs.map
