import { t as store, v as get, r as urls, q as post } from '../server.mjs';

const config = {
  headers: { Authorization: `Bearer ${store.getters.accessToken}` }
};
const getWalletDetails = () => {
  return get(`${urls.GET_WALLET_DETAILS}`, config);
};
const verifyPin = (data) => {
  return get(`${urls.VALIDATE_OTP}?code=${data}`, config);
};
const getBeneficiaries = ({
  discontinued,
  Search,
  PageNumber,
  PageSize
}) => {
  return post(
    `${urls.GET_BENEFICIARIES}?Search=${Search}&discontinued=${discontinued}&?PageNumber=${PageNumber}&PageSize=${PageSize}`,
    {},
    config
  );
};
const removeBeneficiary = (data) => {
  return post(`${urls.REMOVE_BENEFICIARY}`, data, config);
};

export { getBeneficiaries as a, getWalletDetails as g, removeBeneficiary as r, verifyPin as v };
//# sourceMappingURL=walletservice-pesZWM8C.mjs.map
