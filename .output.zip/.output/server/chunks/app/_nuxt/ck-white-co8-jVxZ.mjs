const _imports_0 = "data:image/svg+xml,%3csvg%20width='10'%20height='8'%20viewBox='0%200%2010%208'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M1.5%204L4%206.5L9%201.5'%20stroke='white'%20stroke-width='1.2'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3c/svg%3e";

export { _imports_0 as _ };
//# sourceMappingURL=ck-white-co8-jVxZ.mjs.map
