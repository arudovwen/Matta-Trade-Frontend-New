import { reactive, ref, mergeProps, unref, useSSRContext } from 'vue';
import { u as useRoute } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderClass, ssrRenderList, ssrInterpolate, ssrRenderDynamicModel, ssrRenderComponent, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import { EyeIcon, EyeSlashIcon } from '@heroicons/vue/24/outline';
import useVuelidate from '@vuelidate/core';
import { required, maxLength, helpers, minLength } from '@vuelidate/validators';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main = {
  __name: "[id]",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const form = reactive({
      firstName: "",
      password: "",
      lastName: "",
      confirmPassword: "",
      invitationId: Number(route.params.id)
    });
    const isLoading = ref(false);
    const validPassword = (value) => {
      let res = /[a-z]/.test(value) && /[A-Z]/.test(value) && /[0-9]/.test(value);
      return res;
    };
    const specialPassword = (value) => {
      let res = /[@&!%#$%]/.test(value);
      return res;
    };
    const samePassword = (value) => value === form.password;
    const rules = {
      firstName: {
        required,
        maxLength: maxLength(50)
      },
      lastName: {
        required,
        maxLength: maxLength(50)
      },
      password: {
        required: helpers.withMessage("Password field cannot be empty", required),
        minLength: minLength(8),
        maxLength: maxLength(24),
        validPassword: helpers.withMessage(
          "Password must include UPPER/lowercase characters and number",
          validPassword
        ),
        specialPassword: helpers.withMessage(
          "Password must contain at least 1 of the special  characters @&!-%#$%",
          specialPassword
        )
      },
      confirmPassword: {
        required: helpers.withMessage(
          "Confirm Password field cannot be empty",
          required
        ),
        minLength: minLength(8),
        maxLength: maxLength(24),
        validPassword: helpers.withMessage(
          "Confirm Password is invalid",
          validPassword
        ),
        samePassword: helpers.withMessage("Passwords do not match!", samePassword)
      }
    };
    ref(false);
    const v$ = useVuelidate(rules, form);
    const isShowingPasword = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-full h-full grid items-center" }, _attrs))}><div><h1 class="font-semibold text-3xl md:text-[36px] text-matta-black text-left mb-10"> Create your account! </h1><form><div class="grid grid-cols-2 gap-x-4"><div class="mb-6"><label for="firstName" class="mb-2 font-normal text-xs block">First name</label><input id="firstName" name="firstName"${ssrRenderAttr("value", unref(v$).firstName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).firstName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}"><!--[-->`);
      ssrRenderList(unref(v$).firstName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label for="lastName" class="mb-2 font-normal text-xs block">Last name</label><input name="lastName" id="lastName"${ssrRenderAttr("value", unref(v$).lastName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).lastName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}"><!--[-->`);
      ssrRenderList(unref(v$).lastName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="mb-6"><label for="password" class="mb-2 font-normal text-xs block text-matta-black">Password</label><div class="relative flex items-center"><input${ssrRenderDynamicModel(!unref(isShowingPasword) ? "password" : "text", unref(v$).password.$model, null)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).password.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Password" autocomplete="off" name="password"${ssrRenderAttr("type", !unref(isShowingPasword) ? "password" : "text")}>`);
      if (!unref(isShowingPasword)) {
        _push(ssrRenderComponent(unref(EyeIcon), {
          onClick: ($event) => isShowingPasword.value = !unref(isShowingPasword),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      } else {
        _push(ssrRenderComponent(unref(EyeSlashIcon), {
          onClick: ($event) => isShowingPasword.value = !unref(isShowingPasword),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      }
      _push(`</div><!--[-->`);
      ssrRenderList(unref(v$).password.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-12"><label class="mb-2 font-normal text-xs block text-matta-black">Confirm Password</label><div class="relative flex items-center"><input${ssrRenderDynamicModel(!unref(isShowingPasword) ? "password" : "text", unref(v$).confirmPassword.$model, null)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).confirmPassword.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Password" autocomplete="off"${ssrRenderAttr("type", !unref(isShowingPasword) ? "password" : "text")}>`);
      if (!unref(isShowingPasword)) {
        _push(ssrRenderComponent(unref(EyeIcon), {
          onClick: ($event) => isShowingPasword.value = !unref(isShowingPasword),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      } else {
        _push(ssrRenderComponent(unref(EyeSlashIcon), {
          onClick: ($event) => isShowingPasword.value = !unref(isShowingPasword),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      }
      _push(`</div><!--[-->`);
      ssrRenderList(unref(v$).confirmPassword.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="flex flex-col lg:flex-row justify-between items-center gap-x-4 gap-y-4 lg-gap-y-0"><button${ssrIncludeBooleanAttr(unref(v$).$silentErrors.length || unref(isLoading)) ? " disabled" : ""} class="${ssrRenderClass([{
        "opacity-70 cursor-not-allowed": unref(v$).$silentErrors.length || unref(isLoading)
      }, "border text-base border-primary-500 uppercase text-white w-full bg-primary-500 text-center rounded-lg px-6 py-2 hover:bg-primary-500/80 h-11 leading-[normal]"])}">`);
      if (unref(isLoading)) {
        _push(`<span>Signing up `);
        if (unref(isLoading)) {
          _push(`<i class="fa fa-spinner fa-spin text-white" aria-hidden="true"></i>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</span>`);
      } else {
        _push(`<span> Sign up</span>`);
      }
      _push(`</button></div></form></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/auth/invited-user/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_id_-gcurGxaa.mjs.map
