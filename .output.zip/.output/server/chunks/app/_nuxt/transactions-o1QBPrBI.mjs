import { _ as __nuxt_component_0$1 } from './index-4NCxcAqd.mjs';
import { _ as __nuxt_component_1 } from './AppLoader-SkdFRsgH.mjs';
import { useSSRContext, ref, reactive, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderClass, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { useRoute } from 'vue-router';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '../server.mjs';
import 'unhead';
import '@unhead/shared';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$1 = {
  __name: "TransactionPage",
  __ssrInlineRender: true,
  setup(__props) {
    useRoute();
    const type = ref("1");
    const theads = [
      "date",
      "transaction ID",
      "amount",
      "Payment method",
      "type",
      "merchant",
      "description"
    ];
    const tdata = [];
    const isEmpty = ref(true);
    const isPageLoading = ref(false);
    reactive({
      Status: "",
      Role: "",
      PageSize: 10,
      PageNumber: 1,
      pagecount: 0,
      totalCount: 0,
      Search: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Breadcrumbs = __nuxt_component_0$1;
      const _component_AppLoader = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "gap-y-2 flex flex-col" }, _attrs))} data-v-943b589f><div class="p-6 lg:p-8 bg-white rounded-lg" data-v-943b589f><div class="mb-12" data-v-943b589f>`);
      _push(ssrRenderComponent(_component_Breadcrumbs, null, null, _parent));
      _push(`</div><div class="grid justify-between items-end mb-8" data-v-943b589f><div data-v-943b589f><h1 class="text-3xl lg:text-[48px] lg:leading-[56px] text-matta-black col-span-1 font-medium capitalize mb-4" data-v-943b589f> Transactions </h1><p class="text-sm lg:text-base" data-v-943b589f> Manage your wallet transactions here. </p></div><div data-v-943b589f></div></div><div class="flex justify-end gap-4" data-v-943b589f><button class="${ssrRenderClass([
        type.value === "1" ? "bg-matta-black text-white" : "text-matta-black",
        "border border-matta-black py-3 text-xs md:text-[13px] px-6 flex justify-center rounded-lg items-center hover:bg-matta-black/80 uppercase font-normal leading-[normal] gap-x-1"
      ])}" data-v-943b589f> Credit </button><button class="${ssrRenderClass([
        type.value === "2" ? "bg-matta-black text-white" : "text-matta-black",
        "border border-matta-black py-3 text-xs md:text-[13px] px-6 flex justify-center rounded-lg items-center hover:bg-matta-black/80 uppercase font-normal leading-[normal] gap-x-1"
      ])}" data-v-943b589f> Debit </button></div></div><div class="p-6 lg:p-8 bg-white rounded-lg" data-v-943b589f>`);
      if (!isPageLoading.value) {
        _push(`<div data-v-943b589f>`);
        if (!isEmpty.value) {
          _push(`<div class="max-w-[80vw]" data-v-943b589f><table class="w-full" data-v-943b589f><thead data-v-943b589f><tr data-v-943b589f><!--[-->`);
          ssrRenderList(theads, (item) => {
            _push(`<th class="uppercase text-[#B6B7B9] text-[13px] text-left font-normal border-b py-6 px-3 border-[#E7EBEE]" data-v-943b589f>${ssrInterpolate(item)}</th>`);
          });
          _push(`<!--]--></tr></thead><tbody data-v-943b589f><!--[-->`);
          ssrRenderList(tdata, (item) => {
            _push(`<tr data-v-943b589f><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-943b589f></td><td class="text-matta-black text-sm font-normal border-b py-6 px-3 border-[#E7EBEE]" data-v-943b589f>${ssrInterpolate(item.email)}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-943b589f></td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-943b589f>`);
            if (item.invitationStatusText == "Expired") {
              _push(`<span class="px-2 py-2 text-xs rounded-lg border text-[#EE5C5C] border-[#EE5C5C]" data-v-943b589f>${ssrInterpolate(item.invitationStatusText)}</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.invitationStatusText == "Invited") {
              _push(`<span class="px-2 py-2 text-xs rounded-lg border text-primary border-primary" data-v-943b589f>${ssrInterpolate(item.invitationStatusText)}</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.invitationStatusText == "Verified") {
              _push(`<span class="px-2 py-2 text-xs rounded-lg text-white bg-[#59B221]" data-v-943b589f> Verified</span>`);
            } else {
              _push(`<!---->`);
            }
            _push(`</td></tr>`);
          });
          _push(`<!--]--></tbody></table></div>`);
        } else {
          _push(`<div class="h-[310px] rounded-lg w-full flex items-center justify-center bg-[#F1F3F5]" data-v-943b589f><div class="text-center max-w-sm mx-auto" data-v-943b589f><p class="text-matta-black font-medium" data-v-943b589f>No transaction available</p></div></div>`);
        }
        _push(`</div>`);
      } else {
        _push(`<div class="text-center p-6 lg:p-8 my-24" data-v-943b589f>`);
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
        _push(`</div>`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/wallet/TransactionPage.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-943b589f"]]);
const _sfc_main = {
  __name: "transactions",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierWalletTransactionPage = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierWalletTransactionPage, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/wallet/transactions.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=transactions-o1QBPrBI.mjs.map
