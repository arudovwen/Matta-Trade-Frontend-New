import { _ as __nuxt_component_1 } from './index-eSH9oSpY.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-fc3HHrvA.mjs';
import { ref, mergeProps, unref, isRef, withCtx, createTextVNode, useSSRContext } from 'vue';
import { a as useHead, u as useRoute, e as useRouter } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { useForm } from 'vee-validate';
import * as yup from 'yup';
import { toast } from 'vue3-toastify';
import { a as resetPassword } from './authservices-pXd32gsl.mjs';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './_plugin-vue_export-helper-yVxbj29m.mjs';
import '../../rollup/_vue.mjs';
import 'cleave.js';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main = {
  __name: "reset-password",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Reset password | Matta"
    });
    const isLoading = ref(false);
    const route = useRoute();
    const router = useRouter();
    const formValues = {
      confirmPassword: "",
      password: "",
      token: route.query.code,
      email: route.query.email
    };
    const schema = yup.object({
      password: yup.string().required("Password is required").min(8, "Password must be at least 8 characters").matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
        "Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character"
      ),
      confirmPassword: yup.string().required("Confirm Password is required").oneOf([yup.ref("password"), null], "Passwords must match")
    });
    const { handleSubmit, defineField, errors } = useForm({
      validationSchema: schema,
      initialValues: formValues
    });
    const [password, passwordAtt] = defineField("password");
    const [confirmPassword, confirmPasswordAtt] = defineField("confirmPassword");
    handleSubmit((values) => {
      isLoading.value = true;
      resetPassword(values).then((res) => {
        if (res.status === 200) {
          toast.success("Password Reset successful");
          router.push("/auth/login");
        }
      }).catch((err) => {
        isLoading.value = false;
        if (err.response.data.message || err.response.data.Message) {
          toast.error(err.response.data.message || err.response.data.Message);
        }
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Textinput = __nuxt_component_1;
      const _component_AppButton = __nuxt_component_4;
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "pt-0 lg:pt-0 w-full max-w-[500px] mx-auto grid flex-1 items-center" }, _attrs))}><div><h1 class="text-[#333] darks:text-white mb-[10px] text-[28px] font-bold"> Reset Password </h1><p class="mb-[25px] text-sm text-[#666] darks:text-white/80"> Enter the email associated with your account and we\u201Dll send you instructions to reset your password </p><form><div class="mb-5">`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        hasicon: "",
        placeholder: "",
        label: "New Password",
        type: "password",
        modelValue: unref(password),
        "onUpdate:modelValue": ($event) => isRef(password) ? password.value = $event : null
      }, unref(passwordAtt), {
        error: unref(errors).password
      }), null, _parent));
      _push(`</div><div class="mb-6">`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        hasicon: "",
        placeholder: "",
        label: "Confirm Password",
        type: "password",
        modelValue: unref(confirmPassword),
        "onUpdate:modelValue": ($event) => isRef(confirmPassword) ? confirmPassword.value = $event : null
      }, unref(confirmPasswordAtt), {
        error: unref(errors).confirmPassword
      }), null, _parent));
      _push(`</div><div class="grid gap-y-[22px] mb-9">`);
      _push(ssrRenderComponent(_component_AppButton, {
        type: "submit",
        isLoading: unref(isLoading),
        isDisabled: unref(isLoading),
        text: "Submit",
        btnClass: "btn-primary !py-3"
      }, null, _parent));
      _push(`</div><span class="flex items-center text-center text-sm text-[#333] darks:text-white/80 gap-x-1 justify-center"> Have an account? `);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/auth/login",
        class: "font-semibold text-[#2176FF]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Sign in`);
          } else {
            return [
              createTextVNode("Sign in")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</span></form></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/auth/reset-password.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=reset-password-V8wJzv-6.mjs.map
