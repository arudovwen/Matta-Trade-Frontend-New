import { k as defineStore, w as persistedState, x as useCookie, d as useAuthStore } from '../server.mjs';
import { ref, computed } from 'vue';
import { g as getcart, u as updatecart, a as createcart, r as removecartitem } from './cartservice-JuOkMZ9e.mjs';
import { toast } from 'vue3-toastify';

const useCartStore = defineStore(
  "cart",
  () => {
    const cookie = useCookie("cart");
    const authStore = useAuthStore();
    const cartItems = ref([]);
    const tax = ref(0);
    const cart = computed(() => {
      var _a;
      return (_a = cookie == null ? void 0 : cookie.value) == null ? void 0 : _a.cartItems;
    });
    const cartTotal = computed(() => {
      var _a;
      return (_a = cookie == null ? void 0 : cookie.value) == null ? void 0 : _a.cartItems.length;
    });
    const cartTotalAmount = computed(
      () => {
        var _a;
        return (_a = cookie == null ? void 0 : cookie.value) == null ? void 0 : _a.cartItems.map((item) => item.packagePrice * item.quantity).reduce((a, b) => Number(a) + Number(b), 0);
      }
    );
    function getMyCart() {
      getcart().then((res) => {
        if (res.status === 200) {
          setCart(res.data.data.items);
          setTax(res.data.data.tax);
        }
      });
    }
    function setTax(data) {
      tax.value = data;
    }
    const setCart = (data) => {
      cartItems.value = data;
    };
    async function addToCart(item, type) {
      var _a, _b, _c, _d, _e, _f;
      if (((_a = cookie == null ? void 0 : cookie.value) == null ? void 0 : _a.cartItems.some(
        (ct) => ct.productId === item.productId
      )) && ((_b = cookie == null ? void 0 : cookie.value) == null ? void 0 : _b.cartItems.some((ct) => ct.packageId === item.packageId))) {
        return { status: false, message: "incart" };
      }
      if (!authStore.isLoggedIn) {
        setCart([...(_c = cookie == null ? void 0 : cookie.value) == null ? void 0 : _c.cartItems, item]);
        return { status: true, message: type };
      }
      const cartOperation = cartTotal.value ? updateCartAsync : createCartAsync;
      try {
        const res = await cartOperation(item);
        if (res.status == 200) {
          getMyCart();
          setCart([...(_d = cookie == null ? void 0 : cookie.value) == null ? void 0 : _d.cartItems, item]);
          return { status: true, message: type };
        }
      } catch (error) {
        toast.error((_f = (_e = error == null ? void 0 : error.response) == null ? void 0 : _e.data) == null ? void 0 : _f.Message);
        return { status: false, message: "Error adding to cart" };
      }
    }
    async function updateCartAsync(item) {
      return await updatecart(item);
    }
    function updateCart(item) {
      var _a;
      if (authStore.isLoggedIn) {
        updatecart(item).then((res) => {
          var _a2;
          if (res.status === 200) {
            const tempCart = (_a2 = cookie == null ? void 0 : cookie.value) == null ? void 0 : _a2.cartItems.map((dt) => {
              if (item.id === dt.id) {
                dt.quantity = item.quantity;
              }
              return dt;
            });
            setCart(tempCart);
          }
        });
      } else {
        const tempCart = (_a = cookie == null ? void 0 : cookie.value) == null ? void 0 : _a.cartItems.map((dt) => {
          if (item.id === dt.id) {
            dt.quantity = item.quantity;
          }
          return dt;
        });
        setCart(tempCart);
      }
    }
    async function createCartAsync(item) {
      return await createcart({ items: [item] });
    }
    function removeFromCart(id) {
      var _a;
      if (authStore.isLoggedIn) {
        removecartitem(id).then((res) => {
          var _a2;
          if (res.status === 200) {
            const tempCart = (_a2 = cookie == null ? void 0 : cookie.value) == null ? void 0 : _a2.cartItems.filter(
              (item) => item.id !== id
            );
            setCart(tempCart);
          }
        });
      } else {
        const tempCart = (_a = cookie == null ? void 0 : cookie.value) == null ? void 0 : _a.cartItems.filter(
          (item) => item.id !== id
        );
        setCart(tempCart);
      }
    }
    function clearCart() {
      setCart([]);
    }
    return {
      tax,
      cart,
      setCart,
      getMyCart,
      addToCart,
      clearCart,
      removeFromCart,
      cartTotalAmount,
      cartTotal,
      setTax,
      updateCart,
      cartItems
    };
  },
  {
    persist: {
      storage: persistedState.cookiesWithOptions({
        sameSite: "strict"
      })
    }
  }
);

export { useCartStore as u };
//# sourceMappingURL=cart-fg4oswtQ.mjs.map
