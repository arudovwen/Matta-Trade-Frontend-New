import { _ as __nuxt_component_0, a as __nuxt_component_1$1 } from './AppFooter-UymqQBAh.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-fc3HHrvA.mjs';
import { _ as __nuxt_component_1$2 } from './AppIcon-D3CPABPP.mjs';
import { ref, provide, mergeProps, useSSRContext, reactive, computed, unref, withCtx, createVNode, toDisplayString } from 'vue';
import { x as useCookie, d as useAuthStore, e as useRouter, _ as __nuxt_component_0$2 } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { useRoute } from 'vue-router';
import { u as useCartStore } from './cart-fg4oswtQ.mjs';
import './client-only-uY1C8Tgt.mjs';
import './nuxt-img-qJohECzX.mjs';
import './AppButton-rwP1M0KN.mjs';
import './_plugin-vue_export-helper-yVxbj29m.mjs';
import './data-ZuhAAsy0.mjs';
import '@headlessui/vue';
import './authservices-pXd32gsl.mjs';
import './Center-HbcRsv6_.mjs';
import './IndexModal-vEF7RYpX.mjs';
import '@heroicons/vue/24/solid';
import '@vuelidate/core';
import '@vuelidate/validators';
import 'vue3-toastify';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';
import './cartservice-JuOkMZ9e.mjs';
import './retry-handling-kb1itlan.mjs';

const _sfc_main$2 = {
  __name: "SideComponent",
  __ssrInlineRender: true,
  setup(__props) {
    const formValues = reactive({
      storeUrl: ""
    });
    const authstore = useAuthStore();
    const navigation = [
      {
        name: "Dashboard",
        url: "/overview",
        icon: "mingcute:layout-3-line",
        key: "overview"
      },
      {
        name: "Profile",
        url: "/account/settings",
        icon: "lucide:user",
        key: "account"
      },
      {
        name: "My Orders",
        url: "/procurement/my-orders",
        icon: "lucide:shopping-bag",
        key: "my-orders"
      },
      {
        name: "My Requests",
        url: "/procurement/my-requests",
        icon: "ri:hand-coin-line",
        key: "my-requests"
      },
      {
        name: "Shipping Addresses",
        url: "/procurement/shipping-addresses",
        icon: "ion:map-outline",
        key: "shipping"
      },
      {
        name: "Wallet",
        url: "/wallet/home",
        icon: "ion:wallet-outline",
        key: "wallet"
      },
      {
        name: "Financing requests",
        url: "/financing",
        icon: "f7:tag",
        key: "financing"
      },
      {
        name: "Saved items",
        url: "/account/saved-searches",
        icon: "tdesign:heart",
        key: "saved"
      },
      {
        name: "Storefront",
        url: "/tech-store",
        icon: "solar:shop-outline",
        key: "storefront"
      },
      {
        name: "Company Settings",
        url: "/company/settings",
        icon: "mingcute:building-5-line",
        key: "company"
      },
      {
        name: "Company Customization",
        url: "/company/customization",
        icon: "mingcute:building-5-line",
        key: "company"
      },
      {
        name: "User Management",
        url: "/user-management",
        icon: "lucide:users",
        key: "user"
      },
      {
        name: "Products",
        url: "/storefront/products",
        icon: "fluent-mdl2:product-variant",
        key: "products"
      }
    ];
    const mappedNav = computed(() => {
      return navigation.map((i) => {
        return {
          ...i,
          url: i.key === "storefront" ? `/${formValues.storeSlug}` : i.url
        };
      });
    });
    ref([
      "Company",
      "Procurement",
      "My Account",
      "Storefront",
      "Wallet"
    ]);
    computed(() => {
      return authstore.userType;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_AppIcon = __nuxt_component_1$2;
      _push(`<aside${ssrRenderAttrs(mergeProps({ class: "flex flex-col min-w-[245px]" }, _attrs))}><nav class="bg-white py-[11px] rounded-[10px] border border-[#F4F7FE] shadow-[0px_2px_4px_0px_rgba(0,0,0,0.04)]"><ul><!--[-->`);
      ssrRenderList(unref(mappedNav), (item) => {
        _push(`<li>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: item.url,
          class: "text-sm flex items-center px-5 border-r-[3px] border-transparent",
          activeClass: "!border-primary-500 bg-[#2270FA0F] text-primary-500 block"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="flex items-center gap-x-[10px] flex-1 py-[9px]"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_AppIcon, {
                icon: item.icon,
                iconClass: "text-xl"
              }, null, _parent2, _scopeId));
              _push2(`<span${_scopeId}>${ssrInterpolate(item.name)}</span></span>`);
            } else {
              return [
                createVNode("span", { class: "flex items-center gap-x-[10px] flex-1 py-[9px]" }, [
                  createVNode(_component_AppIcon, {
                    icon: item.icon,
                    iconClass: "text-xl"
                  }, null, 8, ["icon"]),
                  createVNode("span", null, toDisplayString(item.name), 1)
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul></nav></aside>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Dashboard/layout/SideComponent.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "MainComponent",
  __ssrInlineRender: true,
  setup(__props) {
    const store = useAuthStore();
    const route = useRoute();
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_NuxtPage = __nuxt_component_0$2;
      _push(`<section${ssrRenderAttrs(mergeProps({
        class: "flex flex-col overflow-y-auto no-scrollbar",
        style: { height: "calc(100vh - 115px)" }
      }, _attrs))}>`);
      if (unref(route).name !== "company settings" && ((_a = unref(store).userInfo) == null ? void 0 : _a.accountType) == 1) {
        _push(`<div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_NuxtPage, null, null, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Dashboard/layout/MainComponent.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$1;
const _sfc_main = {
  __name: "dashboard",
  __ssrInlineRender: true,
  setup(__props) {
    var _a;
    const cookie = useCookie("cart");
    useAuthStore();
    useCartStore();
    (_a = cookie == null ? void 0 : cookie.value) == null ? void 0 : _a.cartItems;
    const company = ref(null);
    useRouter();
    provide("company", company);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppHeader = __nuxt_component_0;
      const _component_DashboardLayoutSideComponent = __nuxt_component_1;
      const _component_DashboardLayoutMainComponent = __nuxt_component_2;
      const _component_AppFooter = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col gap-y-7 bg-[#F9FAFB] pb-2" }, _attrs))}><div>`);
      _push(ssrRenderComponent(_component_AppHeader, null, null, _parent));
      _push(`</div><div class="flex gap-x-4 flex-1 container"><div class="hidden lg:inline-flex h-full">`);
      _push(ssrRenderComponent(_component_DashboardLayoutSideComponent, null, null, _parent));
      _push(`</div><div class="flex-1 h-full">`);
      _push(ssrRenderComponent(_component_DashboardLayoutMainComponent, null, null, _parent));
      _push(`</div></div><div>`);
      _push(ssrRenderComponent(_component_AppFooter, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=dashboard-riGVYj8t.mjs.map
