import { _ as __nuxt_component_1 } from './nuxt-img-qJohECzX.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { a as useHead } from '../server.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './_plugin-vue_export-helper-yVxbj29m.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main = {
  __name: "order-success",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Order success | Matta"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtImg = __nuxt_component_1;
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "items-center flex justify-center h-[85vh] w-screen p-6" }, _attrs))}><div class="bg-white rounded-[10px] p-5 md:p-9 text-center max-w-[500px]">`);
      _push(ssrRenderComponent(_component_NuxtImg, {
        src: "/images/success.png",
        class: "mx-auto mb-[10px]",
        alt: "success"
      }, null, _parent));
      _push(`<h1 class="text-2xl mb-[27px] font-bold">Order Successful</h1><p class="mb-8 md:mb-10 text-sm text-[#444] leading-[21px]"> Your order will be processed as soon as possible. Your order no is <span class="font-medium text-[#333]">1234569504</span>. You will receive an email shortly with the invoice for your order. </p><div class="flex flex-col md:flex-row gap-y-4 md:gap-y-0 md:gap-x-[14px]">`);
      _push(ssrRenderComponent(_component_AppButton, {
        link: "/overview",
        text: "Proceed to dashboard",
        btnClass: "text-[#2176FF] bg-[#165EF014] w-full !text-sm !font-normal !py-3"
      }, null, _parent));
      _push(ssrRenderComponent(_component_AppButton, {
        link: "/market/all products",
        text: "Continue shopping",
        btnClass: "bg-[#2176FF] text-white w-full !text-sm !font-normal !py-3"
      }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/order-success.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=order-success-XT8A9Di3.mjs.map
