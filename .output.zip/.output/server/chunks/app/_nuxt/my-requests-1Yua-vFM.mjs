import { _ as __nuxt_component_0$2 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_1$4 } from './AppTab-6UxOW17N.mjs';
import { _ as __nuxt_component_0$1 } from './CustomSelect-4D7PaUUe.mjs';
import { _ as __nuxt_component_1$3 } from './AppIcon-D3CPABPP.mjs';
import { useSSRContext, ref, inject, unref, mergeProps, reactive, watch, provide, withCtx, createVNode, createTextVNode, openBlock, createBlock, createCommentVNode, toDisplayString } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderClass, ssrRenderAttr, ssrRenderList } from 'vue/server-renderer';
import { _ as __nuxt_component_2$1 } from './EmptyData-RrNjecQG.mjs';
import { _ as __nuxt_component_1$1 } from './AppLoader-SkdFRsgH.mjs';
import { _ as __nuxt_component_4$1 } from './Simple-GRXlMUar.mjs';
import { _ as __nuxt_component_5$3 } from './SideModal-MJCox7bt.mjs';
import moment from 'moment';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import { Menu, MenuButton, MenuItems } from '@headlessui/vue';
import { p as procurementrequestdetails, a as procurementrequests } from './procurementservice-j_HRfk2m.mjs';
import debounce from 'lodash/debounce.js';
import { _ as __nuxt_component_1$2 } from './nuxt-img-qJohECzX.mjs';
import { d as docdetails, b as buyerdoc } from './requestservice-VXAE2YqE.mjs';
import { s as sellerquotedetail, b as buyerquotes } from './quoteservice-5V3YxrdU.mjs';
import { A as getproductrequests } from '../server.mjs';
import { _ as __nuxt_component_0$3 } from './IndexModal-vEF7RYpX.mjs';
import { useRoute } from 'vue-router';
import './AppButton-rwP1M0KN.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '@heroicons/vue/24/solid';
import '@iconify/vue';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './retry-handling-kb1itlan.mjs';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$a = {
  __name: "AppStatusButton",
  __ssrInlineRender: true,
  props: ["status"],
  setup(__props) {
    const StatusClass = {
      0: "text-[#F79009] bg-[#FFFAEB] border-[#FEDF89]",
      1: "text-[#F79009] bg-[#FFFAEB] border-[#FEDF89]",
      2: "text-[#5925DC] bg-[#F4F3FF] border-[#D9D6FE]",
      3: "text-[#067647] bg-[#ECFDF3] border-[#ABEFC6]",
      4: "text-[#B42318] bg-[#FEF3F2] border-[#FECDCA]",
      5: "text-[#B42318] bg-[#FEF3F2] border-[#FECDCA]"
    };
    const StatusText = {
      0: "Pending",
      1: "In progress",
      2: "Shipped",
      3: "Completed",
      4: "Rejected",
      5: "Suspended"
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1$3;
      _push(`<span${ssrRenderAttrs(mergeProps({
        class: `px-[6px] py-1 text-xs rounded-full flex gap-x-1 items-center border max-w-max font-semibold ${StatusClass[__props.status]}`
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
      _push(`<span class="">${ssrInterpolate(StatusText[__props.status])}</span></span>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/AppStatusButton.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$a;
const _sfc_main$9 = {
  __name: "RequestComponent",
  __ssrInlineRender: true,
  setup(__props) {
    const stage = ref(1);
    const request = inject("request");
    return (_ctx, _push, _parent, _attrs) => {
      if (unref(request)) {
        _push(`<section${ssrRenderAttrs(mergeProps({ class: "flex flex-col gap-y-8" }, _attrs))} data-v-105a6924><div class="flex items-center" data-v-105a6924><span class="mr-3 h-10 w-10 rounded-lg flex items-center justify-center border border-[#E7EBEE] p-2" data-v-105a6924></span><span data-v-105a6924><span class="text-xs font-medium" data-v-105a6924>${ssrInterpolate(unref(request).productName)}</span><br data-v-105a6924><span class="text-xs font-normal" data-v-105a6924>${ssrInterpolate(unref(request).producer)}</span></span></div><div class="grid grid-cols-2 gap-y-8 gap-x-4 mb-8" data-v-105a6924><div data-v-105a6924><p class="text-[12px] text-[#98A2B3] mb-1 capitalize" data-v-105a6924>Status</p>`);
        if (unref(request).requestStatus == 0) {
          _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#E0F7B0]" data-v-105a6924> New</span>`);
        } else {
          _push(`<!---->`);
        }
        if (unref(request).requestStatus == 1) {
          _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#FDD0AF]" data-v-105a6924> In progress</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><div data-v-105a6924><p class="text-[12px] text-[#98A2B3] mb-1 capitalize" data-v-105a6924>created</p><span class="text-xs" data-v-105a6924>${ssrInterpolate(unref(moment)(unref(request).date).format("lll"))}</span></div><div data-v-105a6924><p class="text-[12px] text-[#98A2B3] mb-1 capitalize" data-v-105a6924> number of samples </p><span class="text-xs" data-v-105a6924>${ssrInterpolate(unref(request).numberofSamples)}</span></div><div data-v-105a6924><p class="text-[12px] text-[#98A2B3] mb-1 capitalize" data-v-105a6924> Expected annual usage </p><span class="text-xs" data-v-105a6924>${ssrInterpolate(unref(request).expectedAnualUsage)}</span></div></div>`);
        if (unref(request).description) {
          _push(`<div class="bg-[#F1F3F5] rounded-lg p-6 text-matta-black" data-v-105a6924><div class="" data-v-105a6924><p class="text-sm font-normal" data-v-105a6924>${ssrInterpolate(unref(request).description)}</p></div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="border border-[#D0D5DD] rounded-lg px-6 py-5 text-matta-black" data-v-105a6924><div class="flex justify-between mb-2" data-v-105a6924><h3 class="text-base font-medium" data-v-105a6924>Shipping Address</h3><span data-v-105a6924><i class="uil uil-minusext-lg" data-v-105a6924></i></span></div><div class="text-xs" data-v-105a6924><p class="text-xs font-medium mb-2" data-v-105a6924>${ssrInterpolate(unref(request).firstName)} ${ssrInterpolate(unref(request).lastName)}</p><p class="text-xs flex gap-x-2 items-center mb-2" data-v-105a6924><span data-v-105a6924>${ssrInterpolate(`${unref(request).shippingAddress.country} ${unref(request).shippingAddress.city}`)}</span><span class="h-1 w-1 rounded-full bg-[#DDDDDD]" data-v-105a6924></span><span class="max-w-[200px] truncate ..." data-v-105a6924>${ssrInterpolate(unref(request).shippingAddress.street)}</span></p><p class="text-xs flex gap-x-2 items-center mb-2" data-v-105a6924>${ssrInterpolate(unref(request).phone)}</p><p class="text-xs flex gap-x-2 items-center mb-2" data-v-105a6924>${ssrInterpolate(unref(request).email)}</p></div></div><div class="bg-[#F1F3F5] rounded-lg p-6 text-matta-black" data-v-105a6924><div class="flex justify-between mb-6" data-v-105a6924><h3 class="text-lg font-medium" data-v-105a6924>Timeline</h3><span data-v-105a6924><i class="uil uil-minusext-lg" data-v-105a6924></i></span></div><div class="${ssrRenderClass([unref(stage) > 1 ? "opacity-50" : "", "flex justify-start items-center gap-x-2 mb-3"])}" data-v-105a6924><span class="${ssrRenderClass([unref(stage) > 1 ? "" : " bg-primary-500 text-white", "w-[46px] h-[46px] rounded-full flex items-center justify-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black border border-[#ddd] shadow-xs"])}" data-v-105a6924><i class="uil uil-check" data-v-105a6924></i></span><span data-v-105a6924><span class="text-xs text-[#ABABAB]" data-v-105a6924>Mar 18, 13:05PM</span><br data-v-105a6924><span class="text-xs" data-v-105a6924><span data-v-105a6924>Sample request has been <span class="fomt-medium" data-v-105a6924>Completed</span>.</span></span></span></div><div class="${ssrRenderClass([unref(stage) > 2 ? "opacity-50" : "", "flex justify-start items-center gap-x-2 mb-3"])}" data-v-105a6924><span class="${ssrRenderClass([
          unref(stage) > 2 ? "" : unref(stage) == 2 ? " bg-primary-500 text-white" : unref(stage) < 2 ? "bg-white text-matta-black" : "",
          "w-[46px] h-[46px] rounded-full flex items-center justify-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black border border-[#ddd] shadow-xs"
        ])}" data-v-105a6924><i class="uil uil-map-marker" data-v-105a6924></i></span><span data-v-105a6924><span class="text-xs text-[#ABABAB]" data-v-105a6924>Mar 18, 13:05PM</span><br data-v-105a6924><span class="text-xs" data-v-105a6924><span data-v-105a6924>Sample is ready to be <span class="fomt-medium" data-v-105a6924>Shipped</span>.</span></span></span></div><div class="${ssrRenderClass([unref(stage) > 3 ? "opacity-50" : "", "flex justify-start items-center gap-x-2 mb-3"])}" data-v-105a6924><span class="${ssrRenderClass([
          unref(stage) > 3 ? "" : unref(stage) == 3 ? " bg-primary-500 text-white" : unref(stage) < 3 ? "bg-white text-matta-black" : "",
          "w-[46px] h-[46px] rounded-full flex items-center justify-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black border border-[#ddd] shadow-xs"
        ])}" data-v-105a6924><i class="uil uil-refresh" data-v-105a6924></i></span><span data-v-105a6924><span class="text-xs text-[#ABABAB]" data-v-105a6924>Mar 18, 13:05PM</span><br data-v-105a6924><span class="text-xs" data-v-105a6924><span data-v-105a6924>Status changed from <span class="font-medium" data-v-105a6924>New</span> to <span class="font-medium" data-v-105a6924>In Progress</span>.</span></span></span></div><div class="flex justify-start items-center gap-x-2" data-v-105a6924><span class="${ssrRenderClass([
          unref(stage) > 4 ? "" : unref(stage) == 4 ? " bg-primary-500 text-white" : unref(stage) < 4 ? "bg-white text-matta-black" : "",
          "w-[46px] h-[46px] rounded-full flex items-center justify-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black border border-[#ddd] shadow-xs"
        ])}" data-v-105a6924><i class="uil uil-plus" data-v-105a6924></i></span><span data-v-105a6924><span class="text-xs text-[#ABABAB]" data-v-105a6924>Mar 18, 13:05PM</span><br data-v-105a6924><span class="text-xs" data-v-105a6924><span data-v-105a6924>Sample request <span class="font-medium" data-v-105a6924>#SE554-334</span> created.</span></span></span></div></div></section>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/myrequests/RequestComponent.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["__scopeId", "data-v-105a6924"]]);
const _sfc_main$8 = {
  __name: "RequestTable",
  __ssrInlineRender: true,
  props: ["title", "canCancel"],
  setup(__props) {
    const theads = ["product", "supplier", "date requested", "status", ""];
    const request = ref({});
    const isRequestOpen = ref(false);
    const requests = ref([]);
    const requestId = ref(null);
    ref([]);
    const isOpen = ref(false);
    const products = ref([]);
    ref([]);
    const loading = ref(true);
    function handleCancel(id) {
      requestId.value = id;
      isOpen.value = true;
    }
    function openRequests(val) {
      procurementrequestdetails(val).then((res) => {
        request.value = res.data.data;
        isRequestOpen.value = true;
      });
    }
    const queryParams = reactive({
      SupplierId: "",
      RequestStatus: "",
      ProducerId: "",
      ProductId: "",
      Search: "",
      SortOrder: "",
      PageNumber: 1,
      PageSize: 10
    });
    const isLoading = ref(true);
    function getRequests() {
      isLoading.value = true;
      procurementrequests(queryParams).then((res) => {
        requests.value = res.data.data.data;
        queryParams.totalCount = res.data.data.totalCount;
        isLoading.value = false;
      });
    }
    const statusOptions = [
      {
        id: 0,
        text1: "New"
      },
      {
        id: 1,
        text1: "In Progress"
      }
    ];
    const debounceSearch = debounce(() => {
      getRequests();
    }, 800);
    watch(
      () => ({ ...queryParams }),
      () => {
        debounceSearch();
      }
    );
    provide("request", request);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormsCustomSelect = __nuxt_component_0$1;
      const _component_AppStatusButton = __nuxt_component_1;
      const _component_EmptyData = __nuxt_component_2$1;
      const _component_AppLoader = __nuxt_component_1$1;
      const _component_PaginationSimple = __nuxt_component_4$1;
      const _component_SideModal = __nuxt_component_5$3;
      const _component_SupplierMyrequestsRequestComponent = __nuxt_component_6;
      _push(`<!--[--><div class="hidden lg:flex justify-between items-center mb-8 px-5" data-v-35e300cd><div class="flex gap-x-4" data-v-35e300cd><div class="relative flex items-center" data-v-35e300cd><span class="absolute left-4 pointer-events-none text-[#667085]" data-v-35e300cd><i class="uil uil-search" data-v-35e300cd></i></span><input${ssrRenderAttr("value", unref(queryParams).Search)} placeholder="Search" class="border border-[#D0D5DD] focus:pr-3 pl-10 rounded-lg w-[280px] focus:outline-none py-[10px] transition ease-in-out duration-300" type="search" data-v-35e300cd></div><div class="" data-v-35e300cd>`);
      _push(ssrRenderComponent(_component_FormsCustomSelect, {
        placeholder: "Product",
        options: unref(products),
        modelValue: unref(queryParams).ProductId,
        "onUpdate:modelValue": ($event) => unref(queryParams).ProductId = $event,
        classStyles: "border border-[#D0D5DD] rounded-lg min-w-[180px] py-[10px] px-[14px] focus:outline-none"
      }, null, _parent));
      _push(`</div><div class="" data-v-35e300cd>`);
      _push(ssrRenderComponent(_component_FormsCustomSelect, {
        placeholder: "Producer",
        options: [],
        modelValue: unref(queryParams).Producer,
        "onUpdate:modelValue": ($event) => unref(queryParams).Producer = $event,
        classStyles: "border border-[#D0D5DD] rounded-lg min-w-[180px] py-[10px] px-[14px] focus:outline-none"
      }, null, _parent));
      _push(`</div><div class="" data-v-35e300cd>`);
      _push(ssrRenderComponent(_component_FormsCustomSelect, {
        placeholder: "Status",
        options: statusOptions,
        modelValue: unref(queryParams).RequestStatus,
        "onUpdate:modelValue": ($event) => unref(queryParams).RequestStatus = $event,
        classStyles: "border border-[#D0D5DD] rounded-lg min-w-[180px] py-[10px] px-[14px] focus:outline-none"
      }, null, _parent));
      _push(`</div></div></div>`);
      if (!unref(loading)) {
        _push(`<div data-v-35e300cd>`);
        if (unref(requests).length) {
          _push(`<div class="overflow-x-auto max-w-[80vw] lg:max-w-full pb-20" data-v-35e300cd><table class="w-full" data-v-35e300cd><thead data-v-35e300cd><tr data-v-35e300cd><!--[-->`);
          ssrRenderList(theads, (item) => {
            _push(`<th class="capitalize text-[#475467] text-sm text-left font-medium border-t border-b py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-35e300cd>${ssrInterpolate(item)}</th>`);
          });
          _push(`<!--]--></tr></thead><tbody data-v-35e300cd><!--[-->`);
          ssrRenderList(unref(requests), (item) => {
            _push(`<tr data-v-35e300cd><td class="capitalize text-[#101828] text-sm border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-35e300cd><span class="${ssrRenderClass(item.status == 4 ? "opacity-25" : "")}" data-v-35e300cd><span class="text-sm font-medium" data-v-35e300cd>${ssrInterpolate(item.productName)}</span></span></td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-35e300cd>${ssrInterpolate(item.producer)}</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-35e300cd>${ssrInterpolate(unref(moment)(item.created).format("lll"))}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-35e300cd>`);
            _push(ssrRenderComponent(_component_AppStatusButton, {
              status: item.requestStatus
            }, null, _parent));
            _push(`</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] relative"])}" data-v-35e300cd>`);
            _push(ssrRenderComponent(unref(Menu), {
              class: "relative",
              as: "div"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(ssrRenderComponent(unref(MenuButton), { class: "outline-none" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<i class="uil uil-ellipsis-v" data-v-35e300cd${_scopeId2}></i>`);
                      } else {
                        return [
                          createVNode("i", { class: "uil uil-ellipsis-v" })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                  _push2(ssrRenderComponent(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[140px] rounded-xl overflow-hidden" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<div class="py-2 px-4 hover:bg-gray-50 text-xs whitespace-nowrap cursor-pointer" data-v-35e300cd${_scopeId2}><i class="uil uil-box mr-2" data-v-35e300cd${_scopeId2}></i> Open Request </div>`);
                        if (__props.canCancel) {
                          _push3(`<div class="py-2 px-4 hover:bg-gray-50 text-xx whitespace-nowrap" data-v-35e300cd${_scopeId2}><i class="uil uil-trash mr-2" data-v-35e300cd${_scopeId2}></i> Set as Cancelled </div>`);
                        } else {
                          _push3(`<!---->`);
                        }
                      } else {
                        return [
                          createVNode("div", {
                            class: "py-2 px-4 hover:bg-gray-50 text-xs whitespace-nowrap cursor-pointer",
                            onClick: ($event) => openRequests(item.id)
                          }, [
                            createVNode("i", { class: "uil uil-box mr-2" }),
                            createTextVNode(" Open Request ")
                          ], 8, ["onClick"]),
                          __props.canCancel ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "py-2 px-4 hover:bg-gray-50 text-xx whitespace-nowrap",
                            onClick: ($event) => handleCancel(item.id)
                          }, [
                            createVNode("i", { class: "uil uil-trash mr-2" }),
                            createTextVNode(" Set as Cancelled ")
                          ], 8, ["onClick"])) : createCommentVNode("", true)
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                } else {
                  return [
                    createVNode(unref(MenuButton), { class: "outline-none" }, {
                      default: withCtx(() => [
                        createVNode("i", { class: "uil uil-ellipsis-v" })
                      ]),
                      _: 1
                    }),
                    createVNode(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[140px] rounded-xl overflow-hidden" }, {
                      default: withCtx(() => [
                        createVNode("div", {
                          class: "py-2 px-4 hover:bg-gray-50 text-xs whitespace-nowrap cursor-pointer",
                          onClick: ($event) => openRequests(item.id)
                        }, [
                          createVNode("i", { class: "uil uil-box mr-2" }),
                          createTextVNode(" Open Request ")
                        ], 8, ["onClick"]),
                        __props.canCancel ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "py-2 px-4 hover:bg-gray-50 text-xx whitespace-nowrap",
                          onClick: ($event) => handleCancel(item.id)
                        }, [
                          createVNode("i", { class: "uil uil-trash mr-2" }),
                          createTextVNode(" Set as Cancelled ")
                        ], 8, ["onClick"])) : createCommentVNode("", true)
                      ]),
                      _: 2
                    }, 1024)
                  ];
                }
              }),
              _: 2
            }, _parent));
            _push(`</td></tr>`);
          });
          _push(`<!--]--></tbody></table></div>`);
        } else {
          _push(ssrRenderComponent(_component_EmptyData, {
            url: "/markets",
            buttonText: "go to catalog",
            text: "No sample request have been made"
          }, null, _parent));
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(loading)) {
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="p-5" data-v-35e300cd>`);
      _push(ssrRenderComponent(_component_PaginationSimple, {
        total: unref(queryParams).totalCount,
        current: unref(queryParams).PageNumber,
        "per-page": unref(queryParams).PageSize,
        pageRange: 5,
        onPageChanged: ($event) => unref(queryParams).PageNumber = $event
      }, null, _parent));
      _push(`</div>`);
      if (unref(isRequestOpen)) {
        _push(ssrRenderComponent(_component_SideModal, {
          isOpen: unref(isRequestOpen),
          onTogglePopup: ($event) => isRequestOpen.value = false
        }, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="h-full w-full bg-white rounded-lg p-6 lg:p-8 overflow-auto max-h-full" data-v-35e300cd${_scopeId}><div class="mb-3" data-v-35e300cd${_scopeId}><p class="text-sm text-[#B6B7B9] mb-2" data-v-35e300cd${_scopeId}>Request ID</p><h2 class="font-medium text-2xl" data-v-35e300cd${_scopeId}>${ssrInterpolate(unref(request).requestNumber)}</h2></div><hr class="my-3 border-gray-200" data-v-35e300cd${_scopeId}>`);
              _push2(ssrRenderComponent(_component_SupplierMyrequestsRequestComponent, null, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "h-full w-full bg-white rounded-lg p-6 lg:p-8 overflow-auto max-h-full" }, [
                  createVNode("div", { class: "mb-3" }, [
                    createVNode("p", { class: "text-sm text-[#B6B7B9] mb-2" }, "Request ID"),
                    createVNode("h2", { class: "font-medium text-2xl" }, toDisplayString(unref(request).requestNumber), 1)
                  ]),
                  createVNode("hr", { class: "my-3 border-gray-200" }),
                  createVNode(_component_SupplierMyrequestsRequestComponent)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/myrequests/RequestTable.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["__scopeId", "data-v-35e300cd"]]);
const _sfc_main$7 = {
  __name: "SingleDocument",
  __ssrInlineRender: true,
  setup(__props) {
    const document = inject("document");
    const stage = ref(1);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtImg = __nuxt_component_1$2;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "flex flex-col gap-y-8" }, _attrs))} data-v-ced0e78d><div class="flex items-center" data-v-ced0e78d><span class="mr-3 h-10 w-10 rounded-lg flex items-center justify-center border border-[#E7EBEE] p-2" data-v-ced0e78d>`);
      _push(ssrRenderComponent(_component_NuxtImg, {
        class: "",
        src: unref(document).logo,
        alt: "alt"
      }, null, _parent));
      _push(`</span><span data-v-ced0e78d><span class="text-xs font-medium" data-v-ced0e78d>${ssrInterpolate(unref(document).productName)}</span><br data-v-ced0e78d><span class="text-xs font-normal" data-v-ced0e78d>${ssrInterpolate(unref(document).producer)}</span></span></div><div class="grid grid-cols-2 gap-y-8 gap-x-4 mb-8" data-v-ced0e78d><div data-v-ced0e78d><p class="text-[12px] text-[#B6B7B9] mb-2 uppercase" data-v-ced0e78d>STATUS</p>`);
      if (unref(document).requestStatus == 0) {
        _push(`<span class="px-2 py-2 text-xs rounded-lg bg-[#D0C9FF]" data-v-ced0e78d> New</span>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(document).requestStatus == 2) {
        _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#E0F7B0]" data-v-ced0e78d> Completed</span>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(document).requestStatus == 1) {
        _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#FDD0AF]" data-v-ced0e78d> In progress</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div data-v-ced0e78d><p class="text-[12px] text-[#B6B7B9] mb-2 uppercase" data-v-ced0e78d>created</p><span class="text-xs" data-v-ced0e78d>${ssrInterpolate(unref(moment)(unref(document).createdOn).format("ll"))}</span></div><div data-v-ced0e78d><p class="text-[12px] text-[#B6B7B9] mb-2 uppercase" data-v-ced0e78d>document type</p><span class="text-xs" data-v-ced0e78d>SDS &amp; Other</span></div></div>`);
      if (unref(document).description) {
        _push(`<div class="bg-[#F1F3F5] rounded-lg p-6 text-matta-black" data-v-ced0e78d><div class="" data-v-ced0e78d><p class="text-sm font-normal" data-v-ced0e78d>${ssrInterpolate(unref(document).description)}</p></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<button class="px-6 py-4 w-full border-primary- border text-sm rounded-full text-primary uppercase" data-v-ced0e78d> see documents </button><hr class="my-4 border-[#E7EBEE]" data-v-ced0e78d><div class="bg-[#F1F3F5] rounded-lg p-6 text-matta-black" data-v-ced0e78d><div class="flex justify-between mb-6" data-v-ced0e78d><h3 class="text-lg font-medium" data-v-ced0e78d>Timeline</h3><span data-v-ced0e78d><i class="uil uil-minusext-lg" data-v-ced0e78d></i></span></div><div class="${ssrRenderClass([unref(stage) > 1 ? "opacity-50" : "", "flex justify-start items-center gap-x-2 mb-3"])}" data-v-ced0e78d><span class="${ssrRenderClass([unref(stage) > 1 ? "" : " bg-primary-500 text-white", "w-[46px] h-[46px] rounded-full flex items-center justify-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black border border-[#ddd] shadow-xs"])}" data-v-ced0e78d><i class="uil uil-check" data-v-ced0e78d></i></span><span data-v-ced0e78d><span class="text-xs text-[#ABABAB]" data-v-ced0e78d>Mar 18, 13:05PM</span><br data-v-ced0e78d><span class="text-xs" data-v-ced0e78d><span data-v-ced0e78d>Document request has been <span class="font-medium" data-v-ced0e78d>completed</span>.</span></span></span></div><div class="${ssrRenderClass([unref(stage) > 2 ? "opacity-50" : "", "flex justify-start items-center gap-x-2 mb-3"])}" data-v-ced0e78d><span class="${ssrRenderClass([
        unref(stage) > 2 ? "" : unref(stage) == 2 ? " bg-primary-500 text-white" : unref(stage) < 2 ? "bg-white text-matta-black" : "",
        "w-[46px] h-[46px] rounded-full flex items-center justify-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black border border-[#ddd] shadow-xs"
      ])}" data-v-ced0e78d><i class="uil uil-refresh" data-v-ced0e78d></i></span><span data-v-ced0e78d><span class="text-xs text-[#ABABAB]" data-v-ced0e78d>Mar 18, 13:05PM</span><br data-v-ced0e78d><span class="text-xs" data-v-ced0e78d><span data-v-ced0e78d>Status changed from <span class="font-medium" data-v-ced0e78d>New</span> to <span class="font-medium" data-v-ced0e78d>In Progress</span>.</span></span></span></div><div class="${ssrRenderClass([unref(stage) > 3 ? "opacity-50" : "", "flex justify-start items-center gap-x-2 mb-3"])}" data-v-ced0e78d><span class="${ssrRenderClass([
        unref(stage) > 3 ? "" : unref(stage) == 3 ? " bg-primary-500 text-white" : unref(stage) < 3 ? "bg-white text-matta-black" : "",
        "w-[46px] h-[46px] rounded-full flex items-center justify-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black border border-[#ddd] shadow-xs"
      ])}" data-v-ced0e78d><i class="uil uil-plus" data-v-ced0e78d></i></span><span data-v-ced0e78d><span class="text-xs text-[#ABABAB]" data-v-ced0e78d>Mar 18, 13:05PM</span><br data-v-ced0e78d><span class="text-xs" data-v-ced0e78d><span data-v-ced0e78d>Document request <span class="font-medium" data-v-ced0e78d>#SE554-334</span> created.</span></span></span></div></div></section>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/myrequests/SingleDocument.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const RequestComponent = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["__scopeId", "data-v-ced0e78d"]]);
const _sfc_main$6 = {
  __name: "DocumentsTable",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    ref([]);
    const documents = ref([]);
    const isOpen = ref(false);
    const theads = ["product", "created", "status", "type", ""];
    function openRequest(item) {
      docdetails(item.id).then((res) => {
        document.value = res.data.data;
        isOpen.value = true;
      });
    }
    const document = ref({});
    const queryParams = reactive({
      SupplierId: "",
      RequestStatus: "",
      ProducerId: "",
      ProductId: "",
      Search: "",
      SortOrder: "",
      PageNumber: 1,
      PageSize: 10
    });
    const isLoading = ref(true);
    function getRequestDoc() {
      isLoading.value = true;
      buyerdoc(queryParams).then((res) => {
        documents.value = res.data.data.data;
        queryParams.totalCount = res.data.data.totalCount;
        isLoading.value = false;
      });
    }
    const statusOptions = [
      {
        id: 0,
        text1: "New"
      },
      {
        id: 1,
        text1: "In Progress"
      }
    ];
    const debounceSearch = debounce(() => {
      getRequestDoc();
    }, 800);
    watch(
      () => ({ ...queryParams }),
      () => {
        debounceSearch();
      }
    );
    provide("document", document);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormsCustomSelect = __nuxt_component_0$1;
      const _component_NuxtImg = __nuxt_component_1$2;
      const _component_EmptyData = __nuxt_component_2$1;
      const _component_AppLoader = __nuxt_component_1$1;
      const _component_PaginationSimple = __nuxt_component_4$1;
      const _component_SideModal = __nuxt_component_5$3;
      _push(`<!--[--><div class="flex justify-between items-center mb-8 px-5" data-v-0f75ef9c><div class="flex gap-x-4" data-v-0f75ef9c><div class="relative flex items-center" data-v-0f75ef9c><span class="absolute left-4 pointer-events-none text-[#667085]" data-v-0f75ef9c><i class="uil uil-search" data-v-0f75ef9c></i></span><input${ssrRenderAttr("value", unref(queryParams).Search)} placeholder="Search" class="border border-[#E7E7E7] text-sm focus:pr-3 pl-10 rounded-lg w-[280px] focus:outline-none py-[10px] transition ease-in-out duration-300" type="search" data-v-0f75ef9c></div><div class="" data-v-0f75ef9c>`);
      _push(ssrRenderComponent(_component_FormsCustomSelect, {
        placeholder: "Status",
        options: statusOptions,
        modelValue: unref(queryParams).RequestStatus,
        "onUpdate:modelValue": ($event) => unref(queryParams).RequestStatus = $event,
        classStyles: "border border-[#E7E7E7] text-sm  rounded-lg min-w-[180px] py-[10px] px-[14px] focus:outline-none"
      }, null, _parent));
      _push(`</div></div></div>`);
      if (!unref(isLoading)) {
        _push(`<div data-v-0f75ef9c>`);
        if (unref(documents).length) {
          _push(`<div data-v-0f75ef9c><table class="w-full" data-v-0f75ef9c><thead data-v-0f75ef9c><tr data-v-0f75ef9c><!--[-->`);
          ssrRenderList(theads, (item) => {
            _push(`<th class="capitalize text-[#475467] text-sm text-left font-medium border-t border-b py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-0f75ef9c>${ssrInterpolate(item)}</th>`);
          });
          _push(`<!--]--></tr></thead><tbody data-v-0f75ef9c><!--[-->`);
          ssrRenderList(unref(documents), (item) => {
            _push(`<tr data-v-0f75ef9c><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-0f75ef9c><div class="flex items-center" data-v-0f75ef9c><span class="mr-3 h-10 w-10 rounded-lg flex items-center justify-center border border-[#E7EBEE] p-2" data-v-0f75ef9c>`);
            _push(ssrRenderComponent(_component_NuxtImg, {
              class: "",
              src: item.image,
              alt: "alt"
            }, null, _parent));
            _push(`</span><span class="${ssrRenderClass(item.status == 3 ? "opacity-25" : "")}" data-v-0f75ef9c><span class="text-sm font-medium" data-v-0f75ef9c>${ssrInterpolate(item.productName)}</span><br data-v-0f75ef9c><span class="text-xs font-normal" data-v-0f75ef9c>${ssrInterpolate(item.producer)}</span></span></div></td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-0f75ef9c>${ssrInterpolate(unref(moment)(item.created).format("l"))}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-0f75ef9c>`);
            if (item.requestStatus == 0) {
              _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#D0C9FF]" data-v-0f75ef9c> New</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 1) {
              _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#F9CBE4]" data-v-0f75ef9c> In progress</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 2) {
              _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#BBE5AC]" data-v-0f75ef9c> Shipped</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 3) {
              _push(`<span class="px-2 py-1 text-xs rounded-lg border opacity-25" data-v-0f75ef9c> Completed</span>`);
            } else {
              _push(`<!---->`);
            }
            _push(`</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-0f75ef9c>${ssrInterpolate(item.type)}</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-0f75ef9c>`);
            _push(ssrRenderComponent(unref(Menu), {
              class: "relative",
              as: "div"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(ssrRenderComponent(unref(MenuButton), { class: "outline-none" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<i class="uil uil-ellipsis-v" data-v-0f75ef9c${_scopeId2}></i>`);
                      } else {
                        return [
                          createVNode("i", { class: "uil uil-ellipsis-v" })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                  _push2(ssrRenderComponent(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[180px] rounded-xl overflow-hidden" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<div class="py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap" data-v-0f75ef9c${_scopeId2}><i class="uil uil-file mr-2" data-v-0f75ef9c${_scopeId2}></i> Open Document </div><div class="py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap" data-v-0f75ef9c${_scopeId2}><i class="uil uil-trash mr-2" data-v-0f75ef9c${_scopeId2}></i> Set as Cancelled </div>`);
                      } else {
                        return [
                          createVNode("div", {
                            class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap",
                            onClick: ($event) => openRequest(item)
                          }, [
                            createVNode("i", { class: "uil uil-file mr-2" }),
                            createTextVNode(" Open Document ")
                          ], 8, ["onClick"]),
                          createVNode("div", {
                            onClick: _ctx.cancelRequest,
                            class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                          }, [
                            createVNode("i", { class: "uil uil-trash mr-2" }),
                            createTextVNode(" Set as Cancelled ")
                          ], 8, ["onClick"])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                } else {
                  return [
                    createVNode(unref(MenuButton), { class: "outline-none" }, {
                      default: withCtx(() => [
                        createVNode("i", { class: "uil uil-ellipsis-v" })
                      ]),
                      _: 1
                    }),
                    createVNode(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[180px] rounded-xl overflow-hidden" }, {
                      default: withCtx(() => [
                        createVNode("div", {
                          class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap",
                          onClick: ($event) => openRequest(item)
                        }, [
                          createVNode("i", { class: "uil uil-file mr-2" }),
                          createTextVNode(" Open Document ")
                        ], 8, ["onClick"]),
                        createVNode("div", {
                          onClick: _ctx.cancelRequest,
                          class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                        }, [
                          createVNode("i", { class: "uil uil-trash mr-2" }),
                          createTextVNode(" Set as Cancelled ")
                        ], 8, ["onClick"])
                      ]),
                      _: 2
                    }, 1024)
                  ];
                }
              }),
              _: 2
            }, _parent));
            _push(`</td></tr>`);
          });
          _push(`<!--]--></tbody></table></div>`);
        } else {
          _push(ssrRenderComponent(_component_EmptyData, {
            url: "/markets",
            buttonText: "go to catalog",
            text: "No document request have been made"
          }, null, _parent));
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isLoading)) {
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="p-5" data-v-0f75ef9c>`);
      _push(ssrRenderComponent(_component_PaginationSimple, {
        total: unref(queryParams).totalCount,
        current: unref(queryParams).PageNumber,
        "per-page": unref(queryParams).PageSize,
        pageRange: 5,
        onPageChanged: ($event) => unref(queryParams).PageNumber = $event
      }, null, _parent));
      _push(`</div>`);
      if (unref(isOpen)) {
        _push(ssrRenderComponent(_component_SideModal, {
          isOpen: unref(isOpen),
          onTogglePopup: ($event) => isOpen.value = false
        }, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="h-full w-full bg-white rounded-lg p-6 lg:p-8 overflow-auto max-h-full" data-v-0f75ef9c${_scopeId}><div class="mb-3" data-v-0f75ef9c${_scopeId}><p class="text-[13px] text-[#B6B7B9] mb-2" data-v-0f75ef9c${_scopeId}>Request ID</p><h2 class="font-medium text-2xl" data-v-0f75ef9c${_scopeId}>${ssrInterpolate(unref(document).requestNumber)}</h2></div><hr class="my-3 border-gray-200" data-v-0f75ef9c${_scopeId}>`);
              _push2(ssrRenderComponent(unref(RequestComponent), null, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "h-full w-full bg-white rounded-lg p-6 lg:p-8 overflow-auto max-h-full" }, [
                  createVNode("div", { class: "mb-3" }, [
                    createVNode("p", { class: "text-[13px] text-[#B6B7B9] mb-2" }, "Request ID"),
                    createVNode("h2", { class: "font-medium text-2xl" }, toDisplayString(unref(document).requestNumber), 1)
                  ]),
                  createVNode("hr", { class: "my-3 border-gray-200" }),
                  createVNode(unref(RequestComponent))
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/myrequests/DocumentsTable.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__scopeId", "data-v-0f75ef9c"]]);
const _sfc_main$5 = {
  __name: "QuoteDetail",
  __ssrInlineRender: true,
  setup(__props) {
    const quote = inject("quote");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="mb-8"><h3 class="font-medium text-xl text-gray-700 capitalize"> Request for quote </h3><p class="font-normal text-base capitalize">${ssrInterpolate(unref(quote).buyerBusinessName)}</p></div><div class="mb-8"><p class="font-medium text-lg"><span class="text-gray-500">Product name :</span> ${ssrInterpolate(unref(quote).productName)}</p><div class="grid grid-cols-2"><div><p class="font-nomrmal text-sm text-gray-500">Market</p><p class="font-medium text-sm">${ssrInterpolate(unref(quote).market)}</p></div><div><p class="font-nomrmal text-sm text-gray-500">Application</p><p class="font-medium text-sm">${ssrInterpolate(unref(quote).applications)}</p></div></div><hr class="my-4"><div class="mb-8"><h4 class="font-medium text-lg mb-4 text-gray-700"> Status of request </h4><div class="flex items-start gap-x-3">`);
      if (unref(quote).status == 0) {
        _push(`<i class="fa fa-clock-o text-lg text-yellow-500 w-5"></i>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(quote).status == 1) {
        _push(`<i class="fa fa-clock-o text-lg text-blue-500 w-5"></i>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(quote).status == 2) {
        _push(`<i class="fa fa-clock-o text-lg text-green-500 w-5"></i>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div><div class="flex text-xl items-center font-medium gap-x-2"><p class="">Status</p> : `);
      if (unref(quote).status == 0) {
        _push(`<span class="text-yellow-500">Pending response</span>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(quote).status == 1) {
        _push(`<span class="text-blue-500">Viewed</span>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(quote).status == 2) {
        _push(`<span class="text-green-500">Responsed</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if (unref(quote).status == 0) {
        _push(`<p class="text-base font-medium text-gray-500"> Your request for quote is under review by Matta </p>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(quote).status == 1) {
        _push(`<p class="text-base font-medium text-gray-500"> Your request for quote has been viewed by Matta </p>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(quote).status == 2) {
        _push(`<p class="text-base font-medium text-gray-500"> Your request for quote has been sent by Matta </p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div><hr class="my-4"><div class="mb-6"><h4 class="font-medium text-lg mb-4 text-gray-700">Requested terms</h4><div class="flex items-start mb-3 gap-x-3"><i class="fa fa-hand-o-up text-lg text-gray-500 w-5" aria-hidden="true"></i><div><p class="text-base font-medium"> Estimated ${ssrInterpolate(unref(quote).expectedVolume)} ${ssrInterpolate(unref(quote).unit)}(s) total annual volume </p><p class="text-sm font-normal text-gray-500"> Use: ${ssrInterpolate(unref(quote).productUse)}</p></div></div><div class="flex items-start gap-x-3"><i class="fas fa-truck text-lg text-gray-500 w-5"></i><div class="text-base"><p class="text-sm font-medium mb-1">Your pick up</p><p class="text-sm font-normal flex gap-x-2 items-center"><span>Address : </span><span>${ssrInterpolate(unref(quote).deliverAddress)}</span></p></div></div></div><hr class="my-4"><div><h4 class="text-base font-medium mb-4 text-gray-700"> Order preference </h4><div class="flex items-start gap-x-3 mb-3"><i class="fas fa-clipboard-list text-lg text-gray-500 w-5"></i><div><p class="text-sm flex font-medium items-center gap-x-2"><span class="text-gray-500 text-lg">Special instruction:</span><span>${ssrInterpolate(unref(quote).additionalInformation)}</span></p></div></div><div class="flex items-start gap-x-3 mb-3"><i class="fa fa-user text-lg text-gray-500 w-5" aria-hidden="true"></i><div><p class="text-sm font-medium mb-2 text-gray-700">Requested by</p><p class="text-sm mb-1">${ssrInterpolate(unref(quote).requestedBy)}</p><p class="text-sm font-normal">${ssrInterpolate(unref(quote).contactPhone)}</p></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/myrequests/QuoteDetail.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_5$2 = _sfc_main$5;
const _sfc_main$4 = {
  __name: "QuotesTable",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    const theads = ["quote no", "product", "date created", "status", ""];
    const quotes = inject("quotes");
    ref([]);
    const quoteParams = inject("quoteParams");
    const isOpen = ref(false);
    function openRequest(item) {
      sellerquotedetail(item.id).then((res) => {
        quote.value = res.data.data;
        isOpen.value = true;
      });
    }
    const quote = ref({});
    const statusOptions = [
      {
        id: 0,
        text1: "New"
      },
      {
        id: 1,
        text1: "In Progress"
      }
    ];
    const debounceSearch = debounce(() => {
    }, 800);
    watch(
      () => ({ ...quoteParams }),
      () => {
        debounceSearch();
      }
    );
    provide("quote", quote);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormsCustomSelect = __nuxt_component_0$1;
      const _component_AppIcon = __nuxt_component_1$3;
      const _component_EmptyData = __nuxt_component_2$1;
      const _component_PaginationSimple = __nuxt_component_4$1;
      const _component_SideModal = __nuxt_component_5$3;
      const _component_SupplierMyrequestsQuoteDetail = __nuxt_component_5$2;
      _push(`<!--[--><div class="flex justify-between items-center mb-8 px-5" data-v-e1447cc2><div class="flex gap-x-4" data-v-e1447cc2><div class="relative flex items-center" data-v-e1447cc2><span class="absolute left-4 pointer-events-none text-[#667085]" data-v-e1447cc2><i class="uil uil-search" data-v-e1447cc2></i></span><input${ssrRenderAttr("value", unref(quoteParams).Search)} placeholder="Search" class="border border-[#E7E7E7] text-sm focus:pr-3 pl-10 rounded-lg w-[280px] focus:outline-none py-[10px] transition ease-in-out duration-300" type="search" data-v-e1447cc2></div><div class="" data-v-e1447cc2>`);
      _push(ssrRenderComponent(_component_FormsCustomSelect, {
        placeholder: "Status",
        options: statusOptions,
        modelValue: unref(quoteParams).Status,
        "onUpdate:modelValue": ($event) => unref(quoteParams).Status = $event,
        classStyles: "border border-[#E7E7E7] text-sm  rounded-lg min-w-[180px] py-[10px] px-[14px] focus:outline-none"
      }, null, _parent));
      _push(`</div></div></div>`);
      if (unref(quotes).length) {
        _push(`<div data-v-e1447cc2><table class="w-full" data-v-e1447cc2><thead data-v-e1447cc2><tr data-v-e1447cc2><!--[-->`);
        ssrRenderList(theads, (item) => {
          _push(`<th class="capitalize text-[#475467] text-sm text-left font-medium border-t border-b py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-e1447cc2>${ssrInterpolate(item)}</th>`);
        });
        _push(`<!--]--></tr></thead><tbody data-v-e1447cc2><!--[-->`);
        ssrRenderList(unref(quotes), (item) => {
          _push(`<tr data-v-e1447cc2><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-e1447cc2><div class="flex items-center" data-v-e1447cc2><span class="text-sm font-normal" data-v-e1447cc2>${ssrInterpolate(item.quoteNo)}</span></div></td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-e1447cc2>${ssrInterpolate(item.product)}</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-e1447cc2>${ssrInterpolate(unref(moment)(item.date).format("lll"))}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-e1447cc2>`);
          if (item.status == 0) {
            _push(`<span class="px-[6px] py-[2px] text-xs rounded-full text-[#5925DC] border border-[#D9D6FE] bg-[#F4F3FF] flex gap-x-1 items-center max-w-max" data-v-e1447cc2>`);
            _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
            _push(` ${ssrInterpolate(item.statusText)}</span>`);
          } else {
            _push(`<!---->`);
          }
          if (item.status == 1) {
            _push(`<span class="px-[6px] py-1 text-xs rounded-full border border-pink-100 bg-pink-50 text-pink-500 flex gap-x-1 items-center max-w-max" data-v-e1447cc2>`);
            _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
            _push(` ${ssrInterpolate(item.statusText)}</span>`);
          } else {
            _push(`<!---->`);
          }
          if (item.status == 2) {
            _push(`<span class="px-[6px] py-1 text-xs rounded-full text-[#17B26A] border border-[#ABEFC6] bg-[#ECFDF3] flex gap-x-1 items-center max-w-max" data-v-e1447cc2>`);
            _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
            _push(` ${ssrInterpolate(item.statusText)}</span>`);
          } else {
            _push(`<!---->`);
          }
          if (item.status == 3) {
            _push(`<span class="px-[6px] py-1 text-xs rounded-full text-[#17B26A] border border-[#ABEFC6] bg-[#ECFDF3] flex gap-x-1 items-center max-w-max" data-v-e1447cc2>`);
            _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
            _push(` ${ssrInterpolate(item.statusText)}</span>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-e1447cc2>`);
          _push(ssrRenderComponent(unref(Menu), {
            class: "relative",
            as: "div"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(unref(MenuButton), { class: "outline-none" }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<i class="uil uil-ellipsis-v" data-v-e1447cc2${_scopeId2}></i>`);
                    } else {
                      return [
                        createVNode("i", { class: "uil uil-ellipsis-v" })
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(ssrRenderComponent(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[180px] rounded-xl overflow-hidden" }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<div class="py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap cursor-pointer" data-v-e1447cc2${_scopeId2}><i class="uil uil-file mr-2" data-v-e1447cc2${_scopeId2}></i> Open quote </div>`);
                    } else {
                      return [
                        createVNode("div", {
                          class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap cursor-pointer",
                          onClick: ($event) => openRequest(item)
                        }, [
                          createVNode("i", { class: "uil uil-file mr-2" }),
                          createTextVNode(" Open quote ")
                        ], 8, ["onClick"])
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              } else {
                return [
                  createVNode(unref(MenuButton), { class: "outline-none" }, {
                    default: withCtx(() => [
                      createVNode("i", { class: "uil uil-ellipsis-v" })
                    ]),
                    _: 1
                  }),
                  createVNode(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[180px] rounded-xl overflow-hidden" }, {
                    default: withCtx(() => [
                      createVNode("div", {
                        class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap cursor-pointer",
                        onClick: ($event) => openRequest(item)
                      }, [
                        createVNode("i", { class: "uil uil-file mr-2" }),
                        createTextVNode(" Open quote ")
                      ], 8, ["onClick"])
                    ]),
                    _: 2
                  }, 1024)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</td></tr>`);
        });
        _push(`<!--]--></tbody></table></div>`);
      } else {
        _push(ssrRenderComponent(_component_EmptyData, {
          url: "/markets",
          buttonText: "go to catalog",
          text: "No quote have been made"
        }, null, _parent));
      }
      _push(`<div class="p-5" data-v-e1447cc2>`);
      _push(ssrRenderComponent(_component_PaginationSimple, {
        total: unref(quoteParams).totalCount,
        current: unref(quoteParams).PageNumber,
        "per-page": unref(quoteParams).PageSize,
        pageRange: 5,
        onPageChanged: ($event) => unref(quoteParams).PageNumber = $event
      }, null, _parent));
      _push(`</div>`);
      if (isOpen.value) {
        _push(ssrRenderComponent(_component_SideModal, {
          isOpen: isOpen.value,
          onTogglePopup: ($event) => isOpen.value = false
        }, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="h-full w-full md:min-w-[50vh] bg-white rounded-lg p-6 lg:py-10 overflow-auto max-h-full" data-v-e1447cc2${_scopeId}><div class="mb-3" data-v-e1447cc2${_scopeId}><p class="text-[13px] text-[#B6B7B9] mb-2" data-v-e1447cc2${_scopeId}>Quote No</p><h2 class="font-medium text-2xl" data-v-e1447cc2${_scopeId}>${ssrInterpolate(quote.value.quoteNo)}</h2></div><hr class="my-3 border-gray-200" data-v-e1447cc2${_scopeId}>`);
              _push2(ssrRenderComponent(_component_SupplierMyrequestsQuoteDetail, null, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "h-full w-full md:min-w-[50vh] bg-white rounded-lg p-6 lg:py-10 overflow-auto max-h-full" }, [
                  createVNode("div", { class: "mb-3" }, [
                    createVNode("p", { class: "text-[13px] text-[#B6B7B9] mb-2" }, "Quote No"),
                    createVNode("h2", { class: "font-medium text-2xl" }, toDisplayString(quote.value.quoteNo), 1)
                  ]),
                  createVNode("hr", { class: "my-3 border-gray-200" }),
                  createVNode(_component_SupplierMyrequestsQuoteDetail)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/myrequests/QuotesTable.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-e1447cc2"]]);
const _sfc_main$3 = {
  __name: "ProductDetail",
  __ssrInlineRender: true,
  props: ["request"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="mb-8"><h3 class="font-medium text-xl text-gray-700 capitalize"> Request Detail </h3></div><div class="mb-8"><p class="font-medium text-base mb-4"><span class="text-gray-500">Date </span> <br> ${ssrInterpolate(unref(moment)(__props.request.created).format("l"))}</p><p class="font-medium text-base mb-4"><span class="text-gray-500">Business name </span> <br> ${ssrInterpolate(__props.request.businessName)}</p><p class="font-medium text-base mb-4"><span class="text-gray-500">Chemical name </span> <br> ${ssrInterpolate(__props.request.chemicalName)}</p><p class="font-medium text-base mb-4 gap-x-2"><span class="text-gray-500">Quantity </span> <br> ${ssrInterpolate(__props.request.quantity)}</p><p class="font-medium text-base mb-4 gap-x-2"><span class="text-gray-500">Unit </span> <br> ${ssrInterpolate(__props.request.unit)}</p><div class="bg-[#F1F3F5] rounded-lg p-6 text-matta-black mb-6"><div class="flex justify-between mb-4"><h3 class="text-lg font-medium">Customer information</h3><span><i class="uil uil-minusext-lg"></i></span></div><div class=""><p class="font-medium text-base mb-2 flex items-center gap-x-2"><span class="text-gray-500">Full name :</span> ${ssrInterpolate(__props.request.fullName)}</p><p class="font-medium text-base mb-2 flex items-center gap-x-2"><span class="text-gray-500">Email :</span> ${ssrInterpolate(__props.request.email)}</p><p class="font-medium text-base mb-8 flex items-center gap-x-2"><span class="text-gray-500">Phone number :</span> ${ssrInterpolate(__props.request.phoneCode)}-${ssrInterpolate(__props.request.phone)}</p></div></div><div class="text-right">`);
      if (__props.request.uploadedDocument) {
        _push(`<button class="text-blue-600 text-base mb-4 flex items-center gap-x-2 font-medium"> Download Document <span class="border border-gray-300 rounded-full h-8 w-8 flex items-center justify-center"><i class="uil uil-import"></i></span></button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/myrequests/ProductDetail.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_5$1 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "ProductTable",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    ref([]);
    const requests = ref([]);
    const isOpen = ref(false);
    const request = ref({});
    const theads = ["date", "request no", "business", "email", "chemical", ""];
    function openRequest(item) {
      request.value = item;
      isOpen.value = true;
    }
    const queryParams = reactive({
      SupplierId: "",
      RequestStatus: "",
      ProducerId: "",
      ProductId: "",
      Search: "",
      SortOrder: "",
      PageNumber: 1,
      PageSize: 10
    });
    const isLoading = ref(true);
    function getRequestDoc() {
      isLoading.value = true;
      getproductrequests(queryParams).then((res) => {
        requests.value = res.data.data.data;
        queryParams.totalCount = res.data.data.totalCount;
        isLoading.value = false;
      });
    }
    const statusOptions = [
      {
        id: 0,
        text1: "New"
      },
      {
        id: 1,
        text1: "In Progress"
      }
    ];
    const debounceSearch = debounce(() => {
      getRequestDoc();
    }, 800);
    watch(
      () => [queryParams.Search],
      () => {
        debounceSearch();
      }
    );
    watch(
      () => [queryParams.PageNumber],
      () => {
        getRequestDoc();
      }
    );
    provide("request", request);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormsCustomSelect = __nuxt_component_0$1;
      const _component_EmptyData = __nuxt_component_2$1;
      const _component_AppLoader = __nuxt_component_1$1;
      const _component_PaginationSimple = __nuxt_component_4$1;
      const _component_SideModal = __nuxt_component_5$3;
      const _component_SupplierMyrequestsProductDetail = __nuxt_component_5$1;
      _push(`<!--[--><div class="flex justify-between items-center mb-8 px-5" data-v-be2e75e2><div class="flex gap-x-4" data-v-be2e75e2><div class="relative flex items-center" data-v-be2e75e2><span class="absolute left-4 pointer-events-none text-[#667085]" data-v-be2e75e2><i class="uil uil-search" data-v-be2e75e2></i></span><input${ssrRenderAttr("value", unref(queryParams).Search)} placeholder="Search" class="border border-[#E7E7E7] text-sm focus:pr-3 pl-10 rounded-lg w-[280px] focus:outline-none py-[10px] transition ease-in-out duration-300" type="search" data-v-be2e75e2></div><div class="" data-v-be2e75e2>`);
      _push(ssrRenderComponent(_component_FormsCustomSelect, {
        placeholder: "Status",
        options: statusOptions,
        modelValue: unref(queryParams).RequestStatus,
        "onUpdate:modelValue": ($event) => unref(queryParams).RequestStatus = $event,
        classStyles: "border border-[#E7E7E7] text-sm  rounded-lg min-w-[180px] py-[10px] px-[14px] focus:outline-none"
      }, null, _parent));
      _push(`</div></div></div>`);
      if (!unref(isLoading)) {
        _push(`<div data-v-be2e75e2>`);
        if (unref(requests).length) {
          _push(`<div data-v-be2e75e2><table class="w-full" data-v-be2e75e2><thead data-v-be2e75e2><tr data-v-be2e75e2><!--[-->`);
          ssrRenderList(theads, (item) => {
            _push(`<th class="capitalize text-[#475467] text-sm text-left font-medium border-t border-b py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-be2e75e2>${ssrInterpolate(item)}</th>`);
          });
          _push(`<!--]--></tr></thead><tbody data-v-be2e75e2><!--[-->`);
          ssrRenderList(unref(requests), (item) => {
            _push(`<tr data-v-be2e75e2><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-be2e75e2>${ssrInterpolate(unref(moment)(item.created).format("l"))}</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-be2e75e2>${ssrInterpolate(item.requestNumber)}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-be2e75e2>${ssrInterpolate(item.businessName)}</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-be2e75e2>${ssrInterpolate(item.email)}</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-be2e75e2>${ssrInterpolate(item.chemicalName)}</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-be2e75e2>`);
            _push(ssrRenderComponent(unref(Menu), {
              class: "relative",
              as: "div"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(ssrRenderComponent(unref(MenuButton), { class: "outline-none" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<i class="uil uil-ellipsis-v" data-v-be2e75e2${_scopeId2}></i>`);
                      } else {
                        return [
                          createVNode("i", { class: "uil uil-ellipsis-v" })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                  _push2(ssrRenderComponent(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[180px] rounded-xl overflow-hidden" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<div class="py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap cursor-pointer" data-v-be2e75e2${_scopeId2}><i class="uil uil-file mr-2" data-v-be2e75e2${_scopeId2}></i> Open Request </div>`);
                      } else {
                        return [
                          createVNode("div", {
                            class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap cursor-pointer",
                            onClick: ($event) => openRequest(item)
                          }, [
                            createVNode("i", { class: "uil uil-file mr-2" }),
                            createTextVNode(" Open Request ")
                          ], 8, ["onClick"])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                } else {
                  return [
                    createVNode(unref(MenuButton), { class: "outline-none" }, {
                      default: withCtx(() => [
                        createVNode("i", { class: "uil uil-ellipsis-v" })
                      ]),
                      _: 1
                    }),
                    createVNode(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[180px] rounded-xl overflow-hidden" }, {
                      default: withCtx(() => [
                        createVNode("div", {
                          class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap cursor-pointer",
                          onClick: ($event) => openRequest(item)
                        }, [
                          createVNode("i", { class: "uil uil-file mr-2" }),
                          createTextVNode(" Open Request ")
                        ], 8, ["onClick"])
                      ]),
                      _: 2
                    }, 1024)
                  ];
                }
              }),
              _: 2
            }, _parent));
            _push(`</td></tr>`);
          });
          _push(`<!--]--></tbody></table></div>`);
        } else {
          _push(ssrRenderComponent(_component_EmptyData, {
            url: "/markets",
            buttonText: "go to catalog",
            text: "No product request have been made"
          }, null, _parent));
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isLoading)) {
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="p-5" data-v-be2e75e2>`);
      _push(ssrRenderComponent(_component_PaginationSimple, {
        total: unref(queryParams).totalCount,
        current: unref(queryParams).PageNumber,
        "per-page": unref(queryParams).PageSize,
        pageRange: 5,
        onPageChanged: ($event) => unref(queryParams).PageNumber = $event
      }, null, _parent));
      _push(`</div>`);
      if (unref(isOpen)) {
        _push(ssrRenderComponent(_component_SideModal, {
          isOpen: unref(isOpen),
          onTogglePopup: ($event) => isOpen.value = false
        }, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="h-full w-full bg-white rounded-lg p-6 lg:p-8 overflow-auto max-h-full" data-v-be2e75e2${_scopeId}><div class="mb-3" data-v-be2e75e2${_scopeId}><p class="text-[13px] text-[#B6B7B9] mb-2" data-v-be2e75e2${_scopeId}>Request No</p><h2 class="font-medium text-2xl" data-v-be2e75e2${_scopeId}>${ssrInterpolate(unref(request).requestNumber)}</h2></div><hr class="my-3 border-gray-200" data-v-be2e75e2${_scopeId}>`);
              _push2(ssrRenderComponent(_component_SupplierMyrequestsProductDetail, { request: unref(request) }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "h-full w-full bg-white rounded-lg p-6 lg:p-8 overflow-auto max-h-full" }, [
                  createVNode("div", { class: "mb-3" }, [
                    createVNode("p", { class: "text-[13px] text-[#B6B7B9] mb-2" }, "Request No"),
                    createVNode("h2", { class: "font-medium text-2xl" }, toDisplayString(unref(request).requestNumber), 1)
                  ]),
                  createVNode("hr", { class: "my-3 border-gray-200" }),
                  createVNode(_component_SupplierMyrequestsProductDetail, { request: unref(request) }, null, 8, ["request"])
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/myrequests/ProductTable.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-be2e75e2"]]);
const _sfc_main$1 = {
  __name: "MyRequests",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    useRoute();
    const isOpen = ref(false);
    const active = ref("samples");
    const quotes = ref([]);
    const count = reactive({
      documents: 0,
      samples: 0,
      quotes: 0,
      productRequest: 0
    });
    const tabs = [
      {
        title: "samples",
        key: "samples"
      },
      {
        title: "documents",
        key: "documents"
      },
      {
        title: "quotes",
        key: "quotes"
      },
      {
        title: "products",
        key: "productRequest"
      }
    ];
    const quoteParams = reactive({
      Status: "",
      Search: "",
      SortOrder: "",
      PageNumber: 1,
      PageSize: 10,
      totalCount: 0
    });
    function getquotes() {
      buyerquotes(quoteParams).then((res) => {
        count.quotes = quoteParams.totalCount = res.data.data.totalCount;
        quotes.value = res.data.data.data;
      });
    }
    watch(
      () => [quoteParams.Status, quoteParams.Search, quoteParams.SortOrder],
      () => {
        getquotes();
      }
    );
    provide("active", active);
    provide("quotes", quotes);
    provide("quoteParams", quoteParams);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderComponent = __nuxt_component_0$2;
      const _component_AppTab = __nuxt_component_1$4;
      const _component_SupplierMyrequestsRequestTable = __nuxt_component_2;
      const _component_SupplierMyrequestsDocumentsTable = __nuxt_component_3;
      const _component_SupplierMyrequestsQuotesTable = __nuxt_component_4;
      const _component_SupplierMyrequestsProductTable = __nuxt_component_5;
      const _component_IndexModal = __nuxt_component_0$3;
      const _component_AppIcon = __nuxt_component_1$3;
      _push(`<!--[--><div class="gap-y-2 flex flex-col bg-white rounded-[10px] border border-[#F4F7FE]" data-v-e3be183b>`);
      _push(ssrRenderComponent(_component_HeaderComponent, {
        title: "My requests",
        subtext: "List of your requests for samples and documents."
      }, null, _parent));
      _push(`<div class="pt-5" data-v-e3be183b>`);
      _push(ssrRenderComponent(_component_AppTab, {
        tabs,
        className: "px-5",
        count: unref(count)
      }, null, _parent));
      _push(`<div data-v-e3be183b>`);
      if (unref(active) == "samples") {
        _push(ssrRenderComponent(_component_SupplierMyrequestsRequestTable, { canCancel: false }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(active) == "documents") {
        _push(ssrRenderComponent(_component_SupplierMyrequestsDocumentsTable, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(active) == "quotes") {
        _push(ssrRenderComponent(_component_SupplierMyrequestsQuotesTable, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(active) == "products") {
        _push(ssrRenderComponent(_component_SupplierMyrequestsProductTable, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
      if (unref(isOpen)) {
        _push(ssrRenderComponent(_component_IndexModal, {
          isOpen: unref(isOpen),
          onTogglePopup: ($event) => isOpen.value = false
        }, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="w-[400px] bg-white rounded-lg p-6 lg:p-8 relative" data-v-e3be183b${_scopeId}><span class="hover:bg-gray-50 rounded-full h-6 w-6 flex items-center justify-center absolute top-4 right-4" data-v-e3be183b${_scopeId}>`);
              _push2(ssrRenderComponent(_component_AppIcon, {
                icon: "heroicons-solid:x",
                class: "w-4 h-4"
              }, null, _parent2, _scopeId));
              _push2(`</span><h4 class="text-lg font-medium mb-3" data-v-e3be183b${_scopeId}>Cancel document request</h4><p class="text-sm mb-8" data-v-e3be183b${_scopeId}> Are your sure you want to cancel #DC455-084 document request? </p><div class="flex items-center gap-x-4" data-v-e3be183b${_scopeId}><button type="button" class="text-[13px] uppercase text-matta-black px-2 py-2 hover:text-primary/80 w-full" data-v-e3be183b${_scopeId}> don\u2019t cancel </button><button type="button" class="border text-[13px] border-primary- uppercase w-full text-white bg-primary-500 rounded-lg px-2 py-3 hover:bg-primary/80" data-v-e3be183b${_scopeId}> cancel request </button></div></div>`);
            } else {
              return [
                createVNode("div", { class: "w-[400px] bg-white rounded-lg p-6 lg:p-8 relative" }, [
                  createVNode("span", {
                    onClick: ($event) => isOpen.value = false,
                    class: "hover:bg-gray-50 rounded-full h-6 w-6 flex items-center justify-center absolute top-4 right-4"
                  }, [
                    createVNode(_component_AppIcon, {
                      icon: "heroicons-solid:x",
                      class: "w-4 h-4"
                    })
                  ], 8, ["onClick"]),
                  createVNode("h4", { class: "text-lg font-medium mb-3" }, "Cancel document request"),
                  createVNode("p", { class: "text-sm mb-8" }, " Are your sure you want to cancel #DC455-084 document request? "),
                  createVNode("div", { class: "flex items-center gap-x-4" }, [
                    createVNode("button", {
                      onClick: ($event) => isOpen.value = false,
                      type: "button",
                      class: "text-[13px] uppercase text-matta-black px-2 py-2 hover:text-primary/80 w-full"
                    }, " don\u2019t cancel ", 8, ["onClick"]),
                    createVNode("button", {
                      type: "button",
                      onClick: _ctx.cancelRequest,
                      class: "border text-[13px] border-primary- uppercase w-full text-white bg-primary-500 rounded-lg px-2 py-3 hover:bg-primary/80"
                    }, " cancel request ", 8, ["onClick"])
                  ])
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/MyRequests.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-e3be183b"]]);
const _sfc_main = {
  __name: "my-requests",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierMyRequests = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierMyRequests, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/procurement/my-requests.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=my-requests-1Yua-vFM.mjs.map
