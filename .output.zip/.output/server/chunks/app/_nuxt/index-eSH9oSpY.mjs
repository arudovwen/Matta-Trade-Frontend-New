import { _ as __nuxt_component_1$1 } from './AppIcon-D3CPABPP.mjs';
import { g as getDefaultExportFromNamespaceIfNotNamed, a as getDefaultExportFromCjs, r as require$$0$1, c as commonjsGlobal } from '../../rollup/_vue.mjs';
import * as cleave from 'cleave.js';
import { resolveComponent, mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderClass, ssrRenderAttr, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';

var vueCleave = {exports: {}};

const require$$0 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(cleave);

(function (module, exports) {
	(function webpackUniversalModuleDefinition(root, factory) {
		module.exports = factory(require$$0, require$$0$1);
	})(commonjsGlobal, (__WEBPACK_EXTERNAL_MODULE__144__, __WEBPACK_EXTERNAL_MODULE__976__) => {
	return /******/ (() => { // webpackBootstrap
	/******/ 	var __webpack_modules__ = ({

	/***/ 144:
	/***/ ((module) => {

	module.exports = __WEBPACK_EXTERNAL_MODULE__144__;

	/***/ }),

	/***/ 976:
	/***/ ((module) => {

	module.exports = __WEBPACK_EXTERNAL_MODULE__976__;

	/***/ })

	/******/ 	});
	/************************************************************************/
	/******/ 	// The module cache
	/******/ 	var __webpack_module_cache__ = {};
	/******/ 	
	/******/ 	// The require function
	/******/ 	function __webpack_require__(moduleId) {
	/******/ 		// Check if module is in cache
	/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
	/******/ 		if (cachedModule !== undefined) {
	/******/ 			return cachedModule.exports;
	/******/ 		}
	/******/ 		// Create a new module (and put it into the cache)
	/******/ 		var module = __webpack_module_cache__[moduleId] = {
	/******/ 			// no module.id needed
	/******/ 			// no module.loaded needed
	/******/ 			exports: {}
	/******/ 		};
	/******/ 	
	/******/ 		// Execute the module function
	/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
	/******/ 	
	/******/ 		// Return the exports of the module
	/******/ 		return module.exports;
	/******/ 	}
	/******/ 	
	/************************************************************************/
	/******/ 	/* webpack/runtime/compat get default export */
	/******/ 	(() => {
	/******/ 		// getDefaultExport function for compatibility with non-harmony modules
	/******/ 		__webpack_require__.n = (module) => {
	/******/ 			var getter = module && module.__esModule ?
	/******/ 				() => (module['default']) :
	/******/ 				() => (module);
	/******/ 			__webpack_require__.d(getter, { a: getter });
	/******/ 			return getter;
	/******/ 		};
	/******/ 	})();
	/******/ 	
	/******/ 	/* webpack/runtime/define property getters */
	/******/ 	(() => {
	/******/ 		// define getter functions for harmony exports
	/******/ 		__webpack_require__.d = (exports, definition) => {
	/******/ 			for(var key in definition) {
	/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
	/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
	/******/ 				}
	/******/ 			}
	/******/ 		};
	/******/ 	})();
	/******/ 	
	/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
	/******/ 	(() => {
	/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
	/******/ 	})();
	/******/ 	
	/************************************************************************/
	var __webpack_exports__ = {};
	// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
	(() => {

	// EXPORTS
	__webpack_require__.d(__webpack_exports__, {
	  "default": () => (/* binding */ src)
	});

	// EXTERNAL MODULE: external {"commonjs":"cleave.js","commonjs2":"cleave.js","amd":"cleave.js","root":"Cleave"}
	var external_commonjs_cleave_js_commonjs2_cleave_js_amd_cleave_js_root_Cleave_ = __webpack_require__(144);
	var external_commonjs_cleave_js_commonjs2_cleave_js_amd_cleave_js_root_Cleave_default = /*#__PURE__*/__webpack_require__.n(external_commonjs_cleave_js_commonjs2_cleave_js_amd_cleave_js_root_Cleave_);
	// EXTERNAL MODULE: external {"commonjs":"vue","commonjs2":"vue","amd":"vue","root":"Vue"}
	var external_commonjs_vue_commonjs2_vue_amd_vue_root_Vue_ = __webpack_require__(976);


	/* harmony default export */ const component = ((0, external_commonjs_vue_commonjs2_vue_amd_vue_root_Vue_.defineComponent)({
	  name: 'cleave',
	  compatConfig: {
	    MODE: 3
	  },
	  render() {
	    return (0, external_commonjs_vue_commonjs2_vue_amd_vue_root_Vue_.h)('input', {
	      type: 'text',
	      value: this.cleave ? this.cleave.properties.result : this.modelValue,
	      // Cleave.js will set this as initial value
	      onBlur: this.onBlur
	    });
	  },
	  props: {
	    modelValue: {
	      default: null,
	      required: true,
	      validator(value) {
	        return value === null || typeof value === 'string' || value instanceof String || typeof value === 'number';
	      }
	    },
	    // https://github.com/nosir/cleave.js/blob/master/doc/options.md
	    options: {
	      type: Object,
	      default: () => ({})
	    },
	    // Set this prop as `false` to emit masked value
	    raw: {
	      type: Boolean,
	      default: true
	    }
	  },
	  emits: ['blur', 'update:modelValue'],
	  data() {
	    return {
	      // cleave.js instance
	      cleave: null,
	      // callback backup
	      onValueChangedFn: null
	    };
	  },
	  mounted() {
	    /* istanbul ignore if */
	    if (this.cleave) return;
	    this.cleave = new (external_commonjs_cleave_js_commonjs2_cleave_js_amd_cleave_js_root_Cleave_default())(this.$el, this.getOptions(this.options));
	  },
	  methods: {
	    /**
	     * Inject our method in config options
	     */
	    getOptions(options) {
	      // Preserve original callback
	      this.onValueChangedFn = options.onValueChanged;
	      return Object.assign({}, options, {
	        onValueChanged: this.onValueChanged
	      });
	    },
	    /**
	     * Watch for value changed by cleave and notify parent component
	     */
	    onValueChanged(event) {
	      let value = this.raw ? event.target.rawValue : event.target.value;
	      this.$emit('update:modelValue', value);

	      // Call original callback method
	      if (typeof this.onValueChangedFn === 'function') {
	        this.onValueChangedFn.call(this, event);
	      }
	    },
	    onBlur() {
	      this.$emit('blur', this.modelValue);
	    }
	  },
	  watch: {
	    /**
	     * Watch for any changes in options and redraw
	     */
	    options: {
	      deep: true,
	      handler(newOptions) {
	        this.cleave.destroy();
	        this.cleave = new (external_commonjs_cleave_js_commonjs2_cleave_js_amd_cleave_js_root_Cleave_default())(this.$el, this.getOptions(newOptions));
	        this.cleave.setRawValue(this.modelValue);
	      }
	    },
	    /**
	     * Watch for changes from parent component and notify cleave instance
	     */
	    modelValue(newValue) {
	      /* istanbul ignore if */
	      if (!this.cleave) return;

	      // when v-model is not masked (raw)
	      if (this.raw && newValue === this.cleave.getRawValue()) return;
	      //  when v-model is masked (NOT raw)
	      if (!this.raw && newValue === this.$el.value) return;
	      // Lastly set newValue
	      this.cleave.setRawValue(newValue);
	    }
	  },
	  beforeUnmount() {
	    /* istanbul ignore if */
	    if (!this.cleave) return;
	    this.cleave.destroy();
	    this.cleave = null;
	    this.onValueChangedFn = null;
	  }
	}));

	const src_plugin = (app, params) => {
	  let name = 'cleave';
	  /* istanbul ignore else */
	  if (typeof params === 'string') name = params;
	  app.component(name, component);
	};
	component.install = src_plugin;
	/* harmony default export */ const src = (component);
	})();

	__webpack_exports__ = __webpack_exports__["default"];
	/******/ 	return __webpack_exports__;
	/******/ })()
	;
	}); 
} (vueCleave));

var vueCleaveExports = vueCleave.exports;
const Cleave = /*@__PURE__*/getDefaultExportFromCjs(vueCleaveExports);

const _sfc_main = {
  components: { Cleave },
  props: {
    placeholder: {
      type: String,
      default: "Search"
    },
    label: {
      type: String
    },
    classLabel: {
      type: String,
      default: " "
    },
    classInput: {
      type: String,
      default: "classinput"
    },
    type: {
      type: String,
      default: "text"
      //required: true,
    },
    name: {
      type: String
    },
    modelValue: {
      type: String,
      default: ""
    },
    error: {
      type: String
    },
    hasicon: {
      type: Boolean,
      default: false
    },
    isReadonly: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    },
    horizontal: {
      type: Boolean,
      default: false
    },
    validate: {
      type: String
    },
    msgTooltip: {
      type: Boolean,
      default: false
    },
    description: {
      type: String
    },
    icon: {
      type: String
    },
    isMask: {
      type: Boolean,
      default: false
    },
    options: {
      type: Object,
      default: () => ({
        creditCard: true,
        delimiter: "-"
      })
    }
  },
  data() {
    return {
      types: this.type
    };
  },
  methods: {
    toggleType() {
      this.types = this.types === "text" ? "password" : "text";
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_cleave = resolveComponent("cleave");
  const _component_AppIcon = __nuxt_component_1$1;
  _push(`<div${ssrRenderAttrs(mergeProps({
    class: ["formGroup relative", `${$props.error ? "has-error" : ""}  ${$props.horizontal ? "flex" : ""}  ${$props.validate ? "is-valid" : ""} `]
  }, _attrs))}>`);
  if ($props.label) {
    _push(`<label class="${ssrRenderClass(`${$props.classLabel} ${$props.horizontal ? "flex-0 mr-6 md:w-[100px] w-[60px] break-words" : ""}  inline-block input-label text-sm !text-[#1B2B41B8]`)}"${ssrRenderAttr("for", $props.name)}>${ssrInterpolate($props.label)}</label>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<div class="${ssrRenderClass([$props.horizontal ? "flex-1" : "", "relative"])}">`);
  if (!$props.isMask) {
    _push(`<input${ssrRenderAttr("type", $data.types)}${ssrRenderAttr("name", $props.name)}${ssrRenderAttr("placeholder", $props.placeholder)} class="${ssrRenderClass(`${$props.classInput} input-control w-full block focus:outline-none h-[44px] ${$props.hasicon ? "pr-10" : ""} `)}"${ssrRenderAttr("value", $props.modelValue)}${ssrRenderAttr("error", $props.error)}${ssrRenderAttr("id", $props.name)}${ssrIncludeBooleanAttr($props.isReadonly) ? " readonly" : ""}${ssrIncludeBooleanAttr($props.disabled) ? " disabled" : ""}${ssrRenderAttr("validate", $props.validate)}>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.isMask) {
    _push(ssrRenderComponent(_component_cleave, {
      class: `${$props.classInput} cleave input-control block w-full focus:outline-none h-[44px] `,
      name: $props.name,
      placeholder: $props.placeholder,
      value: $props.modelValue,
      onInput: ($event) => _ctx.$emit("update:modelValue", $event.target.value),
      error: $props.error,
      id: $props.name,
      readonly: $props.isReadonly,
      disabled: $props.disabled,
      validate: $props.validate,
      options: $props.options,
      modelValue: "modelValue"
    }, null, _parent));
  } else {
    _push(`<!---->`);
  }
  _push(`<div class="flex text-xl absolute right-[14px] top-1/2 -translate-y-1/2">`);
  if ($props.hasicon) {
    _push(`<span class="cursor-pointer text-secondary-500">`);
    if ($data.types === "password") {
      _push(ssrRenderComponent(_component_AppIcon, {
        icon: "la:eye",
        class: "text-[#666]"
      }, null, _parent));
    } else {
      _push(ssrRenderComponent(_component_AppIcon, {
        icon: "la:eye-slash",
        class: "text-[#666]"
      }, null, _parent));
    }
    _push(`</span>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.error) {
    _push(`<span class="text-danger-500">`);
    _push(ssrRenderComponent(_component_AppIcon, { icon: "heroicons-outline:information-circle" }, null, _parent));
    _push(`</span>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.validate) {
    _push(`<span class="text-success-500">`);
    _push(ssrRenderComponent(_component_AppIcon, { icon: "bi:check-lg" }, null, _parent));
    _push(`</span>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.icon) {
    _push(`<span class="text-[#666]">`);
    _push(ssrRenderComponent(_component_AppIcon, { icon: $props.icon }, null, _parent));
    _push(`</span>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div>`);
  if ($props.error) {
    _push(`<span class="" class="${ssrRenderClass([
      $props.msgTooltip ? " inline-block bg-danger-500 text-white text-[10px] px-2 py-1 rounded" : " text-danger-500 block text-sm",
      ""
    ])}">${ssrInterpolate($props.error)}</span>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.validate) {
    _push(`<span class="" class="${ssrRenderClass([
      $props.msgTooltip ? " inline-block bg-success-500 text-white text-[10px] px-2 py-1 rounded" : " text-success-500 block text-sm",
      ""
    ])}">${ssrInterpolate($props.validate)}</span>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.description) {
    _push(`<span class="block text-secondary-500 font-light leading-4 text-xs mt-2">${ssrInterpolate($props.description)}</span>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Textinput/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_1 as _ };
//# sourceMappingURL=index-eSH9oSpY.mjs.map
