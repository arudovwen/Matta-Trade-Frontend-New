import { useSSRContext, inject, computed, provide, mergeProps, unref, ref, resolveDirective, withCtx, openBlock, createBlock, toDisplayString, createVNode, Fragment, renderList, createCommentVNode, createTextVNode, Transition, withDirectives, vModelCheckbox, vModelText, watch } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrGetDirectiveProps, ssrRenderClass, ssrRenderList, ssrInterpolate, ssrRenderStyle, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain, ssrLooseEqual } from 'vue/server-renderer';
import { _ as __nuxt_component_0$1 } from './index-4NCxcAqd.mjs';
import { _ as __unimport_currencyFormat } from './currencyFormat-ET0sIbrj.mjs';
import { ChatBubbleLeftIcon, HeartIcon } from '@heroicons/vue/24/outline';
import { useRoute } from 'vue-router';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import { _ as __nuxt_component_1$1 } from './nuxt-img-qJohECzX.mjs';
import { Carousel, Slide } from 'vue3-carousel';
import { _ as __nuxt_component_1 } from './AppIcon-D3CPABPP.mjs';
import Editor from '@tinymce/tinymce-vue';
import { Listbox, ListboxButton, ListboxOptions, ListboxOption, Combobox, ComboboxButton, TransitionRoot, ComboboxOptions, ComboboxOption } from '@headlessui/vue';
import { _ as __nuxt_component_0 } from './IndexModal-vEF7RYpX.mjs';

const _sfc_main$b = {
  __name: "CartCounter",
  __ssrInlineRender: true,
  setup(__props) {
    const product = inject("product");
    const selectedPackage = ref("");
    const counter = ref(1);
    const totalAmount = computed(() => {
      if (!selectedPackage.value)
        return 0;
      return Number(selectedPackage.value.amount) * counter.value;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex items-center gap-x-3 mb-4 w-full" }, _attrs))}><div class="flex items-center bg-[#F1F3F5] rounded-lg relative w-[55%] pr-4">`);
      if (unref(product) && unref(product).packagesAvailable) {
        _push(`<select class="py-5 text-[13px] px-6 bg-transparent capitlize md:uppercase text-matta-black w-full"><option value=""${ssrIncludeBooleanAttr(Array.isArray(selectedPackage.value) ? ssrLooseContain(selectedPackage.value, "") : ssrLooseEqual(selectedPackage.value, "")) ? " selected" : ""}>Select a package</option><!--[-->`);
        ssrRenderList(unref(product).packagesAvailable, (n, i) => {
          _push(`<option${ssrRenderAttr("value", n)}>${ssrInterpolate(n.package ? `${n.package.title} ${n.size}  ${n.unit}` : "-")}</option>`);
        });
        _push(`<!--]--></select>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="flex gap-x-3 items-center w-[45%]"><div class="flex items-center justify-center gap-x-16 w-full lg:w-[250px] rounded-lg bg-[#F1F3F5] relative py-5 text-[13px] px-6 uppercase text-matta-black"><button${ssrIncludeBooleanAttr(counter.value == 0) ? " disabled" : ""}><i class="uil uil-minus"></i></button><span>${ssrInterpolate(counter.value)}</span><button><i class="uil uil-plus"></i></button></div><button class="py-5 text-[13px] px-6 bg-matta-black hidden md:flex w-full justify-center text-white rounded-lg items-center hover:bg-matta-black/80 uppercase text-sm font-normal leading-[unset] gap-x-4"><span>add to cart</span> <i class="uil uil-minus"></i><span class="font-medium">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(totalAmount.value))}</span></button></div></div>`);
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/preview/CartCounter.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const CartCounter = _sfc_main$b;
const _sfc_main$a = {
  __name: "TopBanner",
  __ssrInlineRender: true,
  setup(__props) {
    const formatMoney = inject("formatMoney");
    const product = inject("product");
    const defaultPackage = inject("defaultPackage");
    const route = useRoute();
    const crumbs = [
      { name: "markets", url: `/markets` },
      {
        name: route.params.market,
        url: `/market/${route.params.market}/${route.params.marketId}`
      },
      { name: route.params.type, url: `#` }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Breadcrumbs = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-8 bg-white rounded-lg bg-img" }, _attrs))} data-v-46a470a7><div class="mb-12" data-v-46a470a7>`);
      _push(ssrRenderComponent(_component_Breadcrumbs, {
        manual: true,
        crumbs
      }, null, _parent));
      _push(`</div><div class="grid grid-cols-3 justify-between items-end mb-16" data-v-46a470a7><h1 class="text-[48px] leading-[56px] text-matta-black col-span-1 font-medium capitalize" data-v-46a470a7>${ssrInterpolate(unref(product).name)}</h1><div class="col-span-2 flex items-center justify-end gap-x-12" data-v-46a470a7><div class="px-4 mr-6" data-v-46a470a7><p class="text-xs text-[#ddd] font-normal uppercase" data-v-46a470a7>from</p><p class="text-matta-black" data-v-46a470a7><span class="font-medium text-xl" data-v-46a470a7>\u20A6${ssrInterpolate(unref(defaultPackage) ? unref(formatMoney)(unref(defaultPackage).amount) : 0)}</span>/${ssrInterpolate(unref(defaultPackage) ? unref(defaultPackage).unit : "Kg")}</p></div><div class="flex gap-x-2" data-v-46a470a7><button class="w-[46px] h-[46px] rounded-full flex items-center justify-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black border border-[#ddd] shadow-sm" data-v-46a470a7>`);
      _push(ssrRenderComponent(unref(ChatBubbleLeftIcon), { class: "text-matta-black w-5 h-5" }, null, _parent));
      _push(`</button><button class="w-[46px] h-[46px] rounded-full flex items-center justify-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black border border-[#ddd] shadow-sm" data-v-46a470a7>`);
      {
        _push(ssrRenderComponent(unref(HeartIcon), { class: "w-5 h-5 text-matta-black" }, null, _parent));
      }
      {
        _push(`<!---->`);
      }
      _push(`</button></div><button${ssrIncludeBooleanAttr(!unref(product).sampleAvailable) ? " disabled" : ""} class="${ssrRenderClass([{ "opacity-50 cursor-not-allowed": !unref(product).sampleAvailable }, "flex items-center uppercase whitespace-nowrap text-matta-black bg-transparent hover:text-white hover:bg-matta-black py-2 px-3 md:py-3 md:px-6 border rounded-full border-[#ddd] md:leading-5 text-[10px] sm:text-[13px] shadow-sm"])}" data-v-46a470a7><span data-v-46a470a7>Request a sample</span></button><button${ssrIncludeBooleanAttr(!unref(product).sampleAvailable) ? " disabled" : ""} class="flex items-center uppercase whitespace-nowrap text-matta-black bg-transparent hover:text-white hover:bg-matta-black py-2 px-3 md:py-3 md:px-6 border rounded-full border-[#ddd] md:leading-5 text-[10px] sm:text-[13px] shadow-sm" data-v-46a470a7><span data-v-46a470a7>Request a quote</span></button></div></div>`);
      _push(ssrRenderComponent(CartCounter, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/preview/TopBanner.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const TopBanner = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["__scopeId", "data-v-46a470a7"]]);
const _sfc_main$9 = {
  __name: "SideContent",
  __ssrInlineRender: true,
  setup(__props) {
    const product = inject("product");
    const myslider = ref(null);
    const breakpoints = {
      250: {
        itemsToShow: 1,
        snapAlign: "center"
      }
    };
    const producer = ref(null);
    ref(null);
    ref([]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtImg = __nuxt_component_1$1;
      if (unref(product)) {
        _push(`<aside${ssrRenderAttrs(mergeProps({ class: "rounded-xl grid grid-cols-1 gap-y-3" }, _attrs))}>`);
        if (unref(product) && unref(product).productExperts && unref(product).productExperts.length) {
          _push(`<article class="p-6 lg:p-8 rounded-xl bg-[#F1F3F5]"><div class="flex justify-between items-center"><h5 class="font-medium text-lg mb-6">Experts</h5><span class="flex gap-x-3"><span class="w-6 h-6 flex items-center justify-center text-[10px] bg-[#E7EBEE] rounded-full hover:shadow cursor-pointer"><i class="uil uil-arrow-left text-lg"></i></span><span class="w-6 h-6 flex items-center justify-center text-[10px] bg-[#E7EBEE] rounded-full hover:shadow cursor-pointer"><i class="uil uil-arrow-right text-lg"></i></span></span></div>`);
          if (unref(product) && unref(product).productExperts) {
            _push(ssrRenderComponent(unref(Carousel), {
              ref_key: "myslider",
              ref: myslider,
              breakpoints,
              class: "py-5"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(`<!--[-->`);
                  ssrRenderList(unref(product).productExperts, (item) => {
                    _push2(ssrRenderComponent(unref(Slide), {
                      key: item.email,
                      class: "px-2 py-5"
                    }, {
                      default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                        if (_push3) {
                          _push3(`<div class="w-full"${_scopeId2}><div class="mb-5 text-center"${_scopeId2}><div class="w-28 h-28 rounded-full mx-auto border border-white mb-4 overflow-hidden flex items-center justify-center"${_scopeId2}>`);
                          _push3(ssrRenderComponent(_component_NuxtImg, {
                            src: item.photo ? item.photo : require("~/assets/img/avatar1.svg"),
                            class: "w-full h-full"
                          }, null, _parent3, _scopeId2));
                          _push3(`</div><div${_scopeId2}><p class="font-medium text-base text-matta-black"${_scopeId2}>${ssrInterpolate(item.name)}</p><p class="font-normal text-sm text-[#ABABAB]"${_scopeId2}>${ssrInterpolate(item.role)}</p></div></div><table class="mb-6 w-full table-auto"${_scopeId2}><tbody${_scopeId2}><tr${_scopeId2}><td class="font-normal text-sm text-[#ABABAB] text-left"${_scopeId2}> E-mail </td><td class="font-normal text-sm text-matta-black text-right"${_scopeId2}>${ssrInterpolate(item.email || "-")}</td></tr><tr${_scopeId2}><td class="font-normal text-sm text-[#ABABAB] text-left"${_scopeId2}> Phone number </td><td class="font-normal text-sm text-matta-black text-right"${_scopeId2}>${ssrInterpolate(item.phone || "-")}</td></tr><tr${_scopeId2}><td class="font-normal text-sm text-[#ABABAB] text-left"${_scopeId2}> Language </td><td class="font-normal text-sm text-matta-black text-right"${_scopeId2}>${ssrInterpolate(item.language || "-")}</td></tr></tbody></table><a${ssrRenderAttr("href", `mailto:${item.email}`)}${_scopeId2}><button class="uppercase w-full text-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black py-4 px-3 md:px-6 border rounded-full border-[#ABABAB] md:leading-5 text-[13px] shadow-sm"${_scopeId2}><span${_scopeId2}>send message</span></button></a></div>`);
                        } else {
                          return [
                            createVNode("div", { class: "w-full" }, [
                              createVNode("div", { class: "mb-5 text-center" }, [
                                createVNode("div", { class: "w-28 h-28 rounded-full mx-auto border border-white mb-4 overflow-hidden flex items-center justify-center" }, [
                                  createVNode(_component_NuxtImg, {
                                    src: item.photo ? item.photo : require("~/assets/img/avatar1.svg"),
                                    class: "w-full h-full"
                                  }, null, 8, ["src"])
                                ]),
                                createVNode("div", null, [
                                  createVNode("p", { class: "font-medium text-base text-matta-black" }, toDisplayString(item.name), 1),
                                  createVNode("p", { class: "font-normal text-sm text-[#ABABAB]" }, toDisplayString(item.role), 1)
                                ])
                              ]),
                              createVNode("table", { class: "mb-6 w-full table-auto" }, [
                                createVNode("tbody", null, [
                                  createVNode("tr", null, [
                                    createVNode("td", { class: "font-normal text-sm text-[#ABABAB] text-left" }, " E-mail "),
                                    createVNode("td", { class: "font-normal text-sm text-matta-black text-right" }, toDisplayString(item.email || "-"), 1)
                                  ]),
                                  createVNode("tr", null, [
                                    createVNode("td", { class: "font-normal text-sm text-[#ABABAB] text-left" }, " Phone number "),
                                    createVNode("td", { class: "font-normal text-sm text-matta-black text-right" }, toDisplayString(item.phone || "-"), 1)
                                  ]),
                                  createVNode("tr", null, [
                                    createVNode("td", { class: "font-normal text-sm text-[#ABABAB] text-left" }, " Language "),
                                    createVNode("td", { class: "font-normal text-sm text-matta-black text-right" }, toDisplayString(item.language || "-"), 1)
                                  ])
                                ])
                              ]),
                              createVNode("a", {
                                href: `mailto:${item.email}`
                              }, [
                                createVNode("button", { class: "uppercase w-full text-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black py-4 px-3 md:px-6 border rounded-full border-[#ABABAB] md:leading-5 text-[13px] shadow-sm" }, [
                                  createVNode("span", null, "send message")
                                ])
                              ], 8, ["href"])
                            ])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent2, _scopeId));
                  });
                  _push2(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(product).productExperts, (item) => {
                      return openBlock(), createBlock(unref(Slide), {
                        key: item.email,
                        class: "px-2 py-5"
                      }, {
                        default: withCtx(() => [
                          createVNode("div", { class: "w-full" }, [
                            createVNode("div", { class: "mb-5 text-center" }, [
                              createVNode("div", { class: "w-28 h-28 rounded-full mx-auto border border-white mb-4 overflow-hidden flex items-center justify-center" }, [
                                createVNode(_component_NuxtImg, {
                                  src: item.photo ? item.photo : require("~/assets/img/avatar1.svg"),
                                  class: "w-full h-full"
                                }, null, 8, ["src"])
                              ]),
                              createVNode("div", null, [
                                createVNode("p", { class: "font-medium text-base text-matta-black" }, toDisplayString(item.name), 1),
                                createVNode("p", { class: "font-normal text-sm text-[#ABABAB]" }, toDisplayString(item.role), 1)
                              ])
                            ]),
                            createVNode("table", { class: "mb-6 w-full table-auto" }, [
                              createVNode("tbody", null, [
                                createVNode("tr", null, [
                                  createVNode("td", { class: "font-normal text-sm text-[#ABABAB] text-left" }, " E-mail "),
                                  createVNode("td", { class: "font-normal text-sm text-matta-black text-right" }, toDisplayString(item.email || "-"), 1)
                                ]),
                                createVNode("tr", null, [
                                  createVNode("td", { class: "font-normal text-sm text-[#ABABAB] text-left" }, " Phone number "),
                                  createVNode("td", { class: "font-normal text-sm text-matta-black text-right" }, toDisplayString(item.phone || "-"), 1)
                                ]),
                                createVNode("tr", null, [
                                  createVNode("td", { class: "font-normal text-sm text-[#ABABAB] text-left" }, " Language "),
                                  createVNode("td", { class: "font-normal text-sm text-matta-black text-right" }, toDisplayString(item.language || "-"), 1)
                                ])
                              ])
                            ]),
                            createVNode("a", {
                              href: `mailto:${item.email}`
                            }, [
                              createVNode("button", { class: "uppercase w-full text-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black py-4 px-3 md:px-6 border rounded-full border-[#ABABAB] md:leading-5 text-[13px] shadow-sm" }, [
                                createVNode("span", null, "send message")
                              ])
                            ], 8, ["href"])
                          ])
                        ]),
                        _: 2
                      }, 1024);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`</article>`);
        } else {
          _push(`<!---->`);
        }
        if (producer.value) {
          _push(`<article class="p-6 lg:p-8 rounded-xl bg-[#F1F3F5]"><h5 class="font-medium text-lg mb-6">Producer</h5><div class="flex items-center gap-x-4 mb-6"><div class="w-20 h-20 rounded-xl bg-white flex items-center justify-center">`);
          if (producer.value.logo) {
            _push(ssrRenderComponent(_component_NuxtImg, {
              src: producer.value.logo,
              alt: "logo",
              class: "rounded-xl"
            }, null, _parent));
          } else {
            _push(`<span class="text-lg font-bold">${ssrInterpolate(producer.value.title.slice(0, 1).toUpperCase())}</span>`);
          }
          _push(`</div><div><p class="font-medium text-base text-matta-black">${ssrInterpolate(producer.value.title)}</p>`);
          if (producer.value.location) {
            _push(`<p class="font-normal text-sm text-matta-black"><i class="uil uil-map-marker"></i> ${ssrInterpolate(producer.value.location)}</p>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div></div><button class="uppercase w-full text-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black py-4 px-3 md:px-6 border rounded-full border-[#ABABAB] md:leading-5 text-[13px] shadow-sm"><span>view more products</span></button></article>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</aside>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/preview/SideContent.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const _sfc_main$8 = {
  __name: "ProductDocument",
  __ssrInlineRender: true,
  setup(__props) {
    const product = inject("product");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><section class="flex flex-col gap-y-3"><div class="bg-white p-6 lg:p-8 rounded-lg"><div class=""><!--[-->`);
      ssrRenderList(unref(product).documentInfoModels, (n, id) => {
        _push(`<div class="flex items-center gap-x-4 mb-3"><div class="border rounded-xl p-5 flex flex-1 justify-between"><div class="flex gap-x-3 items-center"><i class="uil uil-file text-2xl"></i><div><p class="text-sm text-matta-black capitalize">${ssrInterpolate(n.fileName)}</p><p class="text-xs text-[#ABABAB]">${ssrInterpolate(parseInt(n.fileSize / 1e3))}kb </p></div></div><div class="flex items-center gap-x-5"><div class="flex-1">${ssrInterpolate(n.category)}</div><span class="text-gray-200 text-3xl font-light">| </span><div class="flex items-center"><a${ssrRenderAttr("href", n.documentUrl)}${ssrRenderAttr("download", n.fileName)}><span class="border border-gray-300 rounded-full h-8 w-8 flex items-center justify-center"><i class="uil uil-import"></i></span></a></div></div></div></div>`);
      });
      _push(`<!--]--></div></div></section><div></div><!--]-->`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/preview/ProductDocument.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const _sfc_main$7 = {
  __name: "ProductProperties",
  __ssrInlineRender: true,
  setup(__props) {
    const tdata = [
      {
        product: "Sieve Retention (at min. 63 \u03BCm)",
        value: "20",
        units: "kg",
        orders: 4
      },
      {
        product: "Sieve Retention (at min. 63 \u03BCm)",
        value: "20",
        units: "kg",
        orders: 4
      },
      {
        product: "Sieve Retention (at min. 63 \u03BCm)",
        value: "20",
        units: "kg",
        orders: 4
      }
    ];
    const theads = ["product", "value", "units", "orders"];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "p-8" }, _attrs))}><p class="mb-16 text-base"> Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui ipsa expedita voluptates, porro sint, corrupti deserunt commodi enim optio tempore maiores exercitationem illo dicta! Quo optio cumque veniam quas explicabo? </p><div><h3 class="mb-4 text-lg">Physical Properties</h3><table class="w-full"><thead><tr><!--[-->`);
      ssrRenderList(theads, (th) => {
        _push(`<th class="text-[#B6B7B9] text-[13px] uppercase py-4 px-2 border-b text-left">${ssrInterpolate(th)}</th>`);
      });
      _push(`<!--]--></tr></thead><tbody><!--[-->`);
      ssrRenderList(tdata, (td) => {
        _push(`<tr><td class="text-sm text-matta-black py-4 px-2 border-b text-left">${ssrInterpolate(td.product)}</td><td class="text-sm text-matta-black py-4 px-2 border-b text-left">${ssrInterpolate(td.value)}</td><td class="text-sm text-matta-black py-4 px-2 border-b text-left">${ssrInterpolate(td.units)}</td><td class="text-sm text-matta-black py-4 px-2 border-b text-left">${ssrInterpolate(td.orders)}</td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></section>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/preview/ProductProperties.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const _sfc_main$6 = {
  __name: "PackageAvailability",
  __ssrInlineRender: true,
  setup(__props) {
    const product = inject("product");
    const theads = ["size", "availability", "purity", "colour", "price"];
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "p-8" }, _attrs))}><div>`);
      if (unref(product)) {
        _push(`<table class="w-full"><thead><tr><!--[-->`);
        ssrRenderList(theads, (th) => {
          _push(`<th class="text-[#B6B7B9] text-[13px] uppercase py-4 px-2 border-b text-left font-medium">${ssrInterpolate(th)}</th>`);
        });
        _push(`<!--]-->`);
        if (unref(product).packagesAvailable.length) {
          _push(`<th class="text-[#B6B7B9] text-[13px] uppercase py-4 px-2 border-b text-left font-medium"> price per ${ssrInterpolate((_a = unref(product).packagesAvailable[0]) == null ? void 0 : _a.unit)}</th>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</tr></thead><tbody><!--[-->`);
        ssrRenderList(unref(product).packagesAvailable, (td, id) => {
          _push(`<tr><td class="text-sm text-matta-black py-4 px-2 border-b text-left">${ssrInterpolate(td.size)}${ssrInterpolate(td.unit)}</td><td class="text-sm text-matta-black py-4 px-2 border-b text-left">`);
          if (td.isAvailable) {
            _push(`<i class="uil uil-check text-green-500"></i>`);
          } else {
            _push(`<!---->`);
          }
          if (!td.isAvailable) {
            _push(`<i class="uil uil-minus text-gray-400"></i>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</td><td class="text-sm text-matta-black py-4 px-2 border-b text-left">${ssrInterpolate(td.purity)}% </td><td class="text-sm text-matta-black py-4 px-2 border-b text-left">${ssrInterpolate(td.color)}</td><td class="text-sm text-matta-black py-4 px-2 border-b text-left">${ssrInterpolate(unref(product).hidePrice ? "-" : ("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(td.amount))}</td><td class="text-sm text-matta-black py-4 px-2 border-b text-left">${ssrInterpolate(unref(product).hidePrice ? "-" : ("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(td.amount))}</td></tr>`);
        });
        _push(`<!--]--></tbody></table>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></section>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/preview/PackageAvailability.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const _sfc_main$5 = {
  __name: "ProductContent",
  __ssrInlineRender: true,
  setup(__props) {
    const myslide = ref(null);
    const breakpoints = {
      250: {
        itemsToShow: 1,
        snapAlign: "center"
      }
    };
    const product = inject("product");
    const sideData = [
      {
        id: "applications",
        title: "Identification & Functionality"
      },
      {
        id: "features",
        title: "Features & Benefits"
      },
      {
        id: "tech",
        title: "Technical Details & Test Data"
      },
      {
        id: "property",
        title: "Properties"
      },
      {
        id: "compliance",
        title: "Regulatory & Compliance"
      }
    ];
    const active = ref("overview");
    const compliance = computed(() => {
      if (!product || !product.propertyItems)
        return;
      return product.propertyItems.compliance;
    });
    const property = computed(() => {
      if (!product || !product.propertyItems)
        return;
      return product.propertyItems.property;
    });
    const technical = computed(() => {
      if (!product || !product.propertyItems)
        return;
      return product.propertyItems.technical;
    });
    const openIndex = ref(["tech"]);
    const count = computed(() => {
      if (!myslide.value)
        return 0;
      return Number(myslide.value.data.currentSlide.value) + 1;
    });
    const maxcount = computed(() => {
      if (!myslide.value)
        return 0;
      return myslide.value.data.slidesCount;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtImg = __nuxt_component_1$1;
      if (unref(product)) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid grid-cols-1 gap-12 bg-white rounded-xl p-6 lg:p-8" }, _attrs))}><div class="bg-[#F1F3F5] flex h-[350px] rounded-xl">`);
        if (unref(product).gallery && unref(product).gallery.length) {
          _push(`<div class="flex-1 rounded-lg overflow-hidden relative">`);
          if (unref(product).gallery) {
            _push(ssrRenderComponent(unref(Carousel), {
              ref_key: "myslide",
              ref: myslide,
              breakpoints,
              class: "h-full"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(`<!--[-->`);
                  ssrRenderList(unref(product).gallery, (item) => {
                    _push2(ssrRenderComponent(unref(Slide), {
                      key: item,
                      class: ""
                    }, {
                      default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                        if (_push3) {
                          _push3(ssrRenderComponent(_component_NuxtImg, {
                            src: item,
                            class: "h-[350px] w-full object-cover",
                            alt: "alt"
                          }, null, _parent3, _scopeId2));
                        } else {
                          return [
                            createVNode(_component_NuxtImg, {
                              src: item,
                              class: "h-[350px] w-full object-cover",
                              alt: "alt"
                            }, null, 8, ["src"])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent2, _scopeId));
                  });
                  _push2(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(product).gallery, (item) => {
                      return openBlock(), createBlock(unref(Slide), {
                        key: item,
                        class: ""
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_NuxtImg, {
                            src: item,
                            class: "h-[350px] w-full object-cover",
                            alt: "alt"
                          }, null, 8, ["src"])
                        ]),
                        _: 2
                      }, 1024);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent));
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        if (unref(product).gallery && unref(product).gallery.length) {
          _push(`<div class="flex flex-col justify-between w-[70px] p-4 text-center items-center"><div class="flex flex-col gap-y-2 items-center text-center">`);
          if (count.value) {
            _push(`<p>${ssrInterpolate(count.value)}</p>`);
          } else {
            _push(`<!---->`);
          }
          _push(`<div class="h-[50px] border w-[1px] border-[#DDDDDD] bg-[#DDDDDD]"></div>`);
          if (maxcount.value) {
            _push(`<p>${ssrInterpolate(maxcount.value)}</p>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div><div><span class="grid gap-y-5"><div class="w-8 h-8 text-base bg-[#E7EBEE] rounded-full flex items-center justify-center cursor-pointer"><i class="uil uil-arrow-left"></i></div><div class="w-8 h-8 text-base bg-[#E7EBEE] rounded-full flex items-center justify-center cursor-pointer"><i class="uil uil-arrow-right"></i></div></span></div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><div class="flex gap-x-4"><button class="${ssrRenderClass([
          active.value == "overview" ? "bg-matta-black text-white" : "text-matta-black",
          "flex gap-x-2 items-center uppercase hover:text-white hover:bg-matta-black py-2 px-3 md:py-4 md:px-6 border rounded-lg border-[#E7EBEE] md:leading-5 text-[10px] sm:text-[13px] shadow-sm"
        ])}"><i class="uil uil-apps"></i><span class="hidden md:inline">|</span> overview </button><button class="${ssrRenderClass([
          active.value == "properties" ? "bg-matta-black text-white" : "text-matta-black",
          "flex gap-x-2 items-center uppercase text-matta-black hover:text-white hover:bg-matta-black py-2 px-3 md:py-4 md:px-6 border rounded-lg border-[#E7EBEE] md:leading-5 text-[10px] sm:text-[13px] shadow-sm"
        ])}"><i class="uil uil-layer-group"></i><span class="hidden md:inline">|</span> properties </button><button class="${ssrRenderClass([
          active.value == "packages" ? "bg-matta-black text-white" : "text-matta-black",
          "flex gap-x-2 items-center uppercase text-matta-black hover:text-white hover:bg-matta-black py-2 px-2 md:py-4 md:px-6 border rounded-lg border-[#E7EBEE] md:leading-5 text-[10px] sm:text-[13px] shadow-sm"
        ])}"><i class="uil uil-box"></i><span class="hidden md:inline">|</span> packaging &amp; availability </button><button class="${ssrRenderClass([
          active.value == "document" ? "bg-matta-black text-white" : "text-matta-black",
          "flex gap-x-2 items-center uppercase text-matta-black hover:text-white hover:bg-matta-black py-2 px-2 md:py-4 md:px-6 border rounded-lg border-[#E7EBEE] md:leading-5 text-[10px] sm:text-[13px] shadow-sm"
        ])}"><i class="uil uil-file"></i><span class="hidden md:inline">|</span> documents </button></div>`);
        if (active.value == "overview") {
          _push(`<div class="flex flex-col gap-y-6"><div><p class="text-base text-matta-black mb-2">${ssrInterpolate(unref(product).description)}</p></div><!--[-->`);
          ssrRenderList(sideData, (d) => {
            _push(`<div><div class="grid grid-cols-3 justify-between items-start"><span class="col-span-2 text-matta-black font-medium text-2xl">${ssrInterpolate(d.title)}</span>`);
            if (!openIndex.value.includes(d.id)) {
              _push(`<span class="text-right text-lg"><i class="uil uil-plus"></i></span>`);
            } else {
              _push(`<!---->`);
            }
            if (openIndex.value.includes(d.id)) {
              _push(`<span class="text-right text-lg"><i class="uil uil-minus"></i></span>`);
            } else {
              _push(`<!---->`);
            }
            _push(`</div><hr class="border-[#DDDDDD] my-4">`);
            if (openIndex.value.includes(d.id)) {
              _push(`<div>`);
              if (technical.value && d.id === "tech") {
                _push(`<div>`);
                if (technical.value.propertyItems && technical.value.propertyItems.length) {
                  _push(`<div class="grid grid-cols-3 gap-4"><!--[-->`);
                  ssrRenderList(technical.value.propertyItems, (n, idx) => {
                    _push(`<div class="">`);
                    if (n.property) {
                      _push(`<h5 class="text-[#B6B7B9] text-[13px] mb-3 uppercase">${ssrInterpolate(n.property.name)}</h5>`);
                    } else {
                      _push(`<!---->`);
                    }
                    _push(`<!--[-->`);
                    ssrRenderList(n.propertyValue, (sub, i) => {
                      _push(`<p class="text-matta-black text-base mb-1">${ssrInterpolate(sub)}</p>`);
                    });
                    _push(`<!--]--></div>`);
                  });
                  _push(`<!--]--></div>`);
                } else {
                  _push(`<!---->`);
                }
                if (technical.value.subSection) {
                  _push(`<div><!--[-->`);
                  ssrRenderList(technical.value.subSection, (n, idx) => {
                    _push(`<div class=""><p class="mb-4">${ssrInterpolate(n.subSectionName)}</p><div class="mb-4 description">${n.description}</div></div>`);
                  });
                  _push(`<!--]--></div>`);
                } else {
                  _push(`<!---->`);
                }
                _push(`</div>`);
              } else {
                _push(`<!---->`);
              }
              if (compliance.value && d.id === "compliance") {
                _push(`<div>`);
                if (compliance.value.propertyItems && compliance.value.propertyItems.length) {
                  _push(`<div class="grid grid-cols-3 gap-4"><!--[-->`);
                  ssrRenderList(compliance.value.propertyItems, (n, idx) => {
                    _push(`<div class="">`);
                    if (n.property) {
                      _push(`<h5 class="text-[#B6B7B9] text-[13px] mb-3 uppercase">${ssrInterpolate(n.property.name)}</h5>`);
                    } else {
                      _push(`<!---->`);
                    }
                    _push(`<!--[-->`);
                    ssrRenderList(n.propertyValue, (sub, i) => {
                      _push(`<p class="text-matta-black text-base mb-1">${ssrInterpolate(sub)}</p>`);
                    });
                    _push(`<!--]--></div>`);
                  });
                  _push(`<!--]--></div>`);
                } else {
                  _push(`<!---->`);
                }
                if (compliance.value.subSection) {
                  _push(`<div><!--[-->`);
                  ssrRenderList(compliance.value.subSection, (n, idx) => {
                    _push(`<div class=""><p class="mb-4">${ssrInterpolate(n.subSectionName)}</p><div class="mb-4 description">${n.description}</div></div>`);
                  });
                  _push(`<!--]--></div>`);
                } else {
                  _push(`<!---->`);
                }
                _push(`</div>`);
              } else {
                _push(`<!---->`);
              }
              if (property.value && d.id === "property") {
                _push(`<div>`);
                if (property.value.propertyItems && property.value.propertyItems.length) {
                  _push(`<div class="grid grid-cols-3 gap-4"><!--[-->`);
                  ssrRenderList(property.value.propertyItems, (n, idx) => {
                    _push(`<div class="">`);
                    if (n.property) {
                      _push(`<h5 class="text-[#B6B7B9] text-[13px] mb-3 uppercase">${ssrInterpolate(n.property.name)}</h5>`);
                    } else {
                      _push(`<!---->`);
                    }
                    _push(`<!--[-->`);
                    ssrRenderList(n.propertyValue, (sub, i) => {
                      _push(`<p class="text-matta-black text-base mb-1">${ssrInterpolate(sub)}</p>`);
                    });
                    _push(`<!--]--></div>`);
                  });
                  _push(`<!--]--></div>`);
                } else {
                  _push(`<!---->`);
                }
                if (property.value.subSection) {
                  _push(`<div><!--[-->`);
                  ssrRenderList(property.value.subSection, (n, idx) => {
                    _push(`<div class=""><p class="mb-4">${ssrInterpolate(n.subSectionName)}</p><div class="mb-4 description">${n.description}</div></div>`);
                  });
                  _push(`<!--]--></div>`);
                } else {
                  _push(`<!---->`);
                }
                _push(`</div>`);
              } else {
                _push(`<!---->`);
              }
              _push(`</div>`);
            } else {
              _push(`<!---->`);
            }
            _push(`</div>`);
          });
          _push(`<!--]--></div>`);
        } else {
          _push(`<!---->`);
        }
        if (active.value == "document") {
          _push(ssrRenderComponent(unref(_sfc_main$8), null, null, _parent));
        } else {
          _push(`<!---->`);
        }
        if (active.value == "properties") {
          _push(ssrRenderComponent(unref(_sfc_main$7), null, null, _parent));
        } else {
          _push(`<!---->`);
        }
        if (active.value == "packages") {
          _push(ssrRenderComponent(unref(_sfc_main$6), null, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/preview/ProductContent.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const _sfc_main$4 = {
  __name: "BackBanner",
  __ssrInlineRender: true,
  setup(__props) {
    inject("togglePreview");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-matta-black text-white p-6 lg:p-8 rounded-lg flex justify-between" }, _attrs))}><div><h5 class="uppercase text-[#ABABAB] text-[13px] mb-4">product preview</h5><h3 class="text-2xl text-white font-medium mb-2"> Preview how this product looks to buyers </h3><p class="text-white text-base"> You can go back to editing or finish and publish the product to catalog. </p></div><div><div class="flex items-end gap-x-4 h-full"><button class="bg-white text-matta-black rounded-full px-6 py-4 hover:bg-slate-50 text-[13px]"> BACK TO EDITING </button></div></div></div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/preview/BackBanner.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {
  __name: "IndexPreview",
  __ssrInlineRender: true,
  setup(__props) {
    const product = inject(["form"]);
    const defaultPackage = computed(() => {
      if (!product)
        return null;
      if (!product.packagesAvailable)
        return null;
      return product && product.packagesAvailable ? product.packagesAvailable[0] : null;
    });
    provide("defaultPackage", defaultPackage);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "min-h-screen flex flex-col p-3 md:p-3 bg-[#E7EBEE] gap-y-2" }, _attrs))}>`);
      _push(ssrRenderComponent(unref(_sfc_main$4), null, null, _parent));
      _push(`<div class="flex-1 flex flex-col gap-y-6"><div class="">`);
      _push(ssrRenderComponent(unref(TopBanner), null, null, _parent));
      _push(`</div><div class="grid grid-cols-4 rounded-lg pb-14 gap-x-4"><div class="col-span-3"><div class="">`);
      _push(ssrRenderComponent(unref(_sfc_main$5), null, null, _parent));
      _push(`</div></div><div class="col-span-1">`);
      _push(ssrRenderComponent(unref(_sfc_main$9), null, null, _parent));
      _push(`</div></div></div></section>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/preview/IndexPreview.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const Preview = _sfc_main$3;
const _sfc_main$2 = {
  __name: "MultiInput",
  __ssrInlineRender: true,
  props: [
    "markets",
    "error",
    "selectedmarkets",
    "applications",
    "subapplications"
  ],
  emits: ["getValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const data = ref({
      selectedmarkets: props.selectedmarkets,
      applications: props.applications,
      subapplications: props.subapplications
    });
    const query = ref("");
    const isOpen = ref(false);
    const filteredMarkets = computed(() => {
      if (!props.markets.length)
        return 0;
      return props.markets.filter(
        (m) => m.title.toLowerCase().includes(query.value.toLowerCase())
      );
    });
    function getMarketName(id) {
      const result = props.markets.find((m) => m.id === id);
      return result.title;
    }
    function toggleOpen() {
      isOpen.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1;
      const _directive_click_outside = resolveDirective("click-outside");
      _push(`<div${ssrRenderAttrs(mergeProps(_attrs, ssrGetDirectiveProps(_ctx, _directive_click_outside, toggleOpen)))}><div class="relative mt-1"><div class="relative w-full cursor-default bg-white text-left focus:outline-none text-sm"><div class="w-full"><div class="${ssrRenderClass([{ "border-red-500": __props.error }, "relative px-[14px] py-[10px] min-h-[44px] rounded-lg items-center flex flex-wrap gap-x-2 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}">`);
      if (data.value.selectedmarkets.length > 0) {
        _push(`<ul class="flex w-full flex-wrap items-center gap-2"><!--[-->`);
        ssrRenderList(data.value.selectedmarkets, (id) => {
          _push(`<li class="bg-white rounded-[6px] px-2 py-1 flex items-center text-xs gap-x-3 border border-[#D0D5DD]"><span class="leading-[initial]">${ssrInterpolate(getMarketName(id))}</span><i class="uil uil-times"></i></li>`);
        });
        _push(`<!--]--></ul>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<span class="right-0 pr-2 absolute">`);
      _push(ssrRenderComponent(_component_AppIcon, {
        icon: "ph:caret-down-bold",
        iconClass: "h-4 w-4 text-[#667085]",
        "aria-hidden": "true"
      }, null, _parent));
      _push(`</span></div></div></div><div style="${ssrRenderStyle(isOpen.value ? null : { display: "none" })}" class="flex flex-col z-40 max-h-[500px] w-[500px] rounded-lg p-[30px] bg-white text-base shadow-[0px_2px_4px_0px_rgba(0,0,0,0.04)] focus:outline-none sm:text-sm border border-[#DCDEE6] mt-1"><div class="relative flex items-center mb-6"><input class="w-full h-10 rounded-lg text-sm px-3 py-1 border border-[#DCDEE6]"${ssrRenderAttr("value", query.value)} placeholder="Type name here"><i class="uil uil-search absolute right-3"></i></div><ul class="overflow-auto flex-1"><!--[-->`);
      ssrRenderList(filteredMarkets.value, (market, idx) => {
        _push(`<li class="mb-4"><label class="flex items-center text-sm gap-x-2"><input type="checkbox" class="accent-matta-black"${ssrRenderAttr("value", market.id)}${ssrIncludeBooleanAttr(Array.isArray(data.value.selectedmarkets) ? ssrLooseContain(data.value.selectedmarkets, market.id) : data.value.selectedmarkets) ? " checked" : ""}> ${ssrInterpolate(market.title)}</label>`);
        if (data.value.selectedmarkets.includes(market.id)) {
          _push(`<ul class="ml-8 mt-3 transition duration-500 ease-in-out"><!--[-->`);
          ssrRenderList(market.applications, (app, id) => {
            _push(`<li class="mb-3"><label class="flex items-center text-sm gap-x-2"><input${ssrRenderAttr("value", app.id)} type="checkbox" class="accent-matta-black"${ssrIncludeBooleanAttr(Array.isArray(data.value.applications) ? ssrLooseContain(data.value.applications, app.id) : data.value.applications) ? " checked" : ""}> ${ssrInterpolate(app.title)}</label>`);
            if (data.value.applications.includes(app.id)) {
              _push(`<ul class="ml-8 mt-3 transition duration-500 ease-in-out"><!--[-->`);
              ssrRenderList(app.subApplications, (subapp, id2) => {
                _push(`<li class="mb-2"><label class="flex items-center text-sm gap-x-2"><input${ssrRenderAttr("value", subapp.id)} class="accent-matta-black" type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(data.value.subapplications) ? ssrLooseContain(data.value.subapplications, subapp.id) : data.value.subapplications) ? " checked" : ""}> ${ssrInterpolate(subapp.title)}</label></li>`);
              });
              _push(`<!--]--></ul>`);
            } else {
              _push(`<!---->`);
            }
            _push(`</li>`);
          });
          _push(`<!--]--></ul>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</li>`);
      });
      _push(`<!--]--></ul><hr class="my-4"><div class="relative flex items-center justify-end gap-x-4"><button type="button" class="text-sm text-matta-black"> Cancel </button><button type="button" class="px-4 py-2 hover:opacity-80 rounded-lg bg-primary-500 text-white text-sm"> Save </button></div></div></div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MultiInput.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "TextEditor",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      default: ""
    },
    showAttachment: {
      default: false
    },
    placeholder: {
      default: "Enter text here"
    },
    id: {}
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const apikey = process.env.VUE_APP_TINYMCE_KEY;
    const url = process.env.VUE_APP_URL;
    const value = ref("");
    const prop = __props;
    const handleFile = (blobInfo, progress) => new Promise((resolve, reject) => {
      const xhr = new (void 0)();
      xhr.withCredentials = false;
      xhr.open(
        "POST",
        `${process.env.VUE_APP_URL}v1/fileservice/uploadsinglephoto`
      );
      xhr.setRequestHeader("Content-Type", "application/json");
      xhr.upload.onprogress = (e) => {
        progress(e.loaded / e.total * 100);
      };
      xhr.onload = () => {
        if (xhr.status === 403) {
          reject({ message: "HTTP Error: " + xhr.status, remove: true });
          return;
        }
        if (xhr.status < 200 || xhr.status >= 300) {
          reject("HTTP Error: " + xhr.status);
          return;
        }
        const json = JSON.parse(xhr.responseText);
        if (!json || typeof json.message != "string") {
          reject("Invalid JSON: " + xhr.responseText);
          return;
        }
        resolve(json.message);
      };
      xhr.onerror = () => {
        reject(
          "Image upload failed due to a XHR Transport error. Code: " + xhr.status
        );
      };
      const formData = new FormData();
      formData.append("base64", blobInfo.base64());
      let body = JSON.stringify({
        base64: blobInfo.base64()
      });
      xhr.send(body);
    });
    const emit = __emit;
    watch(prop, (oldvalue, newvalue) => {
      value.value = newvalue.modelValue;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "relative" }, _attrs))}>`);
      _push(ssrRenderComponent(unref(Editor), {
        "api-key": unref(apikey),
        placeholder: __props.placeholder,
        init: {
          height: 400,
          width: 700,
          selector: __props.id,
          plugins: "fullscreen image link  table advlist lists quickbars",
          menubar: "edit view insert format tools table",
          toolbar: "undo redo | bold italic underline strikethrough | fontselect fontsizeselect formatselect | alignleft aligncenter alignright alignjustify | outdent indent |  numlist bullist | pagebreak | image link",
          toolbar_sticky: true,
          images_upload_url: `${unref(url)}v1/fileservice/uploadsinglephoto`,
          images_upload_handler: handleFile
        },
        modelValue: value.value,
        "onUpdate:modelValue": ($event) => value.value = $event,
        onKeyup: ($event) => emit("update:modelValue", value.value),
        ref: "input",
        class: "rounded-lg px-[14px] py-[10px] w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"
      }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/TextEditor.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "FeaturedProp",
  __ssrInlineRender: true,
  props: ["title", "type", "optional", "subtext"],
  setup(__props) {
    const props = __props;
    const form = inject("form");
    const isAdding = ref("");
    const v$ = inject("v$");
    const isAddingPackage = ref(false);
    ref([
      // "features",
      "applications",
      "property",
      // "compliance",
      "technical"
    ]);
    const desc = computed(() => {
      if (props.type === "property") {
        return "List the physical and chemical properties of the chemicals here with the corresponding values. You can use different sections for different properties.";
      } else {
        return "Indicate the official details of technical information about the chemicals with their corresponding values here, e.g. percentage composition, grade, stability and reactivity etc. (N:B please make this feed";
      }
    });
    function removePropValue(id, i) {
      form.propertyItems[props.type].propertyItems[id].propertyValue.splice(i, 1);
    }
    const newpackage = ref("");
    const valueQuery = ref("");
    const filteredProperties = computed(
      () => valueQuery.value === "" ? form.propertyValueList : form.propertyValueList.filter(
        (i) => i.toLowerCase().replace(/\s+/g, "").includes(valueQuery.value.toLowerCase().replace(/\s+/g, ""))
      )
    );
    const index = ref(null);
    const addingProperty = inject("addProperty");
    const addingPropertyvalue = inject("addPropertyValue");
    function addProperty() {
      let data = {
        type: formType.value,
        name: newpackage.value
      };
      switch (props.type) {
        case "features":
          form.propertyItems.features.propertyItems[index.value].property = data;
          break;
        case "applications":
          form.propertyItems.applications.propertyItems[index.value].property = data;
          break;
        case "property":
          form.propertyItems.property.propertyItems[index.value].property = data;
          break;
        case "compliance":
          form.propertyItems.compliance.propertyItems[index.value].property = data;
          break;
        case "technical":
          form.propertyItems.technical.propertyItems[index.value].property = data;
          break;
      }
      addingProperty(data);
      newpackage.value = "";
      isAddingPackage.value = false;
    }
    function addPropertyValues() {
      let data = {
        type: formType.value,
        name: newpackage.value
      };
      switch (props.type) {
        case "features":
          form.propertyItems.features.propertyItems[index.value].propertyValue.push(
            newpackage.value
          );
          break;
        case "applications":
          form.propertyItems.applications.propertyItems[index.value].propertyValue.push(newpackage.value);
          break;
        case "property":
          form.propertyItems.property.propertyItems[index.value].propertyValue.push(
            newpackage.value
          );
          break;
        case "compliance":
          form.propertyItems.compliance.propertyItems[index.value].propertyValue.push(newpackage.value);
          break;
        case "technical":
          form.propertyItems.technical.propertyItems[index.value].propertyValue.push(newpackage.value);
          break;
      }
      addingPropertyvalue(data);
      newpackage.value = "";
      isAddingPackage.value = false;
    }
    function removeValue(index2) {
      form.propertyValueList.splice(index2, 1);
    }
    function removeProperty(index2) {
      form.properties.splice(index2, 1);
    }
    function handleAddingValues(val) {
      isAdding.value = "values";
      isAddingPackage.value = true;
      index.value = val;
    }
    function handleAddingProperty(val) {
      isAdding.value = "property";
      isAddingPackage.value = true;
      index.value = val;
    }
    const formType = computed(() => {
      let value;
      switch (props.type) {
        case "features":
          value = 0;
          break;
        case "applications":
          value = 1;
          break;
        case "property":
          value = 3;
          break;
        case "compliance":
          value = 4;
          break;
        case "technical":
          value = 5;
      }
      return value;
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c;
      const _component_AppIcon = __nuxt_component_1;
      _push(`<!--[-->`);
      if (unref(form) && unref(form).propertyItems) {
        _push(`<div class="flex gap-x-[78px] justify-between text-left" data-v-0a2e81c8><div class="w-[300px] text-left" data-v-0a2e81c8><h3 class="text-sm text-[#101828] font-semibold flex gap-x-1 items-center" data-v-0a2e81c8><span data-v-0a2e81c8>`);
        if (!__props.optional) {
          _push(`<span class="text-red-500 mr-[.5px]" data-v-0a2e81c8>*</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(` ${ssrInterpolate(__props.title)}</span>`);
        if (__props.type === "property" || __props.type === "technical") {
          _push(`<span data-toggle="tooltip" data-placement="top"${ssrRenderAttr("title", desc.value)} class="cursor-pointer" data-v-0a2e81c8>`);
          _push(ssrRenderComponent(_component_AppIcon, {
            icon: "quill:info",
            iconClass: "text-gray-600"
          }, null, _parent));
          _push(`</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</h3><p class="text-xs text-[#475467]" data-v-0a2e81c8>${ssrInterpolate(__props.subtext)}</p></div><div class="max-w-[654px] w-full" data-v-0a2e81c8>`);
        if (unref(form).propertyItems && unref(form).propertyItems[__props.type] && unref(form).propertyItems[__props.type].propertyItems && unref(form).propertyItems[__props.type].propertyItems.length) {
          _push(`<div class="mb-1 grid gap-y-6" data-v-0a2e81c8><!--[-->`);
          ssrRenderList(unref(form).propertyItems[__props.type].propertyItems, (prop, id) => {
            _push(`<div class="flex gap-x-4 items-start" data-v-0a2e81c8><div class="flex-1" data-v-0a2e81c8>`);
            _push(ssrRenderComponent(unref(Listbox), {
              modelValue: prop.property,
              "onUpdate:modelValue": ($event) => prop.property = $event
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(`<div class="relative mt-1" data-v-0a2e81c8${_scopeId}>`);
                  _push2(ssrRenderComponent(unref(ListboxButton), { class: "relative w-full text-left rounded-lg appearance-none px-[14px] py-[10px] flex items-center h-11 border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        if (prop.property) {
                          _push3(`<span class="block truncate capitalize" data-v-0a2e81c8${_scopeId2}>${ssrInterpolate(prop.property.name)}</span>`);
                        } else {
                          _push3(`<span class="text-sm text-[#B6B7B9]" data-v-0a2e81c8${_scopeId2}>Select property</span>`);
                        }
                        _push3(`<span class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" data-v-0a2e81c8${_scopeId2}>`);
                        _push3(ssrRenderComponent(_component_AppIcon, {
                          icon: "ph:caret-down-bold",
                          iconClass: "h-4 w-4 text-[#667085]",
                          "aria-hidden": "true"
                        }, null, _parent3, _scopeId2));
                        _push3(`</span>`);
                      } else {
                        return [
                          prop.property ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "block truncate capitalize"
                          }, toDisplayString(prop.property.name), 1)) : (openBlock(), createBlock("span", {
                            key: 1,
                            class: "text-sm text-[#B6B7B9]"
                          }, "Select property")),
                          createVNode("span", { class: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" }, [
                            createVNode(_component_AppIcon, {
                              icon: "ph:caret-down-bold",
                              iconClass: "h-4 w-4 text-[#667085]",
                              "aria-hidden": "true"
                            })
                          ])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                  _push2(ssrRenderComponent(unref(ListboxOptions), { class: "absolute mt-1 w-[200px] z-40 overflow-auto rounded-md bg-white py-4 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<div class="max-h-80 overflow-y-auto" data-v-0a2e81c8${_scopeId2}><!--[-->`);
                        ssrRenderList(unref(form).properties, (p, i) => {
                          _push3(ssrRenderComponent(unref(ListboxOption), {
                            key: i,
                            value: p,
                            as: "template"
                          }, {
                            default: withCtx(({ selected }, _push4, _parent4, _scopeId3) => {
                              if (_push4) {
                                _push4(`<li class="${ssrRenderClass([
                                  "relative cursor-pointer capitalize text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                                ])}" data-v-0a2e81c8${_scopeId3}><div class="flex items-center gap-x-2 justify-between" data-v-0a2e81c8${_scopeId3}><span class="${ssrRenderClass([
                                  selected ? "font-medium" : "font-normal"
                                ])}" data-v-0a2e81c8${_scopeId3}>${ssrInterpolate(p.name)}</span><span class="pl-6 cursor-pointer" data-v-0a2e81c8${_scopeId3}>x</span></div></li>`);
                              } else {
                                return [
                                  createVNode("li", { class: [
                                    "relative cursor-pointer capitalize text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                                  ] }, [
                                    createVNode("div", { class: "flex items-center gap-x-2 justify-between" }, [
                                      createVNode("span", {
                                        class: [
                                          selected ? "font-medium" : "font-normal"
                                        ]
                                      }, toDisplayString(p.name), 3),
                                      createVNode("span", {
                                        class: "pl-6 cursor-pointer",
                                        onClick: ($event) => removeProperty(_ctx.n)
                                      }, "x", 8, ["onClick"])
                                    ])
                                  ])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent3, _scopeId2));
                        });
                        _push3(`<!--]--></div>`);
                        if (!unref(form).properties.length) {
                          _push3(`<p class="text-[#B6B7B9] py-2 pl-6 pr-4 text-sm" data-v-0a2e81c8${_scopeId2}> Nothing found </p>`);
                        } else {
                          _push3(`<!---->`);
                        }
                        _push3(`<hr class="my-2" data-v-0a2e81c8${_scopeId2}><div class="py-2 pl-6 pr-4" data-v-0a2e81c8${_scopeId2}><button type="button" class="text-primary" data-v-0a2e81c8${_scopeId2}><i class="uil uil-plus text-sm" data-v-0a2e81c8${_scopeId2}></i> Add item </button></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "max-h-80 overflow-y-auto" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(unref(form).properties, (p, i) => {
                              return openBlock(), createBlock(unref(ListboxOption), {
                                key: i,
                                value: p,
                                as: "template"
                              }, {
                                default: withCtx(({ selected }) => [
                                  createVNode("li", { class: [
                                    "relative cursor-pointer capitalize text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                                  ] }, [
                                    createVNode("div", { class: "flex items-center gap-x-2 justify-between" }, [
                                      createVNode("span", {
                                        class: [
                                          selected ? "font-medium" : "font-normal"
                                        ]
                                      }, toDisplayString(p.name), 3),
                                      createVNode("span", {
                                        class: "pl-6 cursor-pointer",
                                        onClick: ($event) => removeProperty(_ctx.n)
                                      }, "x", 8, ["onClick"])
                                    ])
                                  ])
                                ]),
                                _: 2
                              }, 1032, ["value"]);
                            }), 128))
                          ]),
                          !unref(form).properties.length ? (openBlock(), createBlock("p", {
                            key: 0,
                            class: "text-[#B6B7B9] py-2 pl-6 pr-4 text-sm"
                          }, " Nothing found ")) : createCommentVNode("", true),
                          createVNode("hr", { class: "my-2" }),
                          createVNode("div", { class: "py-2 pl-6 pr-4" }, [
                            createVNode("button", {
                              type: "button",
                              class: "text-primary",
                              onClick: ($event) => handleAddingProperty(id)
                            }, [
                              createVNode("i", { class: "uil uil-plus text-sm" }),
                              createTextVNode(" Add item ")
                            ], 8, ["onClick"])
                          ])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                  _push2(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "relative mt-1" }, [
                      createVNode(unref(ListboxButton), { class: "relative w-full text-left rounded-lg appearance-none px-[14px] py-[10px] flex items-center h-11 border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" }, {
                        default: withCtx(() => [
                          prop.property ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "block truncate capitalize"
                          }, toDisplayString(prop.property.name), 1)) : (openBlock(), createBlock("span", {
                            key: 1,
                            class: "text-sm text-[#B6B7B9]"
                          }, "Select property")),
                          createVNode("span", { class: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" }, [
                            createVNode(_component_AppIcon, {
                              icon: "ph:caret-down-bold",
                              iconClass: "h-4 w-4 text-[#667085]",
                              "aria-hidden": "true"
                            })
                          ])
                        ]),
                        _: 2
                      }, 1024),
                      createVNode(Transition, {
                        "leave-active-class": "transition duration-100 ease-in",
                        "leave-from-class": "opacity-100",
                        "leave-to-class": "opacity-0"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(ListboxOptions), { class: "absolute mt-1 w-[200px] z-40 overflow-auto rounded-md bg-white py-4 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm" }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "max-h-80 overflow-y-auto" }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(unref(form).properties, (p, i) => {
                                  return openBlock(), createBlock(unref(ListboxOption), {
                                    key: i,
                                    value: p,
                                    as: "template"
                                  }, {
                                    default: withCtx(({ selected }) => [
                                      createVNode("li", { class: [
                                        "relative cursor-pointer capitalize text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                                      ] }, [
                                        createVNode("div", { class: "flex items-center gap-x-2 justify-between" }, [
                                          createVNode("span", {
                                            class: [
                                              selected ? "font-medium" : "font-normal"
                                            ]
                                          }, toDisplayString(p.name), 3),
                                          createVNode("span", {
                                            class: "pl-6 cursor-pointer",
                                            onClick: ($event) => removeProperty(_ctx.n)
                                          }, "x", 8, ["onClick"])
                                        ])
                                      ])
                                    ]),
                                    _: 2
                                  }, 1032, ["value"]);
                                }), 128))
                              ]),
                              !unref(form).properties.length ? (openBlock(), createBlock("p", {
                                key: 0,
                                class: "text-[#B6B7B9] py-2 pl-6 pr-4 text-sm"
                              }, " Nothing found ")) : createCommentVNode("", true),
                              createVNode("hr", { class: "my-2" }),
                              createVNode("div", { class: "py-2 pl-6 pr-4" }, [
                                createVNode("button", {
                                  type: "button",
                                  class: "text-primary",
                                  onClick: ($event) => handleAddingProperty(id)
                                }, [
                                  createVNode("i", { class: "uil uil-plus text-sm" }),
                                  createTextVNode(" Add item ")
                                ], 8, ["onClick"])
                              ])
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        _: 2
                      }, 1024)
                    ])
                  ];
                }
              }),
              _: 2
            }, _parent));
            _push(`<!--[-->`);
            ssrRenderList(unref(v$).propertyItems[__props.type].propertyItems.$each.$response.$errors[id].property, (error) => {
              _push(`<div class="text-red-500 mt-1 w-full" data-v-0a2e81c8><div class="error-msg text-error text-xs font-semibold" data-v-0a2e81c8>${ssrInterpolate(error.$message)}</div></div>`);
            });
            _push(`<!--]--></div><div class="flex-1" data-v-0a2e81c8>`);
            _push(ssrRenderComponent(unref(Combobox), {
              modelValue: prop.propertyValue,
              "onUpdate:modelValue": ($event) => prop.propertyValue = $event,
              multiple: ""
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(`<div class="relative mt-1" data-v-0a2e81c8${_scopeId}><div class="relative w-full cursor-default overflow-hidden rounded-lg bg-white text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75 focus-visible:ring-offset-2 focus-visible:ring-offset-teal-300 sm:text-sm" data-v-0a2e81c8${_scopeId}>`);
                  _push2(ssrRenderComponent(unref(ComboboxButton), { class: "w-full" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<div class="relative px-[14px] py-[10px] min-h-[44px] rounded-lg flex items-center flex-wrap gap-x-2 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" data-v-0a2e81c8${_scopeId2}>`);
                        if (prop.propertyValue.length > 0) {
                          _push3(`<ul class="flex w-full items-center gap-x-2 gap-y-1 flex-wrap" data-v-0a2e81c8${_scopeId2}><!--[-->`);
                          ssrRenderList(prop.propertyValue, (i, n) => {
                            _push3(`<li class="bg-white rounded-lg px-1 py-[2px] flex items-center text-xs gap-x-3 capitalize border-[#D0D5DD] border rounded-1" data-v-0a2e81c8${_scopeId2}><span class="leading-[initial]" data-v-0a2e81c8${_scopeId2}>${ssrInterpolate(i)}</span><i class="uil uil-times" data-v-0a2e81c8${_scopeId2}></i></li>`);
                          });
                          _push3(`<!--]--></ul>`);
                        } else {
                          _push3(`<span class="text-sm text-[#B6B7B9]" data-v-0a2e81c8${_scopeId2}>Property value</span>`);
                        }
                        _push3(`<span class="right-0 pr-2 absolute" data-v-0a2e81c8${_scopeId2}>`);
                        _push3(ssrRenderComponent(_component_AppIcon, {
                          icon: "ph:caret-down-bold",
                          iconClass: "h-4 w-4 text-[#667085]",
                          "aria-hidden": "true"
                        }, null, _parent3, _scopeId2));
                        _push3(`</span></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "relative px-[14px] py-[10px] min-h-[44px] rounded-lg flex items-center flex-wrap gap-x-2 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" }, [
                            prop.propertyValue.length > 0 ? (openBlock(), createBlock("ul", {
                              key: 0,
                              class: "flex w-full items-center gap-x-2 gap-y-1 flex-wrap"
                            }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(prop.propertyValue, (i, n) => {
                                return openBlock(), createBlock("li", {
                                  key: i,
                                  class: "bg-white rounded-lg px-1 py-[2px] flex items-center text-xs gap-x-3 capitalize border-[#D0D5DD] border rounded-1"
                                }, [
                                  createVNode("span", { class: "leading-[initial]" }, toDisplayString(i), 1),
                                  createVNode("i", {
                                    class: "uil uil-times",
                                    onClick: ($event) => removePropValue(id, n)
                                  }, null, 8, ["onClick"])
                                ]);
                              }), 128))
                            ])) : (openBlock(), createBlock("span", {
                              key: 1,
                              class: "text-sm text-[#B6B7B9]"
                            }, "Property value")),
                            createVNode("span", { class: "right-0 pr-2 absolute" }, [
                              createVNode(_component_AppIcon, {
                                icon: "ph:caret-down-bold",
                                iconClass: "h-4 w-4 text-[#667085]",
                                "aria-hidden": "true"
                              })
                            ])
                          ])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                  _push2(`</div>`);
                  _push2(ssrRenderComponent(unref(TransitionRoot), {
                    leave: "transition ease-in duration-100",
                    leaveFrom: "opacity-100",
                    leaveTo: "opacity-0"
                  }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(ssrRenderComponent(unref(ComboboxOptions), { class: "absolute mt-1 md:min-w-[350px] px-8 overflow-auto z-40 rounded-md bg-white py-4 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm" }, {
                          default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                            if (_push4) {
                              _push4(`<div class="relative flex items-center mb-4" data-v-0a2e81c8${_scopeId3}><input${ssrRenderAttr("value", valueQuery.value)} class="px-5 py-1 h-10 rounded-lg w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" data-v-0a2e81c8${_scopeId3}><i class="uil uil-search absolute right-3" data-v-0a2e81c8${_scopeId3}></i></div>`);
                              if (filteredProperties.value.length === 0 && valueQuery.value !== "") {
                                _push4(`<div class="relative cursor-default select-none py-2 px-4 text-gray-700" data-v-0a2e81c8${_scopeId3}> Nothing found. </div>`);
                              } else {
                                _push4(`<!---->`);
                              }
                              _push4(`<div class="max-h-80 overflow-y-auto" data-v-0a2e81c8${_scopeId3}><!--[-->`);
                              ssrRenderList(filteredProperties.value, (i, n) => {
                                _push4(ssrRenderComponent(unref(ComboboxOption), {
                                  as: "template",
                                  key: n,
                                  value: i
                                }, {
                                  default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                                    if (_push5) {
                                      _push5(`<li class="relative cursor-default select-none py-2" data-v-0a2e81c8${_scopeId4}><div class="flex items-center gap-x-2" data-v-0a2e81c8${_scopeId4}><div class="flex-1 flex items-center gap-x-2" data-v-0a2e81c8${_scopeId4}><input${ssrRenderAttr("id", `market${n}`)} type="checkbox" class="accent-matta-black"${ssrIncludeBooleanAttr(Array.isArray(prop.propertyValue) ? ssrLooseContain(prop.propertyValue, i) : prop.propertyValue) ? " checked" : ""}${ssrRenderAttr("value", i)} data-v-0a2e81c8${_scopeId4}><span class="text-matta-black leading-[initial] capitalize" data-v-0a2e81c8${_scopeId4}>${ssrInterpolate(i)}</span></div><span class="pl-6 cursor-pointer" data-v-0a2e81c8${_scopeId4}>x</span></div></li>`);
                                    } else {
                                      return [
                                        createVNode("li", { class: "relative cursor-default select-none py-2" }, [
                                          createVNode("div", { class: "flex items-center gap-x-2" }, [
                                            createVNode("div", { class: "flex-1 flex items-center gap-x-2" }, [
                                              withDirectives(createVNode("input", {
                                                id: `market${n}`,
                                                type: "checkbox",
                                                class: "accent-matta-black",
                                                "onUpdate:modelValue": ($event) => prop.propertyValue = $event,
                                                value: i
                                              }, null, 8, ["id", "onUpdate:modelValue", "value"]), [
                                                [vModelCheckbox, prop.propertyValue]
                                              ]),
                                              createVNode("span", { class: "text-matta-black leading-[initial] capitalize" }, toDisplayString(i), 1)
                                            ]),
                                            createVNode("span", {
                                              class: "pl-6 cursor-pointer",
                                              onClick: ($event) => removeValue(n)
                                            }, "x", 8, ["onClick"])
                                          ])
                                        ])
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent4, _scopeId3));
                              });
                              _push4(`<!--]--></div><hr class="my-2" data-v-0a2e81c8${_scopeId3}><div class="py-2 pl-6 pr-4" data-v-0a2e81c8${_scopeId3}><button type="button" class="text-primary-500" data-v-0a2e81c8${_scopeId3}><i class="uil uil-plus text-sm" data-v-0a2e81c8${_scopeId3}></i> Add a value </button></div>`);
                            } else {
                              return [
                                createVNode("div", { class: "relative flex items-center mb-4" }, [
                                  withDirectives(createVNode("input", {
                                    "onUpdate:modelValue": ($event) => valueQuery.value = $event,
                                    class: "px-5 py-1 h-10 rounded-lg w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"
                                  }, null, 8, ["onUpdate:modelValue"]), [
                                    [vModelText, valueQuery.value]
                                  ]),
                                  createVNode("i", { class: "uil uil-search absolute right-3" })
                                ]),
                                filteredProperties.value.length === 0 && valueQuery.value !== "" ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "relative cursor-default select-none py-2 px-4 text-gray-700"
                                }, " Nothing found. ")) : createCommentVNode("", true),
                                createVNode("div", { class: "max-h-80 overflow-y-auto" }, [
                                  (openBlock(true), createBlock(Fragment, null, renderList(filteredProperties.value, (i, n) => {
                                    return openBlock(), createBlock(unref(ComboboxOption), {
                                      as: "template",
                                      key: n,
                                      value: i
                                    }, {
                                      default: withCtx(() => [
                                        createVNode("li", { class: "relative cursor-default select-none py-2" }, [
                                          createVNode("div", { class: "flex items-center gap-x-2" }, [
                                            createVNode("div", { class: "flex-1 flex items-center gap-x-2" }, [
                                              withDirectives(createVNode("input", {
                                                id: `market${n}`,
                                                type: "checkbox",
                                                class: "accent-matta-black",
                                                "onUpdate:modelValue": ($event) => prop.propertyValue = $event,
                                                value: i
                                              }, null, 8, ["id", "onUpdate:modelValue", "value"]), [
                                                [vModelCheckbox, prop.propertyValue]
                                              ]),
                                              createVNode("span", { class: "text-matta-black leading-[initial] capitalize" }, toDisplayString(i), 1)
                                            ]),
                                            createVNode("span", {
                                              class: "pl-6 cursor-pointer",
                                              onClick: ($event) => removeValue(n)
                                            }, "x", 8, ["onClick"])
                                          ])
                                        ])
                                      ]),
                                      _: 2
                                    }, 1032, ["value"]);
                                  }), 128))
                                ]),
                                createVNode("hr", { class: "my-2" }),
                                createVNode("div", { class: "py-2 pl-6 pr-4" }, [
                                  createVNode("button", {
                                    type: "button",
                                    class: "text-primary-500",
                                    onClick: ($event) => handleAddingValues(id)
                                  }, [
                                    createVNode("i", { class: "uil uil-plus text-sm" }),
                                    createTextVNode(" Add a value ")
                                  ], 8, ["onClick"])
                                ])
                              ];
                            }
                          }),
                          _: 2
                        }, _parent3, _scopeId2));
                      } else {
                        return [
                          createVNode(unref(ComboboxOptions), { class: "absolute mt-1 md:min-w-[350px] px-8 overflow-auto z-40 rounded-md bg-white py-4 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm" }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "relative flex items-center mb-4" }, [
                                withDirectives(createVNode("input", {
                                  "onUpdate:modelValue": ($event) => valueQuery.value = $event,
                                  class: "px-5 py-1 h-10 rounded-lg w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, valueQuery.value]
                                ]),
                                createVNode("i", { class: "uil uil-search absolute right-3" })
                              ]),
                              filteredProperties.value.length === 0 && valueQuery.value !== "" ? (openBlock(), createBlock("div", {
                                key: 0,
                                class: "relative cursor-default select-none py-2 px-4 text-gray-700"
                              }, " Nothing found. ")) : createCommentVNode("", true),
                              createVNode("div", { class: "max-h-80 overflow-y-auto" }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(filteredProperties.value, (i, n) => {
                                  return openBlock(), createBlock(unref(ComboboxOption), {
                                    as: "template",
                                    key: n,
                                    value: i
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("li", { class: "relative cursor-default select-none py-2" }, [
                                        createVNode("div", { class: "flex items-center gap-x-2" }, [
                                          createVNode("div", { class: "flex-1 flex items-center gap-x-2" }, [
                                            withDirectives(createVNode("input", {
                                              id: `market${n}`,
                                              type: "checkbox",
                                              class: "accent-matta-black",
                                              "onUpdate:modelValue": ($event) => prop.propertyValue = $event,
                                              value: i
                                            }, null, 8, ["id", "onUpdate:modelValue", "value"]), [
                                              [vModelCheckbox, prop.propertyValue]
                                            ]),
                                            createVNode("span", { class: "text-matta-black leading-[initial] capitalize" }, toDisplayString(i), 1)
                                          ]),
                                          createVNode("span", {
                                            class: "pl-6 cursor-pointer",
                                            onClick: ($event) => removeValue(n)
                                          }, "x", 8, ["onClick"])
                                        ])
                                      ])
                                    ]),
                                    _: 2
                                  }, 1032, ["value"]);
                                }), 128))
                              ]),
                              createVNode("hr", { class: "my-2" }),
                              createVNode("div", { class: "py-2 pl-6 pr-4" }, [
                                createVNode("button", {
                                  type: "button",
                                  class: "text-primary-500",
                                  onClick: ($event) => handleAddingValues(id)
                                }, [
                                  createVNode("i", { class: "uil uil-plus text-sm" }),
                                  createTextVNode(" Add a value ")
                                ], 8, ["onClick"])
                              ])
                            ]),
                            _: 2
                          }, 1024)
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                  _push2(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "relative mt-1" }, [
                      createVNode("div", { class: "relative w-full cursor-default overflow-hidden rounded-lg bg-white text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75 focus-visible:ring-offset-2 focus-visible:ring-offset-teal-300 sm:text-sm" }, [
                        createVNode(unref(ComboboxButton), { class: "w-full" }, {
                          default: withCtx(() => [
                            createVNode("div", { class: "relative px-[14px] py-[10px] min-h-[44px] rounded-lg flex items-center flex-wrap gap-x-2 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" }, [
                              prop.propertyValue.length > 0 ? (openBlock(), createBlock("ul", {
                                key: 0,
                                class: "flex w-full items-center gap-x-2 gap-y-1 flex-wrap"
                              }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(prop.propertyValue, (i, n) => {
                                  return openBlock(), createBlock("li", {
                                    key: i,
                                    class: "bg-white rounded-lg px-1 py-[2px] flex items-center text-xs gap-x-3 capitalize border-[#D0D5DD] border rounded-1"
                                  }, [
                                    createVNode("span", { class: "leading-[initial]" }, toDisplayString(i), 1),
                                    createVNode("i", {
                                      class: "uil uil-times",
                                      onClick: ($event) => removePropValue(id, n)
                                    }, null, 8, ["onClick"])
                                  ]);
                                }), 128))
                              ])) : (openBlock(), createBlock("span", {
                                key: 1,
                                class: "text-sm text-[#B6B7B9]"
                              }, "Property value")),
                              createVNode("span", { class: "right-0 pr-2 absolute" }, [
                                createVNode(_component_AppIcon, {
                                  icon: "ph:caret-down-bold",
                                  iconClass: "h-4 w-4 text-[#667085]",
                                  "aria-hidden": "true"
                                })
                              ])
                            ])
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      createVNode(unref(TransitionRoot), {
                        leave: "transition ease-in duration-100",
                        leaveFrom: "opacity-100",
                        leaveTo: "opacity-0"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(ComboboxOptions), { class: "absolute mt-1 md:min-w-[350px] px-8 overflow-auto z-40 rounded-md bg-white py-4 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm" }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "relative flex items-center mb-4" }, [
                                withDirectives(createVNode("input", {
                                  "onUpdate:modelValue": ($event) => valueQuery.value = $event,
                                  class: "px-5 py-1 h-10 rounded-lg w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"
                                }, null, 8, ["onUpdate:modelValue"]), [
                                  [vModelText, valueQuery.value]
                                ]),
                                createVNode("i", { class: "uil uil-search absolute right-3" })
                              ]),
                              filteredProperties.value.length === 0 && valueQuery.value !== "" ? (openBlock(), createBlock("div", {
                                key: 0,
                                class: "relative cursor-default select-none py-2 px-4 text-gray-700"
                              }, " Nothing found. ")) : createCommentVNode("", true),
                              createVNode("div", { class: "max-h-80 overflow-y-auto" }, [
                                (openBlock(true), createBlock(Fragment, null, renderList(filteredProperties.value, (i, n) => {
                                  return openBlock(), createBlock(unref(ComboboxOption), {
                                    as: "template",
                                    key: n,
                                    value: i
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("li", { class: "relative cursor-default select-none py-2" }, [
                                        createVNode("div", { class: "flex items-center gap-x-2" }, [
                                          createVNode("div", { class: "flex-1 flex items-center gap-x-2" }, [
                                            withDirectives(createVNode("input", {
                                              id: `market${n}`,
                                              type: "checkbox",
                                              class: "accent-matta-black",
                                              "onUpdate:modelValue": ($event) => prop.propertyValue = $event,
                                              value: i
                                            }, null, 8, ["id", "onUpdate:modelValue", "value"]), [
                                              [vModelCheckbox, prop.propertyValue]
                                            ]),
                                            createVNode("span", { class: "text-matta-black leading-[initial] capitalize" }, toDisplayString(i), 1)
                                          ]),
                                          createVNode("span", {
                                            class: "pl-6 cursor-pointer",
                                            onClick: ($event) => removeValue(n)
                                          }, "x", 8, ["onClick"])
                                        ])
                                      ])
                                    ]),
                                    _: 2
                                  }, 1032, ["value"]);
                                }), 128))
                              ]),
                              createVNode("hr", { class: "my-2" }),
                              createVNode("div", { class: "py-2 pl-6 pr-4" }, [
                                createVNode("button", {
                                  type: "button",
                                  class: "text-primary-500",
                                  onClick: ($event) => handleAddingValues(id)
                                }, [
                                  createVNode("i", { class: "uil uil-plus text-sm" }),
                                  createTextVNode(" Add a value ")
                                ], 8, ["onClick"])
                              ])
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        _: 2
                      }, 1024)
                    ])
                  ];
                }
              }),
              _: 2
            }, _parent));
            _push(`<!--[-->`);
            ssrRenderList(unref(v$).propertyItems[__props.type].propertyItems.$each.$response.$errors[id].propertyValue, (error) => {
              _push(`<div class="text-red-500 mt-1 w-full" data-v-0a2e81c8><div class="error-msg text-error text-xs font-semibold" data-v-0a2e81c8>${ssrInterpolate(error.$message)}</div></div>`);
            });
            _push(`<!--]--></div><div class="flex items-center" data-v-0a2e81c8><span class="bg-gray-50 rounded-full h-8 w-8 flex items-center justify-center text-sm text-[#475467] cursor-pointer" data-v-0a2e81c8>`);
            _push(ssrRenderComponent(_component_AppIcon, { icon: "fa:trash-o" }, null, _parent));
            _push(`</span></div></div>`);
          });
          _push(`<!--]--></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="flex items-center gap-x-4 mt-3" data-v-0a2e81c8><button type="button" class="text-primary-500 text-xs" data-v-0a2e81c8><i class="uil uil-plus" data-v-0a2e81c8></i> Add property </button>`);
        if (!((_a = unref(form).propertyItems[__props.type]) == null ? void 0 : _a.subSection.length)) {
          _push(`<button type="button" class="text-primary-500 text-xs" data-v-0a2e81c8><i class="uil uil-plus" data-v-0a2e81c8></i> Add subsection </button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
        if ((_b = unref(form).propertyItems[__props.type]) == null ? void 0 : _b.subSection.length) {
          _push(`<div class="" data-v-0a2e81c8><hr class="my-4" data-v-0a2e81c8><!--[-->`);
          ssrRenderList((_c = unref(form).propertyItems[__props.type]) == null ? void 0 : _c.subSection, (prop, id) => {
            _push(`<div class="md:w-[85%] mb-1 flex items-start gap-x-4" data-v-0a2e81c8><div class="flex-1" data-v-0a2e81c8><div class="mb-6" data-v-0a2e81c8><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-0a2e81c8> Subsection name</label><input class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" autofocus="on" placeholder="Enter subsection name..."${ssrRenderAttr("value", prop.subSectionName)} data-v-0a2e81c8></div><div class="mb-6" data-v-0a2e81c8><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-0a2e81c8> Description</label>`);
            _push(ssrRenderComponent(unref(_sfc_main$1), {
              modelValue: prop.description,
              "onUpdate:modelValue": ($event) => prop.description = $event,
              placeholder: "Enter description"
            }, null, _parent));
            _push(`</div></div><div class="flex items-center" data-v-0a2e81c8><span class="bg-gray-50 rounded-full h-8 w-8 flex items-center justify-center" data-v-0a2e81c8><i class="uil uil-times" data-v-0a2e81c8></i></span></div></div>`);
          });
          _push(`<!--]--><button type="button" class="text-primary-500 text-xs" data-v-0a2e81c8><i class="uil uil-plus" data-v-0a2e81c8></i> Add subsection </button></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div data-v-0a2e81c8>`);
      _push(ssrRenderComponent(unref(__nuxt_component_0), {
        isOpen: isAddingPackage.value,
        onToggleModal: ($event) => isAddingPackage.value = false
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (isAdding.value == "property") {
              _push2(`<div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 w-[400px]" data-v-0a2e81c8${_scopeId}><div class="flex justify-between mb-5 items-center" data-v-0a2e81c8${_scopeId}><h4 class="font-medium text-matta-black text-xl" data-v-0a2e81c8${_scopeId}>Add new value</h4><i class="uil uil-times cursor-pointer text-lg hover:ring-1 w-6 h-6 ring-gray-200 flex items-center justify-center hover:ring-offset-2 rounded-full" data-v-0a2e81c8${_scopeId}></i></div><input${ssrRenderAttr("value", newpackage.value)} class="rounded-lg px-3 py-3 h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" autofocus="on" placeholder="Enter property name..." data-v-0a2e81c8${_scopeId}><div class="flex justify-end gap-x-2 items-center mt-8" data-v-0a2e81c8${_scopeId}><button type="button" class="appearance-none text-xs leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 uppercase" data-v-0a2e81c8${_scopeId}> Cancel </button><button type="button" class="appearance-none text-xs leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase" data-v-0a2e81c8${_scopeId}> Save </button></div></div>`);
            } else {
              _push2(`<div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 w-[400px]" data-v-0a2e81c8${_scopeId}><div class="flex justify-between mb-5 items-center" data-v-0a2e81c8${_scopeId}><h4 class="font-medium text-matta-black text-xl" data-v-0a2e81c8${_scopeId}>Add new value</h4><i class="uil uil-times cursor-pointer text-lg hover:ring-1 w-6 h-6 ring-gray-200 flex items-center justify-center hover:ring-offset-2 rounded-full" data-v-0a2e81c8${_scopeId}></i></div><input${ssrRenderAttr("value", newpackage.value)} class="rounded-lg px-3 py-3 h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" autofocus="on" placeholder="Enter property values..." data-v-0a2e81c8${_scopeId}><div class="flex justify-end gap-x-2 items-center mt-8" data-v-0a2e81c8${_scopeId}><button type="button" class="appearance-none text-xs leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 uppercase" data-v-0a2e81c8${_scopeId}> Cancel </button><button type="button" class="appearance-none text-xs leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase" data-v-0a2e81c8${_scopeId}> Save </button></div></div>`);
            }
          } else {
            return [
              isAdding.value == "property" ? (openBlock(), createBlock("div", {
                key: 0,
                class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 w-[400px]"
              }, [
                createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                  createVNode("h4", { class: "font-medium text-matta-black text-xl" }, "Add new value"),
                  createVNode("i", {
                    class: "uil uil-times cursor-pointer text-lg hover:ring-1 w-6 h-6 ring-gray-200 flex items-center justify-center hover:ring-offset-2 rounded-full",
                    onClick: ($event) => isAddingPackage.value = false
                  }, null, 8, ["onClick"])
                ]),
                withDirectives(createVNode("input", {
                  "onUpdate:modelValue": ($event) => newpackage.value = $event,
                  class: "rounded-lg px-3 py-3 h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
                  autocomplete: "off",
                  autofocus: "on",
                  placeholder: "Enter property name..."
                }, null, 8, ["onUpdate:modelValue"]), [
                  [vModelText, newpackage.value]
                ]),
                createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                  createVNode("button", {
                    type: "button",
                    onClick: ($event) => isAddingPackage.value = false,
                    class: "appearance-none text-xs leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 uppercase"
                  }, " Cancel ", 8, ["onClick"]),
                  createVNode("button", {
                    type: "button",
                    onClick: addProperty,
                    class: "appearance-none text-xs leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase"
                  }, " Save ")
                ])
              ])) : (openBlock(), createBlock("div", {
                key: 1,
                class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 w-[400px]"
              }, [
                createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                  createVNode("h4", { class: "font-medium text-matta-black text-xl" }, "Add new value"),
                  createVNode("i", {
                    class: "uil uil-times cursor-pointer text-lg hover:ring-1 w-6 h-6 ring-gray-200 flex items-center justify-center hover:ring-offset-2 rounded-full",
                    onClick: ($event) => isAddingPackage.value = false
                  }, null, 8, ["onClick"])
                ]),
                withDirectives(createVNode("input", {
                  "onUpdate:modelValue": ($event) => newpackage.value = $event,
                  class: "rounded-lg px-3 py-3 h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
                  autocomplete: "off",
                  autofocus: "on",
                  placeholder: "Enter property values..."
                }, null, 8, ["onUpdate:modelValue"]), [
                  [vModelText, newpackage.value]
                ]),
                createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                  createVNode("button", {
                    type: "button",
                    onClick: ($event) => isAddingPackage.value = false,
                    class: "appearance-none text-xs leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 uppercase"
                  }, " Cancel ", 8, ["onClick"]),
                  createVNode("button", {
                    type: "button",
                    onClick: addPropertyValues,
                    class: "appearance-none text-xs leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase"
                  }, " Save ")
                ])
              ]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/AddProduct/FeaturedProp.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const FeaturedProp = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-0a2e81c8"]]);
const _imports_0 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAJ8SURBVHgB7Zg/aBNRHMe/73IX6kUbi+3Y4Fipg9XNKLg41ClOFgWLoKP/hgqCYEXEQaRYJ0XwDyjdrIviooJVXKoOirqJOogKNdo0bZL29f2uveRyl1xf7+WSDveBQPK+1/4++f3ekZcw1GDjwNRmw8BtzrCNiZdQYG9ffPjB6cQFBERDDTk9jndg2KMqRzDOhw+O5M4jIB5B3cBII8ScqEh6BBlDBiEQVFJDEwki2VRBYrWSTRckViPZEkFCVjJ0weJ8/UxGMnTB/3num68kGbrgx2/zvl0k/CRDF8wXON58KeFXdsH3unqSzL3QdXjKfyYh8/teR5VTy+5iWSJBVSJBVSJBVSJBVSJBVda8oC57Yf92A1tTsfLrsYkCvv+pnFDSPToO7IojK85/N5/O1c3GXhasI5gs0h0kwYHdcXR3akhv0fHs4gb0LgsPZdrw8Ox663lqk4bJq+3Y2aNXZckEs7Ln4u/srKGCBHXlxK0ZZC5PW124dGgdkibD0P42nLuft7LB0Rxefy7hjFgj6E1RRwev5ayMOpgOS9DJq08lq5vt5tLx7YNjbJRRdymnx+O3xXJGb+LK+CxkCSzY3aXh30zlbJs0WdXzH6Lbdp7qrJShfdzr2MsNFaTC1BHaj/vEgzpDY6eR0pipOI2vf4eBCbGWFYLu7O7JhDV2WaSP/KNHzfI/ps7cEPvKHhVJU2H7Ln8yWcRxMUq6jrLrx8zyjeHMauE+8jf0O4m9H2sV98v8BOVvJwn8iq8kVo/oo04Vj6AYxF+sIby/sHK8R4tg4I/cax7BWAxHWtFFqqlp7JR73SP4807HV11DH+cYR5PERK0XVJNqu/NF77sMWhJmgY0AAAAASUVORK5CYII=";

export { FeaturedProp as F, Preview as P, __nuxt_component_2 as _, _imports_0 as a };
//# sourceMappingURL=filetype-LhTNRnFG.mjs.map
