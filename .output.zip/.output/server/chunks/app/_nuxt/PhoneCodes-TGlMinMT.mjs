import { useSSRContext, ref, computed, watch, unref, mergeProps, isRef, withCtx, openBlock, createBlock, createVNode, toDisplayString, createCommentVNode, withDirectives, vShow, vModelText, Fragment, renderList, Transition } from 'vue';
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderList, ssrRenderClass, ssrRenderStyle } from 'vue/server-renderer';
import { Listbox, ListboxButton, ListboxOptions, ListboxOption } from '@headlessui/vue';
import CountryList from 'country-list-with-dial-code-and-flag';

const _sfc_main = {
  __name: "PhoneCodes",
  __ssrInlineRender: true,
  props: [
    "label",
    "id",
    "modelValue",
    "placeholder",
    "classStyles"
  ],
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emits = __emit;
    const selectedOption = ref(null);
    const query = ref("");
    const filteredCodes = computed(() => {
      var _a;
      if (!query.value.length)
        return CountryList;
      return (_a = CountryList) == null ? void 0 : _a.filter(
        (item) => item.name.toLowerCase().includes(query.value.toLowerCase())
      );
    });
    watch(selectedOption, () => {
      var _a;
      if (((_a = selectedOption.value) == null ? void 0 : _a.dial_code) == null)
        return;
      emits("update:modelValue", selectedOption.value.dial_code);
    });
    watch(
      () => props.modelValue,
      () => {
        var _a;
        if (!props.modelValue)
          return {};
        selectedOption.value = (_a = CountryList) == null ? void 0 : _a.find(
          (i) => i.dial_code == props.modelValue
        );
      }
    );
    watch(
      () => [...CountryList],
      () => {
        if (!props.modelValue)
          return {};
        selectedOption.value = CountryList.find(
          (i) => i.dial_code == props.modelValue
        );
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(Listbox), mergeProps({
        class: "flex items-center",
        modelValue: unref(selectedOption),
        "onUpdate:modelValue": ($event) => isRef(selectedOption) ? selectedOption.value = $event : null
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="relative h-full"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ListboxButton), {
              class: [__props.classStyles, "relative cursor-pointer h-full text-left flex items-center rounded-l-lg px-4 gap-x-2 py-3 border placeholder:text-[#B6B7B9] focus:outline-matta-black/20 text-sm"]
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  if (unref(selectedOption)) {
                    _push3(`<span class="text-sm"${_scopeId2}><div class="text-[#3A3745] flex items-center gap-x-1"${_scopeId2}>`);
                    if (unref(selectedOption)) {
                      _push3(`<span${_scopeId2}>${ssrInterpolate(unref(selectedOption).dial_code)}</span>`);
                    } else {
                      _push3(`<!---->`);
                    }
                    _push3(`</div></span>`);
                  } else {
                    _push3(`<span class="block text-sm text-[#8F8C9A] whitespace-nowrap"${_scopeId2}>${ssrInterpolate(__props.placeholder)}</span>`);
                  }
                  _push3(`<i class="uil uil-angle-down text-[#101828]"${_scopeId2}></i>`);
                } else {
                  return [
                    unref(selectedOption) ? (openBlock(), createBlock("span", {
                      key: 0,
                      class: "text-sm"
                    }, [
                      createVNode("div", { class: "text-[#3A3745] flex items-center gap-x-1" }, [
                        unref(selectedOption) ? (openBlock(), createBlock("span", { key: 0 }, toDisplayString(unref(selectedOption).dial_code), 1)) : createCommentVNode("", true)
                      ])
                    ])) : (openBlock(), createBlock("span", {
                      key: 1,
                      class: "block text-sm text-[#8F8C9A] whitespace-nowrap"
                    }, toDisplayString(__props.placeholder), 1)),
                    createVNode("i", { class: "uil uil-angle-down text-[#101828]" })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(ListboxOptions), { class: "absolute mt-1 w-full min-w-[320px] border border-gray-200 z-40 rounded-lg bg-white py-6 text-xs shadow-lg ring-1 ring-black ring-opacity-5 outline-0 sm:text-[13px]" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="relative flex items-center mb-3 mt-3 px-4"${_scopeId2}><input${ssrRenderAttr("value", unref(query))} placeholder="Search" class="text-xs rounded-lg px-3 py-1 h-10 w-full border placeholder:text-[#B6B7B9] focus:outline-matta-black/20"${_scopeId2}></div><div class="max-h-60 overflow-y-auto py-2"${_scopeId2}><!--[-->`);
                  ssrRenderList(unref(filteredCodes), (z) => {
                    _push3(ssrRenderComponent(unref(ListboxOption), {
                      key: z,
                      value: z,
                      as: "template"
                    }, {
                      default: withCtx(({ active, selected }, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<li class="${ssrRenderClass([
                            active || selected ? "bg-gray-50" : "",
                            "relative cursor-pointer select-none py-[11px] px-[20px] text-loft-black hover:bg-gray-100  flex items-center justify-between"
                          ])}"${_scopeId3}><p class="text-sm text-[#101828] capitalize"${_scopeId3}>${ssrInterpolate(z.dial_code)} - \xA0 ${ssrInterpolate(z.name)}</p><i class="uil uil-check text-[#101828]" style="${ssrRenderStyle(selected ? null : { display: "none" })}"${_scopeId3}></i></li>`);
                        } else {
                          return [
                            createVNode("li", {
                              class: [
                                active || selected ? "bg-gray-50" : "",
                                "relative cursor-pointer select-none py-[11px] px-[20px] text-loft-black hover:bg-gray-100  flex items-center justify-between"
                              ]
                            }, [
                              createVNode("p", { class: "text-sm text-[#101828] capitalize" }, toDisplayString(z.dial_code) + " - \xA0 " + toDisplayString(z.name), 1),
                              withDirectives(createVNode("i", { class: "uil uil-check text-[#101828]" }, null, 512), [
                                [vShow, selected]
                              ])
                            ], 2)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]--></div>`);
                } else {
                  return [
                    createVNode("div", { class: "relative flex items-center mb-3 mt-3 px-4" }, [
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => isRef(query) ? query.value = $event : null,
                        placeholder: "Search",
                        class: "text-xs rounded-lg px-3 py-1 h-10 w-full border placeholder:text-[#B6B7B9] focus:outline-matta-black/20"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(query)]
                      ])
                    ]),
                    createVNode("div", { class: "max-h-60 overflow-y-auto py-2" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(filteredCodes), (z) => {
                        return openBlock(), createBlock(unref(ListboxOption), {
                          key: z,
                          value: z,
                          as: "template"
                        }, {
                          default: withCtx(({ active, selected }) => [
                            createVNode("li", {
                              class: [
                                active || selected ? "bg-gray-50" : "",
                                "relative cursor-pointer select-none py-[11px] px-[20px] text-loft-black hover:bg-gray-100  flex items-center justify-between"
                              ]
                            }, [
                              createVNode("p", { class: "text-sm text-[#101828] capitalize" }, toDisplayString(z.dial_code) + " - \xA0 " + toDisplayString(z.name), 1),
                              withDirectives(createVNode("i", { class: "uil uil-check text-[#101828]" }, null, 512), [
                                [vShow, selected]
                              ])
                            ], 2)
                          ]),
                          _: 2
                        }, 1032, ["value"]);
                      }), 128))
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "relative h-full" }, [
                createVNode(unref(ListboxButton), {
                  class: [__props.classStyles, "relative cursor-pointer h-full text-left flex items-center rounded-l-lg px-4 gap-x-2 py-3 border placeholder:text-[#B6B7B9] focus:outline-matta-black/20 text-sm"]
                }, {
                  default: withCtx(() => [
                    unref(selectedOption) ? (openBlock(), createBlock("span", {
                      key: 0,
                      class: "text-sm"
                    }, [
                      createVNode("div", { class: "text-[#3A3745] flex items-center gap-x-1" }, [
                        unref(selectedOption) ? (openBlock(), createBlock("span", { key: 0 }, toDisplayString(unref(selectedOption).dial_code), 1)) : createCommentVNode("", true)
                      ])
                    ])) : (openBlock(), createBlock("span", {
                      key: 1,
                      class: "block text-sm text-[#8F8C9A] whitespace-nowrap"
                    }, toDisplayString(__props.placeholder), 1)),
                    createVNode("i", { class: "uil uil-angle-down text-[#101828]" })
                  ]),
                  _: 1
                }, 8, ["class"]),
                createVNode(Transition, {
                  "leave-active-class": "transition duration-100 ease-in",
                  "leave-from-class": "opacity-100",
                  "leave-to-class": "opacity-0"
                }, {
                  default: withCtx(() => [
                    createVNode(unref(ListboxOptions), { class: "absolute mt-1 w-full min-w-[320px] border border-gray-200 z-40 rounded-lg bg-white py-6 text-xs shadow-lg ring-1 ring-black ring-opacity-5 outline-0 sm:text-[13px]" }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "relative flex items-center mb-3 mt-3 px-4" }, [
                          withDirectives(createVNode("input", {
                            "onUpdate:modelValue": ($event) => isRef(query) ? query.value = $event : null,
                            placeholder: "Search",
                            class: "text-xs rounded-lg px-3 py-1 h-10 w-full border placeholder:text-[#B6B7B9] focus:outline-matta-black/20"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(query)]
                          ])
                        ]),
                        createVNode("div", { class: "max-h-60 overflow-y-auto py-2" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(filteredCodes), (z) => {
                            return openBlock(), createBlock(unref(ListboxOption), {
                              key: z,
                              value: z,
                              as: "template"
                            }, {
                              default: withCtx(({ active, selected }) => [
                                createVNode("li", {
                                  class: [
                                    active || selected ? "bg-gray-50" : "",
                                    "relative cursor-pointer select-none py-[11px] px-[20px] text-loft-black hover:bg-gray-100  flex items-center justify-between"
                                  ]
                                }, [
                                  createVNode("p", { class: "text-sm text-[#101828] capitalize" }, toDisplayString(z.dial_code) + " - \xA0 " + toDisplayString(z.name), 1),
                                  withDirectives(createVNode("i", { class: "uil uil-check text-[#101828]" }, null, 512), [
                                    [vShow, selected]
                                  ])
                                ], 2)
                              ]),
                              _: 2
                            }, 1032, ["value"]);
                          }), 128))
                        ])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/forms/PhoneCodes.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const PhoneCodes = _sfc_main;

export { PhoneCodes as P };
//# sourceMappingURL=PhoneCodes-TGlMinMT.mjs.map
