import { _ as __nuxt_component_0$1 } from './HeaderComponent-IydhH04E.mjs';
import { u as useShippingStore, _ as __nuxt_component_1, a as __nuxt_component_7, b as __nuxt_component_8 } from './shipping-_26UFRW3.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { _ as __nuxt_component_1$1 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_2 } from './EmptyData-RrNjecQG.mjs';
import { _ as __nuxt_component_1$2 } from './AppLoader-SkdFRsgH.mjs';
import { _ as __nuxt_component_6 } from './Center-HbcRsv6_.mjs';
import { useSSRContext, ref, provide, mergeProps, unref, withCtx, createVNode, openBlock, createBlock, createCommentVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderClass } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';
import './index-eSH9oSpY.mjs';
import '../../rollup/_vue.mjs';
import 'cleave.js';
import './index-mLIR32Vn.mjs';
import './ck-white-co8-jVxZ.mjs';
import 'vee-validate';
import 'yup';
import './cartservice-JuOkMZ9e.mjs';
import './retry-handling-kb1itlan.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '@iconify/vue';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import '@headlessui/vue';

const _sfc_main$1 = {
  __name: "ShippingAddresses",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    const shippingStore = useShippingStore();
    const type = ref("form");
    const detail = ref("detail");
    const isOpen = ref(false);
    function openModal(val) {
      type.value = val;
      isOpen.value = true;
    }
    function btnFunction() {
      openModal("form");
    }
    function handleEdit(val) {
      detail.value = val;
      type.value = "edit";
      isOpen.value = true;
    }
    provide("type", type);
    provide("isOpen", isOpen);
    provide("detail", detail);
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_HeaderComponent = __nuxt_component_0$1;
      const _component_CheckoutShippingAddress = __nuxt_component_1;
      const _component_AppButton = __nuxt_component_4;
      const _component_AppIcon = __nuxt_component_1$1;
      const _component_EmptyData = __nuxt_component_2;
      const _component_AppLoader = __nuxt_component_1$2;
      const _component_ModalCenter = __nuxt_component_6;
      const _component_CheckoutShippingForm = __nuxt_component_7;
      const _component_CheckoutShippingEditForm = __nuxt_component_8;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "gap-y-4 flex flex-col pb-10" }, _attrs))} data-v-15a8d625><div class="bg-white rounded-[10px]" data-v-15a8d625>`);
      _push(ssrRenderComponent(_component_HeaderComponent, { title: "Shipping address" }, null, _parent));
      if (!unref(shippingStore).isLoading) {
        _push(`<div class="p-5" data-v-15a8d625>`);
        if ((_a = unref(shippingStore).addressesData) == null ? void 0 : _a.length) {
          _push(`<div class="mb-6 grid grid-cols-2 gap-6" data-v-15a8d625><!--[-->`);
          ssrRenderList(unref(shippingStore).addressesData, (n) => {
            _push(`<div class="${ssrRenderClass([
              n.isDefault ? "border-[#91B3F8] bg-[#E3EBFD] " : "border-[#ECF1FD]",
              "rounded-[10px] py-3 px-[16px] border-2 cursor-pointer"
            ])}" data-v-15a8d625><div data-v-15a8d625>`);
            _push(ssrRenderComponent(_component_CheckoutShippingAddress, {
              detail: n,
              active: n.isDefault
            }, null, _parent));
            _push(`</div><div class="flex gap-x-5 mt-3" data-v-15a8d625>`);
            _push(ssrRenderComponent(_component_AppButton, {
              onClick: ($event) => handleEdit(n),
              text: "Edit",
              type: "button",
              icon: "iconamoon:edit",
              btnClass: " !px-0 0 !py-[0] text-xs sm:text-sm !font-normal",
              iconClass: "!text-base"
            }, null, _parent));
            _push(ssrRenderComponent(_component_AppButton, {
              text: "Delete",
              icon: "bx:trash",
              btnClass: " !px-0  !py-[0] text-xs sm:text-sm !font-normal text-red-600",
              iconClass: "!text-base"
            }, null, _parent));
            _push(`</div></div>`);
          });
          _push(`<!--]--><div class="rounded-[10px] py-3 px-[16px] border-2 cursor-pointer flex flex-col gap-y-1 border-[#ECF1FD] h-[180px] items-center justify-center text-[#9EB8F5]" data-v-15a8d625>`);
          _push(ssrRenderComponent(_component_AppIcon, {
            icon: "fa6-solid:truck",
            iconClass: "text-2xl"
          }, null, _parent));
          _push(`<span class="text-sm" data-v-15a8d625>Add new shipping address</span></div></div>`);
        } else {
          _push(ssrRenderComponent(_component_EmptyData, {
            onBtnFunction: btnFunction,
            type: "shipping",
            title: "No shipping address",
            subtext: "",
            btnText: "Add new shipping address"
          }, null, _parent));
        }
        _push(`</div>`);
      } else {
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
      }
      _push(`</div>`);
      _push(ssrRenderComponent(_component_ModalCenter, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="w-full max-w-[500px] p-6 md:py-9 md:px-10 z-[999] relative" data-v-15a8d625${_scopeId}>`);
            if (unref(type) === "form") {
              _push2(ssrRenderComponent(_component_CheckoutShippingForm, null, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (unref(type) === "edit") {
              _push2(ssrRenderComponent(_component_CheckoutShippingEditForm, null, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "w-full max-w-[500px] p-6 md:py-9 md:px-10 z-[999] relative" }, [
                unref(type) === "form" ? (openBlock(), createBlock(_component_CheckoutShippingForm, { key: 0 })) : createCommentVNode("", true),
                unref(type) === "edit" ? (openBlock(), createBlock(_component_CheckoutShippingEditForm, { key: 1 })) : createCommentVNode("", true)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/ShippingAddresses.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-15a8d625"]]);
const _sfc_main = {
  __name: "shipping-addresses",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierShippingAddresses = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierShippingAddresses, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/procurement/shipping-addresses.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=shipping-addresses-sCbxGxhQ.mjs.map
