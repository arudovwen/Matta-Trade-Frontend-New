import { defineComponent, useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderClass, ssrIncludeBooleanAttr, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';

const _sfc_main = defineComponent({
  name: "Pagination",
  props: {
    options: {
      type: Array,
      default: () => [{}]
    },
    enableText: {
      type: Boolean,
      default: false
    },
    enableInput: {
      type: Boolean,
      default: false
    },
    enableSelect: {
      type: Boolean,
      default: false
    },
    enableSearch: {
      type: Boolean,
      default: false
    },
    pageChanged: {
      type: Function
    },
    perPageChanged: {
      type: Function
    },
    current: {
      type: Number,
      default: 1
    },
    total: {
      type: Number,
      default: 0
    },
    perPage: {
      type: Number,
      default: 10
    },
    pageRange: {
      type: Number,
      default: 2
    },
    textBeforeInput: {
      type: String,
      default: "Go to page"
    },
    textAfterInput: {
      type: String,
      default: "Go"
    },
    paginationClass: {
      type: String,
      default: "default"
    },
    searchClasss: {
      type: String,
      default: "default"
    },
    wrapperClass: {
      type: String,
      default: "justify-between"
    }
  },
  data() {
    return {
      input: "",
      input2: null
    };
  },
  methods: {
    hasFirst: function() {
      return this.rangeStart !== 1;
    },
    hasLast: function() {
      return this.rangeEnd < this.totalPages;
    },
    hasPrev: function() {
      return this.current > 1;
    },
    hasNext: function() {
      return this.current < this.totalPages;
    },
    changePage: function(page) {
      if (page > 0 && page <= this.totalPages) {
        this.$emit("page-changed", page);
      }
      if (this.pageChanged) {
        this.pageChanged({ currentPage: page });
      }
    },
    customPerPageChange(page) {
      this.perPageChanged({ currentPerPage: page });
    }
  },
  computed: {
    pages: function() {
      var pages = [];
      for (var i = this.rangeStart; i <= this.rangeEnd; i++) {
        pages.push(i);
      }
      return pages;
    },
    rangeStart: function() {
      var start = this.current - this.pageRange;
      return start > 0 ? start : 1;
    },
    rangeEnd: function() {
      var end = this.current + this.pageRange;
      return end < this.totalPages ? end : this.totalPages;
    },
    totalPages: function() {
      return Math.ceil(this.total / this.perPage);
    },
    nextPage: function() {
      return this.current + 1;
    },
    prevPage: function() {
      return this.current - 1;
    }
  }
});
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({
    class: ["flex justify-start items-center relative z-[999]", _ctx.wrapperClass]
  }, _attrs))} data-v-e4d609c1><ul class="${ssrRenderClass([_ctx.paginationClass, "pagination mx-auto lg:mx-0 bg-white border border-[#EFF1F5] p-[10px] rounded-[10px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.03)]"])}" data-v-e4d609c1><li class="leading-4" data-v-e4d609c1><button${ssrIncludeBooleanAttr(_ctx.current === 1) ? " disabled" : ""} class="${ssrRenderClass(_ctx.current === 1 ? " opacity-50 cursor-not-allowed" : "")}" data-v-e4d609c1>`);
  if (_ctx.enableText) {
    _push(`<span class="text-sm" data-v-e4d609c1>Previous</span>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</button></li>`);
  if (_ctx.hasFirst()) {
    _push(`<li class="" data-v-e4d609c1><button data-v-e4d609c1><div data-v-e4d609c1><span data-v-e4d609c1> 1 </span></div></button></li>`);
  } else {
    _push(`<!---->`);
  }
  if (_ctx.hasFirst()) {
    _push(`<li class="text-slate-600 dark:text-slate-300" data-v-e4d609c1>...</li>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<!--[-->`);
  ssrRenderList(_ctx.pages, (page, i) => {
    _push(`<li class="" data-v-e4d609c1><button data-v-e4d609c1><div class="${ssrRenderClass([{
      active: _ctx.current === page
    }, ""])}" class="" data-v-e4d609c1><span class="" data-v-e4d609c1>${ssrInterpolate(page)}</span></div></button></li>`);
  });
  _push(`<!--]-->`);
  if (_ctx.hasLast()) {
    _push(`<li class="text-slate-600 dark:text-slate-300" data-v-e4d609c1>...</li>`);
  } else {
    _push(`<!---->`);
  }
  if (_ctx.hasLast()) {
    _push(`<li class="" data-v-e4d609c1><button data-v-e4d609c1><div data-v-e4d609c1><span data-v-e4d609c1>${ssrInterpolate(_ctx.totalPages)}</span></div></button></li>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<li class="text-xl leading-4 dark:text-[#333]" data-v-e4d609c1><button${ssrIncludeBooleanAttr(_ctx.current === _ctx.totalPages) ? " disabled" : ""} class="${ssrRenderClass(
    _ctx.current === _ctx.totalPages ? " opacity-50 cursor-not-allowed" : ""
  )}" data-v-e4d609c1>`);
  if (_ctx.enableText) {
    _push(`<span class="text-sm" data-v-e4d609c1>Next</span>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</button></li></ul></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Pagination/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-e4d609c1"]]);

export { __nuxt_component_5 as _ };
//# sourceMappingURL=index-auAvMvtw.mjs.map
