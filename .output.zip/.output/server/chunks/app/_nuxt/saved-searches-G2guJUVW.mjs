import { _ as __nuxt_component_0$1 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_2 } from './Card-x8tysvFx.mjs';
import { _ as __nuxt_component_4 } from './Simple-GRXlMUar.mjs';
import { _ as __nuxt_component_2$1 } from './EmptyData-RrNjecQG.mjs';
import { _ as __nuxt_component_1 } from './AppLoader-SkdFRsgH.mjs';
import { e as useRouter } from '../server.mjs';
import { useSSRContext, ref, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import { useRoute } from 'vue-router';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './AppButton-rwP1M0KN.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import './nuxt-img-qJohECzX.mjs';
import './currencyFormat-ET0sIbrj.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$1 = {
  __name: "SavedSearches",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    useRoute();
    const router = useRouter();
    const loading = ref(false);
    ref(false);
    const productsData = ref([]);
    ref(20);
    const btnFunction = () => {
      router.push("/market");
    };
    const next = () => {
    };
    const prev = () => {
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderComponent = __nuxt_component_0$1;
      const _component_ProductCard = __nuxt_component_2;
      const _component_PaginationSimple = __nuxt_component_4;
      const _component_EmptyData = __nuxt_component_2$1;
      const _component_AppLoader = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white rounded-[10px] pb-20" }, _attrs))} data-v-23b2ebde>`);
      _push(ssrRenderComponent(_component_HeaderComponent, { title: "Saved items" }, null, _parent));
      _push(`<div class="pt-[30px]" data-v-23b2ebde>`);
      if (!unref(loading)) {
        _push(`<div data-v-23b2ebde>`);
        if (unref(productsData).length) {
          _push(`<div class="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-x-4 gap-y-[30px]" data-v-23b2ebde><!--[-->`);
          ssrRenderList(unref(productsData), (n, idx) => {
            _push(ssrRenderComponent(_component_ProductCard, {
              key: idx,
              index: idx,
              detail: n
            }, null, _parent));
          });
          _push(`<!--]--><div class="px-[30px] py-6 w-full mt-6" data-v-23b2ebde>`);
          _push(ssrRenderComponent(_component_PaginationSimple, {
            total: 40,
            pageNumber: 1,
            pageSize: 10,
            onNext: next,
            onPrev: prev,
            perPage: 5
          }, null, _parent));
          _push(`</div></div>`);
        } else {
          _push(ssrRenderComponent(_component_EmptyData, {
            onBtnFunction: btnFunction,
            btnText: "Search for products",
            title: "No saved items found",
            subtext: "You do not have any item saved yet. Click the \u201CSave for later\u201D icon on the product page and it will show up here"
          }, null, _parent));
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(loading)) {
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/SavedSearches.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-23b2ebde"]]);
const _sfc_main = {
  __name: "saved-searches",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierSavedSearches = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierSavedSearches, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/account/saved-searches.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=saved-searches-G2guJUVW.mjs.map
