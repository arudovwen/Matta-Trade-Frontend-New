import { defineComponent, useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderClass } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';

const _sfc_main = defineComponent({
  name: "Pagination",
  props: {
    options: {
      type: Array,
      default: () => [{}]
    },
    enableText: {
      type: Boolean,
      default: false
    },
    enableInput: {
      type: Boolean,
      default: false
    },
    enableSelect: {
      type: Boolean,
      default: false
    },
    enableSearch: {
      type: Boolean,
      default: false
    },
    pageChanged: {
      type: Function
    },
    perPageChanged: {
      type: Function
    },
    current: {
      type: Number,
      default: 1
    },
    total: {
      type: Number,
      default: 0
    },
    perPage: {
      type: Number,
      default: 10
    },
    pageRange: {
      type: Number,
      default: 2
    },
    textBeforeInput: {
      type: String,
      default: "Go to page"
    },
    textAfterInput: {
      type: String,
      default: "Go"
    },
    paginationClass: {
      type: String,
      default: "default"
    },
    searchClasss: {
      type: String,
      default: "default"
    },
    wrapperClass: {
      type: String,
      default: "justify-between"
    }
  },
  data() {
    return {
      input: "",
      input2: null
    };
  },
  methods: {
    hasFirst: function() {
      return this.rangeStart !== 1;
    },
    hasLast: function() {
      return this.rangeEnd < this.totalPages;
    },
    hasPrev: function() {
      return this.current > 1;
    },
    hasNext: function() {
      return this.current < this.totalPages;
    },
    changePage: function(page) {
      if (page > 0 && page <= this.totalPages) {
        this.$emit("page-changed", page);
      }
      if (this.pageChanged) {
        this.pageChanged({ currentPage: page });
      }
    },
    customPerPageChange(page) {
      this.perPageChanged({ currentPerPage: page });
    }
  },
  computed: {
    pages: function() {
      var pages = [];
      for (var i = this.rangeStart; i <= this.rangeEnd; i++) {
        pages.push(i);
      }
      return pages;
    },
    rangeStart: function() {
      var start = this.current - this.pageRange;
      return start > 0 ? start : 1;
    },
    rangeEnd: function() {
      var end = this.current + this.pageRange;
      return end < this.totalPages ? end : this.totalPages;
    },
    totalPages: function() {
      return Math.ceil(this.total / this.perPage);
    },
    nextPage: function() {
      return this.current + 1;
    },
    prevPage: function() {
      return this.current - 1;
    }
  }
});
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({
    class: ["flex justify-between items-center relative z-[999]", _ctx.wrapperClass]
  }, _attrs))} data-v-709411ea><span class="text-sm text-[#344054]" data-v-709411ea> Page <span data-v-709411ea>${ssrInterpolate(_ctx.current)}</span> to <span data-v-709411ea>${ssrInterpolate(_ctx.totalPages)}</span></span><div class="flex gap-x-4" data-v-709411ea><button${ssrIncludeBooleanAttr(_ctx.current === 1) ? " disabled" : ""} class="${ssrRenderClass(`${_ctx.current === 1 ? " opacity-50 cursor-not-allowed" : ""} border border-[#D0D5DD] rounded-[5px] text-sm px-4 py-2`)}" data-v-709411ea><span class="text-sm" data-v-709411ea>Previous</span></button><button${ssrIncludeBooleanAttr(_ctx.current === _ctx.totalPages) ? " disabled" : ""} class="${ssrRenderClass(`${_ctx.current === _ctx.totalPages ? " opacity-50 cursor-not-allowed" : ""} border border-[#D0D5DD] rounded-[5px] text-sm px-4 py-2`)}" data-v-709411ea><span class="text-sm" data-v-709411ea>Next</span></button></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Pagination/Simple.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-709411ea"]]);

export { __nuxt_component_4 as _ };
//# sourceMappingURL=Simple-GRXlMUar.mjs.map
