import { _ as __nuxt_component_0$4 } from './index-4NCxcAqd.mjs';
import { _ as __nuxt_component_1$3 } from './nuxt-img-qJohECzX.mjs';
import { _ as __nuxt_component_1$4 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { _ as __nuxt_component_4$1 } from './index-RMKHVahR.mjs';
import { _ as __nuxt_component_5 } from './CartButton-sf044Ti9.mjs';
import { _ as __nuxt_component_5$1 } from './SideModal-MJCox7bt.mjs';
import { ref, provide, useSSRContext, inject, reactive, resolveComponent, unref, withCtx, createVNode, createTextVNode, withModifiers, withDirectives, vModelText, openBlock, createBlock, Fragment, renderList, toDisplayString, vModelDynamic, createCommentVNode, computed, watch, isRef, mergeProps, Transition } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderClass, ssrRenderList, ssrInterpolate, ssrRenderDynamicModel, ssrIncludeBooleanAttr, ssrRenderStyle, ssrLooseContain, ssrLooseEqual } from 'vue/server-renderer';
import { P as PhoneCodes } from './PhoneCodes-TGlMinMT.mjs';
import { _ as __nuxt_component_0$5 } from './IndexModal-vEF7RYpX.mjs';
import { C as CountriesSelect } from './CountriesSelect-jqw8V4-X.mjs';
import useVuelidate from '@vuelidate/core';
import { helpers, required, email, maxLength, minLength, numeric } from '@vuelidate/validators';
import { toast } from 'vue3-toastify';
import { d as getalladdress } from './cartservice-JuOkMZ9e.mjs';
import { TransitionRoot, Dialog, TransitionChild, DialogOverlay, Listbox, ListboxButton, ListboxOptions, ListboxOption } from '@headlessui/vue';
import { EyeIcon, EyeSlashIcon, CheckCircleIcon } from '@heroicons/vue/24/outline';
import { u as useRoute, y as useStore, d as useAuthStore, s as storeToRefs, e as useRouter, B as likeproduct, b as getProducts, c as useMarketStore, f as useApplicationStore } from '../server.mjs';
import { l as loginUser, r as registerUser } from './authservices-pXd32gsl.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import { u as useProductStore, a as useSupplierStore } from './supplier-RTXftR8K.mjs';
import { b as addrequest } from './procurementservice-j_HRfk2m.mjs';
import { _ as __nuxt_component_2$6 } from './SelectComponent-Q1jk_qng.mjs';
import { m as measurements } from './constants-7QnerJ-N.mjs';
import { C as CurrencyInput } from './CurrencyInput-krSh-4ij.mjs';
import { n as newquote } from './quoteservice-5V3YxrdU.mjs';
import { _ as __unimport_currencyFormat } from './currencyFormat-ET0sIbrj.mjs';
import { XMarkIcon } from '@heroicons/vue/24/solid';
import { u as useCartStore } from './cart-fg4oswtQ.mjs';
import { _ as __nuxt_component_2$5 } from './Skelenton-oPDHwk9e.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '@iconify/vue';
import 'country-list-with-dial-code-and-flag';
import './countries-4zSrMx8v.mjs';
import './retry-handling-kb1itlan.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';
import 'vue-currency-input';

const _sfc_main$j = {
  __name: "UsageDetails",
  __ssrInlineRender: true,
  setup(__props) {
    const request1$ = inject("request1$");
    const sampleForm = inject("sampleForm");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<form${ssrRenderAttrs(mergeProps({ class: "mt-12" }, _attrs))}><legend class="text-lg font-medium mb-2">Usage Details</legend><p class="text-xs text-[#ABABAB] mb-8"> This information will help us get you the right materials. </p><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Number of Samples</label><div class="flex relative"><div class="flex relative items-center w-full"><select${ssrRenderAttr("value", unref(request1$).numberofSamples.$model)} disabled class="${ssrRenderClass([{ "border-red-500 ": unref(request1$).numberofSamples.$error }, "rounded-lg appearance-none px-[14px] py-[10px] h-11 border w-full bg-[#F1F3F5] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}"><!--[-->`);
      ssrRenderList(10, (z) => {
        _push(`<option${ssrRenderAttr("value", z)}><span class="flex gap-x-6"><span>${ssrInterpolate(z)}</span></span></option>`);
      });
      _push(`<!--]--></select></div></div><!--[-->`);
      ssrRenderList(unref(request1$).numberofSamples.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-normal text-xs block">What quantity would you purchase? </label><div class="flex relative"><div class="flex h-[60px] w-full items-center gap-x-3 lg:gap-x-4 rounded-lg bg-[#F1F3F5] relative py-4 md:py-5 text-xs lg:text-[13px] px-4 lg:px-4 uppercase text-matta-black"><button class="disabled:opacity-20 disabled:cursor-not-allowed p-2" type="button"${ssrIncludeBooleanAttr(unref(sampleForm).expectedAnualUsage <= 1) ? " disabled" : ""}><i class="uil uil-minus text-lg"></i></button><input min="1" class="min-w-[30px] md:min-w-[50px] text-center text-xs md:text-base bg-transparent focus:outline-matta-black/10 flex-1 p-2"${ssrRenderAttr("value", unref(sampleForm).expectedAnualUsage)}><button type="button" class="p-2"><i class="uil uil-plus"></i></button></div></div><!--[-->`);
      ssrRenderList(unref(request1$).expectedAnualUsage.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></form>`);
    };
  }
};
const _sfc_setup$j = _sfc_main$j.setup;
_sfc_main$j.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Information/sample/UsageDetails.vue");
  return _sfc_setup$j ? _sfc_setup$j(props, ctx) : void 0;
};
const __nuxt_component_0$3 = _sfc_main$j;
const _sfc_main$i = {
  __name: "ShippingForm",
  __ssrInlineRender: true,
  setup(__props) {
    inject("togglePopup");
    inject("handleReload");
    const form = reactive({
      firstName: "",
      lastName: "",
      country: "",
      city: "",
      street: "",
      postalCode: "",
      isDefault: false
    });
    const isLoading = ref(false);
    const rules = {
      firstName: {
        required,
        maxLength: maxLength(50)
      },
      postalCode: {
        required
      },
      lastName: {
        required
      },
      country: {
        required
      },
      street: {
        required
      },
      city: {
        required
      }
    };
    const v$ = useVuelidate(rules, form);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormsCountriesSelect = CountriesSelect;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-6" }, _attrs))}><h3 class="font-medium text-2xl mb-8">Add new shipping address</h3><form><div class="grid grid-cols-2 gap-x-4"><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">First name</label><input${ssrRenderAttr("value", unref(v$).firstName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).firstName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on"><!--[-->`);
      ssrRenderList(unref(v$).firstName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Last name</label><input${ssrRenderAttr("value", unref(v$).lastName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).lastName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on"><!--[-->`);
      ssrRenderList(unref(v$).lastName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="grid grid-cols-2 gap-x-4"><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Country</label><div class="relative">`);
      _push(ssrRenderComponent(_component_FormsCountriesSelect, {
        modelValue: unref(v$).country.$model,
        "onUpdate:modelValue": ($event) => unref(v$).country.$model = $event
      }, null, _parent));
      _push(`<!--[-->`);
      ssrRenderList(unref(v$).country.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">City</label><input${ssrRenderAttr("value", unref(v$).city.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).city.$error }, "px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] rounded-lg focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" placeholder="Company city"><!--[-->`);
      ssrRenderList(unref(v$).city.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="grid grid-cols-2 gap-x-4"><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Street</label><input${ssrRenderAttr("value", unref(v$).street.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).street.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on"><!--[-->`);
      ssrRenderList(unref(v$).street.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Postal code</label><input${ssrRenderAttr("value", unref(v$).postalCode.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).postalCode.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on"><!--[-->`);
      ssrRenderList(unref(v$).postalCode.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="mb-6"><label class="text-xs flex gap-x-2 items-center"><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(form).isDefault) ? ssrLooseContain(unref(form).isDefault, null) : unref(form).isDefault) ? " checked" : ""} class="accent-matta-black">Mark as Default shipping address </label></div><div class="flex justify-end gap-x-4 mt-8"><button type="button" class="text-xs upperase hover:bg-gray-50"> Cancel </button><button type="submit"${ssrIncludeBooleanAttr(unref(isLoading)) ? " disabled" : ""} class="text-xs uppercase bg-primary-500 text-white px-5 py-4 rounded-lg hover:bg-primary/70 disabled:opacity-60"> Submit </button></div></form></div>`);
    };
  }
};
const _sfc_setup$i = _sfc_main$i.setup;
_sfc_main$i.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Information/sample/ShippingForm.vue");
  return _sfc_setup$i ? _sfc_setup$i(props, ctx) : void 0;
};
const __nuxt_component_2$4 = _sfc_main$i;
const _sfc_main$h = {
  __name: "ShippingAddress",
  __ssrInlineRender: true,
  setup(__props) {
    const request2$ = inject("request2$");
    const sampleForm = inject("sampleForm");
    const isOpen = ref(false);
    const selectedoption = ref();
    const addresses = ref([]);
    const phoneCode = ref("+234");
    watch(selectedoption, () => {
      sampleForm.shippingAddressId = selectedoption.value.id;
    });
    function togglePopup() {
      isOpen.value = false;
    }
    function handleReload() {
      getalladdress().then((res) => {
        addresses.value = res.data.data;
      });
      isOpen.value = false;
    }
    provide("togglePopup", togglePopup);
    provide("handleReload", handleReload);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormsPhoneCodes = PhoneCodes;
      const _component_IndexModal = __nuxt_component_0$5;
      const _component_InformationSampleShippingForm = __nuxt_component_2$4;
      _push(`<!--[--><form class="mt-12"><legend class="text-lg font-medium mb-1">Shipping Address</legend><p class="text-sm text-[#ABABAB] mb-8"> Choose your shipping options for samples requested. </p><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">E-mail</label><input class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" placeholder="E-mail" autocomplete="off" autofocus="on"${ssrRenderAttr("value", unref(request2$).email.$model)}><!--[-->`);
      ssrRenderList(unref(request2$).email.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Phone number</label><div class="flex relative rounded-lg h-11">`);
      _push(ssrRenderComponent(_component_FormsPhoneCodes, {
        modelValue: phoneCode.value,
        "onUpdate:modelValue": ($event) => phoneCode.value = $event
      }, null, _parent));
      _push(`<input${ssrRenderAttr("value", unref(request2$).phone.$model)} class="flex-1 rounded-r-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" autofocus="on" placeholder="08160723884" type="tel"></div><!--[-->`);
      ssrRenderList(unref(request2$).phone.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Address</label>`);
      _push(ssrRenderComponent(unref(Listbox), {
        modelValue: selectedoption.value,
        "onUpdate:modelValue": ($event) => selectedoption.value = $event
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="relative w-full"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ListboxButton), { class: "relative w-full cursor-default rounded-lg min-h-[40px] border-[#D0D5DD] bg-[#F1F3F5] py-2 px-[15px] text-left shadow-[0px_1px_2px_rgba(16,24,40,0.05)] sm:text-[13px] flex items-center" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  if (selectedoption.value) {
                    _push3(`<span class="flex gap-x-1 text-[#101828] text-[13px] whitespace-nowrap"${_scopeId2}><span class="font-medium capitalize"${_scopeId2}>${ssrInterpolate(`${selectedoption.value.firstName} ${selectedoption.value.lastName}`)}</span>, <span class="truncate ... max-w-[170px]"${_scopeId2}>${ssrInterpolate(selectedoption.value.street)}</span></span>`);
                  } else {
                    _push3(`<span class="block text-[#8F8C9A] text-[13px] whitespace-nowrap"${_scopeId2}>Choose your shipping adress...</span>`);
                  }
                  _push3(`<span class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2"${_scopeId2}><i class="uil uil-angle-down absolute right-2 appearance-none"${_scopeId2}></i></span>`);
                } else {
                  return [
                    selectedoption.value ? (openBlock(), createBlock("span", {
                      key: 0,
                      class: "flex gap-x-1 text-[#101828] text-[13px] whitespace-nowrap"
                    }, [
                      createVNode("span", { class: "font-medium capitalize" }, toDisplayString(`${selectedoption.value.firstName} ${selectedoption.value.lastName}`), 1),
                      createTextVNode(", "),
                      createVNode("span", { class: "truncate ... max-w-[170px]" }, toDisplayString(selectedoption.value.street), 1)
                    ])) : (openBlock(), createBlock("span", {
                      key: 1,
                      class: "block text-[#8F8C9A] text-[13px] whitespace-nowrap"
                    }, "Choose your shipping adress...")),
                    createVNode("span", { class: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" }, [
                      createVNode("i", { class: "uil uil-angle-down absolute right-2 appearance-none" })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ListboxOptions), { class: "absolute mt-1 w-full z-40 rounded-lg bg-white px-6 pb-6 text-xs shadow-lg ring-1 ring-black ring-opacity-5 outline-0 sm:text-[13px]" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="max-h-60 overflow-y-auto mb-3"${_scopeId2}><!--[-->`);
                  ssrRenderList(addresses.value, (option) => {
                    _push3(ssrRenderComponent(unref(ListboxOption), {
                      key: option.name,
                      value: option,
                      as: "template"
                    }, {
                      default: withCtx(({ active }, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<li class="${ssrRenderClass([
                            active ? "bg-gray-100" : "",
                            "relative cursor-default select-none pt-6 pb-6 text-loft-black border-b hover:bg-gray-50"
                          ])}"${_scopeId3}><p class="text-sm font-medium mb-1 capitalize"${_scopeId3}>${ssrInterpolate(`${option.firstName} ${option.lastName}`)}</p><p class="flex items-center justify-start gap-x-2 text-xs"${_scopeId3}><span${_scopeId3}>${ssrInterpolate(option.country)}</span><span class="p-[.15rem] rounded-full bg-[#DDDDDD]"${_scopeId3}></span><span class="line-clamp-1"${_scopeId3}>${ssrInterpolate(option.street)}</span></p></li>`);
                        } else {
                          return [
                            createVNode("li", {
                              class: [
                                active ? "bg-gray-100" : "",
                                "relative cursor-default select-none pt-6 pb-6 text-loft-black border-b hover:bg-gray-50"
                              ]
                            }, [
                              createVNode("p", { class: "text-sm font-medium mb-1 capitalize" }, toDisplayString(`${option.firstName} ${option.lastName}`), 1),
                              createVNode("p", { class: "flex items-center justify-start gap-x-2 text-xs" }, [
                                createVNode("span", null, toDisplayString(option.country), 1),
                                createVNode("span", { class: "p-[.15rem] rounded-full bg-[#DDDDDD]" }),
                                createVNode("span", { class: "line-clamp-1" }, toDisplayString(option.street), 1)
                              ])
                            ], 2)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]--></div><button type="button" class="text-xs text-primary mt-2"${_scopeId2}><i class="uil uil-plus"${_scopeId2}></i><span${_scopeId2}>Add new shipping address</span></button>`);
                } else {
                  return [
                    createVNode("div", { class: "max-h-60 overflow-y-auto mb-3" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(addresses.value, (option) => {
                        return openBlock(), createBlock(unref(ListboxOption), {
                          key: option.name,
                          value: option,
                          as: "template"
                        }, {
                          default: withCtx(({ active }) => [
                            createVNode("li", {
                              class: [
                                active ? "bg-gray-100" : "",
                                "relative cursor-default select-none pt-6 pb-6 text-loft-black border-b hover:bg-gray-50"
                              ]
                            }, [
                              createVNode("p", { class: "text-sm font-medium mb-1 capitalize" }, toDisplayString(`${option.firstName} ${option.lastName}`), 1),
                              createVNode("p", { class: "flex items-center justify-start gap-x-2 text-xs" }, [
                                createVNode("span", null, toDisplayString(option.country), 1),
                                createVNode("span", { class: "p-[.15rem] rounded-full bg-[#DDDDDD]" }),
                                createVNode("span", { class: "line-clamp-1" }, toDisplayString(option.street), 1)
                              ])
                            ], 2)
                          ]),
                          _: 2
                        }, 1032, ["value"]);
                      }), 128))
                    ]),
                    createVNode("button", {
                      type: "button",
                      class: "text-xs text-primary mt-2",
                      onClick: ($event) => isOpen.value = true
                    }, [
                      createVNode("i", { class: "uil uil-plus" }),
                      createVNode("span", null, "Add new shipping address")
                    ], 8, ["onClick"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "relative w-full" }, [
                createVNode(unref(ListboxButton), { class: "relative w-full cursor-default rounded-lg min-h-[40px] border-[#D0D5DD] bg-[#F1F3F5] py-2 px-[15px] text-left shadow-[0px_1px_2px_rgba(16,24,40,0.05)] sm:text-[13px] flex items-center" }, {
                  default: withCtx(() => [
                    selectedoption.value ? (openBlock(), createBlock("span", {
                      key: 0,
                      class: "flex gap-x-1 text-[#101828] text-[13px] whitespace-nowrap"
                    }, [
                      createVNode("span", { class: "font-medium capitalize" }, toDisplayString(`${selectedoption.value.firstName} ${selectedoption.value.lastName}`), 1),
                      createTextVNode(", "),
                      createVNode("span", { class: "truncate ... max-w-[170px]" }, toDisplayString(selectedoption.value.street), 1)
                    ])) : (openBlock(), createBlock("span", {
                      key: 1,
                      class: "block text-[#8F8C9A] text-[13px] whitespace-nowrap"
                    }, "Choose your shipping adress...")),
                    createVNode("span", { class: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" }, [
                      createVNode("i", { class: "uil uil-angle-down absolute right-2 appearance-none" })
                    ])
                  ]),
                  _: 1
                }),
                createVNode(Transition, {
                  "leave-active-class": "transition duration-100 ease-in",
                  "leave-from-class": "opacity-100",
                  "leave-to-class": "opacity-0"
                }, {
                  default: withCtx(() => [
                    createVNode("div", null, [
                      createVNode(unref(ListboxOptions), { class: "absolute mt-1 w-full z-40 rounded-lg bg-white px-6 pb-6 text-xs shadow-lg ring-1 ring-black ring-opacity-5 outline-0 sm:text-[13px]" }, {
                        default: withCtx(() => [
                          createVNode("div", { class: "max-h-60 overflow-y-auto mb-3" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(addresses.value, (option) => {
                              return openBlock(), createBlock(unref(ListboxOption), {
                                key: option.name,
                                value: option,
                                as: "template"
                              }, {
                                default: withCtx(({ active }) => [
                                  createVNode("li", {
                                    class: [
                                      active ? "bg-gray-100" : "",
                                      "relative cursor-default select-none pt-6 pb-6 text-loft-black border-b hover:bg-gray-50"
                                    ]
                                  }, [
                                    createVNode("p", { class: "text-sm font-medium mb-1 capitalize" }, toDisplayString(`${option.firstName} ${option.lastName}`), 1),
                                    createVNode("p", { class: "flex items-center justify-start gap-x-2 text-xs" }, [
                                      createVNode("span", null, toDisplayString(option.country), 1),
                                      createVNode("span", { class: "p-[.15rem] rounded-full bg-[#DDDDDD]" }),
                                      createVNode("span", { class: "line-clamp-1" }, toDisplayString(option.street), 1)
                                    ])
                                  ], 2)
                                ]),
                                _: 2
                              }, 1032, ["value"]);
                            }), 128))
                          ]),
                          createVNode("button", {
                            type: "button",
                            class: "text-xs text-primary mt-2",
                            onClick: ($event) => isOpen.value = true
                          }, [
                            createVNode("i", { class: "uil uil-plus" }),
                            createVNode("span", null, "Add new shipping address")
                          ], 8, ["onClick"])
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--[-->`);
      ssrRenderList(unref(request2$).shippingAddressId.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Description</label><textarea placeholder="" row="4" class="placeholder:text-xs rounded-lg px-[14px] py-[10px] w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20">${ssrInterpolate(unref(request2$).addressDescription.$model)}</textarea><!--[-->`);
      ssrRenderList(unref(request2$).addressDescription.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></form>`);
      _push(ssrRenderComponent(_component_IndexModal, {
        isOpen: isOpen.value,
        onTogglePopup: ($event) => isOpen.value = false
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_InformationSampleShippingForm, null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_InformationSampleShippingForm)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$h = _sfc_main$h.setup;
_sfc_main$h.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Information/sample/ShippingAddress.vue");
  return _sfc_setup$h ? _sfc_setup$h(props, ctx) : void 0;
};
const __nuxt_component_1$2 = _sfc_main$h;
const _sfc_main$g = {
  __name: "RequestComplete",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-8 text-center mt-24" }, _attrs))}>`);
      _push(ssrRenderComponent(unref(CheckCircleIcon), { class: "h-20 w-20 text-green-400 mb-8 mx-auto" }, null, _parent));
      _push(`<p class="text-xl mb-3 font-medium">Request has been sent</p><p class="text-xs"> We will notify you as soon as we receive the requested document. </p></div>`);
    };
  }
};
const _sfc_setup$g = _sfc_main$g.setup;
_sfc_main$g.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Information/sample/RequestComplete.vue");
  return _sfc_setup$g ? _sfc_setup$g(props, ctx) : void 0;
};
const __nuxt_component_2$3 = _sfc_main$g;
const _imports_0 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAnCAYAAABnlOo2AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAeGVYSWZNTQAqAAAACAAFARIAAwAAAAEAAQAAARoABQAAAAEAAABKARsABQAAAAEAAABSASgAAwAAAAEAAgAAh2kABAAAAAEAAABaAAAAAAAAAJAAAAABAAAAkAAAAAEAAqACAAQAAAABAAAAJKADAAQAAAABAAAAJwAAAADIRUFkAAAACXBIWXMAABYlAAAWJQFJUiTwAAACy2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNi4wLjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8dGlmZjpZUmVzb2x1dGlvbj4xNDQ8L3RpZmY6WVJlc29sdXRpb24+CiAgICAgICAgIDx0aWZmOlJlc29sdXRpb25Vbml0PjI8L3RpZmY6UmVzb2x1dGlvblVuaXQ+CiAgICAgICAgIDx0aWZmOlhSZXNvbHV0aW9uPjE0NDwvdGlmZjpYUmVzb2x1dGlvbj4KICAgICAgICAgPHRpZmY6T3JpZW50YXRpb24+MTwvdGlmZjpPcmllbnRhdGlvbj4KICAgICAgICAgPGV4aWY6UGl4ZWxYRGltZW5zaW9uPjIwODwvZXhpZjpQaXhlbFhEaW1lbnNpb24+CiAgICAgICAgIDxleGlmOkNvbG9yU3BhY2U+MTwvZXhpZjpDb2xvclNwYWNlPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+OTY8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4Kn6W2dQAABDJJREFUWAntVs1v3EQUf2+8u2loqrpSKe0B5FCOSHVLK6FKqF7gD9jwJZUeGo6oBzhWCmizEh/HlhMnlHAKn0q4Q9YVl4ogsrkjxZwC5WNdtDSiXs/wnhO7Xu947SpbEFJGWnve73395s288QLsj/0K7K0CeL/um45tHhSiAWBcAAE2KmUpQJPjIChfIXqgoEO/G6EM3BNux7ufHKUJbTm2ZRjVJiVtxARKJloMw6BVllghIa7IlKg2FcKbJQlozVDh/MOr37W0yhQ4ktBuVdpkb6V89jL1qFr1UdUSedFvObZNWzROMpzKUkbNzsvJuLZCD6AyOxwUvHZsdW1xR9A/hwhFXWRU18nc0rvsogp8QNVR1E0I0mNUgbAEwik69NSFmVGCDHtUMm4QHeACMgpV6044dX3adf2sP8tbztOWqPRn6SA3I31JMmw7UKHu1eNWsPboZhRE81AKPZRq5pi71tGoh6Bbzjmb76qibUo7DhDqf1Nd2P72+Cz90jbRnMlIKahDbnpDyjECCSHVBrMfVrscO/xlEnpfToO8XUtShVT2EwUHMjHewyRp+yCoJgfReGQbDl36ESqP9eLQi/8GGU6WEBIGXIizR4rDdyNSk8/8DHdD+CCte5DzZMuCryvU6mhnk5GBV3k+mM7iWfnZd3u5zZC1HZLVQWf1LfyJ8VTbo8VAdoQKN7JYjmzl4IWwVD1ecEQo2TICTJ0novJ0+DgxodCK46UJxdh/+k4T8nVMyOCwDh8nJlEmuVOEcrYGwRlncn0sTAglh1pK3BB0zWcdrvWetM4unXS+v/iFm9WlZSlVPS1n57TyBgh8I4tHctjvxHhCCA3pghKXY8VW+BC807Phh+Ao3QaqSbgb63Rv9+1DI/XPvddr0j+DoUGQ584fSSqUbFlVhCtkHSmYxJU/z++Q2QnhnF16yRmKVhJw3u9aREbrj5mFJoSwDr4C9fGn24/DldvngSs0MIRatpca1gBWQnDmu6aQtXaeqZTyq7SOCN4bHy7b1kd/n9y8hwzOyNgLVFjvXFzxBjV6ickY1VqbFmrrLHi72nNT02ldUiEGX5/peGSU+90inVVBY/OpT15cKKrWmaUXZu88MbcuK79qyXA+itfid3oMVIgV9kLDNCbFOgJaJBYNagR1Q9JKI0MFpiGQ/sJSR+3e/KJ/FCZ+uwTVv84MxCKboeqwwRAhBnn1Bop2SVLsUjgm/mjARHdm1075Muifpu7yso5aQmx07rOXbSnD5XGSqlCVDvz+qg+BWXfnjnSyZFjOJcTKcVeKtykUYqbzyudaMpxz4FAzkB7cTeG2PE2Bcg962r5g7obcoSPIsP/ICqUTRNUCYx4RLqfxEnM6+Ngq+vTEcUoTih24C8UB0aCz5RA57iiLgpisp7lPT18AuqFUGzWUKzdL3llx/P33/64C/wCsCHJXzVpDAAAAAABJRU5ErkJggg==";
const _sfc_main$f = {
  __name: "RegisterComponent",
  __ssrInlineRender: true,
  setup(__props) {
    inject("toggleAuth");
    const type = ref("buyer");
    inject("handleSubmit");
    const form = reactive({
      email: "",
      password: "",
      business_UserType: 0,
      confirmPassword: "",
      BusinessName: "BusinessName"
    });
    const isLoading = ref(false);
    const validPassword = (value) => {
      let res = /[a-z]/.test(value) && /[A-Z]/.test(value) && /[0-9]/.test(value);
      return res;
    };
    const specialPassword = (value) => {
      let res = /[@&!%#$%]/.test(value);
      return res;
    };
    const samePassword = (value) => value === form.password;
    const rules = {
      email: {
        required: helpers.withMessage("Email field cannot be empty", required),
        email: helpers.withMessage("Email is invalid", email),
        maxLength: maxLength(50)
      },
      password: {
        required: helpers.withMessage("Password field cannot be empty", required),
        minLength: minLength(8),
        maxLength: maxLength(24),
        validPassword: helpers.withMessage(
          "Password must include UPPER/lowercase characters and number",
          validPassword
        ),
        specialPassword: helpers.withMessage(
          "Password must contain at least 1 of the special  characters @&!-%#$%",
          specialPassword
        )
      },
      confirmPassword: {
        required: helpers.withMessage(
          "Confirm Password field cannot be empty",
          required
        ),
        minLength: minLength(8),
        maxLength: maxLength(24),
        validPassword: helpers.withMessage(
          "Confirm Password is invalid",
          validPassword
        ),
        samePassword: helpers.withMessage("Passwords do not match!", samePassword)
      }
    };
    ref(false);
    const v$ = useVuelidate(rules, form);
    const isShowingPasword = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "mt-12 max-w-[400px]" }, _attrs))}><p class="text-lg font-medium mb-2">Only one step left!</p><p class="text-sm text-[#ABABAB] mb-8"> Sign Up with your work email so Supplier can respond. Already have an account? <span class="text-primary">Log in <i class="uil uil-arrow-up-right text-x"></i></span></p><form><div class="flex gap-x-3 md:gap-x-6 items-center mb-10"><button type="button" class="${ssrRenderClass([
        unref(type) === "buyer" ? "border-matta-black bg-matta-black hover:bg-matta-black/80 text-white" : "border-matta-black bg-white hover:bg-matta-black/10 text-matta-black",
        "border uppercase w-full rounded-lg px-6 py-3 text-sm flex items-center gap-x-2 justify-center"
      ])}"><i class="uil uil-shopping-cart-alt"></i><span class="opacity-50">|</span><span>Buyer</span></button><button type="button" class="${ssrRenderClass([
        unref(type) === "supplier" ? "border-matta-black bg-matta-black hover:bg-matta-black/80 text-white" : "border-matta-black bg-white hover:bg-matta-black/10 text-matta-black",
        "border uppercase w-full rounded-lg px-6 py-3 text-sm flex items-center gap-x-2 justify-center"
      ])}"><i class="uil uil-shop"></i><span class="opacity-50">|</span><span>Supplier</span></button></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">E-mail</label><input${ssrRenderAttr("value", unref(v$).email.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).email.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="E-mail" autocomplete="off" autofocus="on"><!--[-->`);
      ssrRenderList(unref(v$).email.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-normal text-xs block text-matta-black">Password</label><div class="relative flex items-center"><input${ssrRenderDynamicModel(!unref(isShowingPasword) ? "password" : "text", unref(v$).password.$model, null)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).password.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Password" autocomplete="off"${ssrRenderAttr("type", !unref(isShowingPasword) ? "password" : "text")}>`);
      if (!unref(isShowingPasword)) {
        _push(ssrRenderComponent(unref(EyeIcon), {
          onClick: ($event) => isShowingPasword.value = !unref(isShowingPasword),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      } else {
        _push(ssrRenderComponent(unref(EyeSlashIcon), {
          onClick: ($event) => isShowingPasword.value = !unref(isShowingPasword),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      }
      _push(`</div><!--[-->`);
      ssrRenderList(unref(v$).password.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-12"><label class="mb-2 font-normal text-xs block text-matta-black">Confirm Password</label><div class="relative flex items-center"><input${ssrRenderDynamicModel(!unref(isShowingPasword) ? "password" : "text", unref(v$).confirmPassword.$model, null)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).confirmPassword.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Password" autocomplete="off"${ssrRenderAttr("type", !unref(isShowingPasword) ? "password" : "text")}>`);
      if (!unref(isShowingPasword)) {
        _push(ssrRenderComponent(unref(EyeIcon), {
          onClick: ($event) => isShowingPasword.value = !unref(isShowingPasword),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      } else {
        _push(ssrRenderComponent(unref(EyeSlashIcon), {
          onClick: ($event) => isShowingPasword.value = !unref(isShowingPasword),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      }
      _push(`</div><!--[-->`);
      ssrRenderList(unref(v$).confirmPassword.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class=""><button${ssrIncludeBooleanAttr(unref(v$).$silentErrors.length || unref(isLoading)) ? " disabled" : ""} class="${ssrRenderClass([{
        "opacity-70 cursor-not-allowed": unref(v$).$silentErrors.length || unref(isLoading)
      }, "border mb-4 text-[13px] border-primary- uppercase text-white w-full min-w-[55px] bg-primary-500 text-center opacity-80 rounded-full px-6 py-2 hover:opacity-100 h-11 leading-[normal]"])}">`);
      if (unref(isLoading)) {
        _push(`<span>Signing up <i style="${ssrRenderStyle(unref(isLoading) ? null : { display: "none" })}" class="fa fa-spinner fa-spin text-white" aria-hidden="true"></i></span>`);
      } else {
        _push(`<span> Sign up</span>`);
      }
      _push(`</button><div class="text-center mt-4"><p class="mb-0 text-matta-black text-sm relative before:absolute before:w-[25%] before:border-t before:top-[7px] after:top-[7px] before:left-0 after:right-0 after:border-t after:w-[25%] after:absolute text-center uppercase"> Or continue with </p><div class="flex justify-center gap-x-6 mt-6"><button class="border border-[#E7EBEE] rounded-full flex items-center h-11 w-12 justify-center text-center hover:bg-gray-400 hover:shadow-sm relative"><img${ssrRenderAttr("src", _imports_0)} alt="google" class="w-4 h-auto"></button></div></div></div></form></div>`);
    };
  }
};
const _sfc_setup$f = _sfc_main$f.setup;
_sfc_main$f.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Information/sample/RegisterComponent.vue");
  return _sfc_setup$f ? _sfc_setup$f(props, ctx) : void 0;
};
const __nuxt_component_3$1 = _sfc_main$f;
const _sfc_main$e = {
  __name: "LoginModal",
  __ssrInlineRender: true,
  props: {
    title: {
      default: ""
    },
    text: {
      default: ""
    },
    isOpen: {
      default: false
    },
    showSignup: {
      default: true
    }
  },
  emits: ["deleteItem", "close"],
  setup(__props, { emit: __emit }) {
    const emits = __emit;
    const toggleModal = inject("toggleModal");
    function handleclose(val) {
      emits("close", val);
    }
    const store = useStore();
    const form = reactive({
      email: "",
      password: ""
    });
    const isLoading = ref(false);
    const validPassword = (value) => {
      let res = /[a-z]/.test(value) && /[A-Z]/.test(value) && /[0-9]/.test(value);
      return res;
    };
    const rules = {
      email: {
        required: helpers.withMessage("Email field cannot be empty", required),
        email: helpers.withMessage("Email is invalid", email),
        maxLength: maxLength(50)
      },
      password: {
        required: helpers.withMessage("Password field cannot be empty", required),
        minLength: minLength(8),
        validPassword: helpers.withMessage("Password is invalid", validPassword),
        maxLength: maxLength(24)
      }
    };
    const invalidCredentials = ref(false);
    const v$ = useVuelidate(rules, form);
    const isShowingPasword = ref(false);
    async function handleSubmit() {
      const validity = await v$.value.$validate();
      if (!validity)
        return;
      isLoading.value = true;
      loginUser(form).then((res) => {
        if (res.status === 200) {
          store.commit("setUser", res.data.data);
          store.dispatch("handleToken", res.data.data.jwToken).then(() => {
            handleclose("success");
          });
          toast.info("Login successful");
          (void 0).location.reload();
        }
      }).catch((err) => {
        invalidCredentials.value = true;
        isLoading.value = false;
        toast.error(err.response.data.message || err.response.data.Message);
      });
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-8bcaccc4>`);
      _push(ssrRenderComponent(unref(TransitionRoot), {
        as: "template",
        show: __props.isOpen
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Dialog), {
              as: "div",
              class: "relative z-[999]",
              onClose: ($event) => handleclose("close")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="fixed z-10 inset-0 overflow-y-auto" data-v-8bcaccc4${_scopeId2}><div class="flex items-center sm:items-center justify-center min-h-full p-4 text-center sm:p-0" data-v-8bcaccc4${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                    "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                    "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="relative bg-white rounded-lg text-left p-6 lg:p-10 overflow-hidden shadow-xl transform transition-all sm:w-[400px]" data-v-8bcaccc4${_scopeId3}><span class="cursor-pointer" data-v-8bcaccc4${_scopeId3}><i class="uil uil-times cursor-pointer text-lg absolute top-4 right-4" data-v-8bcaccc4${_scopeId3}></i></span><div class="w-full h-full grid items-center" data-v-8bcaccc4${_scopeId3}><div data-v-8bcaccc4${_scopeId3}><form data-v-8bcaccc4${_scopeId3}><div class="mb-6" data-v-8bcaccc4${_scopeId3}><label class="mb-2 font-normal text-xs block" data-v-8bcaccc4${_scopeId3}>E-mail</label><input${ssrRenderAttr("value", unref(v$).email.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).email.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="E-mail" autocomplete="off" autofocus="on" data-v-8bcaccc4${_scopeId3}><!--[-->`);
                        ssrRenderList(unref(v$).email.$errors, (error) => {
                          _push4(`<div class="text-red-500 mt-1" data-v-8bcaccc4${_scopeId3}><div class="error-msg text-error text-xs font-semibold" data-v-8bcaccc4${_scopeId3}>${ssrInterpolate(error.$message)}</div></div>`);
                        });
                        _push4(`<!--]--></div><div class="mb-6" data-v-8bcaccc4${_scopeId3}><label class="mb-2 font-normal text-xs block text-matta-black" data-v-8bcaccc4${_scopeId3}>Password</label><div class="relative flex items-center" data-v-8bcaccc4${_scopeId3}><input${ssrRenderDynamicModel(!isShowingPasword.value ? "password" : "text", unref(v$).password.$model, null)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).password.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Password" autocomplete="off"${ssrRenderAttr("type", !isShowingPasword.value ? "password" : "text")} data-v-8bcaccc4${_scopeId3}>`);
                        if (!isShowingPasword.value) {
                          _push4(ssrRenderComponent(unref(EyeIcon), {
                            onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                            class: "w-4 h-4 absolute cursor-pointer right-6"
                          }, null, _parent4, _scopeId3));
                        } else {
                          _push4(ssrRenderComponent(unref(EyeSlashIcon), {
                            onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                            class: "w-4 h-4 absolute cursor-pointer right-6"
                          }, null, _parent4, _scopeId3));
                        }
                        _push4(`</div><!--[-->`);
                        ssrRenderList(unref(v$).password.$errors, (error) => {
                          _push4(`<div class="text-red-500 mt-1" data-v-8bcaccc4${_scopeId3}><div class="error-msg text-error text-xs font-semibold" data-v-8bcaccc4${_scopeId3}>${ssrInterpolate(error.$message)}</div></div>`);
                        });
                        _push4(`<!--]--></div><div class="mb-6 flex items-center justify-between" data-v-8bcaccc4${_scopeId3}><label class="flex text-xs items-center text-matta-black" data-v-8bcaccc4${_scopeId3}><input type="checkbox" class="mr-1 accent-matta-black" data-v-8bcaccc4${_scopeId3}> Keep me logged in </label>`);
                        _push4(ssrRenderComponent(_component_router_link, {
                          to: "/forgot-password",
                          class: "text-xs hover:underline"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`Forgot password? `);
                            } else {
                              return [
                                createTextVNode("Forgot password? ")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(`</div><div class="mb-4" data-v-8bcaccc4${_scopeId3}><button type="submit"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} class="border text-[13px] mb-4 border-primary-500 uppercase text-white lg:min-w-[120px] w-full bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11" data-v-8bcaccc4${_scopeId3}><span data-v-8bcaccc4${_scopeId3}>`);
                        if (isLoading.value) {
                          _push4(`<span class="flex gap-x-4 justify-center items-center" data-v-8bcaccc4${_scopeId3}><span data-v-8bcaccc4${_scopeId3}> Signing in...</span>`);
                          if (isLoading.value) {
                            _push4(`<i class="fa fa-spinner fa-spin text-white" aria-hidden="true" data-v-8bcaccc4${_scopeId3}></i>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          _push4(`</span>`);
                        } else {
                          _push4(`<span data-v-8bcaccc4${_scopeId3}>Sign in</span>`);
                        }
                        _push4(`</span></button></div>`);
                        if (__props.showSignup) {
                          _push4(`<div data-v-8bcaccc4${_scopeId3}> Don&#39;t have an account? <span class="text-primary cursor-pointer" data-v-8bcaccc4${_scopeId3}>Sign up</span></div>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(`</form></div></div></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "relative bg-white rounded-lg text-left p-6 lg:p-10 overflow-hidden shadow-xl transform transition-all sm:w-[400px]" }, [
                            createVNode("span", {
                              onClick: ($event) => handleclose("close"),
                              class: "cursor-pointer"
                            }, [
                              createVNode("i", { class: "uil uil-times cursor-pointer text-lg absolute top-4 right-4" })
                            ], 8, ["onClick"]),
                            createVNode("div", { class: "w-full h-full grid items-center" }, [
                              createVNode("div", null, [
                                createVNode("form", {
                                  onSubmit: withModifiers(handleSubmit, ["prevent"])
                                }, [
                                  createVNode("div", { class: "mb-6" }, [
                                    createVNode("label", { class: "mb-2 font-normal text-xs block" }, "E-mail"),
                                    withDirectives(createVNode("input", {
                                      "onUpdate:modelValue": ($event) => unref(v$).email.$model = $event,
                                      class: [{ "border-red-500": unref(v$).email.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                                      placeholder: "E-mail",
                                      autocomplete: "off",
                                      autofocus: "on"
                                    }, null, 10, ["onUpdate:modelValue"]), [
                                      [vModelText, unref(v$).email.$model]
                                    ]),
                                    (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).email.$errors, (error) => {
                                      return openBlock(), createBlock("div", {
                                        class: "text-red-500 mt-1",
                                        key: error.$uid
                                      }, [
                                        createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                                      ]);
                                    }), 128))
                                  ]),
                                  createVNode("div", { class: "mb-6" }, [
                                    createVNode("label", { class: "mb-2 font-normal text-xs block text-matta-black" }, "Password"),
                                    createVNode("div", { class: "relative flex items-center" }, [
                                      withDirectives(createVNode("input", {
                                        "onUpdate:modelValue": ($event) => unref(v$).password.$model = $event,
                                        class: [{ "border-red-500 ": unref(v$).password.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                                        placeholder: "Password",
                                        autocomplete: "off",
                                        type: !isShowingPasword.value ? "password" : "text"
                                      }, null, 10, ["onUpdate:modelValue", "type"]), [
                                        [vModelDynamic, unref(v$).password.$model]
                                      ]),
                                      !isShowingPasword.value ? (openBlock(), createBlock(unref(EyeIcon), {
                                        key: 0,
                                        onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                        class: "w-4 h-4 absolute cursor-pointer right-6"
                                      }, null, 8, ["onClick"])) : (openBlock(), createBlock(unref(EyeSlashIcon), {
                                        key: 1,
                                        onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                        class: "w-4 h-4 absolute cursor-pointer right-6"
                                      }, null, 8, ["onClick"]))
                                    ]),
                                    (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).password.$errors, (error) => {
                                      return openBlock(), createBlock("div", {
                                        class: "text-red-500 mt-1",
                                        key: error.$uid
                                      }, [
                                        createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                                      ]);
                                    }), 128))
                                  ]),
                                  createVNode("div", { class: "mb-6 flex items-center justify-between" }, [
                                    createVNode("label", { class: "flex text-xs items-center text-matta-black" }, [
                                      createVNode("input", {
                                        type: "checkbox",
                                        class: "mr-1 accent-matta-black"
                                      }),
                                      createTextVNode(" Keep me logged in ")
                                    ]),
                                    createVNode(_component_router_link, {
                                      to: "/forgot-password",
                                      class: "text-xs hover:underline"
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Forgot password? ")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  createVNode("div", { class: "mb-4" }, [
                                    createVNode("button", {
                                      type: "submit",
                                      disabled: isLoading.value,
                                      class: "border text-[13px] mb-4 border-primary-500 uppercase text-white lg:min-w-[120px] w-full bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11"
                                    }, [
                                      createVNode("span", null, [
                                        isLoading.value ? (openBlock(), createBlock("span", {
                                          key: 0,
                                          class: "flex gap-x-4 justify-center items-center"
                                        }, [
                                          createVNode("span", null, " Signing in..."),
                                          isLoading.value ? (openBlock(), createBlock("i", {
                                            key: 0,
                                            class: "fa fa-spinner fa-spin text-white",
                                            "aria-hidden": "true"
                                          })) : createCommentVNode("", true)
                                        ])) : (openBlock(), createBlock("span", { key: 1 }, "Sign in"))
                                      ])
                                    ], 8, ["disabled"])
                                  ]),
                                  __props.showSignup ? (openBlock(), createBlock("div", { key: 0 }, [
                                    createTextVNode(" Don't have an account? "),
                                    createVNode("span", {
                                      class: "text-primary cursor-pointer",
                                      onClick: ($event) => unref(toggleModal)("signup")
                                    }, "Sign up", 8, ["onClick"])
                                  ])) : createCommentVNode("", true)
                                ], 32)
                              ])
                            ])
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode(unref(TransitionChild), {
                      as: "template",
                      enter: "ease-out duration-300",
                      "enter-from": "opacity-0",
                      "enter-to": "opacity-100",
                      leave: "ease-in duration-200",
                      "leave-from": "opacity-100",
                      "leave-to": "opacity-0"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" })
                      ]),
                      _: 1
                    }),
                    createVNode("div", { class: "fixed z-10 inset-0 overflow-y-auto" }, [
                      createVNode("div", { class: "flex items-center sm:items-center justify-center min-h-full p-4 text-center sm:p-0" }, [
                        createVNode(unref(TransitionChild), {
                          as: "template",
                          enter: "ease-out duration-300",
                          "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                          "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                          leave: "ease-in duration-200",
                          "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                          "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                        }, {
                          default: withCtx(() => [
                            createVNode("div", { class: "relative bg-white rounded-lg text-left p-6 lg:p-10 overflow-hidden shadow-xl transform transition-all sm:w-[400px]" }, [
                              createVNode("span", {
                                onClick: ($event) => handleclose("close"),
                                class: "cursor-pointer"
                              }, [
                                createVNode("i", { class: "uil uil-times cursor-pointer text-lg absolute top-4 right-4" })
                              ], 8, ["onClick"]),
                              createVNode("div", { class: "w-full h-full grid items-center" }, [
                                createVNode("div", null, [
                                  createVNode("form", {
                                    onSubmit: withModifiers(handleSubmit, ["prevent"])
                                  }, [
                                    createVNode("div", { class: "mb-6" }, [
                                      createVNode("label", { class: "mb-2 font-normal text-xs block" }, "E-mail"),
                                      withDirectives(createVNode("input", {
                                        "onUpdate:modelValue": ($event) => unref(v$).email.$model = $event,
                                        class: [{ "border-red-500": unref(v$).email.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                                        placeholder: "E-mail",
                                        autocomplete: "off",
                                        autofocus: "on"
                                      }, null, 10, ["onUpdate:modelValue"]), [
                                        [vModelText, unref(v$).email.$model]
                                      ]),
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).email.$errors, (error) => {
                                        return openBlock(), createBlock("div", {
                                          class: "text-red-500 mt-1",
                                          key: error.$uid
                                        }, [
                                          createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                                        ]);
                                      }), 128))
                                    ]),
                                    createVNode("div", { class: "mb-6" }, [
                                      createVNode("label", { class: "mb-2 font-normal text-xs block text-matta-black" }, "Password"),
                                      createVNode("div", { class: "relative flex items-center" }, [
                                        withDirectives(createVNode("input", {
                                          "onUpdate:modelValue": ($event) => unref(v$).password.$model = $event,
                                          class: [{ "border-red-500 ": unref(v$).password.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                                          placeholder: "Password",
                                          autocomplete: "off",
                                          type: !isShowingPasword.value ? "password" : "text"
                                        }, null, 10, ["onUpdate:modelValue", "type"]), [
                                          [vModelDynamic, unref(v$).password.$model]
                                        ]),
                                        !isShowingPasword.value ? (openBlock(), createBlock(unref(EyeIcon), {
                                          key: 0,
                                          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                          class: "w-4 h-4 absolute cursor-pointer right-6"
                                        }, null, 8, ["onClick"])) : (openBlock(), createBlock(unref(EyeSlashIcon), {
                                          key: 1,
                                          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                          class: "w-4 h-4 absolute cursor-pointer right-6"
                                        }, null, 8, ["onClick"]))
                                      ]),
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).password.$errors, (error) => {
                                        return openBlock(), createBlock("div", {
                                          class: "text-red-500 mt-1",
                                          key: error.$uid
                                        }, [
                                          createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                                        ]);
                                      }), 128))
                                    ]),
                                    createVNode("div", { class: "mb-6 flex items-center justify-between" }, [
                                      createVNode("label", { class: "flex text-xs items-center text-matta-black" }, [
                                        createVNode("input", {
                                          type: "checkbox",
                                          class: "mr-1 accent-matta-black"
                                        }),
                                        createTextVNode(" Keep me logged in ")
                                      ]),
                                      createVNode(_component_router_link, {
                                        to: "/forgot-password",
                                        class: "text-xs hover:underline"
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode("Forgot password? ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    createVNode("div", { class: "mb-4" }, [
                                      createVNode("button", {
                                        type: "submit",
                                        disabled: isLoading.value,
                                        class: "border text-[13px] mb-4 border-primary-500 uppercase text-white lg:min-w-[120px] w-full bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11"
                                      }, [
                                        createVNode("span", null, [
                                          isLoading.value ? (openBlock(), createBlock("span", {
                                            key: 0,
                                            class: "flex gap-x-4 justify-center items-center"
                                          }, [
                                            createVNode("span", null, " Signing in..."),
                                            isLoading.value ? (openBlock(), createBlock("i", {
                                              key: 0,
                                              class: "fa fa-spinner fa-spin text-white",
                                              "aria-hidden": "true"
                                            })) : createCommentVNode("", true)
                                          ])) : (openBlock(), createBlock("span", { key: 1 }, "Sign in"))
                                        ])
                                      ], 8, ["disabled"])
                                    ]),
                                    __props.showSignup ? (openBlock(), createBlock("div", { key: 0 }, [
                                      createTextVNode(" Don't have an account? "),
                                      createVNode("span", {
                                        class: "text-primary cursor-pointer",
                                        onClick: ($event) => unref(toggleModal)("signup")
                                      }, "Sign up", 8, ["onClick"])
                                    ])) : createCommentVNode("", true)
                                  ], 32)
                                ])
                              ])
                            ])
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Dialog), {
                as: "div",
                class: "relative z-[999]",
                onClose: ($event) => handleclose("close")
              }, {
                default: withCtx(() => [
                  createVNode(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" })
                    ]),
                    _: 1
                  }),
                  createVNode("div", { class: "fixed z-10 inset-0 overflow-y-auto" }, [
                    createVNode("div", { class: "flex items-center sm:items-center justify-center min-h-full p-4 text-center sm:p-0" }, [
                      createVNode(unref(TransitionChild), {
                        as: "template",
                        enter: "ease-out duration-300",
                        "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                        "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                        leave: "ease-in duration-200",
                        "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                        "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                      }, {
                        default: withCtx(() => [
                          createVNode("div", { class: "relative bg-white rounded-lg text-left p-6 lg:p-10 overflow-hidden shadow-xl transform transition-all sm:w-[400px]" }, [
                            createVNode("span", {
                              onClick: ($event) => handleclose("close"),
                              class: "cursor-pointer"
                            }, [
                              createVNode("i", { class: "uil uil-times cursor-pointer text-lg absolute top-4 right-4" })
                            ], 8, ["onClick"]),
                            createVNode("div", { class: "w-full h-full grid items-center" }, [
                              createVNode("div", null, [
                                createVNode("form", {
                                  onSubmit: withModifiers(handleSubmit, ["prevent"])
                                }, [
                                  createVNode("div", { class: "mb-6" }, [
                                    createVNode("label", { class: "mb-2 font-normal text-xs block" }, "E-mail"),
                                    withDirectives(createVNode("input", {
                                      "onUpdate:modelValue": ($event) => unref(v$).email.$model = $event,
                                      class: [{ "border-red-500": unref(v$).email.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                                      placeholder: "E-mail",
                                      autocomplete: "off",
                                      autofocus: "on"
                                    }, null, 10, ["onUpdate:modelValue"]), [
                                      [vModelText, unref(v$).email.$model]
                                    ]),
                                    (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).email.$errors, (error) => {
                                      return openBlock(), createBlock("div", {
                                        class: "text-red-500 mt-1",
                                        key: error.$uid
                                      }, [
                                        createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                                      ]);
                                    }), 128))
                                  ]),
                                  createVNode("div", { class: "mb-6" }, [
                                    createVNode("label", { class: "mb-2 font-normal text-xs block text-matta-black" }, "Password"),
                                    createVNode("div", { class: "relative flex items-center" }, [
                                      withDirectives(createVNode("input", {
                                        "onUpdate:modelValue": ($event) => unref(v$).password.$model = $event,
                                        class: [{ "border-red-500 ": unref(v$).password.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                                        placeholder: "Password",
                                        autocomplete: "off",
                                        type: !isShowingPasword.value ? "password" : "text"
                                      }, null, 10, ["onUpdate:modelValue", "type"]), [
                                        [vModelDynamic, unref(v$).password.$model]
                                      ]),
                                      !isShowingPasword.value ? (openBlock(), createBlock(unref(EyeIcon), {
                                        key: 0,
                                        onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                        class: "w-4 h-4 absolute cursor-pointer right-6"
                                      }, null, 8, ["onClick"])) : (openBlock(), createBlock(unref(EyeSlashIcon), {
                                        key: 1,
                                        onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                        class: "w-4 h-4 absolute cursor-pointer right-6"
                                      }, null, 8, ["onClick"]))
                                    ]),
                                    (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).password.$errors, (error) => {
                                      return openBlock(), createBlock("div", {
                                        class: "text-red-500 mt-1",
                                        key: error.$uid
                                      }, [
                                        createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                                      ]);
                                    }), 128))
                                  ]),
                                  createVNode("div", { class: "mb-6 flex items-center justify-between" }, [
                                    createVNode("label", { class: "flex text-xs items-center text-matta-black" }, [
                                      createVNode("input", {
                                        type: "checkbox",
                                        class: "mr-1 accent-matta-black"
                                      }),
                                      createTextVNode(" Keep me logged in ")
                                    ]),
                                    createVNode(_component_router_link, {
                                      to: "/forgot-password",
                                      class: "text-xs hover:underline"
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode("Forgot password? ")
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  createVNode("div", { class: "mb-4" }, [
                                    createVNode("button", {
                                      type: "submit",
                                      disabled: isLoading.value,
                                      class: "border text-[13px] mb-4 border-primary-500 uppercase text-white lg:min-w-[120px] w-full bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11"
                                    }, [
                                      createVNode("span", null, [
                                        isLoading.value ? (openBlock(), createBlock("span", {
                                          key: 0,
                                          class: "flex gap-x-4 justify-center items-center"
                                        }, [
                                          createVNode("span", null, " Signing in..."),
                                          isLoading.value ? (openBlock(), createBlock("i", {
                                            key: 0,
                                            class: "fa fa-spinner fa-spin text-white",
                                            "aria-hidden": "true"
                                          })) : createCommentVNode("", true)
                                        ])) : (openBlock(), createBlock("span", { key: 1 }, "Sign in"))
                                      ])
                                    ], 8, ["disabled"])
                                  ]),
                                  __props.showSignup ? (openBlock(), createBlock("div", { key: 0 }, [
                                    createTextVNode(" Don't have an account? "),
                                    createVNode("span", {
                                      class: "text-primary cursor-pointer",
                                      onClick: ($event) => unref(toggleModal)("signup")
                                    }, "Sign up", 8, ["onClick"])
                                  ])) : createCommentVNode("", true)
                                ], 32)
                              ])
                            ])
                          ])
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              }, 8, ["onClose"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$e = _sfc_main$e.setup;
_sfc_main$e.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/LoginModal.vue");
  return _sfc_setup$e ? _sfc_setup$e(props, ctx) : void 0;
};
const __nuxt_component_9 = /* @__PURE__ */ _export_sfc(_sfc_main$e, [["__scopeId", "data-v-8bcaccc4"]]);
const _sfc_main$d = {
  __name: "IndexSample",
  __ssrInlineRender: true,
  emits: ["togglePopup"],
  setup(__props, { emit: __emit }) {
    var _a, _b, _c, _d, _e, _f, _g;
    const supplierStore = useSupplierStore();
    const authStore = useAuthStore();
    inject("togglePopup");
    const product = inject("product");
    const sampleForm = reactive({
      sellerId: (_a = product.value) == null ? void 0 : _a.supplierId,
      seller: (_b = supplierStore.supplierData) == null ? void 0 : _b.companyName,
      productId: (_c = product.value) == null ? void 0 : _c.id,
      productImg: (_d = product.value) == null ? void 0 : _d.gallery[0],
      productName: (_e = product.value) == null ? void 0 : _e.name,
      producerId: (_f = product.value) == null ? void 0 : _f.producer.id,
      producer: (_g = product.value) == null ? void 0 : _g.producer.title,
      numberofSamples: 1,
      expectedAnualUsage: 1,
      description: "None",
      email: "",
      phone: "",
      shippingAddressId: null,
      addressDescription: ""
    });
    useStore();
    const showAuth = ref(false);
    const isOpen = ref(false);
    const active = ref(1);
    const isLoading = ref(false);
    const authType = ref("login");
    const myrules1 = {
      numberofSamples: { required },
      expectedAnualUsage: { required },
      description: {}
    };
    const myrules2 = {
      email: { required, email },
      phone: { required, numeric },
      shippingAddressId: { required },
      addressDescription: { required }
    };
    const request1$ = useVuelidate(myrules1, sampleForm);
    const request2$ = useVuelidate(myrules2, sampleForm);
    async function handleSubmit() {
      const validity1 = await request1$.value.$validate();
      const validity2 = await request2$.value.$validate();
      if (!validity1 || !validity2)
        return;
      isLoading.value = true;
      addrequest(sampleForm).then((res) => {
        if (res.status === 200) {
          active.value = 3;
        }
      }).catch((err) => {
        isLoading.value = false;
        toast.error(err.response.data.message || err.response.data.Message);
      });
    }
    function toggleAuth() {
      isOpen.value = true;
    }
    function toggleModal(val) {
      authType.value = val;
    }
    computed(() => {
      return authStore.isLoggedIn;
    });
    function handleclose() {
      isOpen.value = false;
      if (active.value == 2) {
        handleSubmit();
      } else {
        showAuth.value = false;
      }
    }
    provide("handleSubmit", handleSubmit);
    provide("toggleModal", toggleModal);
    provide("toggleAuth", toggleAuth);
    provide("request1$", request1$);
    provide("request2$", request2$);
    provide("sampleForm", sampleForm);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_InformationSampleUsageDetails = __nuxt_component_0$3;
      const _component_InformationSampleShippingAddress = __nuxt_component_1$2;
      const _component_InformationSampleRequestComplete = __nuxt_component_2$3;
      const _component_InformationSampleRegisterComponent = __nuxt_component_3$1;
      const _component_router_link = resolveComponent("router-link");
      const _component_LoginModal = __nuxt_component_9;
      _push(`<!--[--><form class="flex flex-col h-full overflow-y-auto"><div class="flex-1"><div class="flex justify-between items-center mb-6"><h4 class="text-lg sm:text-2xl font-medium">Request a Sample</h4></div><div class="flex justify-between items-center mb-2 text-[13px] uppercase"><h4 class="text-[13px] uppercase">${ssrInterpolate(unref(product).name)}</h4><span>Step ${ssrInterpolate(unref(active))}/3</span></div><div class="grid grid-cols-3 border-b border-[#E7EBEE]"><!--[-->`);
      ssrRenderList(3, (n) => {
        _push(`<span class="${ssrRenderClass(`rounded-full pt-1 ${unref(active) >= n ? "bg-primary" : "bg-white"}`)}"></span>`);
      });
      _push(`<!--]--></div><div>`);
      if (unref(active) === 1) {
        _push(ssrRenderComponent(_component_InformationSampleUsageDetails, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(active) === 2 && !unref(showAuth)) {
        _push(`<div>`);
        _push(ssrRenderComponent(_component_InformationSampleShippingAddress, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(active) === 3) {
        _push(ssrRenderComponent(_component_InformationSampleRequestComplete, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(active) === 2 && unref(showAuth)) {
        _push(ssrRenderComponent(_component_InformationSampleRegisterComponent, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      if (unref(active) !== 3) {
        _push(`<div>`);
        if (!unref(authStore).isLoggedIn) {
          _push(`<span class="mb-2 text-primary text-xs">Log In to speed up your request <i class="uil uil-arrow-up-right text-x"></i></span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="flex justify-between gap-x-2 items-center mt-8"><button type="button" class="appearance-none border w-1/2 leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"> Cancel </button>`);
        if (unref(active) > 1) {
          _push(`<button type="button" class="appearance-none border w-1/2 leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"> Back </button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<button type="button" class="appearance-none border w-1/2 border-primary- leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase"> Next </button></div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(active) === 3) {
        _push(`<div><div class="flex justify-between gap-x-2 items-center mt-8">`);
        _push(ssrRenderComponent(_component_router_link, { to: "/procurement/my-requests" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<button type="button" class="appearance-none border w-full leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"${_scopeId}> My Requests </button>`);
            } else {
              return [
                createVNode("button", {
                  type: "button",
                  class: "appearance-none border w-full leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"
                }, " My Requests ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<button type="button" class="appearance-none border w-full border-primary- leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase"> product page </button></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</form>`);
      if (unref(isOpen)) {
        _push(ssrRenderComponent(_component_LoginModal, {
          showSignup: false,
          isOpen: unref(isOpen),
          onClose: handleclose
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$d = _sfc_main$d.setup;
_sfc_main$d.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Information/sample/IndexSample.vue");
  return _sfc_setup$d ? _sfc_setup$d(props, ctx) : void 0;
};
const __nuxt_component_7 = _sfc_main$d;
const _sfc_main$c = {
  __name: "UsageDetails",
  __ssrInlineRender: true,
  setup(__props) {
    const request1$ = inject("request1$");
    const quoteForm = inject("quoteForm");
    const product = inject("product");
    const applications = ref([]);
    const marketStore = useMarketStore();
    const appStore = useApplicationStore();
    function onGetMarket(data) {
      applications.value = data.categorySubMenu;
      quoteForm.market = data.title;
    }
    function onGetApp(data) {
      quoteForm.applications = data.title;
    }
    const marketOptions = computed(() => {
      if (!marketStore.marketsData.length)
        return [];
      return marketStore.marketsData.map((i) => {
        i.name = i.title;
        return i;
      });
    });
    const appOptions = computed(() => {
      if (!appStore.applicationsData.length)
        return [];
      return appStore.applicationsData.map((i) => {
        i.name = i.title;
        return i;
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormsSelectComponent = __nuxt_component_2$6;
      _push(`<form${ssrRenderAttrs(mergeProps({ class: "mt-8" }, _attrs))}><legend class="text-lg font-medium mb-1">Purchase Details</legend><p class="text-xs text-[#ABABAB] mb-5"> This information will help us prepare your quote. </p><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Market</label>`);
      _push(ssrRenderComponent(_component_FormsSelectComponent, {
        onOnGetData: onGetMarket,
        options: marketOptions.value,
        showSearch: true,
        placeholder: "Select market",
        class: { "border-red-500 ": unref(request1$).market.$error },
        classStyles: "appearance-none h-[46px] text-matta-black bg-transparent py-2 px-3 min-w-[150px] cursor-pointer md:py-3 md:px-3 border !rounded-lg border-[#ddd] md:leading-5 text-[10px] !sm:text-[13px] shadow-sm focus:outline-gray-200"
      }, null, _parent));
      _push(`<!--[-->`);
      ssrRenderList(unref(request1$).market.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Application</label>`);
      _push(ssrRenderComponent(_component_FormsSelectComponent, {
        onOnGetData: onGetApp,
        options: appOptions.value,
        showSearch: true,
        placeholder: "Select application",
        class: { "border-red-500 ": unref(request1$).applications.$error },
        classStyles: "appearance-none h-[46px] text-matta-black bg-transparent py-2 px-3 min-w-[150px] cursor-pointer md:py-3 md:px-3 border !rounded-lg border-[#ddd] md:leading-5 text-[10px] !sm:text-[13px] shadow-sm focus:outline-gray-200"
      }, null, _parent));
      _push(`<!--[-->`);
      ssrRenderList(unref(request1$).applications.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Package type</label>`);
      if (unref(product) && unref(product).packagesAvailable) {
        _push(`<select class="${ssrRenderClass([{ "border-red-500 ": unref(request1$).package.$error }, "disabled:opacity-60 h-[46px] placeholder:text-sm w-full text-matta-black bg-transparent py-2 px-3 min-w-[150px] cursor-pointer md:py-3 md:px-3 border !rounded-lg border-[#ddd] md:leading-5 text-[13px] shadow-sm focus:outline-gray-200"])}"><option${ssrRenderAttr("value", null)} disabled${ssrIncludeBooleanAttr(Array.isArray(unref(request1$).package.$model) ? ssrLooseContain(unref(request1$).package.$model, null) : ssrLooseEqual(unref(request1$).package.$model, null)) ? " selected" : ""}>Select a package</option><!--[-->`);
        ssrRenderList(unref(product).packagesAvailable, (n, i) => {
          _push(`<option${ssrRenderAttr("value", n)}>${ssrInterpolate(n.package ? `${n.package.title} ${n.size}  ${n.unit}` : "-")}</option>`);
        });
        _push(`<!--]--></select>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--[-->`);
      ssrRenderList(unref(request1$).package.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-normal text-xs block">How do you intend to use the product?</label><textarea placeholder="Tell us here" class="${ssrRenderClass([{ "border-red-500 ": unref(request1$).productUse.$error }, "h-[46px] placeholder:text-sm w-full text-matta-black bg-transparent py-2 px-3 min-w-[150px] cursor-pointer md:py-3 md:px-3 border !rounded-lg border-[#ddd] md:leading-5 text-[13px] shadow-sm focus:outline-gray-200"])}">${ssrInterpolate(unref(request1$).productUse.$model)}</textarea><!--[-->`);
      ssrRenderList(unref(request1$).productUse.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-normal text-xs block">Expected annual volume</label><div class="flex items-center gap-x-2 h-[46px] placeholder:text-sm w-full text-matta-black bg-transparent px-3 min-w-[150px] cursor-pointer md:px-3 border rounded-lg border-[#ddd] md:leading-5 text-[10px] sm:text-[13px] shadow-sm focus:outline-gray-200">`);
      _push(ssrRenderComponent(unref(CurrencyInput), {
        placeholder: "Tell us here",
        class: [{ "border-red-500 ": unref(request1$).expectedVolume.$error }, "flex-1 py-2 md:py-3 outline-none"],
        modelValue: unref(request1$).expectedVolume.$model,
        "onUpdate:modelValue": ($event) => unref(request1$).expectedVolume.$model = $event,
        options: {
          currency: "ngn",
          currencyDisplay: "hidden"
        }
      }, null, _parent));
      _push(`<select class="h-full outline-none border-l pl-2 py-2 md:py-3"><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(unref(request1$).unit.$model) ? ssrLooseContain(unref(request1$).unit.$model, "") : ssrLooseEqual(unref(request1$).unit.$model, "")) ? " selected" : ""}>Unit</option><!--[-->`);
      ssrRenderList("measurements" in _ctx ? _ctx.measurements : unref(measurements), (unit) => {
        _push(`<option>${ssrInterpolate(unit.value)}</option>`);
      });
      _push(`<!--]--></select></div><!--[-->`);
      ssrRenderList(unref(request1$).expectedVolume.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></form>`);
    };
  }
};
const _sfc_setup$c = _sfc_main$c.setup;
_sfc_main$c.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Information/quote/UsageDetails.vue");
  return _sfc_setup$c ? _sfc_setup$c(props, ctx) : void 0;
};
const __nuxt_component_0$2 = _sfc_main$c;
const _sfc_main$b = {
  __name: "ShippingForm",
  __ssrInlineRender: true,
  setup(__props) {
    inject("togglePopup");
    inject("handleReload");
    const form = reactive({
      firstName: "",
      lastName: "",
      country: "",
      city: "",
      street: "",
      postalCode: "",
      isDefault: false
    });
    const isLoading = ref(false);
    const rules = {
      firstName: {
        required,
        maxLength: maxLength(50)
      },
      postalCode: {},
      lastName: {
        required
      },
      country: {
        required
      },
      street: {
        required
      },
      city: {
        required
      }
    };
    const v$ = useVuelidate(rules, form);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormsCountriesSelect = CountriesSelect;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-6" }, _attrs))}><h3 class="font-medium text-2xl mb-8">Add new shipping address</h3><form><div class="grid grid-cols-2 gap-x-4"><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">First name</label><input${ssrRenderAttr("value", unref(v$).firstName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).firstName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on"><!--[-->`);
      ssrRenderList(unref(v$).firstName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Last name</label><input${ssrRenderAttr("value", unref(v$).lastName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).lastName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on"><!--[-->`);
      ssrRenderList(unref(v$).lastName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="grid grid-cols-2 gap-x-4"><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Country</label><div class="flex relative">`);
      _push(ssrRenderComponent(_component_FormsCountriesSelect, {
        modelValue: unref(v$).country.$model,
        "onUpdate:modelValue": ($event) => unref(v$).country.$model = $event
      }, null, _parent));
      _push(`<!--[-->`);
      ssrRenderList(unref(v$).country.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">City</label><input${ssrRenderAttr("value", unref(v$).city.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).city.$error }, "px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] rounded-lg focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" placeholder="Company city"><!--[-->`);
      ssrRenderList(unref(v$).city.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="grid grid-cols-2 gap-x-4"><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Street</label><input${ssrRenderAttr("value", unref(v$).street.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).street.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on"><!--[-->`);
      ssrRenderList(unref(v$).street.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Postal code</label><input${ssrRenderAttr("value", unref(v$).postalCode.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).postalCode.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on"><!--[-->`);
      ssrRenderList(unref(v$).postalCode.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="mb-6"><label class="text-xs flex gap-x-2 items-center"><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(form).isDefault) ? ssrLooseContain(unref(form).isDefault, null) : unref(form).isDefault) ? " checked" : ""} class="accent-matta-black">Mark as Default shipping address </label></div><div class="flex justify-end gap-x-4 mt-8"><button type="button" class="text-xs upperase hover:bg-gray-50"> Cancel </button><button type="submit"${ssrIncludeBooleanAttr(unref(isLoading)) ? " disabled" : ""} class="text-xs uppercase bg-primary-500 text-white px-5 py-4 rounded-lg hover:bg-primary/70 disabled:opacity-60"> Submit </button></div></form></div>`);
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Information/quote/ShippingForm.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const __nuxt_component_2$2 = _sfc_main$b;
const _sfc_main$a = {
  __name: "ShippingAddress",
  __ssrInlineRender: true,
  setup(__props) {
    const authStore = useAuthStore();
    useStore();
    const request2$ = inject("request2$");
    const quoteForm = inject("quoteForm");
    const isOpen = ref(false);
    const selectedoption = ref();
    const addresses = ref([]);
    watch(selectedoption, () => {
      quoteForm.deliverAddress = `${selectedoption.value.street}, ${selectedoption.value.city}, ${selectedoption.value.country}. ${selectedoption.value.postalCode}`;
    });
    function togglePopup() {
      isOpen.value = false;
    }
    function handleReload() {
      getalladdress().then((res) => {
        addresses.value = res.data.data;
      });
      togglePopup();
    }
    provide("handleReload", handleReload);
    provide("togglePopup", togglePopup);
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_FormsPhoneCodes = PhoneCodes;
      const _component_IndexModal = __nuxt_component_0$5;
      const _component_InformationQuoteShippingForm = __nuxt_component_2$2;
      _push(`<!--[--><form class="mt-8"><legend class="text-lg font-medium mb-1">Shipping Address</legend><p class="text-sm text-[#ABABAB] mb-8"> Choose your shipping options for samples requested. </p><div class="mb-6 grid gap-y-3 border-gray-200 rounded-lg text-sm"><p><span class="text-gray-500">Name:</span> ${ssrInterpolate((_a = unref(authStore).userInfo) == null ? void 0 : _a.fullName)}</p><p><span class="text-gray-500">Email:</span> ${ssrInterpolate((_b = unref(authStore).userInfo) == null ? void 0 : _b.email)}</p></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Phone number</label><div class="flex relative rounded-lg h-11">`);
      _push(ssrRenderComponent(_component_FormsPhoneCodes, {
        modelValue: unref(quoteForm).phoneCode,
        "onUpdate:modelValue": ($event) => unref(quoteForm).phoneCode = $event
      }, null, _parent));
      _push(`<input${ssrRenderAttr("value", unref(request2$).phone.$model)} class="flex-1 rounded-r-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20 placeholder:text-sm" autocomplete="off" autofocus="on" placeholder="08160723884" type="tel"></div><!--[-->`);
      ssrRenderList(unref(request2$).phone.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Address</label>`);
      _push(ssrRenderComponent(unref(Listbox), {
        modelValue: selectedoption.value,
        "onUpdate:modelValue": ($event) => selectedoption.value = $event
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="relative w-full"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ListboxButton), { class: "relative w-full cursor-default rounded-lg min-h-[40px] border-[#D0D5DD] bg-[#F1F3F5] py-2 px-[15px] text-left shadow-[0px_1px_2px_rgba(16,24,40,0.05)] sm:text-[13px] flex items-center" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  if (selectedoption.value) {
                    _push3(`<span class="flex gap-x-1 text-[#101828] text-[13px] whitespace-nowrap"${_scopeId2}><span class="font-medium"${_scopeId2}>${ssrInterpolate(`${selectedoption.value.firstName} ${selectedoption.value.lastName}`)}</span>, <span class="truncate ... max-w-[170px]"${_scopeId2}>${ssrInterpolate(selectedoption.value.street)}</span></span>`);
                  } else {
                    _push3(`<span class="block text-[#8F8C9A] text-[13px] whitespace-nowrap"${_scopeId2}>Choose your shipping adress...</span>`);
                  }
                  _push3(`<span class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2"${_scopeId2}><i class="uil uil-angle-down absolute right-2 appearance-none"${_scopeId2}></i></span>`);
                } else {
                  return [
                    selectedoption.value ? (openBlock(), createBlock("span", {
                      key: 0,
                      class: "flex gap-x-1 text-[#101828] text-[13px] whitespace-nowrap"
                    }, [
                      createVNode("span", { class: "font-medium" }, toDisplayString(`${selectedoption.value.firstName} ${selectedoption.value.lastName}`), 1),
                      createTextVNode(", "),
                      createVNode("span", { class: "truncate ... max-w-[170px]" }, toDisplayString(selectedoption.value.street), 1)
                    ])) : (openBlock(), createBlock("span", {
                      key: 1,
                      class: "block text-[#8F8C9A] text-[13px] whitespace-nowrap"
                    }, "Choose your shipping adress...")),
                    createVNode("span", { class: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" }, [
                      createVNode("i", { class: "uil uil-angle-down absolute right-2 appearance-none" })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ListboxOptions), { class: "absolute mt-1 w-full z-40 rounded-lg border border-gray-200 bg-white px-6 pb-6 text-xs shadow-lg ring-1 ring-black ring-opacity-5 outline-0 sm:text-[13px]" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="max-h-60 overflow-y-auto mb-3"${_scopeId2}><!--[-->`);
                  ssrRenderList(addresses.value, (option) => {
                    _push3(ssrRenderComponent(unref(ListboxOption), {
                      key: option.name,
                      value: option,
                      as: "template"
                    }, {
                      default: withCtx(({ active }, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<li class="${ssrRenderClass([
                            active ? "bg-gray-100" : "",
                            "relative cursor-default select-none pt-6 pb-6 text-loft-black border-b hover:bg-gray-50"
                          ])}"${_scopeId3}><p class="text-sm font-medium mb-1"${_scopeId3}>${ssrInterpolate(`${option.firstName} ${option.lastName}`)}</p><p class="flex items-center justify-start gap-x-2 text-xs"${_scopeId3}><span${_scopeId3}>${ssrInterpolate(option.country)}</span><span class="p-[.15rem] rounded-full bg-[#DDDDDD]"${_scopeId3}></span><span class="line-clamp-1"${_scopeId3}>${ssrInterpolate(option.street)}</span></p></li>`);
                        } else {
                          return [
                            createVNode("li", {
                              class: [
                                active ? "bg-gray-100" : "",
                                "relative cursor-default select-none pt-6 pb-6 text-loft-black border-b hover:bg-gray-50"
                              ]
                            }, [
                              createVNode("p", { class: "text-sm font-medium mb-1" }, toDisplayString(`${option.firstName} ${option.lastName}`), 1),
                              createVNode("p", { class: "flex items-center justify-start gap-x-2 text-xs" }, [
                                createVNode("span", null, toDisplayString(option.country), 1),
                                createVNode("span", { class: "p-[.15rem] rounded-full bg-[#DDDDDD]" }),
                                createVNode("span", { class: "line-clamp-1" }, toDisplayString(option.street), 1)
                              ])
                            ], 2)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]--></div><button type="button" class="text-xs text-primary mt-2"${_scopeId2}><i class="uil uil-plus"${_scopeId2}></i><span${_scopeId2}>Add new shipping address</span></button>`);
                } else {
                  return [
                    createVNode("div", { class: "max-h-60 overflow-y-auto mb-3" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(addresses.value, (option) => {
                        return openBlock(), createBlock(unref(ListboxOption), {
                          key: option.name,
                          value: option,
                          as: "template"
                        }, {
                          default: withCtx(({ active }) => [
                            createVNode("li", {
                              class: [
                                active ? "bg-gray-100" : "",
                                "relative cursor-default select-none pt-6 pb-6 text-loft-black border-b hover:bg-gray-50"
                              ]
                            }, [
                              createVNode("p", { class: "text-sm font-medium mb-1" }, toDisplayString(`${option.firstName} ${option.lastName}`), 1),
                              createVNode("p", { class: "flex items-center justify-start gap-x-2 text-xs" }, [
                                createVNode("span", null, toDisplayString(option.country), 1),
                                createVNode("span", { class: "p-[.15rem] rounded-full bg-[#DDDDDD]" }),
                                createVNode("span", { class: "line-clamp-1" }, toDisplayString(option.street), 1)
                              ])
                            ], 2)
                          ]),
                          _: 2
                        }, 1032, ["value"]);
                      }), 128))
                    ]),
                    createVNode("button", {
                      type: "button",
                      class: "text-xs text-primary mt-2",
                      onClick: ($event) => isOpen.value = true
                    }, [
                      createVNode("i", { class: "uil uil-plus" }),
                      createVNode("span", null, "Add new shipping address")
                    ], 8, ["onClick"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "relative w-full" }, [
                createVNode(unref(ListboxButton), { class: "relative w-full cursor-default rounded-lg min-h-[40px] border-[#D0D5DD] bg-[#F1F3F5] py-2 px-[15px] text-left shadow-[0px_1px_2px_rgba(16,24,40,0.05)] sm:text-[13px] flex items-center" }, {
                  default: withCtx(() => [
                    selectedoption.value ? (openBlock(), createBlock("span", {
                      key: 0,
                      class: "flex gap-x-1 text-[#101828] text-[13px] whitespace-nowrap"
                    }, [
                      createVNode("span", { class: "font-medium" }, toDisplayString(`${selectedoption.value.firstName} ${selectedoption.value.lastName}`), 1),
                      createTextVNode(", "),
                      createVNode("span", { class: "truncate ... max-w-[170px]" }, toDisplayString(selectedoption.value.street), 1)
                    ])) : (openBlock(), createBlock("span", {
                      key: 1,
                      class: "block text-[#8F8C9A] text-[13px] whitespace-nowrap"
                    }, "Choose your shipping adress...")),
                    createVNode("span", { class: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" }, [
                      createVNode("i", { class: "uil uil-angle-down absolute right-2 appearance-none" })
                    ])
                  ]),
                  _: 1
                }),
                createVNode(Transition, {
                  "leave-active-class": "transition duration-100 ease-in",
                  "leave-from-class": "opacity-100",
                  "leave-to-class": "opacity-0"
                }, {
                  default: withCtx(() => [
                    createVNode("div", null, [
                      createVNode(unref(ListboxOptions), { class: "absolute mt-1 w-full z-40 rounded-lg border border-gray-200 bg-white px-6 pb-6 text-xs shadow-lg ring-1 ring-black ring-opacity-5 outline-0 sm:text-[13px]" }, {
                        default: withCtx(() => [
                          createVNode("div", { class: "max-h-60 overflow-y-auto mb-3" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(addresses.value, (option) => {
                              return openBlock(), createBlock(unref(ListboxOption), {
                                key: option.name,
                                value: option,
                                as: "template"
                              }, {
                                default: withCtx(({ active }) => [
                                  createVNode("li", {
                                    class: [
                                      active ? "bg-gray-100" : "",
                                      "relative cursor-default select-none pt-6 pb-6 text-loft-black border-b hover:bg-gray-50"
                                    ]
                                  }, [
                                    createVNode("p", { class: "text-sm font-medium mb-1" }, toDisplayString(`${option.firstName} ${option.lastName}`), 1),
                                    createVNode("p", { class: "flex items-center justify-start gap-x-2 text-xs" }, [
                                      createVNode("span", null, toDisplayString(option.country), 1),
                                      createVNode("span", { class: "p-[.15rem] rounded-full bg-[#DDDDDD]" }),
                                      createVNode("span", { class: "line-clamp-1" }, toDisplayString(option.street), 1)
                                    ])
                                  ], 2)
                                ]),
                                _: 2
                              }, 1032, ["value"]);
                            }), 128))
                          ]),
                          createVNode("button", {
                            type: "button",
                            class: "text-xs text-primary mt-2",
                            onClick: ($event) => isOpen.value = true
                          }, [
                            createVNode("i", { class: "uil uil-plus" }),
                            createVNode("span", null, "Add new shipping address")
                          ], 8, ["onClick"])
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--[-->`);
      ssrRenderList(unref(request2$).deliverAddress.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-normal text-xs block">Additional information</label><textarea placeholder="" row="4" class="placeholder:text-xs rounded-lg px-[14px] py-[10px] w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20">${ssrInterpolate(unref(request2$).additionalInformation.$model)}</textarea><!--[-->`);
      ssrRenderList(unref(request2$).additionalInformation.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></form>`);
      _push(ssrRenderComponent(_component_IndexModal, {
        isOpen: isOpen.value,
        onTogglePopup: ($event) => isOpen.value = false
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_InformationQuoteShippingForm, null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_InformationQuoteShippingForm)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Information/quote/ShippingAddress.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const __nuxt_component_1$1 = _sfc_main$a;
const _sfc_main$9 = {
  __name: "RequestComplete",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-8 text-center mt-24" }, _attrs))}>`);
      _push(ssrRenderComponent(unref(CheckCircleIcon), { class: "h-20 w-20 text-green-400 mb-8 mx-auto" }, null, _parent));
      _push(`<p class="text-xl mb-3 font-medium">Quote has been sent</p><p class="text-xs"> We will notify you as soon as we receive the requested quote. </p></div>`);
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Information/quote/RequestComplete.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const __nuxt_component_2$1 = _sfc_main$9;
const _sfc_main$8 = {
  __name: "RegisterComponent",
  __ssrInlineRender: true,
  setup(__props) {
    inject("toggleAuth");
    const type = ref("buyer");
    inject("handleSubmit");
    const form = reactive({
      email: "",
      password: "",
      business_UserType: 0,
      confirmPassword: "",
      BusinessName: "BusinessName"
    });
    const isLoading = ref(false);
    const validPassword = (value) => {
      let res = /[a-z]/.test(value) && /[A-Z]/.test(value) && /[0-9]/.test(value);
      return res;
    };
    const specialPassword = (value) => {
      let res = /[@&!%#$%]/.test(value);
      return res;
    };
    const samePassword = (value) => value === form.password;
    const rules = {
      email: {
        required: helpers.withMessage("Email field cannot be empty", required),
        email: helpers.withMessage("Email is invalid", email),
        maxLength: maxLength(50)
      },
      password: {
        required: helpers.withMessage("Password field cannot be empty", required),
        minLength: minLength(8),
        maxLength: maxLength(24),
        validPassword: helpers.withMessage(
          "Password must include UPPER/lowercase characters and number",
          validPassword
        ),
        specialPassword: helpers.withMessage(
          "Password must contain at least 1 of the special  characters @&!-%#$%",
          specialPassword
        )
      },
      confirmPassword: {
        required: helpers.withMessage(
          "Confirm Password field cannot be empty",
          required
        ),
        minLength: minLength(8),
        maxLength: maxLength(24),
        validPassword: helpers.withMessage(
          "Confirm Password is invalid",
          validPassword
        ),
        samePassword: helpers.withMessage("Passwords do not match!", samePassword)
      }
    };
    ref(false);
    const v$ = useVuelidate(rules, form);
    const isShowingPasword = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "mt-12 max-w-[400px]" }, _attrs))}><p class="text-lg font-medium mb-2">Only one step left!</p><p class="text-sm text-[#ABABAB] mb-8"> Sign Up with your work email so Supplier can respond. Already have an account? <span class="text-primary">Log in <i class="uil uil-arrow-up-right text-x"></i></span></p><form><div class="flex gap-x-3 md:gap-x-6 items-center mb-10"><button type="button" class="${ssrRenderClass([
        unref(type) === "buyer" ? "border-matta-black bg-matta-black hover:bg-matta-black/80 text-white" : "border-matta-black bg-white hover:bg-matta-black/10 text-matta-black",
        "border uppercase w-full rounded-lg px-6 py-3 text-sm flex items-center gap-x-2 justify-center"
      ])}"><i class="uil uil-shopping-cart-alt"></i><span class="opacity-50">|</span><span>Buyer</span></button><button type="button" class="${ssrRenderClass([
        unref(type) === "supplier" ? "border-matta-black bg-matta-black hover:bg-matta-black/80 text-white" : "border-matta-black bg-white hover:bg-matta-black/10 text-matta-black",
        "border uppercase w-full rounded-lg px-6 py-3 text-sm flex items-center gap-x-2 justify-center"
      ])}"><i class="uil uil-shop"></i><span class="opacity-50">|</span><span>Supplier</span></button></div><div class="mb-6"><label class="mb-2 font-medium text-sm text-[#344054] block text-left">E-mail</label><input${ssrRenderAttr("value", unref(v$).email.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).email.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="E-mail" autocomplete="off" autofocus="on"><!--[-->`);
      ssrRenderList(unref(v$).email.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6"><label class="mb-2 font-normal text-xs block text-matta-black">Password</label><div class="relative flex items-center"><input${ssrRenderDynamicModel(!unref(isShowingPasword) ? "password" : "text", unref(v$).password.$model, null)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).password.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Password" autocomplete="off"${ssrRenderAttr("type", !unref(isShowingPasword) ? "password" : "text")}>`);
      if (!unref(isShowingPasword)) {
        _push(ssrRenderComponent(unref(EyeIcon), {
          onClick: ($event) => isShowingPasword.value = !unref(isShowingPasword),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      } else {
        _push(ssrRenderComponent(unref(EyeSlashIcon), {
          onClick: ($event) => isShowingPasword.value = !unref(isShowingPasword),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      }
      _push(`</div><!--[-->`);
      ssrRenderList(unref(v$).password.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-12"><label class="mb-2 font-normal text-xs block text-matta-black">Confirm Password</label><div class="relative flex items-center"><input${ssrRenderDynamicModel(!unref(isShowingPasword) ? "password" : "text", unref(v$).confirmPassword.$model, null)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).confirmPassword.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Password" autocomplete="off"${ssrRenderAttr("type", !unref(isShowingPasword) ? "password" : "text")}>`);
      if (!unref(isShowingPasword)) {
        _push(ssrRenderComponent(unref(EyeIcon), {
          onClick: ($event) => isShowingPasword.value = !unref(isShowingPasword),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      } else {
        _push(ssrRenderComponent(unref(EyeSlashIcon), {
          onClick: ($event) => isShowingPasword.value = !unref(isShowingPasword),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      }
      _push(`</div><!--[-->`);
      ssrRenderList(unref(v$).confirmPassword.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class=""><button${ssrIncludeBooleanAttr(unref(v$).$silentErrors.length || unref(isLoading)) ? " disabled" : ""} class="${ssrRenderClass([{
        "opacity-70 cursor-not-allowed": unref(v$).$silentErrors.length || unref(isLoading)
      }, "border mb-4 text-[13px] border-primary- uppercase text-white w-full min-w-[55px] bg-primary-500 text-center opacity-80 rounded-full px-6 py-2 hover:opacity-100 h-11 leading-[normal]"])}">`);
      if (unref(isLoading)) {
        _push(`<span>Signing up <i style="${ssrRenderStyle(unref(isLoading) ? null : { display: "none" })}" class="fa fa-spinner fa-spin text-white" aria-hidden="true"></i></span>`);
      } else {
        _push(`<span> Sign up</span>`);
      }
      _push(`</button><div class="text-center mt-4"><p class="mb-0 text-matta-black text-sm relative before:absolute before:w-[25%] before:border-t before:top-[7px] after:top-[7px] before:left-0 after:right-0 after:border-t after:w-[25%] after:absolute text-center uppercase"> Or continue with </p><div class="flex justify-center gap-x-6 mt-6"><button class="border border-[#E7EBEE] rounded-full flex items-center h-11 w-12 justify-center text-center hover:bg-gray-400 hover:shadow-sm relative"><img${ssrRenderAttr("src", _imports_0)} alt="google" class="w-4 h-auto"></button></div></div></div></form></div>`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Information/quote/RegisterComponent.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$8;
const _sfc_main$7 = {
  __name: "IndexQuote",
  __ssrInlineRender: true,
  emits: ["togglePopup"],
  setup(__props, { emit: __emit }) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
    const supplierStore = useSupplierStore();
    inject("togglePopup");
    const authStore = useAuthStore();
    useStore();
    const product = inject("product");
    const quoteForm = reactive({
      sellerId: (_a = product.value) == null ? void 0 : _a.supplierId,
      seller: (_b = supplierStore.supplierData) == null ? void 0 : _b.companyName,
      productId: (_c = product.value) == null ? void 0 : _c.id,
      productImg: (_d = product.value) == null ? void 0 : _d.gallery[0],
      productName: (_e = product.value) == null ? void 0 : _e.name,
      producerId: (_f = product.value) == null ? void 0 : _f.producer.id,
      producer: (_g = product.value) == null ? void 0 : _g.producer.title,
      buyerBusinessName: "",
      requestedBy: (_h = authStore == null ? void 0 : authStore.userInfo) == null ? void 0 : _h.fullName,
      sellerName: (_i = supplierStore.supplierData) == null ? void 0 : _i.companyName,
      market: "",
      productUse: "",
      expectedVolume: 0,
      unit: (_j = product.value) == null ? void 0 : _j.unit,
      deliverAddress: "",
      contactPhone: "",
      additionalInformation: "",
      phoneCode: "+234",
      phone: null,
      package: null,
      applications: ""
    });
    const showAuth = ref(false);
    const isOpen = ref(false);
    const active = ref(1);
    const isLoading = ref(false);
    const authType = ref("login");
    const myrules1 = {
      market: { required },
      applications: { required },
      productUse: { required },
      expectedVolume: { required },
      package: { required },
      unit: { required }
    };
    const validPhoneLength = (value) => quoteForm.phoneCode === "+234" ? value.length > 9 && value.length < 12 : true;
    const myrules2 = {
      deliverAddress: { required },
      phone: {
        required,
        numeric,
        validPhoneLength: helpers.withMessage(
          "Phone number must be between 10 0r 11 digits",
          validPhoneLength
        )
      },
      additionalInformation: {}
    };
    const request1$ = useVuelidate(myrules1, quoteForm);
    const request2$ = useVuelidate(myrules2, quoteForm);
    async function handleSubmit() {
      const validity1 = await request1$.value.$validate();
      const validity2 = await request2$.value.$validate();
      if (!validity1 || !validity2)
        return;
      isLoading.value = true;
      quoteForm.contactPhone = `${quoteForm.phoneCode} - ${quoteForm.phone}`;
      newquote(quoteForm).then((res) => {
        if (res.status === 200) {
          active.value = 3;
        }
      }).catch((err) => {
        isLoading.value = false;
        toast.error(err.response.data.message || err.response.data.Message);
      });
    }
    function toggleAuth() {
      isOpen.value = true;
    }
    function toggleModal(val) {
      authType.value = val;
    }
    computed(() => {
      return authStore.isLoggedIn;
    });
    function handleclose() {
      isOpen.value = false;
      if (active.value == 2) {
        handleSubmit();
      } else {
        showAuth.value = false;
      }
    }
    provide("handleSubmit", handleSubmit);
    provide("toggleModal", toggleModal);
    provide("toggleAuth", toggleAuth);
    provide("request1$", request1$);
    provide("request2$", request2$);
    provide("quoteForm", quoteForm);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_InformationQuoteUsageDetails = __nuxt_component_0$2;
      const _component_InformationQuoteShippingAddress = __nuxt_component_1$1;
      const _component_InformationQuoteRequestComplete = __nuxt_component_2$1;
      const _component_InformationQuoteRegisterComponent = __nuxt_component_3;
      const _component_router_link = resolveComponent("router-link");
      const _component_LoginModal = __nuxt_component_9;
      _push(`<!--[--><form class="flex flex-col h-full overflow-y-auto"><div class="flex-1"><div class="flex justify-between items-center mb-6"><h4 class="text-lg sm:text-2xl font-medium">Request a Quote</h4></div><div class="flex justify-between items-center mb-2 text-[13px] uppercase"><h4 class="text-[13px] uppercase">${ssrInterpolate(unref(product).name)}</h4><span>Step ${ssrInterpolate(unref(active))}/3</span></div><div class="grid grid-cols-3 border-b border-[#E7EBEE]"><!--[-->`);
      ssrRenderList(3, (n) => {
        _push(`<span class="${ssrRenderClass(`rounded-full pt-1 ${unref(active) >= n ? "bg-primary" : "bg-white"}`)}"></span>`);
      });
      _push(`<!--]--></div><div>`);
      if (unref(active) === 1) {
        _push(ssrRenderComponent(_component_InformationQuoteUsageDetails, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(active) === 2 && !unref(showAuth)) {
        _push(`<div>`);
        _push(ssrRenderComponent(_component_InformationQuoteShippingAddress, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(active) === 3) {
        _push(ssrRenderComponent(_component_InformationQuoteRequestComplete, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(active) === 2 && unref(showAuth)) {
        _push(ssrRenderComponent(_component_InformationQuoteRegisterComponent, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      if (unref(active) !== 3) {
        _push(`<div>`);
        if (!unref(authStore).isLoggedIn) {
          _push(`<span class="mb-2 text-primary text-xs">Log In to speed up your request <i class="uil uil-arrow-up-right text-x"></i></span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="flex justify-between gap-x-2 items-center mt-8"><button type="button" class="appearance-none border w-1/2 leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"> Cancel </button>`);
        if (unref(active) > 1) {
          _push(`<button type="button" class="appearance-none border w-1/2 leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"> Back </button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<button type="button" class="appearance-none border w-1/2 border-primary- leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase"> Next </button></div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(active) === 3) {
        _push(`<div><div class="grid grid-cols-2 justify-between gap-x-2 items-center mt-8">`);
        _push(ssrRenderComponent(_component_router_link, { to: "/procurement/my-requests" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<button type="button" class="appearance-none whitespace-nowrap border w-full leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"${_scopeId}> My Quotes </button>`);
            } else {
              return [
                createVNode("button", {
                  type: "button",
                  class: "appearance-none whitespace-nowrap border w-full leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 text-[13px] uppercase"
                }, " My Quotes ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`<button type="button" class="appearance-none border w-full border-primary- leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase"> product page </button></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</form>`);
      if (unref(isOpen)) {
        _push(ssrRenderComponent(_component_LoginModal, {
          showSignup: false,
          isOpen: unref(isOpen),
          onClose: handleclose
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Information/quote/IndexQuote.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_8 = _sfc_main$7;
const _sfc_main$6 = {
  __name: "RegisterModal",
  __ssrInlineRender: true,
  props: ["title", "text", "isOpen"],
  emits: ["deleteItem", "close"],
  setup(__props, { emit: __emit }) {
    const store = useStore();
    const type = ref("buyer");
    const form = reactive({
      email: "",
      password: "",
      business_UserType: 0,
      confirmPassword: "",
      BusinessName: "BusinessName"
    });
    const emits = __emit;
    const toggleModal = inject("toggleModal");
    function handleclose(val) {
      emits("close", val);
    }
    const isLoading = ref(false);
    const validPassword = (value) => {
      let res = /[a-z]/.test(value) && /[A-Z]/.test(value) && /[0-9]/.test(value);
      return res;
    };
    const specialPassword = (value) => {
      let res = /[@&!%#$%]/.test(value);
      return res;
    };
    const samePassword = (value) => value === form.password;
    const rules = {
      email: {
        required: helpers.withMessage("Email field cannot be empty", required),
        email: helpers.withMessage("Email is invalid", email),
        maxLength: maxLength(50)
      },
      password: {
        required: helpers.withMessage("Password field cannot be empty", required),
        minLength: minLength(8),
        maxLength: maxLength(24),
        validPassword: helpers.withMessage(
          "Password must include UPPER/lowercase characters and number",
          validPassword
        ),
        specialPassword: helpers.withMessage(
          "Password must contain at least 1 of the special  characters @&!-%#$%",
          specialPassword
        )
      },
      confirmPassword: {
        required: helpers.withMessage(
          "Confirm Password field cannot be empty",
          required
        ),
        minLength: minLength(8),
        maxLength: maxLength(24),
        validPassword: helpers.withMessage(
          "Confirm Password is invalid",
          validPassword
        ),
        samePassword: helpers.withMessage("Passwords do not match!", samePassword)
      }
    };
    const v$ = useVuelidate(rules, form);
    const isShowingPasword = ref(false);
    async function handleSubmit() {
      const validity = await v$.value.$validate();
      if (!validity)
        return;
      isLoading.value = true;
      type.value == "buyer" ? form.business_UserType = 0 : form.business_UserType = 1;
      registerUser(form).then((res) => {
        if (res.status === 200) {
          loginUser(form).then((res2) => {
            if (res2.status === 200) {
              store.commit("setUser", res2.data.data);
              toast.info("Login successful", {
                position: "bottom"
              });
              handleclose("success");
            }
          }).catch((err) => {
            isLoading.value = false;
            toast.error(err.response.data.message || err.response.data.Message, {
              position: "bottom"
            });
          });
        }
      }).catch((err) => {
        isLoading.value = false;
        toast.error(err.response.data.message || err.response.data.Message);
      });
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(unref(TransitionRoot), {
        as: "template",
        show: __props.isOpen
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Dialog), {
              as: "div",
              class: "relative z-[999]",
              onClose: ($event) => handleclose("close")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div class="fixed z-10 inset-0 overflow-y-auto"${_scopeId2}><div class="flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                    "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                    "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="relative bg-white rounded-lg text-left p-6 lg:p-8 overflow-hidden shadow-xl transform transition-all sm:w-[500px]"${_scopeId3}><span class="cursor-pointer"${_scopeId3}><i class="uil uil-times cursor-pointer text-lg absolute top-4 right-4"${_scopeId3}></i></span><div class="w-full h-full grid items-center"${_scopeId3}><div${_scopeId3}>`);
                        if (!unref(store).getters.isLoggedIn) {
                          _push4(`<form${_scopeId3}><p class="text-sm mb-8"${_scopeId3}> Sign Up with your work email so Supplier can respond. Already have an account? <span class="text-primary cursor-pointer"${_scopeId3}>Sign in <i class="uil uil-arrow-up-right"${_scopeId3}></i></span></p><div class="flex gap-x-4 items-center mb-10"${_scopeId3}><button type="button" class="${ssrRenderClass([
                            type.value === "buyer" ? "border-matta-black bg-matta-black hover:bg-matta-black/80 text-white" : "border-matta-black bg-white hover:bg-matta-black/10 text-matta-black",
                            "border uppercase w-full rounded-lg px-6 py-3 flex items-center gap-x-2 justify-center text-xs"
                          ])}"${_scopeId3}><i class="uil uil-shopping-cart-alt"${_scopeId3}></i><span class="opacity-50"${_scopeId3}>|</span><span${_scopeId3}>Buyer</span></button><button type="button" class="${ssrRenderClass([
                            type.value === "supplier" ? "border-matta-black bg-matta-black hover:bg-matta-black/80 text-white" : "border-matta-black bg-white hover:bg-matta-black/10 text-matta-black",
                            "border uppercase w-full rounded-lg px-6 py-3 flex items-center gap-x-2 justify-center text-xs"
                          ])}"${_scopeId3}><i class="uil uil-shop"${_scopeId3}></i><span class="opacity-50"${_scopeId3}>|</span><span${_scopeId3}>Supplier</span></button></div><div class="mb-6"${_scopeId3}><label class="mb-2 font-normal text-xs block"${_scopeId3}>E-mail</label><input${ssrRenderAttr("value", unref(v$).email.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).email.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="E-mail" type="email"${_scopeId3}><!--[-->`);
                          ssrRenderList(unref(v$).email.$errors, (error) => {
                            _push4(`<div class="text-red-500 mt-1"${_scopeId3}><div class="error-msg text-error text-xs font-semibold"${_scopeId3}>${ssrInterpolate(error.$message)}</div></div>`);
                          });
                          _push4(`<!--]--></div><div class="grid grid-cols-2 gap-x-6"${_scopeId3}><div class="mb-6"${_scopeId3}><label class="mb-2 font-normal text-xs block text-matta-black"${_scopeId3}>Password</label><div class="relative flex items-center"${_scopeId3}><input${ssrRenderDynamicModel(!isShowingPasword.value ? "password" : "text", unref(v$).password.$model, null)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).password.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Password" autocomplete="off"${ssrRenderAttr("type", !isShowingPasword.value ? "password" : "text")}${_scopeId3}>`);
                          if (!isShowingPasword.value) {
                            _push4(ssrRenderComponent(unref(EyeIcon), {
                              onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                              class: "w-4 h-4 absolute cursor-pointer right-6"
                            }, null, _parent4, _scopeId3));
                          } else {
                            _push4(ssrRenderComponent(unref(EyeSlashIcon), {
                              onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                              class: "w-4 h-4 absolute cursor-pointer right-6"
                            }, null, _parent4, _scopeId3));
                          }
                          _push4(`</div><!--[-->`);
                          ssrRenderList(unref(v$).password.$errors, (error) => {
                            _push4(`<div class="text-red-500 mt-1"${_scopeId3}><div class="error-msg text-error text-xs font-semibold"${_scopeId3}>${ssrInterpolate(error.$message)}</div></div>`);
                          });
                          _push4(`<!--]--></div><div class="mb-6"${_scopeId3}><label class="mb-2 font-normal text-xs block text-matta-black"${_scopeId3}>Confirm Password</label><div class="relative flex items-center"${_scopeId3}><input${ssrRenderDynamicModel(!isShowingPasword.value ? "password" : "text", unref(v$).confirmPassword.$model, null)} class="${ssrRenderClass([{
                            "border-red-500 ": unref(v$).confirmPassword.$error
                          }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Password" autocomplete="off"${ssrRenderAttr("type", !isShowingPasword.value ? "password" : "text")}${_scopeId3}>`);
                          if (!isShowingPasword.value) {
                            _push4(ssrRenderComponent(unref(EyeIcon), {
                              onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                              class: "w-4 h-4 absolute cursor-pointer right-6"
                            }, null, _parent4, _scopeId3));
                          } else {
                            _push4(ssrRenderComponent(unref(EyeSlashIcon), {
                              onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                              class: "w-4 h-4 absolute cursor-pointer right-6"
                            }, null, _parent4, _scopeId3));
                          }
                          _push4(`</div><!--[-->`);
                          ssrRenderList(unref(v$).confirmPassword.$errors, (error) => {
                            _push4(`<div class="text-red-500 mt-1"${_scopeId3}><div class="error-msg text-error text-xs font-semibold"${_scopeId3}>${ssrInterpolate(error.$message)}</div></div>`);
                          });
                          _push4(`<!--]--></div></div><div class="flex justify-between gap-x-6 items-center mt-4"${_scopeId3}><button${ssrIncludeBooleanAttr(isLoading.value || unref(v$).$silentErrors.length) ? " disabled" : ""} type="submit" class="border text-[13px] border-primary- uppercase min-w-[150px] w-full text-white bg-primary-500 text-center rounded-full px-6 py-4 hover:bg-primary/80 leading-[normal]"${_scopeId3}>`);
                          if (!isLoading.value) {
                            _push4(`<span${_scopeId3}>Sign up</span>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          if (isLoading.value) {
                            _push4(`<span${_scopeId3}>Signing up `);
                            if (isLoading.value) {
                              _push4(`<i class="fa fa-spinner fa-spin text-white" aria-hidden="true"${_scopeId3}></i>`);
                            } else {
                              _push4(`<!---->`);
                            }
                            _push4(`</span>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          _push4(`</button></div></form>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(`</div></div></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "relative bg-white rounded-lg text-left p-6 lg:p-8 overflow-hidden shadow-xl transform transition-all sm:w-[500px]" }, [
                            createVNode("span", {
                              onClick: ($event) => handleclose("close"),
                              class: "cursor-pointer"
                            }, [
                              createVNode("i", { class: "uil uil-times cursor-pointer text-lg absolute top-4 right-4" })
                            ], 8, ["onClick"]),
                            createVNode("div", { class: "w-full h-full grid items-center" }, [
                              createVNode("div", null, [
                                !unref(store).getters.isLoggedIn ? (openBlock(), createBlock("form", {
                                  key: 0,
                                  onSubmit: withModifiers(handleSubmit, ["prevent"])
                                }, [
                                  createVNode("p", { class: "text-sm mb-8" }, [
                                    createTextVNode(" Sign Up with your work email so Supplier can respond. Already have an account? "),
                                    createVNode("span", {
                                      class: "text-primary cursor-pointer",
                                      onClick: ($event) => unref(toggleModal)("signin")
                                    }, [
                                      createTextVNode("Sign in "),
                                      createVNode("i", { class: "uil uil-arrow-up-right" })
                                    ], 8, ["onClick"])
                                  ]),
                                  createVNode("div", { class: "flex gap-x-4 items-center mb-10" }, [
                                    createVNode("button", {
                                      onClick: ($event) => type.value = "buyer",
                                      type: "button",
                                      class: [
                                        "border uppercase w-full rounded-lg px-6 py-3 flex items-center gap-x-2 justify-center text-xs",
                                        type.value === "buyer" ? "border-matta-black bg-matta-black hover:bg-matta-black/80 text-white" : "border-matta-black bg-white hover:bg-matta-black/10 text-matta-black"
                                      ]
                                    }, [
                                      createVNode("i", { class: "uil uil-shopping-cart-alt" }),
                                      createVNode("span", { class: "opacity-50" }, "|"),
                                      createVNode("span", null, "Buyer")
                                    ], 10, ["onClick"]),
                                    createVNode("button", {
                                      onClick: ($event) => type.value = "supplier",
                                      type: "button",
                                      class: [
                                        "border uppercase w-full rounded-lg px-6 py-3 flex items-center gap-x-2 justify-center text-xs",
                                        type.value === "supplier" ? "border-matta-black bg-matta-black hover:bg-matta-black/80 text-white" : "border-matta-black bg-white hover:bg-matta-black/10 text-matta-black"
                                      ]
                                    }, [
                                      createVNode("i", { class: "uil uil-shop" }),
                                      createVNode("span", { class: "opacity-50" }, "|"),
                                      createVNode("span", null, "Supplier")
                                    ], 10, ["onClick"])
                                  ]),
                                  createVNode("div", { class: "mb-6" }, [
                                    createVNode("label", { class: "mb-2 font-normal text-xs block" }, "E-mail"),
                                    withDirectives(createVNode("input", {
                                      "onUpdate:modelValue": ($event) => unref(v$).email.$model = $event,
                                      class: [{ "border-red-500": unref(v$).email.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                                      placeholder: "E-mail",
                                      type: "email"
                                    }, null, 10, ["onUpdate:modelValue"]), [
                                      [vModelText, unref(v$).email.$model]
                                    ]),
                                    (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).email.$errors, (error) => {
                                      return openBlock(), createBlock("div", {
                                        class: "text-red-500 mt-1",
                                        key: error.$uid
                                      }, [
                                        createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                                      ]);
                                    }), 128))
                                  ]),
                                  createVNode("div", { class: "grid grid-cols-2 gap-x-6" }, [
                                    createVNode("div", { class: "mb-6" }, [
                                      createVNode("label", { class: "mb-2 font-normal text-xs block text-matta-black" }, "Password"),
                                      createVNode("div", { class: "relative flex items-center" }, [
                                        withDirectives(createVNode("input", {
                                          "onUpdate:modelValue": ($event) => unref(v$).password.$model = $event,
                                          class: [{ "border-red-500 ": unref(v$).password.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                                          placeholder: "Password",
                                          autocomplete: "off",
                                          type: !isShowingPasword.value ? "password" : "text"
                                        }, null, 10, ["onUpdate:modelValue", "type"]), [
                                          [vModelDynamic, unref(v$).password.$model]
                                        ]),
                                        !isShowingPasword.value ? (openBlock(), createBlock(unref(EyeIcon), {
                                          key: 0,
                                          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                          class: "w-4 h-4 absolute cursor-pointer right-6"
                                        }, null, 8, ["onClick"])) : (openBlock(), createBlock(unref(EyeSlashIcon), {
                                          key: 1,
                                          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                          class: "w-4 h-4 absolute cursor-pointer right-6"
                                        }, null, 8, ["onClick"]))
                                      ]),
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).password.$errors, (error) => {
                                        return openBlock(), createBlock("div", {
                                          class: "text-red-500 mt-1",
                                          key: error.$uid
                                        }, [
                                          createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                                        ]);
                                      }), 128))
                                    ]),
                                    createVNode("div", { class: "mb-6" }, [
                                      createVNode("label", { class: "mb-2 font-normal text-xs block text-matta-black" }, "Confirm Password"),
                                      createVNode("div", { class: "relative flex items-center" }, [
                                        withDirectives(createVNode("input", {
                                          "onUpdate:modelValue": ($event) => unref(v$).confirmPassword.$model = $event,
                                          class: [{
                                            "border-red-500 ": unref(v$).confirmPassword.$error
                                          }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                                          placeholder: "Password",
                                          autocomplete: "off",
                                          type: !isShowingPasword.value ? "password" : "text"
                                        }, null, 10, ["onUpdate:modelValue", "type"]), [
                                          [vModelDynamic, unref(v$).confirmPassword.$model]
                                        ]),
                                        !isShowingPasword.value ? (openBlock(), createBlock(unref(EyeIcon), {
                                          key: 0,
                                          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                          class: "w-4 h-4 absolute cursor-pointer right-6"
                                        }, null, 8, ["onClick"])) : (openBlock(), createBlock(unref(EyeSlashIcon), {
                                          key: 1,
                                          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                          class: "w-4 h-4 absolute cursor-pointer right-6"
                                        }, null, 8, ["onClick"]))
                                      ]),
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).confirmPassword.$errors, (error) => {
                                        return openBlock(), createBlock("div", {
                                          class: "text-red-500 mt-1",
                                          key: error.$uid
                                        }, [
                                          createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                                        ]);
                                      }), 128))
                                    ])
                                  ]),
                                  createVNode("div", { class: "flex justify-between gap-x-6 items-center mt-4" }, [
                                    createVNode("button", {
                                      disabled: isLoading.value || unref(v$).$silentErrors.length,
                                      type: "submit",
                                      class: "border text-[13px] border-primary- uppercase min-w-[150px] w-full text-white bg-primary-500 text-center rounded-full px-6 py-4 hover:bg-primary/80 leading-[normal]"
                                    }, [
                                      !isLoading.value ? (openBlock(), createBlock("span", { key: 0 }, "Sign up")) : createCommentVNode("", true),
                                      isLoading.value ? (openBlock(), createBlock("span", { key: 1 }, [
                                        createTextVNode("Signing up "),
                                        isLoading.value ? (openBlock(), createBlock("i", {
                                          key: 0,
                                          class: "fa fa-spinner fa-spin text-white",
                                          "aria-hidden": "true"
                                        })) : createCommentVNode("", true)
                                      ])) : createCommentVNode("", true)
                                    ], 8, ["disabled"])
                                  ])
                                ], 32)) : createCommentVNode("", true)
                              ])
                            ])
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode(unref(TransitionChild), {
                      as: "template",
                      enter: "ease-out duration-300",
                      "enter-from": "opacity-0",
                      "enter-to": "opacity-100",
                      leave: "ease-in duration-200",
                      "leave-from": "opacity-100",
                      "leave-to": "opacity-0"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" })
                      ]),
                      _: 1
                    }),
                    createVNode("div", { class: "fixed z-10 inset-0 overflow-y-auto" }, [
                      createVNode("div", { class: "flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0" }, [
                        createVNode(unref(TransitionChild), {
                          as: "template",
                          enter: "ease-out duration-300",
                          "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                          "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                          leave: "ease-in duration-200",
                          "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                          "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                        }, {
                          default: withCtx(() => [
                            createVNode("div", { class: "relative bg-white rounded-lg text-left p-6 lg:p-8 overflow-hidden shadow-xl transform transition-all sm:w-[500px]" }, [
                              createVNode("span", {
                                onClick: ($event) => handleclose("close"),
                                class: "cursor-pointer"
                              }, [
                                createVNode("i", { class: "uil uil-times cursor-pointer text-lg absolute top-4 right-4" })
                              ], 8, ["onClick"]),
                              createVNode("div", { class: "w-full h-full grid items-center" }, [
                                createVNode("div", null, [
                                  !unref(store).getters.isLoggedIn ? (openBlock(), createBlock("form", {
                                    key: 0,
                                    onSubmit: withModifiers(handleSubmit, ["prevent"])
                                  }, [
                                    createVNode("p", { class: "text-sm mb-8" }, [
                                      createTextVNode(" Sign Up with your work email so Supplier can respond. Already have an account? "),
                                      createVNode("span", {
                                        class: "text-primary cursor-pointer",
                                        onClick: ($event) => unref(toggleModal)("signin")
                                      }, [
                                        createTextVNode("Sign in "),
                                        createVNode("i", { class: "uil uil-arrow-up-right" })
                                      ], 8, ["onClick"])
                                    ]),
                                    createVNode("div", { class: "flex gap-x-4 items-center mb-10" }, [
                                      createVNode("button", {
                                        onClick: ($event) => type.value = "buyer",
                                        type: "button",
                                        class: [
                                          "border uppercase w-full rounded-lg px-6 py-3 flex items-center gap-x-2 justify-center text-xs",
                                          type.value === "buyer" ? "border-matta-black bg-matta-black hover:bg-matta-black/80 text-white" : "border-matta-black bg-white hover:bg-matta-black/10 text-matta-black"
                                        ]
                                      }, [
                                        createVNode("i", { class: "uil uil-shopping-cart-alt" }),
                                        createVNode("span", { class: "opacity-50" }, "|"),
                                        createVNode("span", null, "Buyer")
                                      ], 10, ["onClick"]),
                                      createVNode("button", {
                                        onClick: ($event) => type.value = "supplier",
                                        type: "button",
                                        class: [
                                          "border uppercase w-full rounded-lg px-6 py-3 flex items-center gap-x-2 justify-center text-xs",
                                          type.value === "supplier" ? "border-matta-black bg-matta-black hover:bg-matta-black/80 text-white" : "border-matta-black bg-white hover:bg-matta-black/10 text-matta-black"
                                        ]
                                      }, [
                                        createVNode("i", { class: "uil uil-shop" }),
                                        createVNode("span", { class: "opacity-50" }, "|"),
                                        createVNode("span", null, "Supplier")
                                      ], 10, ["onClick"])
                                    ]),
                                    createVNode("div", { class: "mb-6" }, [
                                      createVNode("label", { class: "mb-2 font-normal text-xs block" }, "E-mail"),
                                      withDirectives(createVNode("input", {
                                        "onUpdate:modelValue": ($event) => unref(v$).email.$model = $event,
                                        class: [{ "border-red-500": unref(v$).email.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                                        placeholder: "E-mail",
                                        type: "email"
                                      }, null, 10, ["onUpdate:modelValue"]), [
                                        [vModelText, unref(v$).email.$model]
                                      ]),
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).email.$errors, (error) => {
                                        return openBlock(), createBlock("div", {
                                          class: "text-red-500 mt-1",
                                          key: error.$uid
                                        }, [
                                          createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                                        ]);
                                      }), 128))
                                    ]),
                                    createVNode("div", { class: "grid grid-cols-2 gap-x-6" }, [
                                      createVNode("div", { class: "mb-6" }, [
                                        createVNode("label", { class: "mb-2 font-normal text-xs block text-matta-black" }, "Password"),
                                        createVNode("div", { class: "relative flex items-center" }, [
                                          withDirectives(createVNode("input", {
                                            "onUpdate:modelValue": ($event) => unref(v$).password.$model = $event,
                                            class: [{ "border-red-500 ": unref(v$).password.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                                            placeholder: "Password",
                                            autocomplete: "off",
                                            type: !isShowingPasword.value ? "password" : "text"
                                          }, null, 10, ["onUpdate:modelValue", "type"]), [
                                            [vModelDynamic, unref(v$).password.$model]
                                          ]),
                                          !isShowingPasword.value ? (openBlock(), createBlock(unref(EyeIcon), {
                                            key: 0,
                                            onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                            class: "w-4 h-4 absolute cursor-pointer right-6"
                                          }, null, 8, ["onClick"])) : (openBlock(), createBlock(unref(EyeSlashIcon), {
                                            key: 1,
                                            onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                            class: "w-4 h-4 absolute cursor-pointer right-6"
                                          }, null, 8, ["onClick"]))
                                        ]),
                                        (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).password.$errors, (error) => {
                                          return openBlock(), createBlock("div", {
                                            class: "text-red-500 mt-1",
                                            key: error.$uid
                                          }, [
                                            createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                                          ]);
                                        }), 128))
                                      ]),
                                      createVNode("div", { class: "mb-6" }, [
                                        createVNode("label", { class: "mb-2 font-normal text-xs block text-matta-black" }, "Confirm Password"),
                                        createVNode("div", { class: "relative flex items-center" }, [
                                          withDirectives(createVNode("input", {
                                            "onUpdate:modelValue": ($event) => unref(v$).confirmPassword.$model = $event,
                                            class: [{
                                              "border-red-500 ": unref(v$).confirmPassword.$error
                                            }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                                            placeholder: "Password",
                                            autocomplete: "off",
                                            type: !isShowingPasword.value ? "password" : "text"
                                          }, null, 10, ["onUpdate:modelValue", "type"]), [
                                            [vModelDynamic, unref(v$).confirmPassword.$model]
                                          ]),
                                          !isShowingPasword.value ? (openBlock(), createBlock(unref(EyeIcon), {
                                            key: 0,
                                            onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                            class: "w-4 h-4 absolute cursor-pointer right-6"
                                          }, null, 8, ["onClick"])) : (openBlock(), createBlock(unref(EyeSlashIcon), {
                                            key: 1,
                                            onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                            class: "w-4 h-4 absolute cursor-pointer right-6"
                                          }, null, 8, ["onClick"]))
                                        ]),
                                        (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).confirmPassword.$errors, (error) => {
                                          return openBlock(), createBlock("div", {
                                            class: "text-red-500 mt-1",
                                            key: error.$uid
                                          }, [
                                            createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                                          ]);
                                        }), 128))
                                      ])
                                    ]),
                                    createVNode("div", { class: "flex justify-between gap-x-6 items-center mt-4" }, [
                                      createVNode("button", {
                                        disabled: isLoading.value || unref(v$).$silentErrors.length,
                                        type: "submit",
                                        class: "border text-[13px] border-primary- uppercase min-w-[150px] w-full text-white bg-primary-500 text-center rounded-full px-6 py-4 hover:bg-primary/80 leading-[normal]"
                                      }, [
                                        !isLoading.value ? (openBlock(), createBlock("span", { key: 0 }, "Sign up")) : createCommentVNode("", true),
                                        isLoading.value ? (openBlock(), createBlock("span", { key: 1 }, [
                                          createTextVNode("Signing up "),
                                          isLoading.value ? (openBlock(), createBlock("i", {
                                            key: 0,
                                            class: "fa fa-spinner fa-spin text-white",
                                            "aria-hidden": "true"
                                          })) : createCommentVNode("", true)
                                        ])) : createCommentVNode("", true)
                                      ], 8, ["disabled"])
                                    ])
                                  ], 32)) : createCommentVNode("", true)
                                ])
                              ])
                            ])
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Dialog), {
                as: "div",
                class: "relative z-[999]",
                onClose: ($event) => handleclose("close")
              }, {
                default: withCtx(() => [
                  createVNode(unref(TransitionChild), {
                    as: "template",
                    enter: "ease-out duration-300",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "ease-in duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0"
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(DialogOverlay), { class: "fixed inset-0 bg-[#222222]/60 transition-opacity" })
                    ]),
                    _: 1
                  }),
                  createVNode("div", { class: "fixed z-10 inset-0 overflow-y-auto" }, [
                    createVNode("div", { class: "flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0" }, [
                      createVNode(unref(TransitionChild), {
                        as: "template",
                        enter: "ease-out duration-300",
                        "enter-from": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
                        "enter-to": "opacity-100 translate-y-0 sm:scale-100",
                        leave: "ease-in duration-200",
                        "leave-from": "opacity-100 translate-y-0 sm:scale-100",
                        "leave-to": "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                      }, {
                        default: withCtx(() => [
                          createVNode("div", { class: "relative bg-white rounded-lg text-left p-6 lg:p-8 overflow-hidden shadow-xl transform transition-all sm:w-[500px]" }, [
                            createVNode("span", {
                              onClick: ($event) => handleclose("close"),
                              class: "cursor-pointer"
                            }, [
                              createVNode("i", { class: "uil uil-times cursor-pointer text-lg absolute top-4 right-4" })
                            ], 8, ["onClick"]),
                            createVNode("div", { class: "w-full h-full grid items-center" }, [
                              createVNode("div", null, [
                                !unref(store).getters.isLoggedIn ? (openBlock(), createBlock("form", {
                                  key: 0,
                                  onSubmit: withModifiers(handleSubmit, ["prevent"])
                                }, [
                                  createVNode("p", { class: "text-sm mb-8" }, [
                                    createTextVNode(" Sign Up with your work email so Supplier can respond. Already have an account? "),
                                    createVNode("span", {
                                      class: "text-primary cursor-pointer",
                                      onClick: ($event) => unref(toggleModal)("signin")
                                    }, [
                                      createTextVNode("Sign in "),
                                      createVNode("i", { class: "uil uil-arrow-up-right" })
                                    ], 8, ["onClick"])
                                  ]),
                                  createVNode("div", { class: "flex gap-x-4 items-center mb-10" }, [
                                    createVNode("button", {
                                      onClick: ($event) => type.value = "buyer",
                                      type: "button",
                                      class: [
                                        "border uppercase w-full rounded-lg px-6 py-3 flex items-center gap-x-2 justify-center text-xs",
                                        type.value === "buyer" ? "border-matta-black bg-matta-black hover:bg-matta-black/80 text-white" : "border-matta-black bg-white hover:bg-matta-black/10 text-matta-black"
                                      ]
                                    }, [
                                      createVNode("i", { class: "uil uil-shopping-cart-alt" }),
                                      createVNode("span", { class: "opacity-50" }, "|"),
                                      createVNode("span", null, "Buyer")
                                    ], 10, ["onClick"]),
                                    createVNode("button", {
                                      onClick: ($event) => type.value = "supplier",
                                      type: "button",
                                      class: [
                                        "border uppercase w-full rounded-lg px-6 py-3 flex items-center gap-x-2 justify-center text-xs",
                                        type.value === "supplier" ? "border-matta-black bg-matta-black hover:bg-matta-black/80 text-white" : "border-matta-black bg-white hover:bg-matta-black/10 text-matta-black"
                                      ]
                                    }, [
                                      createVNode("i", { class: "uil uil-shop" }),
                                      createVNode("span", { class: "opacity-50" }, "|"),
                                      createVNode("span", null, "Supplier")
                                    ], 10, ["onClick"])
                                  ]),
                                  createVNode("div", { class: "mb-6" }, [
                                    createVNode("label", { class: "mb-2 font-normal text-xs block" }, "E-mail"),
                                    withDirectives(createVNode("input", {
                                      "onUpdate:modelValue": ($event) => unref(v$).email.$model = $event,
                                      class: [{ "border-red-500": unref(v$).email.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                                      placeholder: "E-mail",
                                      type: "email"
                                    }, null, 10, ["onUpdate:modelValue"]), [
                                      [vModelText, unref(v$).email.$model]
                                    ]),
                                    (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).email.$errors, (error) => {
                                      return openBlock(), createBlock("div", {
                                        class: "text-red-500 mt-1",
                                        key: error.$uid
                                      }, [
                                        createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                                      ]);
                                    }), 128))
                                  ]),
                                  createVNode("div", { class: "grid grid-cols-2 gap-x-6" }, [
                                    createVNode("div", { class: "mb-6" }, [
                                      createVNode("label", { class: "mb-2 font-normal text-xs block text-matta-black" }, "Password"),
                                      createVNode("div", { class: "relative flex items-center" }, [
                                        withDirectives(createVNode("input", {
                                          "onUpdate:modelValue": ($event) => unref(v$).password.$model = $event,
                                          class: [{ "border-red-500 ": unref(v$).password.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                                          placeholder: "Password",
                                          autocomplete: "off",
                                          type: !isShowingPasword.value ? "password" : "text"
                                        }, null, 10, ["onUpdate:modelValue", "type"]), [
                                          [vModelDynamic, unref(v$).password.$model]
                                        ]),
                                        !isShowingPasword.value ? (openBlock(), createBlock(unref(EyeIcon), {
                                          key: 0,
                                          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                          class: "w-4 h-4 absolute cursor-pointer right-6"
                                        }, null, 8, ["onClick"])) : (openBlock(), createBlock(unref(EyeSlashIcon), {
                                          key: 1,
                                          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                          class: "w-4 h-4 absolute cursor-pointer right-6"
                                        }, null, 8, ["onClick"]))
                                      ]),
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).password.$errors, (error) => {
                                        return openBlock(), createBlock("div", {
                                          class: "text-red-500 mt-1",
                                          key: error.$uid
                                        }, [
                                          createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                                        ]);
                                      }), 128))
                                    ]),
                                    createVNode("div", { class: "mb-6" }, [
                                      createVNode("label", { class: "mb-2 font-normal text-xs block text-matta-black" }, "Confirm Password"),
                                      createVNode("div", { class: "relative flex items-center" }, [
                                        withDirectives(createVNode("input", {
                                          "onUpdate:modelValue": ($event) => unref(v$).confirmPassword.$model = $event,
                                          class: [{
                                            "border-red-500 ": unref(v$).confirmPassword.$error
                                          }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                                          placeholder: "Password",
                                          autocomplete: "off",
                                          type: !isShowingPasword.value ? "password" : "text"
                                        }, null, 10, ["onUpdate:modelValue", "type"]), [
                                          [vModelDynamic, unref(v$).confirmPassword.$model]
                                        ]),
                                        !isShowingPasword.value ? (openBlock(), createBlock(unref(EyeIcon), {
                                          key: 0,
                                          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                          class: "w-4 h-4 absolute cursor-pointer right-6"
                                        }, null, 8, ["onClick"])) : (openBlock(), createBlock(unref(EyeSlashIcon), {
                                          key: 1,
                                          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
                                          class: "w-4 h-4 absolute cursor-pointer right-6"
                                        }, null, 8, ["onClick"]))
                                      ]),
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(v$).confirmPassword.$errors, (error) => {
                                        return openBlock(), createBlock("div", {
                                          class: "text-red-500 mt-1",
                                          key: error.$uid
                                        }, [
                                          createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                                        ]);
                                      }), 128))
                                    ])
                                  ]),
                                  createVNode("div", { class: "flex justify-between gap-x-6 items-center mt-4" }, [
                                    createVNode("button", {
                                      disabled: isLoading.value || unref(v$).$silentErrors.length,
                                      type: "submit",
                                      class: "border text-[13px] border-primary- uppercase min-w-[150px] w-full text-white bg-primary-500 text-center rounded-full px-6 py-4 hover:bg-primary/80 leading-[normal]"
                                    }, [
                                      !isLoading.value ? (openBlock(), createBlock("span", { key: 0 }, "Sign up")) : createCommentVNode("", true),
                                      isLoading.value ? (openBlock(), createBlock("span", { key: 1 }, [
                                        createTextVNode("Signing up "),
                                        isLoading.value ? (openBlock(), createBlock("i", {
                                          key: 0,
                                          class: "fa fa-spinner fa-spin text-white",
                                          "aria-hidden": "true"
                                        })) : createCommentVNode("", true)
                                      ])) : createCommentVNode("", true)
                                    ], 8, ["disabled"])
                                  ])
                                ], 32)) : createCommentVNode("", true)
                              ])
                            ])
                          ])
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              }, 8, ["onClose"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/RegisterModal.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_10 = _sfc_main$6;
const _sfc_main$5 = {
  __name: "AddedToCart",
  __ssrInlineRender: true,
  props: [
    "name",
    "selectedPackage",
    "totalAmount",
    "quantity",
    "hidePrice"
  ],
  emits: "close",
  setup(__props, { emit: __emit }) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 rounded-xl w-full sm:min-w-[200px] max-w-[250px] fixed bg-white top-20 right-0 md:right-5 shadow-[5px_12px_35px_rgba(44,44,44,0.12)] fade-in-right" }, _attrs))}><div class="flex items-center justify-between mb-4"><span class="text-[13px] text-gray-500 font-bold">ADDED TO CART</span><span>`);
      _push(ssrRenderComponent(unref(XMarkIcon), { class: "w-4 h-4" }, null, _parent));
      _push(`</span></div><div>`);
      if (__props.selectedPackage) {
        _push(`<div><div class="text-xs mb-2 font-medium max-w-max truncate">${ssrInterpolate(__props.name)}</div><div class="flex justify-between items-center"><div class="text-[10px] capitalize"><span class="">${ssrInterpolate(__props.selectedPackage.title)}</span><span class="h-1 w-1 rounded-full bg-gray-300"></span><span>${ssrInterpolate(__props.selectedPackage.price)}</span></div><span class="text-[10px]">x ${ssrInterpolate(__props.quantity)}</span></div>`);
        if (!__props.hidePrice) {
          _push(`<hr class="border-gray-200 my-2">`);
        } else {
          _push(`<!---->`);
        }
        if (!__props.hidePrice) {
          _push(`<div class="flex justify-between items-center"><span class="text-xs text-gray-400">Total</span><span class="text-xs font-medium">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(__props.totalAmount))}</span></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/AddedToCart.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_11 = _sfc_main$5;
const _sfc_main$4 = {
  __name: "Detail",
  __ssrInlineRender: true,
  setup(__props) {
    var _a;
    const isLoading = inject("isLoading");
    const store = useProductStore();
    const cartStore = useCartStore();
    const authStore = useAuthStore();
    const supplierStore = useSupplierStore();
    const { productData } = storeToRefs(store);
    const isAdded = ref(false);
    const route = useRoute();
    const router = useRouter();
    const selectedPackage = ref(null);
    const { name, id, category } = route.params;
    const imageUrl = ref((_a = productData == null ? void 0 : productData.value) == null ? void 0 : _a.featuredPhoto);
    const isSaved = ref(false);
    const packageOptions = computed(
      () => {
        var _a2, _b;
        return (_b = (_a2 = productData == null ? void 0 : productData.value) == null ? void 0 : _a2.packagesAvailable) == null ? void 0 : _b.map((i) => {
          return {
            ...i,
            label: `${i.package.title}/${i.size}${i.unit} - ${__unimport_currencyFormat(
              i.amount
            )}`,
            value: JSON.stringify({ ...i })
          };
        });
      }
    );
    const links = [
      {
        title: "home",
        url: "/"
      },
      {
        title: category,
        url: `/market/${category}/${route.query.categoryId ? route.query.categoryId : ""}`
      },
      {
        title: name,
        url: "#"
      }
    ];
    const isOpen = ref(false);
    const active = ref("signin");
    const isAuthOpen = ref(false);
    const requestType = ref(null);
    function handleclose(val) {
      if (val == "success") {
        (void 0).location.reload();
      }
      isAuthOpen.value = isOpen.value = false;
    }
    function handleRequest(type) {
      if (authStore.isLoggedIn) {
        isOpen.value = true;
        requestType.value = type;
      } else {
        isAuthOpen.value = true;
      }
    }
    function toggleModal(val) {
      active.value = val;
    }
    const mypackage = computed(() => JSON.parse(selectedPackage.value));
    const counter = ref(1);
    function handleCart(type) {
      var _a2, _b, _c, _d;
      if (!selectedPackage.value) {
        toast.info("Please choose a package");
        return;
      }
      let data = {
        id: 0,
        packageId: mypackage == null ? void 0 : mypackage.value.package.id,
        unit: mypackage == null ? void 0 : mypackage.value.unit,
        productId: (_a2 = productData == null ? void 0 : productData.value) == null ? void 0 : _a2.id,
        product: productData == null ? void 0 : productData.value.name,
        productImg: (_b = productData == null ? void 0 : productData.value) == null ? void 0 : _b.featuredPhoto,
        selectedPackage: (_c = mypackage == null ? void 0 : mypackage.value.package) == null ? void 0 : _c.title,
        selectedPackageData: mypackage.value,
        productBrandName: productData == null ? void 0 : productData.value.productBrandName,
        supplierId: productData == null ? void 0 : productData.value.supplierId,
        producer: (_d = productData.value) == null ? void 0 : _d.manufacturer,
        quantity: counter.value,
        packagePrice: mypackage == null ? void 0 : mypackage.value.amount
      };
      cartStore == null ? void 0 : cartStore.addToCart(data, type).then((res) => {
        if (!res.status && res.message === "incart") {
          toast.info("Already in your cart");
        }
        if (res.status && res.message !== "buy") {
          isAdded.value = true;
          setTimeout(() => {
            isAdded.value = false;
          }, 3e3);
        }
        if (res.message === "buy") {
          router.push("/cart");
        }
      });
    }
    function handleSave() {
      if (!authStore.isLoggedIn) {
        toast.info("Login to continue");
        return;
      }
      isSaved.value = true;
      toast.success("Saved");
    }
    function handleLike(value) {
      if (!authStore.isLoggedIn) {
        toast.info("Login to continue");
      }
      let data = {
        businessId: authStore.userId,
        productId: productData.value.id,
        productName: productData.value.name,
        productImg: productData.value.gallery.length ? productData.value.gallery[0] : "",
        backgroundbg: "",
        price: productData.value.price,
        unit: productData.value.unit,
        supplier: productData.value.companyName,
        manufacturer: productData.value.manufacturer,
        options: productData.value.packagesAvailable.length,
        featuredPack: productData.value.packages.length ? productData.value.packages[0].title : ""
      };
      if (value) {
        unlikeproduct(data).then((res) => {
          if (res.status === 200) {
            toast.success("Successfully Unliked");
          }
        });
      } else {
        likeproduct(data).then((res) => {
          if (res.status === 200) {
            toast.success("Successfully liked");
          }
        });
      }
    }
    function togglePopup() {
      isOpen.value = false;
    }
    watch(productData, () => {
      var _a2;
      supplierStore.fetchSupplier(productData.value.supplierId);
      imageUrl.value = (_a2 = productData == null ? void 0 : productData.value) == null ? void 0 : _a2.featuredPhoto;
    });
    provide("counter", counter);
    provide("toggleModal", toggleModal);
    provide("togglePopup", togglePopup);
    provide("product", productData);
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b, _c, _d, _e;
      const _component_Breadcrumbs = __nuxt_component_0$4;
      const _component_NuxtImg = __nuxt_component_1$3;
      const _component_AppIcon = __nuxt_component_1$4;
      const _component_AppButton = __nuxt_component_4;
      const _component_Select = __nuxt_component_4$1;
      const _component_CartButton = __nuxt_component_5;
      const _component_SideModal = __nuxt_component_5$1;
      const _component_InformationSampleIndexSample = __nuxt_component_7;
      const _component_InformationQuoteIndexQuote = __nuxt_component_8;
      const _component_LoginModal = __nuxt_component_9;
      const _component_RegisterModal = __nuxt_component_10;
      const _component_AddedToCart = __nuxt_component_11;
      _push(`<!--[--><div>`);
      _push(ssrRenderComponent(_component_Breadcrumbs, {
        className: "mb-8 !text-[#333] last:!text-[#165EF0]",
        links
      }, null, _parent));
      _push(`<div class="p-4 sm:p-6 lg:p-[30px] bg-white rounded-[10px] flex flex-col lg:flex-row gap-x-[38px] gap-y-10 lg:gap-y-0"><div class="flex-1 flex flex-col-reverse lg:flex-row gap-y-[14px] lg:gap-y-0 lg:gap-x-[14px]">`);
      if (!unref(isLoading)) {
        _push(`<div class="lg:w-[100px] flex flex-row lg:flex-col gap-x-3 lg:gap-x-0 lg:gap-y-3"><!--[-->`);
        ssrRenderList(unref(productData).gallery, (n) => {
          _push(ssrRenderComponent(_component_NuxtImg, {
            src: n,
            key: n,
            alt: n,
            width: "100px",
            height: "100",
            onClick: ($event) => imageUrl.value = n,
            class: "bg-gray-100 w-16 lg:w-[100px] object-cover h-16 lg:h-[100px] rounded-[5px]"
          }, null, _parent));
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isLoading)) {
        _push(`<div class="lg:w-[100px] flex flex-row lg:flex-col gap-x-3 lg:gap-x-0 lg:gap-y-3"><!--[-->`);
        ssrRenderList(4, (n) => {
          _push(`<div class="bg-gray-200 animate-pulse w-16 lg:w-[100px] object-cover h-16 lg:h-[100px] rounded-[5px]"></div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      if (!unref(isLoading)) {
        _push(`<div class="flex-1 relative">`);
        _push(ssrRenderComponent(_component_NuxtImg, {
          src: unref(imageUrl) || unref(productData).featuredPhoto,
          alt: "cover",
          width: "400",
          height: "300",
          class: "bg-gray-100 w-full h-[200px] lg:h-[300px] xl:h-[460px] rounded-[5px] object-cover"
        }, null, _parent));
        _push(`<span class="absolute h-5 sm:h-[30px] w-5 sm:w-[30px] rounded-full right-[10px] top-[10px] bg-white/70 flex items-center justify-center">`);
        _push(ssrRenderComponent(_component_AppIcon, {
          onClick: ($event) => handleLike(unref(productData).liked),
          icon: !unref(productData).liked ? "ph:heart" : "ph:heart-fill",
          class: "text-xs sm:text-sm md:text-base darks:text-white"
        }, null, _parent));
        _push(`</span></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isLoading)) {
        _push(`<div class="flex-1 relative"><div class="bg-gray-200 animate-pulse w-full h-[200px] lg:h-[300px] xl:h-[460px] rounded-[10px]"></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if (!unref(isLoading)) {
        _push(`<div class="lg:w-[550px]"><h1 class="font-bold text-lg sm:text-2xl lg:text-[32px] mb-3 lg:mb-6">${ssrInterpolate(unref(productData).name)}</h1><p class="text-[#444] text-xs lg:text-sm mb-6">${ssrInterpolate(unref(productData).description)}</p>`);
        if (!unref(productData).hidePrice) {
          _push(`<p class="text-xl lg:text-2xl font-[800] mb-6">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(((_a2 = unref(productData)) == null ? void 0 : _a2.price) || 0))} <span class="text-sm text-[#444] font-normal">/${ssrInterpolate(unref(productData).unit)}</span></p>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<p class="text-xs :text-sm mb-6"><span class="font-normal">Producer:</span><span class="font-bold">${ssrInterpolate((_c = (_b = unref(productData)) == null ? void 0 : _b.producer) == null ? void 0 : _c.title)}</span></p><div class="flex flex-col md:flex-row gap-x-[18px] gap-y-4 lg:gap-y-0 mb-6 justify-start"><div class="flex flex-col sm:flex-row gap-y-4 lg:gap-y-0 gap-x-4 items-center">`);
        if ((_d = unref(productData)) == null ? void 0 : _d.sampleAvailable) {
          _push(ssrRenderComponent(_component_AppButton, {
            onClick: ($event) => handleRequest("sample"),
            text: "Request sample",
            btnClass: "!rounded-[5px] !text-[#333] px-[15px] !py-[6px] text-xs sm:text-sm border border-[#DBDBDB]"
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(ssrRenderComponent(_component_AppButton, {
          onClick: ($event) => handleRequest("quote"),
          text: "Request quote",
          btnClass: "!rounded-[5px] !text-[#333] px-[15px] !py-[6px] text-xs sm:text-sm border border-[#DBDBDB] "
        }, null, _parent));
        _push(`</div>`);
        _push(ssrRenderComponent(_component_AppButton, {
          onClick: handleSave,
          icon: unref(isSaved) ? "tdesign:heart-filled" : "tdesign:heart",
          text: "Save for later",
          btnClass: "text-xs sm:text-sm !py-0 !px-0 w-full sm:!w-auto sm:!max-w-max items-center"
        }, null, _parent));
        _push(`</div><div class="mb-6"><h2 class="font-bold text-sm mb-2">Choose packaging</h2>`);
        _push(ssrRenderComponent(_component_Select, {
          modelValue: unref(selectedPackage),
          "onUpdate:modelValue": ($event) => isRef(selectedPackage) ? selectedPackage.value = $event : null,
          options: unref(packageOptions),
          placeholder: "Select a package",
          classInput: "min-w-[180px] w-full !bg-white !border-[#E7E7E7] !rounded-[4px] !text-[#333] !h-[50px] cursor-pointer bg-[#FCFCFC]"
        }, null, _parent));
        _push(`</div>`);
        if (!unref(productData).hidePrice) {
          _push(`<div class="flex flex-col lg:flex-row gap-y-4 lg:gap-y-0 gap-x-4"><div class="h-[50px] lg:flex-1">`);
          _push(ssrRenderComponent(_component_CartButton, null, null, _parent));
          _push(`</div><div class="flex flex-col sm:flex-row gap-y-4 lg:gap-y-0 gap-x-4">`);
          _push(ssrRenderComponent(_component_AppButton, {
            onClick: ($event) => handleCart("add"),
            text: "Add to cart",
            icon: "bytesize:cart",
            btnClass: "bg-primary-500  text-white !px-4 !sm:px-6 !py-[13px] text-xs sm:text-sm w-full lg:!w-[140px]"
          }, null, _parent));
          _push(ssrRenderComponent(_component_AppButton, {
            onClick: ($event) => handleCart("buy"),
            icon: "icon-park-outline:mall-bag",
            text: "Buy now",
            btnClass: "text-white  !px-[15px] !py-[13px] !normal-case bg-[#f90] flex w-full lg:!w-[140px]"
          }, null, _parent));
          _push(`</div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isLoading)) {
        _push(`<div class="lg:w-[550px]"><h1 class="font-bold text-lg sm:text-2xl lg:text-[32px] mb-3 lg:mb-6 bg-gray-200 w-[160px] p-[8px] rounded-full animate-pulse"></h1><p class="text-[#444] text-xs lg:text-sm mb-6 bg-gray-200 w-[260px] p-[8px] rounded-full animate-pulse"></p><p class="text-xl lg:text-2xl font-[800] mb-6 bg-gray-200 w-[160px] p-[6px] rounded-full animate-pulse"></p><p class="text-xs :text-sm mb-6"><span class="font-normal bg-gray-200 inline-flex w-[80px] p-[4px] rounded-full animate-pulse"></span><span class="font-bold bg-gray-200 w-[140px] inline-flex p-[4px] rounded-full animate-pulse ml-2"></span></p><div class="flex flex-col md:flex-row gap-x-[18px] gap-y-4 lg:gap-y-0 mb-6 justify-start items-center"><div class="flex flex-col sm:flex-row gap-y-4 lg:gap-y-0 gap-x-4 items-center">`);
        _push(ssrRenderComponent(_component_AppButton, {
          text: "",
          btnClass: "!rounded-[5px] !text-[#333] px-[15px] !py-[6px] text-xs sm:text-sm border border-[#DBDBDB] !bg-gray-200 w-[160px] !h-[38px] rounded-full animate-pulse"
        }, null, _parent));
        _push(ssrRenderComponent(_component_AppButton, {
          text: "",
          btnClass: "!rounded-[5px] !text-[#333] px-[15px] !py-[6px] text-xs sm:text-sm border border-[#DBDBDB] !bg-gray-200 w-[160px] !h-[38px] rounded-full animate-pulse"
        }, null, _parent));
        _push(`</div><p class="text-xl lg:text-2xl font-[800] bg-gray-200 w-[160px] p-[6px] rounded-full animate-pulse"></p></div><div class="mb-6"><p class="text-xl lg:text-2xl font-[800] mb-6 bg-gray-200 w-[160px] p-[6px] rounded-full animate-pulse"></p>`);
        _push(ssrRenderComponent(_component_AppButton, {
          text: "",
          btnClass: "!rounded-[5px] !text-[#333] px-[15px] !py-[6px] text-xs sm:text-sm border border-[#DBDBDB] !bg-gray-200 w-[260px] !h-[50px] rounded-full animate-pulse"
        }, null, _parent));
        _push(`</div><div class="flex flex-col lg:flex-row gap-y-4 lg:gap-y-0 gap-x-4">`);
        _push(ssrRenderComponent(_component_AppButton, {
          text: "",
          btnClass: "!rounded-[5px] !text-[#333] px-[15px] !py-[6px] text-xs sm:text-sm border border-[#DBDBDB] !bg-gray-200 w-[160px] !h-[50px] rounded-full animate-pulse"
        }, null, _parent));
        _push(`<div class="flex flex-col sm:flex-row gap-y-4 lg:gap-y-0 gap-x-4">`);
        _push(ssrRenderComponent(_component_AppButton, {
          text: "",
          btnClass: "!rounded-[5px] !text-[#333] px-[15px] !py-[6px] text-xs sm:text-sm border border-[#DBDBDB] !bg-gray-200 w-[160px] !h-[50px] rounded-full animate-pulse"
        }, null, _parent));
        _push(ssrRenderComponent(_component_AppButton, {
          text: "",
          btnClass: "!rounded-[5px] !text-[#333] px-[15px] !py-[6px] text-xs sm:text-sm border border-[#DBDBDB] !bg-gray-200 w-[160px] !h-[50px] rounded-full animate-pulse"
        }, null, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      if (unref(isOpen)) {
        _push(ssrRenderComponent(_component_SideModal, {
          isOpen: unref(isOpen),
          onTogglePopup: ($event) => isOpen.value = false
        }, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="h-full w-full bg-white rounded-lg p-6 lg:p-10"${_scopeId}>`);
              if (unref(requestType) == "sample") {
                _push2(ssrRenderComponent(_component_InformationSampleIndexSample, {
                  onTogglePopup: ($event) => isOpen.value = false
                }, null, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              if (unref(requestType) == "quote") {
                _push2(ssrRenderComponent(_component_InformationQuoteIndexQuote, {
                  onTogglePopup: ($event) => isOpen.value = false
                }, null, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "h-full w-full bg-white rounded-lg p-6 lg:p-10" }, [
                  unref(requestType) == "sample" ? (openBlock(), createBlock(_component_InformationSampleIndexSample, {
                    key: 0,
                    onTogglePopup: ($event) => isOpen.value = false
                  }, null, 8, ["onTogglePopup"])) : createCommentVNode("", true),
                  unref(requestType) == "quote" ? (openBlock(), createBlock(_component_InformationQuoteIndexQuote, {
                    key: 1,
                    onTogglePopup: ($event) => isOpen.value = false
                  }, null, 8, ["onTogglePopup"])) : createCommentVNode("", true)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(isAuthOpen) && unref(active) == "signin") {
        _push(ssrRenderComponent(_component_LoginModal, {
          showSignup: true,
          isOpen: unref(isAuthOpen),
          onClose: handleclose
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(isAuthOpen) && unref(active) == "signup") {
        _push(ssrRenderComponent(_component_RegisterModal, {
          showSignup: true,
          isOpen: unref(isAuthOpen),
          onClose: handleclose
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(isAdded)) {
        _push(ssrRenderComponent(_component_AddedToCart, {
          selectedPackage: unref(mypackage).package,
          onClose: ($event) => isAdded.value = false,
          totalAmount: (_e = unref(mypackage)) == null ? void 0 : _e.amount,
          quantity: unref(counter),
          name: unref(productData).name,
          hidePrice: unref(productData).hidePrice
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/product/Detail.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_0$1 = _sfc_main$4;
const _sfc_main$3 = {
  __name: "index",
  __ssrInlineRender: true,
  props: ["detail", "keydata"],
  setup(__props) {
    const documentType = ref("");
    const documentList = computed(() => {
      return detail.filter(
        (i) => i.category.toLowerCase().includes(documentType.value.toLowerCase())
      );
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g;
      if (__props.keydata !== "documents") {
        _push(`<div${ssrRenderAttrs(_attrs)}>`);
        if (((_a = __props.detail) == null ? void 0 : _a.propertyItems) && ((_b = __props.detail) == null ? void 0 : _b.propertyItems.length)) {
          _push(`<div class="grid grid-cols-2 gap-x-[75px] gap-y-6"><!--[-->`);
          ssrRenderList((_c = __props.detail) == null ? void 0 : _c.propertyItems, (n) => {
            _push(`<div class="mb-6">`);
            if (n.property) {
              _push(`<p class="text-[#A4A4A4] text-xs capitalize mb-1">${ssrInterpolate(n.property.name)}</p>`);
            } else {
              _push(`<!---->`);
            }
            _push(`<!--[-->`);
            ssrRenderList(n.propertyValue, (sub, i) => {
              _push(`<p class="text-sm font-medium capitalize">${ssrInterpolate(sub)}</p>`);
            });
            _push(`<!--]--></div>`);
          });
          _push(`<!--]-->`);
          if ((_d = __props.detail) == null ? void 0 : _d.subSection) {
            _push(`<div><!--[-->`);
            ssrRenderList((_e = __props.detail) == null ? void 0 : _e.subSection, (n, idx) => {
              _push(`<div class=""><p class="mb-4 capitalize">${ssrInterpolate(n.subSectionName)}</p><div class="mb-4 description">${n.description}</div></div>`);
            });
            _push(`<!--]--></div>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        if (!((_f = __props.detail) == null ? void 0 : _f.propertyItems) || !((_g = __props.detail) == null ? void 0 : _g.propertyItems.length)) {
          _push(`<div class="text-[#A4A4A4] text-xs py-4 opacity-50"> No information available </div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid grid-cols-1 gap-x-[75px] gap-y-6" }, _attrs))}><!--[-->`);
        ssrRenderList(unref(documentList), (n, id) => {
          _push(`<div class="flex jus items-center"><div class="flex gap-x-2"><p class="text-sm font-medium">${ssrInterpolate(n.fileName)}</p><p class="text-[#A4A4A4] text-xs">${ssrInterpolate(parseInt(n.fileSize / 1e3))}kb </p></div><div class="flex items-center gap-x-5 text-sm"><p class="flex-1 whitespace-nowrap">${ssrInterpolate(n.category)}</p><span class="text-gray-200 text-3xl font-light">| </span><div class="flex items-center"><a${ssrRenderAttr("href", n.documentUrl)}${ssrRenderAttr("download", n.fileName)}><span class="border border-gray-300 rounded-full h-8 w-8 flex items-center justify-center"><i class="uil uil-import"></i></span></a></div></div></div>`);
        });
        _push(`<!--]-->`);
        if (!unref(documentList) || !_ctx.documentLists.length) {
          _push(`<div class="text-[#A4A4A4] text-xs py-4 opacity-50"> No information available </div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      }
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/product/Info/index.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "Information",
  __ssrInlineRender: true,
  setup(__props) {
    const store = useProductStore();
    const { productData } = storeToRefs(store);
    const tabs = [
      {
        title: "Technical details & test data",
        key: "technical"
      },
      {
        title: "Properties",
        key: "property"
      },
      {
        title: "Regulatory & Compliance",
        key: "compliance"
      },
      {
        title: "Documents",
        key: "documents"
      }
      //   {
      //     title: "Table",
      //     key: "table",
      //   },
    ];
    function handleProp(value) {
      var _a, _b;
      return (_b = (_a = productData == null ? void 0 : productData.value) == null ? void 0 : _a.propertyItems) == null ? void 0 : _b.propertyItems[value];
    }
    const active = ref("technical");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ProductInfo = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white rounded-[10px]" }, _attrs))}><div class="px-5 pt-5 flex gap-x-[30px] items-center border-b border-[#f3f3f3] w-full overflow-x-auto no-scrollbar"><!--[-->`);
      ssrRenderList(tabs, (n) => {
        _push(`<button class="${ssrRenderClass(`${unref(active) === n.key ? "text-[#165EF0] border-[#165EF0]" : "border-transparent"} text-xs pb-[19px] border-b-2 block whitespace-nowrap`)}">${ssrInterpolate(n.title)}</button>`);
      });
      _push(`<!--]--></div><div class="p-5 max-w-[700px]">`);
      _push(ssrRenderComponent(_component_ProductInfo, {
        detail: handleProp(unref(active)),
        keydata: unref(active)
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/product/Information.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "Similar",
  __ssrInlineRender: true,
  props: {
    title: {
      type: String,
      default: "Hot deals"
    }
  },
  setup(__props) {
    useRouter();
    const route = useRouter();
    const store = useProductStore();
    const { productData, productsData, loading } = storeToRefs(store);
    const queryParams = reactive({
      MarketApplication: "",
      Status: "",
      MarketId: "",
      MarketSubApplication: "",
      PageSize: 10,
      PageNumber: 1
    });
    function getAllProducts() {
      store.setLoader(true);
      getProducts({
        ...queryParams,
        applications: productData == null ? void 0 : productData.value.marketApplications,
        MarketSubApplication: productData == null ? void 0 : productData.value.marketSubapplications
      }).then((res) => {
        if (res.status === 200) {
          store.setProducts(res.data);
          store.setLoader(false);
        }
      }).catch(() => {
        setLoader(false);
      });
    }
    watch(
      () => [productData.value, route],
      () => {
        getAllProducts();
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1$4;
      const _component_NuxtImg = __nuxt_component_1$3;
      const _component_ProductSkelenton = __nuxt_component_2$5;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "" }, _attrs))}><div class="lg:mb-[30px]"><div class="flex justify-between items-center mb-6"><h2 class="text-xs sm:text-base lg:text-xl font-bold text-[#222] darks:text-white"> Similar products you might like </h2></div>`);
      if (!unref(loading)) {
        _push(`<div class="flex gap-x-4 md:gap-x-6 no-scrollbar hover:scrollbar overflow-x-auto pb-6"><!--[-->`);
        ssrRenderList(unref(productsData).slice(0, 10), (slide) => {
          _push(`<div class="w-full cursor-pointer min-w-[140px] sm:min-w-[160px] lg:min-w-[250px] max-w-[250px] bg-white darks:bg-gray-800 rounded-[10px] shadow-[0px_2px_8px_0px_rgba(0,0,0,0.05)] overflow-hidden"><div class="w-full h-[90px] sm:h-[120px] lg:h-[140px] xl:h-[160px] bg-gray-200 bg-cover bg-center relative"><span class="absolute h-5 sm:h-[30px] w-5 sm:w-[30px] rounded-full right-[10px] top-[10px] bg-white/70 flex items-center justify-center">`);
          _push(ssrRenderComponent(_component_AppIcon, {
            icon: !slide.liked ? "ph:heart" : "ph:heart-fill",
            class: "text-xs sm:text-sm md:text-base darks:text-white"
          }, null, _parent));
          _push(`</span>`);
          _push(ssrRenderComponent(_component_NuxtImg, {
            src: slide.converPhoto,
            alt: "image",
            width: "276",
            height: "160",
            class: "w-full h-full object-cover",
            fit: "cover",
            loading: "lazy"
          }, null, _parent));
          _push(`</div><div class="w-full py-3 md:py-5 px-3 xl:px-5"><span class="block mb-1 font-medium truncate max-w-max text-[12px] sm:text-sm xl:text-base darks:text-white leading-tight">${ssrInterpolate(slide.title)}</span><span class="block mb-[14px] sm:mb-4 text-[10px] sm:text-[12px] xl:text-sm truncate max-w-max text-[#666] darks:text-white/80 leading-tight">${ssrInterpolate(slide.manufacturer)}</span><div class="flex justify-between items-start md:items-center">`);
          if (slide.hidePrice) {
            _push(`<span class="font-semibold text-[12px] sm:text-sm xl:text-base text-[#2176FF] leading-tight">Request Quote</span>`);
          } else {
            _push(`<span class="text-base flex flex-col md:flex-row gap-x-1 md:items-center"><span class="gap-x-1 flex items-center">`);
            if (slide.oldprice) {
              _push(`<span class="line-through text-[#666] darks:text-white/80 text-[12px] sm:text-sm xl:text-base font-semibold leading-tight">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(slide.oldprice))}/${ssrInterpolate(slide.unit)}</span>`);
            } else {
              _push(`<!---->`);
            }
            _push(`<span class="font-bold ml-[2px] text-[12px] sm:text-sm xl:text-base text-[#333] darks:text-white leading-tight">${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(slide.price))}/${ssrInterpolate(slide.unit)}</span></span></span>`);
          }
          _push(`</div></div></div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(loading)) {
        _push(`<div class="flex xl:grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-y-8 gap-x-4 md:gap-x-6 no-scrollbar hover:scrollbar pb-6"><!--[-->`);
        ssrRenderList(5, (n) => {
          _push(`<div>`);
          _push(ssrRenderComponent(_component_ProductSkelenton, null, null, _parent));
          _push(`</div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/product/Similar.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$1;
const _sfc_main = {
  __name: "[id]",
  __ssrInlineRender: true,
  setup(__props) {
    useProductStore();
    const route = useRoute();
    route.params;
    const loading = ref(true);
    provide("isLoading", loading);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ProductDetail = __nuxt_component_0$1;
      const _component_ProductInformation = __nuxt_component_1;
      const _component_ProductSimilar = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="flex flex-col w-full container gap-y-5 py-10"><div>`);
      _push(ssrRenderComponent(_component_ProductDetail, null, null, _parent));
      _push(`</div><div class="mb-6">`);
      _push(ssrRenderComponent(_component_ProductInformation, null, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_component_ProductSimilar, null, null, _parent));
      _push(`</div><div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/product/[name]/[[category]]/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_id_--nlZSAcW.mjs.map
