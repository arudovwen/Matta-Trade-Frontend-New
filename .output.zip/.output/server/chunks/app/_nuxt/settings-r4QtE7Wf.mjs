import { _ as __nuxt_component_0$2 } from './index-4NCxcAqd.mjs';
import { _ as __nuxt_component_1$1 } from './AppIcon-D3CPABPP.mjs';
import { useSSRContext, reactive, ref, mergeProps, unref, inject, withCtx, createVNode, openBlock, createBlock, createCommentVNode, withModifiers, withDirectives, vModelText, Fragment, renderList, toDisplayString, provide } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderClass, ssrRenderList, ssrIncludeBooleanAttr, ssrRenderDynamicModel } from 'vue/server-renderer';
import { _ as __nuxt_component_0$1 } from './IndexModal-vEF7RYpX.mjs';
import { EyeIcon, EyeSlashIcon } from '@heroicons/vue/24/outline';
import useVuelidate from '@vuelidate/core';
import { helpers, required, minLength, maxLength, numeric } from '@vuelidate/validators';
import { v as verifyPin } from './walletservice-pesZWM8C.mjs';
import { toast } from 'vue3-toastify';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import { C as CurrencyInput } from './CurrencyInput-krSh-4ij.mjs';
import { useRoute } from 'vue-router';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '../server.mjs';
import 'unhead';
import '@unhead/shared';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';
import '@iconify/vue';
import '@heroicons/vue/24/solid';
import '@headlessui/vue';
import 'vue-currency-input';

const _sfc_main$4 = {
  __name: "CreatePin",
  __ssrInlineRender: true,
  props: ["details"],
  emits: ["close"],
  setup(__props, { emit: __emit }) {
    var _a;
    const props = __props;
    const form = reactive({
      pin: "",
      confirmPin: "",
      walletId: (_a = props == null ? void 0 : props.details) == null ? void 0 : _a.walletId
    });
    const form1 = reactive({
      otp: null
    });
    const isLoading = ref(false);
    const step = ref(1);
    const samePin = (value) => value === form.pin;
    const rules = {
      pin: {
        required: helpers.withMessage("Pin field cannot be empty", required),
        minLength: minLength(4),
        maxLength: maxLength(4),
        numeric
      },
      confirmPin: {
        samePin: helpers.withMessage("Pins must match", samePin)
      },
      walletId: {
        required
      }
    };
    const rule = {
      otp: {
        required,
        minLength: minLength(6),
        maxLength: maxLength(6),
        numeric
      }
    };
    const v$ = useVuelidate(rules, form);
    const v1$ = useVuelidate(rule, form1);
    const isShowingPasword = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "min-w-[400px] py-10 px-6" }, _attrs))} data-v-be3c31d9><span class="block text-2xl font-medium text-center mb-2" data-v-be3c31d9>${ssrInterpolate(step.value === 1 ? "Create transaction pin" : "Enter OTP code")}</span>`);
      if (step.value === 1) {
        _push(`<form data-v-be3c31d9><div class="mb-6" data-v-be3c31d9><label class="mb-2 font-normal text-xs block text-matta-black" data-v-be3c31d9>New pin</label><div class="relative flex items-center" data-v-be3c31d9><input${ssrRenderAttr("value", unref(v$).pin.$model)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).pin.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Enter new pin" data-v-be3c31d9>`);
        if (!isShowingPasword.value) {
          _push(ssrRenderComponent(unref(EyeIcon), {
            onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
            class: "w-4 h-4 absolute cursor-pointer right-6"
          }, null, _parent));
        } else {
          _push(ssrRenderComponent(unref(EyeSlashIcon), {
            onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
            class: "w-4 h-4 absolute cursor-pointer right-6"
          }, null, _parent));
        }
        _push(`</div><!--[-->`);
        ssrRenderList(unref(v$).pin.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-be3c31d9><div class="error-msg text-error text-xs font-semibold" data-v-be3c31d9>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="mb-6" data-v-be3c31d9><label class="mb-2 font-normal text-xs block text-matta-black" data-v-be3c31d9>Confirm pin</label><div class="relative flex items-center" data-v-be3c31d9><input${ssrRenderAttr("value", unref(v$).confirmPin.$model)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).confirmPin.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Confirm your pin" data-v-be3c31d9>`);
        if (!isShowingPasword.value) {
          _push(ssrRenderComponent(unref(EyeIcon), {
            onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
            class: "w-4 h-4 absolute cursor-pointer right-6"
          }, null, _parent));
        } else {
          _push(ssrRenderComponent(unref(EyeSlashIcon), {
            onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
            class: "w-4 h-4 absolute cursor-pointer right-6"
          }, null, _parent));
        }
        _push(`</div><!--[-->`);
        ssrRenderList(unref(v$).confirmPin.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-be3c31d9><div class="error-msg text-error text-xs font-semibold" data-v-be3c31d9>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="" data-v-be3c31d9><button type="submit"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} class="border text-[13px] mb-4 border-primary- uppercase text-white lg:min-w-[120px] w-full bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11" data-v-be3c31d9><span data-v-be3c31d9>`);
        if (isLoading.value) {
          _push(`<span class="flex gap-x-4 justify-center items-center" data-v-be3c31d9><span data-v-be3c31d9> Processing...</span>`);
          if (isLoading.value) {
            _push(`<i class="fa fa-spinner fa-spin text-white" aria-hidden="true" data-v-be3c31d9></i>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</span>`);
        } else {
          _push(`<span data-v-be3c31d9>Submit</span>`);
        }
        _push(`</span></button></div></form>`);
      } else {
        _push(`<!---->`);
      }
      if (step.value === 2) {
        _push(`<form data-v-be3c31d9><div class="mb-6" data-v-be3c31d9><label class="mb-2 font-normal text-xs block text-matta-black" data-v-be3c31d9>Otp code</label><div class="relative flex items-center" data-v-be3c31d9><input${ssrRenderAttr("value", unref(v1$).otp.$model)} class="${ssrRenderClass([{ "border-red-500 ": unref(v1$).otp.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Enter otp code" data-v-be3c31d9></div><!--[-->`);
        ssrRenderList(unref(v1$).otp.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-be3c31d9><div class="error-msg text-error text-xs font-semibold" data-v-be3c31d9>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div class="" data-v-be3c31d9><button type="submit"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} class="border text-[13px] mb-4 border-primary- uppercase text-white lg:min-w-[120px] w-full bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11" data-v-be3c31d9><span data-v-be3c31d9>`);
        if (isLoading.value) {
          _push(`<span class="flex gap-x-4 justify-center items-center" data-v-be3c31d9><span data-v-be3c31d9> Processing...</span>`);
          if (isLoading.value) {
            _push(`<i class="fa fa-spinner fa-spin text-white" aria-hidden="true" data-v-be3c31d9></i>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</span>`);
        } else {
          _push(`<span data-v-be3c31d9>Create pin</span>`);
        }
        _push(`</span></button></div></form>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/wallet/modals/CreatePin.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const CreatePin = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-be3c31d9"]]);
const _sfc_main$3 = {
  __name: "transactionPin",
  __ssrInlineRender: true,
  setup(__props) {
    const isOpen = ref(false);
    const details = inject("details");
    const isCreatePin = ref(false);
    const form = reactive({
      currentPin: "",
      pin: "",
      confirmPin: "",
      walletId: ""
    });
    const form1 = reactive({
      otp: null
    });
    const rule = {
      otp: {
        required,
        minLength: minLength(6),
        maxLength: maxLength(6),
        numeric
      }
    };
    const v1$ = useVuelidate(rule, form1);
    const isPageLoading = inject("isPageLoading");
    const isLoading = inject("isLoading");
    const isVerify = ref(false);
    const validPassword = (value) => value === form.pin;
    const rules = {
      currentPin: {
        required,
        numeric,
        minLength: minLength(4),
        maxLength: maxLength(4)
      },
      walletId: { required },
      pin: {
        required: helpers.withMessage("Pin field cannot be empty", required),
        minLength: minLength(4),
        maxLength: maxLength(4),
        numeric
      },
      confirmPin: {
        validPassword: helpers.withMessage("Pin is invalid", validPassword)
      }
    };
    const v$ = useVuelidate(rules, form);
    const isShowingPasword = ref(false);
    async function verifyWalletPin() {
      form.walletId = details.value.walletId;
      const validity = await v1$.value.$validate();
      if (!validity)
        return;
      verifyPin(form1.otp).then((res) => {
        if (res.status == 200) {
          toast.info("Pin changed successfully");
          isOpen.value = isVerify.value = isLoading.value = false;
          v$.value.$reset();
          v1$.value.$reset();
          form1.otp = form.currentPin = form.pin = form.confirmPin = "";
        }
      }).catch((err) => {
        isLoading.value = false;
        toast.error(err.response.data.message || err.response.data.Message);
      });
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_AppIcon = __nuxt_component_1$1;
      _push(`<!--[--><div class="grid gap-8 lg:grid-cols-2" data-v-0b0f67a8><div data-v-0b0f67a8><span class="block text-base font-medium mb-1" data-v-0b0f67a8>Transaction pin</span><span class="block text-sm" data-v-0b0f67a8>Manage your transaction pin</span></div><div class="max-w-[400px]" data-v-0b0f67a8><form data-v-0b0f67a8><div class="mb-6" data-v-0b0f67a8><label class="mb-2 font-normal text-xs block text-matta-black" data-v-0b0f67a8>Current pin</label><div class="relative flex items-center" data-v-0b0f67a8><input${ssrRenderDynamicModel(!isShowingPasword.value ? "password" : "text", unref(v$).currentPin.$model, null)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).currentPin.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Enter current pin" autocomplete="off"${ssrRenderAttr("type", !isShowingPasword.value ? "password" : "text")} maxlength="4" data-v-0b0f67a8>`);
      if (!isShowingPasword.value) {
        _push(ssrRenderComponent(unref(EyeIcon), {
          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      } else {
        _push(ssrRenderComponent(unref(EyeSlashIcon), {
          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      }
      _push(`</div><!--[-->`);
      ssrRenderList(unref(v$).currentPin.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-0b0f67a8><div class="error-msg text-error text-xs font-semibold" data-v-0b0f67a8>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6" data-v-0b0f67a8><label class="mb-2 font-normal text-xs block text-matta-black" data-v-0b0f67a8>New pin</label><div class="relative flex items-center" data-v-0b0f67a8><input${ssrRenderDynamicModel(!isShowingPasword.value ? "password" : "text", unref(v$).pin.$model, null)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).pin.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Enter new pin" autocomplete="off"${ssrRenderAttr("type", !isShowingPasword.value ? "password" : "text")} maxlength="4" data-v-0b0f67a8>`);
      if (!isShowingPasword.value) {
        _push(ssrRenderComponent(unref(EyeIcon), {
          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      } else {
        _push(ssrRenderComponent(unref(EyeSlashIcon), {
          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      }
      _push(`</div><!--[-->`);
      ssrRenderList(unref(v$).pin.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-0b0f67a8><div class="error-msg text-error text-xs font-semibold" data-v-0b0f67a8>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6" data-v-0b0f67a8><label class="mb-2 font-normal text-xs block text-matta-black" data-v-0b0f67a8>Confirm pin</label><div class="relative flex items-center" data-v-0b0f67a8><input${ssrRenderDynamicModel(!isShowingPasword.value ? "password" : "text", unref(v$).confirmPin.$model, null)} class="${ssrRenderClass([{ "border-red-500 ": unref(v$).confirmPin.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Confirm your pin" autocomplete="off"${ssrRenderAttr("type", !isShowingPasword.value ? "password" : "text")} maxlength="4" data-v-0b0f67a8>`);
      if (!isShowingPasword.value) {
        _push(ssrRenderComponent(unref(EyeIcon), {
          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      } else {
        _push(ssrRenderComponent(unref(EyeSlashIcon), {
          onClick: ($event) => isShowingPasword.value = !isShowingPasword.value,
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      }
      _push(`</div><!--[-->`);
      ssrRenderList(unref(v$).confirmPin.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-0b0f67a8><div class="error-msg text-error text-xs font-semibold" data-v-0b0f67a8>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="" data-v-0b0f67a8><button type="submit"${ssrIncludeBooleanAttr(unref(isLoading)) ? " disabled" : ""} class="border text-[13px] mb-4 border-primary- uppercase text-white lg:min-w-[120px] w-full bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11" data-v-0b0f67a8><span data-v-0b0f67a8>`);
      if (unref(isLoading)) {
        _push(`<span class="flex gap-x-4 justify-center items-center" data-v-0b0f67a8><span data-v-0b0f67a8> Processing...</span>`);
        if (unref(isLoading)) {
          _push(`<i class="fa fa-spinner fa-spin text-white" aria-hidden="true" data-v-0b0f67a8></i>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</span>`);
      } else {
        _push(`<span data-v-0b0f67a8>Change pin</span>`);
      }
      _push(`</span></button></div>`);
      if (!((_a = unref(details)) == null ? void 0 : _a.pinSet) && !unref(isPageLoading)) {
        _push(`<span class="block text-sm text-center" data-v-0b0f67a8>Don&#39;t have a transaction pin? <button type="button" class="text-blue-700" data-v-0b0f67a8> Create pin </button></span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</form></div></div>`);
      _push(ssrRenderComponent(unref(__nuxt_component_0$1), {
        isOpen: isOpen.value,
        onTogglePopup: ($event) => isCreatePin.value = isOpen.value = false
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="max-w-[500px]" data-v-0b0f67a8${_scopeId}>`);
            if (isCreatePin.value) {
              _push2(ssrRenderComponent(unref(CreatePin), {
                onClose: ($event) => isCreatePin.value = isOpen.value = false,
                details: unref(details)
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (isVerify.value) {
              _push2(`<form class="w-full p-6" data-v-0b0f67a8${_scopeId}><legend class="text-xl font-medium text-center mb-5 block" data-v-0b0f67a8${_scopeId}> Enter OTP code </legend><div class="mb-6" data-v-0b0f67a8${_scopeId}><label class="mb-2 font-normal text-xs block text-matta-black" data-v-0b0f67a8${_scopeId}>Otp code</label><div class="relative flex items-center" data-v-0b0f67a8${_scopeId}><input${ssrRenderAttr("value", unref(v1$).otp.$model)} class="${ssrRenderClass([{ "border-red-500 ": unref(v1$).otp.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" placeholder="Enter otp code" data-v-0b0f67a8${_scopeId}></div><!--[-->`);
              ssrRenderList(unref(v1$).otp.$errors, (error) => {
                _push2(`<div class="text-red-500 mt-1" data-v-0b0f67a8${_scopeId}><div class="error-msg text-error text-xs font-semibold" data-v-0b0f67a8${_scopeId}>${ssrInterpolate(error.$message)}</div></div>`);
              });
              _push2(`<!--]--></div><div class="" data-v-0b0f67a8${_scopeId}><button type="submit"${ssrIncludeBooleanAttr(unref(isLoading)) ? " disabled" : ""} class="border text-[13px] mb-4 border-primary- uppercase text-white lg:min-w-[120px] w-full bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11" data-v-0b0f67a8${_scopeId}><span data-v-0b0f67a8${_scopeId}>`);
              if (unref(isLoading)) {
                _push2(`<span class="flex gap-x-4 justify-center items-center" data-v-0b0f67a8${_scopeId}><span data-v-0b0f67a8${_scopeId}> Processing...</span>`);
                if (unref(isLoading)) {
                  _push2(`<i class="fa fa-spinner fa-spin text-white" aria-hidden="true" data-v-0b0f67a8${_scopeId}></i>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</span>`);
              } else {
                _push2(`<span data-v-0b0f67a8${_scopeId}>Confirm</span>`);
              }
              _push2(`</span></button></div></form>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<span class="cursor-pointer" data-v-0b0f67a8${_scopeId}>`);
            _push2(ssrRenderComponent(_component_AppIcon, {
              icon: "heroicons-solid:x",
              class: "w-4 h-4 absolute top-4 right-3 text-matta-black z-10"
            }, null, _parent2, _scopeId));
            _push2(`</span></div>`);
          } else {
            return [
              createVNode("div", { class: "max-w-[500px]" }, [
                isCreatePin.value ? (openBlock(), createBlock(unref(CreatePin), {
                  key: 0,
                  onClose: ($event) => isCreatePin.value = isOpen.value = false,
                  details: unref(details)
                }, null, 8, ["onClose", "details"])) : createCommentVNode("", true),
                isVerify.value ? (openBlock(), createBlock("form", {
                  key: 1,
                  onSubmit: withModifiers(verifyWalletPin, ["prevent"]),
                  class: "w-full p-6"
                }, [
                  createVNode("legend", { class: "text-xl font-medium text-center mb-5 block" }, " Enter OTP code "),
                  createVNode("div", { class: "mb-6" }, [
                    createVNode("label", { class: "mb-2 font-normal text-xs block text-matta-black" }, "Otp code"),
                    createVNode("div", { class: "relative flex items-center" }, [
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => unref(v1$).otp.$model = $event,
                        class: [{ "border-red-500 ": unref(v1$).otp.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"],
                        placeholder: "Enter otp code"
                      }, null, 10, ["onUpdate:modelValue"]), [
                        [vModelText, unref(v1$).otp.$model]
                      ])
                    ]),
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(v1$).otp.$errors, (error) => {
                      return openBlock(), createBlock("div", {
                        class: "text-red-500 mt-1",
                        key: error.$uid
                      }, [
                        createVNode("div", { class: "error-msg text-error text-xs font-semibold" }, toDisplayString(error.$message), 1)
                      ]);
                    }), 128))
                  ]),
                  createVNode("div", { class: "" }, [
                    createVNode("button", {
                      type: "submit",
                      disabled: unref(isLoading),
                      class: "border text-[13px] mb-4 border-primary- uppercase text-white lg:min-w-[120px] w-full bg-primary-500 rounded-lg px-6 py-2 hover:bg-primary/80 h-11"
                    }, [
                      createVNode("span", null, [
                        unref(isLoading) ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "flex gap-x-4 justify-center items-center"
                        }, [
                          createVNode("span", null, " Processing..."),
                          unref(isLoading) ? (openBlock(), createBlock("i", {
                            key: 0,
                            class: "fa fa-spinner fa-spin text-white",
                            "aria-hidden": "true"
                          })) : createCommentVNode("", true)
                        ])) : (openBlock(), createBlock("span", { key: 1 }, "Confirm"))
                      ])
                    ], 8, ["disabled"])
                  ])
                ], 32)) : createCommentVNode("", true),
                createVNode("span", {
                  class: "cursor-pointer",
                  onClick: ($event) => isCreatePin.value = isOpen.value = false
                }, [
                  createVNode(_component_AppIcon, {
                    icon: "heroicons-solid:x",
                    class: "w-4 h-4 absolute top-4 right-3 text-matta-black z-10"
                  })
                ], 8, ["onClick"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/wallet/settings/transactionPin.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-0b0f67a8"]]);
const _sfc_main$2 = {
  __name: "transactionLimit",
  __ssrInlineRender: true,
  setup(__props) {
    inject("details");
    const form = reactive({
      amount: 0
    });
    const form1 = reactive({
      upperLimit: 0
    });
    const rule = {
      amount: {
        required,
        numeric
      }
    };
    const rule1 = {
      upperLimit: {
        required,
        numeric
      }
    };
    const v$ = useVuelidate(rule, form);
    const v1$ = useVuelidate(rule1, form1);
    const isLoading = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid gap-8 lg:grid-cols-2" }, _attrs))} data-v-3e38d67e><div data-v-3e38d67e><span class="block text-base font-medium mb-1" data-v-3e38d67e>Transaction limits</span><span class="block text-sm" data-v-3e38d67e>Manage your transaction limits for deposits and withdrawals</span></div><div data-v-3e38d67e><div class="max-w-[400px] mb-10" data-v-3e38d67e><h5 class="text-[13px] font-medium mb-1" data-v-3e38d67e>Lower Limit</h5><p class="text-xs mb-6" data-v-3e38d67e> Get notified when your spend account balance drops below your threshold. </p><div class="flex gap-x-2 items-center mb-5" data-v-3e38d67e>`);
      _push(ssrRenderComponent(unref(CurrencyInput), {
        modelValue: unref(v$).amount.$model,
        "onUpdate:modelValue": ($event) => unref(v$).amount.$model = $event,
        class: "rounded-lg px-5 text-sm py-3 h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20 flex-1",
        placeholder: "",
        options: {
          currency: "ngn",
          currencyDisplay: "narrowSymbol"
        }
      }, null, _parent));
      _push(`<button type="button"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} class="px-6 py-3 rounded-md bg-primary-500 text-white hover:bg-primary/80 active:scale-95" data-v-3e38d67e> Set </button></div><!--[-->`);
      ssrRenderList(unref(v$).amount.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-3e38d67e><div class="error-msg text-error text-xs font-semibold" data-v-3e38d67e>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="max-w-[400px]" data-v-3e38d67e><h5 class="text-[13px] font-medium mb-1" data-v-3e38d67e>Upper Limit</h5><p class="text-xs mb-6" data-v-3e38d67e> To further secure your transactions, activate a 2FA (two-factor authentication) when a transaction is above your set upper limit. </p><div class="flex gap-x-2 items-center mb-5" data-v-3e38d67e>`);
      _push(ssrRenderComponent(unref(CurrencyInput), {
        modelValue: unref(v1$).upperLimit.$model,
        "onUpdate:modelValue": ($event) => unref(v1$).upperLimit.$model = $event,
        class: "rounded-lg px-5 text-sm py-3 h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
        placeholder: "",
        options: {
          currency: "ngn",
          currencyDisplay: "narrowSymbol"
        }
      }, null, _parent));
      _push(`<button type="button"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} class="px-6 py-3 rounded-md bg-primary-500 text-white hover:bg-primary/80 active:scale-95 disabled:opacity:60" data-v-3e38d67e> Set </button></div><!--[-->`);
      ssrRenderList(unref(v1$).upperLimit.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-3e38d67e><div class="error-msg text-error text-xs font-semibold" data-v-3e38d67e>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/wallet/settings/transactionLimit.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-3e38d67e"]]);
const _sfc_main$1 = {
  __name: "SettingsPage",
  __ssrInlineRender: true,
  setup(__props) {
    const details = ref(null);
    useRoute();
    const isPageLoading = ref(true);
    const isLoading = ref(false);
    provide("details", details);
    provide("isLoading", isLoading);
    provide("isPageLoading", isPageLoading);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Breadcrumbs = __nuxt_component_0$2;
      const _component_SupplierWalletSettingsTransactionPin = __nuxt_component_1;
      const _component_SupplierWalletSettingsTransactionLimit = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "gap-y-2 flex flex-col" }, _attrs))} data-v-08187f66><div class="p-6 lg:p-8 bg-white rounded-lg" data-v-08187f66><div class="mb-12" data-v-08187f66>`);
      _push(ssrRenderComponent(_component_Breadcrumbs, null, null, _parent));
      _push(`</div><div class="grid justify-between items-end mb-8" data-v-08187f66><div data-v-08187f66><h1 class="text-3xl lg:text-[48px] lg:leading-[56px] text-matta-black col-span-1 font-medium capitalize mb-4" data-v-08187f66> Settings </h1><p class="text-sm lg:text-base" data-v-08187f66> Manage your wallet transactions, withdrawals and top-ups. </p></div><div data-v-08187f66></div></div></div><div data-v-08187f66>`);
      if (unref(details)) {
        _push(`<div class="p-6 lg:p-8 bg-white rounded-lg grid gap-y-20" data-v-08187f66>`);
        _push(ssrRenderComponent(_component_SupplierWalletSettingsTransactionPin, null, null, _parent));
        _push(ssrRenderComponent(_component_SupplierWalletSettingsTransactionLimit, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/wallet/SettingsPage.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-08187f66"]]);
const _sfc_main = {
  __name: "settings",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierWalletSettingsPage = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierWalletSettingsPage, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/wallet/settings.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=settings-r4QtE7Wf.mjs.map
