import { _ as __nuxt_component_1$1 } from './AppIcon-D3CPABPP.mjs';
import { defineComponent, ref, computed, useSSRContext, getCurrentInstance, watch, mergeProps, unref, isRef } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrLooseContain, ssrGetDynamicModelProps, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _imports_0 } from './ck-white-co8-jVxZ.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';

const _sfc_main$1 = defineComponent({
  name: "Checkbox",
  inheritAttrs: false,
  props: {
    label: {
      type: String
    },
    checked: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    },
    name: {
      type: String,
      default: "checkbox"
    },
    activeClass: {
      type: String,
      default: " ring-black-500  bg-slate-900 darks:bg-slate-700 darks:ring-slate-700 "
    },
    labelClass: {
      type: String
    },
    value: {
      type: null
    },
    modelValue: {
      type: null
    }
  },
  emits: {
    "update:modelValue": (newValue) => ({
      modelValue: newValue
    })
    // use newValue
    // "update:checked": (newValue) => true,
  },
  setup(props, context) {
    const ck = ref(props.checked);
    const onChange = () => {
      ck.value = !ck.value;
    };
    const localValue = computed({
      get: () => props.modelValue,
      set: (newValue) => context.emit("update:modelValue", newValue)
    });
    return { localValue, ck, onChange };
  }
});
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  let _temp0;
  _push(`<div${ssrRenderAttrs(_attrs)}><label class="${ssrRenderClass([_ctx.disabled ? " cursor-not-allowed opacity-50" : "cursor-pointer", "flex items-center"])}"><input${ssrRenderAttrs((_temp0 = mergeProps({
    type: "checkbox",
    class: "hidden",
    disabled: _ctx.disabled,
    name: _ctx.name,
    value: _ctx.value,
    checked: Array.isArray(_ctx.localValue) ? ssrLooseContain(_ctx.localValue, _ctx.value) : _ctx.localValue
  }, _ctx.$attrs), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, _ctx.localValue))))}><span class="${ssrRenderClass([
    _ctx.localValue.includes(_ctx.value) ? _ctx.activeClass + " border-none " : "bg-white border border-[rgba(223,223,223,1)] darks:bg-slate-600 darks:border-slate-600",
    "h-4 w-4 border flex-none border-slate-200 darks:border-slate-800 rounded inline-flex mr-3 relative transition-all duration-150"
  ])}">`);
  if (_ctx.localValue.includes(_ctx.value)) {
    _push(`<img${ssrRenderAttr("src", _imports_0)} alt="image" class="h-[10px] w-[10px] block m-auto">`);
  } else {
    _push(`<!---->`);
  }
  _push(`</span>`);
  if (_ctx.label) {
    _push(`<span class="${ssrRenderClass(`text-[#333] darks:text-slate-400 text-sm leading-6 ${_ctx.labelClass}`)}">${ssrInterpolate(_ctx.label)}</span>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</label></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Checkbox/multi.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = {
  __name: "SideTab",
  __ssrInlineRender: true,
  props: ["lists", "title", "modelValue"],
  setup(__props) {
    const active = ref(true);
    const { emit } = getCurrentInstance();
    const props = __props;
    const selected = ref([]);
    watch(selected, (newValue) => {
      emit("update:modelValue", newValue);
    });
    watch(
      () => props.modelValue,
      (newValue) => {
        selected.value = newValue;
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1$1;
      const _component_CheckboxMulti = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "px-[15px] pt-[15px] pb-[36px]" }, _attrs))}><div class="flex justify-between items-center mb-[15px]"><span class="font-bold text-base">${ssrInterpolate(__props.title)}</span><span class="cursor-pointer">`);
      _push(ssrRenderComponent(_component_AppIcon, {
        icon: unref(active) ? "charm:minus" : "charm:plus"
      }, null, _parent));
      _push(`</span></div>`);
      if (unref(active)) {
        _push(`<div><ul class="grid gap-y-[10px] max-h-[300px] overflow-y-auto"><!--[-->`);
        ssrRenderList(__props.lists, (list) => {
          _push(`<li class="flex items-center capitalize">`);
          _push(ssrRenderComponent(_component_CheckboxMulti, {
            modelValue: unref(selected),
            "onUpdate:modelValue": ($event) => isRef(selected) ? selected.value = $event : null,
            label: list.title.toLowerCase(),
            labelClass: "text-xs md:text-sm",
            value: list.value
          }, null, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--></ul></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/SideTab.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;
function ucFirst(str) {
  if (typeof str !== "string" || str.length === 0) {
    return str;
  }
  return str.charAt(0).toUpperCase() + str.slice(1);
}

export { __nuxt_component_0 as _, ucFirst as u };
//# sourceMappingURL=ucFirst-myEoadyv.mjs.map
