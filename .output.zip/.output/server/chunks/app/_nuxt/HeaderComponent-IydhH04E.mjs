import { _ as __nuxt_component_1 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { e as useRouter } from '../server.mjs';
import { useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';

const _sfc_main = {
  __name: "HeaderComponent",
  __ssrInlineRender: true,
  props: [
    "title",
    "className",
    "welcome",
    "subtext",
    "btnText",
    "btnIcon",
    "canGoback"
  ],
  emits: ["onClick"],
  setup(__props, { emit: __emit }) {
    const emits = __emit;
    useRouter();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1;
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["w-full py-5 px-[30px] border-[#F4F7FE] border-b flex items-center justify-between", __props.className]
      }, _attrs))}><div>`);
      if (__props.title) {
        _push(`<h1 class="text-lg text-[#101828] col-span-1 font-semibold flex gap-x-3 items-center capitalize">`);
        if (__props.canGoback) {
          _push(`<span class="cursor-pointer">`);
          _push(ssrRenderComponent(_component_AppIcon, { icon: "ph:arrow-left-bold" }, null, _parent));
          _push(`</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(` ${ssrInterpolate(__props.title)}</h1>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.welcome) {
        _push(`<h1 class="text-[30px] text-[#101828] font-semibold capitalize">${ssrInterpolate(__props.welcome)}</h1>`);
      } else {
        _push(`<!---->`);
      }
      ssrRenderSlot(_ctx.$slots, "subtext", {}, () => {
        if (__props.subtext) {
          _push(`<p class="text-sm text-[#475467]">${ssrInterpolate(__props.subtext)}</p>`);
        } else {
          _push(`<!---->`);
        }
      }, _push, _parent);
      _push(`</div><div>`);
      ssrRenderSlot(_ctx.$slots, "button", {}, () => {
        if (__props.btnText) {
          _push(ssrRenderComponent(_component_AppButton, {
            onClick: ($event) => emits("onClick"),
            text: __props.btnText,
            icon: __props.btnIcon,
            btnClass: "!px-[14px] !py-[10px] bg-primary-500 !text-white !text-sm"
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
      }, _push, _parent);
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/HeaderComponent.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=HeaderComponent-IydhH04E.mjs.map
