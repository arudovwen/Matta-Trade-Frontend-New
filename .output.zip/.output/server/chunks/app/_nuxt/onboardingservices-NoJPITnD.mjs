import { t as store, q as post, r as urls } from '../server.mjs';

const config = {
  headers: { Authorization: `Bearer ${store.getters.accessToken}` }
};
async function uploadfile(data) {
  return await post(urls.UPLOAD_FILE, data, config);
}

export { uploadfile as u };
//# sourceMappingURL=onboardingservices-NoJPITnD.mjs.map
