import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-fc3HHrvA.mjs';
import { _ as __nuxt_component_1 } from './nuxt-img-qJohECzX.mjs';
import { mergeProps, unref, withCtx, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot } from 'vue/server-renderer';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import '../server.mjs';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';

const AuthBg = "" + buildAssetsURL("authbg.Nh0asBXz.png");
const _sfc_main = {
  __name: "auth",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_NuxtImg = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "grid grid-cols-1 lg:grid-cols-12 h-screen w-screen bg-cover bg-center",
        style: { backgroundImage: `url('${unref(AuthBg)}')` }
      }, _attrs))}><div class="relative hidden lg:flex items-center lg:col-span-7 bg-[rgba(3,14,46,0.85)]"><div class="top-8 left-10 logo absolute z-10">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_NuxtImg, {
              src: "/logo-matta-white.png",
              alt: "Matta",
              class: "w-[120px] h-auto"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_NuxtImg, {
                src: "/logo-matta-white.png",
                alt: "Matta",
                class: "w-[120px] h-auto"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex items-center text-white text-left container"><div class="px-10"><div class="max-w-[660px] 2xl:max-w-[700px] mb-10"><h1 class="text-4xl leading-10 xl:text-5xl 2xl:text-[56px] font-bold mb-6 xl:leading-[1.2]"> Sell your chemicals, raw materials and finished goods easily on Matta </h1><p class="text-base xl:text-xl 2xl:text-2xl"> Discover and buy chemicals, raw materials, ingredients, and commodities all in one place. </p></div></div></div></div><div class="bg-white px-6 xl:px-10 flex flex-col lg:col-span-5 lg:justify-center h-full overflow-y-auto"><div class="pt-6 pb-2 z-10 lg:hidden">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_NuxtImg, {
              src: "/images/logo.png",
              width: "100",
              height: "26",
              alt: "Matta",
              class: "w-[100px] h-auto z-10"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_NuxtImg, {
                src: "/images/logo.png",
                width: "100",
                height: "26",
                alt: "Matta",
                class: "w-[100px] h-auto z-10"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex-1 flex flex-col justify-center">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/auth.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=auth-SHPjfjxk.mjs.map
