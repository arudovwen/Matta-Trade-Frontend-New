import { ref, computed } from 'vue';
import { k as defineStore, l as getProducers, m as getsupplier } from '../server.mjs';

const useProductStore = defineStore("products", () => {
  const products = ref([]);
  const product = ref([]);
  const producers = ref([]);
  const total = ref(0);
  const isLoading = ref(false);
  const productsData = computed(() => products.value);
  const productData = computed(() => product.value);
  const producerData = computed(() => producers.value);
  const loading = computed(() => isLoading.value);
  function setProduct(data) {
    product.value = data;
  }
  function setProducts({ data, totalCount }) {
    products.value = data;
    total.value = totalCount;
    (void 0).scrollTo(0, 0);
  }
  function getAllProducers() {
    getProducers({ PageNumber: 1, PageSize: 50 }).then((res) => {
      producers.value = res.data.data;
    });
  }
  function setLoader(data) {
    isLoading.value = data;
  }
  return {
    total,
    product,
    products,
    productsData,
    productData,
    setProducts,
    setProduct,
    loading,
    setLoader,
    producerData,
    getAllProducers
  };
});
const useSupplierStore = defineStore("supplier", () => {
  const suppliers = ref([]);
  const supplier = ref(null);
  const producers = ref([]);
  const suppliersData = computed(() => suppliers.value);
  const supplierData = computed(() => supplier.value);
  const producersData = computed(() => producers.value);
  function fetchSupplier(id) {
    getsupplier({ supplierId: id }).then((res) => {
      supplier.value = res.data;
    });
  }
  function fetchProducers(query) {
    getProducers(query).then((res) => {
      producers.value = res.data.data.data;
    });
  }
  return {
    suppliersData,
    supplierData,
    fetchSupplier,
    producersData,
    fetchProducers
  };
});

export { useSupplierStore as a, useProductStore as u };
//# sourceMappingURL=supplier-RTXftR8K.mjs.map
