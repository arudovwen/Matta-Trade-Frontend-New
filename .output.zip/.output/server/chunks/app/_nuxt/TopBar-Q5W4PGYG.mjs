import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { resolveComponent, mergeProps, withCtx, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrRenderClass } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';

const _imports_0 = "" + buildAssetsURL("logo.0AODuwjp.svg");
const _sfc_main = {
  __name: "TopBar",
  __ssrInlineRender: true,
  props: {
    active: {
      default: null
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-white rounded-lg" }, _attrs))} data-v-0dbb39b7><nav class="flex justify-between gap-x-2 items-center py-5 px-6" data-v-0dbb39b7><div class="flex items-center" data-v-0dbb39b7>`);
      _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} width="80" height="auto" alt="Matta" data-v-0dbb39b7${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                width: "80",
                height: "auto",
                alt: "Matta"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div data-v-0dbb39b7>`);
      _push(ssrRenderComponent(_component_router_link, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button type="button" class="appearance-none h-auto leading-none py-2 px-5 text-xs md:text-[13px] uppercase border rounded-full border-primary- text-primary hover:bg-slate-50 flex items-center justify-center" data-v-0dbb39b7${_scopeId}> Skip </button>`);
          } else {
            return [
              createVNode("button", {
                type: "button",
                class: "appearance-none h-auto leading-none py-2 px-5 text-xs md:text-[13px] uppercase border rounded-full border-primary- text-primary hover:bg-slate-50 flex items-center justify-center"
              }, " Skip ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></nav><div class="grid grid-cols-3" data-v-0dbb39b7><!--[-->`);
      ssrRenderList(3, (n) => {
        _push(`<div class="${ssrRenderClass([__props.active >= n ? "bg-primary" : "", "p-[.25rem]"])}" data-v-0dbb39b7></div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/onboarding/layout/TopBar.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-0dbb39b7"]]);

export { __nuxt_component_0 as _ };
//# sourceMappingURL=TopBar-Q5W4PGYG.mjs.map
