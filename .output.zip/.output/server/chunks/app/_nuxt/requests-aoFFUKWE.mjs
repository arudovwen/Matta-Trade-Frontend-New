import { _ as __nuxt_component_0$2 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_1$3 } from './AppTab-6UxOW17N.mjs';
import { _ as __nuxt_component_0$1 } from './CustomSelect-4D7PaUUe.mjs';
import { _ as __nuxt_component_1 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_2$1 } from './EmptyData-RrNjecQG.mjs';
import { _ as __nuxt_component_1$1 } from './AppLoader-SkdFRsgH.mjs';
import { _ as __nuxt_component_4$1 } from './Simple-GRXlMUar.mjs';
import { _ as __nuxt_component_5 } from './SideModal-MJCox7bt.mjs';
import { useSSRContext, ref, inject, reactive, unref, mergeProps, watch, provide, withCtx, createVNode, createTextVNode, openBlock, createBlock, createCommentVNode, toDisplayString } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrIncludeBooleanAttr, ssrRenderAttr, ssrRenderClass } from 'vue/server-renderer';
import moment from 'moment';
import { c as samplerequestdetails, e as samplerequests, s as sellerdoc, a as sellerdocdetails } from './requestservice-VXAE2YqE.mjs';
import useVuelidate from '@vuelidate/core';
import { required } from '@vuelidate/validators';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import { Menu, MenuButton, MenuItems } from '@headlessui/vue';
import debounce from 'lodash/debounce.js';
import { _ as __nuxt_component_1$2 } from './nuxt-img-qJohECzX.mjs';
import { a as buyerquotedetail, c as sellerquotes } from './quoteservice-5V3YxrdU.mjs';
import { _ as __nuxt_component_0$3 } from './IndexModal-vEF7RYpX.mjs';
import { useRoute } from 'vue-router';
import './AppButton-rwP1M0KN.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '../server.mjs';
import 'unhead';
import '@unhead/shared';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';
import '@heroicons/vue/24/solid';
import '@iconify/vue';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import './retry-handling-kb1itlan.mjs';

const _sfc_main$7 = {
  __name: "RequestComponent",
  __ssrInlineRender: true,
  setup(__props) {
    var _a, _b, _c;
    ref(1);
    const request = inject("request");
    const isUploading = ref(false);
    const form = reactive({
      sampleRequestId: (_a = request == null ? void 0 : request.value) == null ? void 0 : _a.id,
      documentName: `${(_c = (_b = request == null ? void 0 : request.value) == null ? void 0 : _b.productName) == null ? void 0 : _c.replaceAll(" ", "")}-Document`,
      url: ""
    });
    const myrules = {
      sampleRequestId: { required },
      documentName: { required },
      url: { required }
    };
    const request$ = useVuelidate(myrules, form);
    const isLoading = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      if (unref(request)) {
        _push(`<section${ssrRenderAttrs(mergeProps({ class: "flex flex-col gap-y-8" }, _attrs))} data-v-b1698c31><div class="flex items-center" data-v-b1698c31><span class="mr-3 h-10 w-10 rounded-lg flex items-center justify-center border border-[#E7EBEE] p-2" data-v-b1698c31></span><span data-v-b1698c31><span class="text-xs font-medium" data-v-b1698c31>${ssrInterpolate(unref(request).productName)}</span><br data-v-b1698c31><span class="text-xs font-normal" data-v-b1698c31>${ssrInterpolate(unref(request).producer)}</span></span></div><div class="grid grid-cols-2 gap-y-8 gap-x-4 mb-8" data-v-b1698c31><div data-v-b1698c31><p class="text-[12px] text-[#98A2B3] mb-1 capitalize" data-v-b1698c31>Status</p>`);
        if (unref(request).requestStatus == 0) {
          _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#E0F7B0]" data-v-b1698c31> New</span>`);
        } else {
          _push(`<!---->`);
        }
        if (unref(request).requestStatus == 1) {
          _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#FDD0AF]" data-v-b1698c31> In progress</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><div data-v-b1698c31><p class="text-[12px] text-[#98A2B3] mb-1 capitalize" data-v-b1698c31>created</p><span class="text-xs" data-v-b1698c31>${ssrInterpolate(unref(moment)(unref(request).date).format("lll"))}</span></div><div data-v-b1698c31><p class="text-[12px] text-[#98A2B3] mb-1 capitalize" data-v-b1698c31> number of samples </p><span class="text-xs" data-v-b1698c31>${ssrInterpolate(unref(request).numberofSamples)}</span></div><div data-v-b1698c31><p class="text-[12px] text-[#98A2B3] mb-1 capitalize" data-v-b1698c31> Expected annual usage </p><span class="text-xs" data-v-b1698c31>${ssrInterpolate(unref(request).expectedAnualUsage)}</span></div></div>`);
        if (unref(request).description) {
          _push(`<div class="bg-[#F1F3F5] rounded-lg p-6 text-matta-black" data-v-b1698c31><div class="" data-v-b1698c31><p class="text-sm font-normal" data-v-b1698c31>${ssrInterpolate(unref(request).description)}</p></div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="bg-[#F1F3F5] rounded-lg p-6 text-matta-black" data-v-b1698c31><div class="mb-6" data-v-b1698c31><label class="mb-2 text-sm block text-matta-black font-bold" data-v-b1698c31>Upload Request document</label><div class="relative flex items-center" data-v-b1698c31><input class="border flex-1 block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200" type="file" id="formFile" accept=".xls, .xlsx, .png, .jpg, .jpeg, .docx, .pdf" data-v-b1698c31>`);
        if (unref(isUploading)) {
          _push(`<div class="ml-2" data-v-b1698c31><i class="fa fa-spinner fa-spin" aria-hidden="true" data-v-b1698c31></i></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><!--[-->`);
        ssrRenderList(unref(request$).url.$errors, (error) => {
          _push(`<div class="text-red-500 mt-1" data-v-b1698c31><div class="error-msg text-error text-xs font-semibold" data-v-b1698c31>${ssrInterpolate(error.$message)}</div></div>`);
        });
        _push(`<!--]--></div><div data-v-b1698c31><button${ssrIncludeBooleanAttr(!unref(form).url || unref(isLoading)) ? " disabled" : ""} class="bg-matta-black text-sm px-6 py-2 rounded-lg text-white active:scale-95 ml-auto block disabled:opacity-60" data-v-b1698c31> Upload `);
        if (unref(isLoading)) {
          _push(`<i class="fa fa-spinner fa-spin" aria-hidden="true" data-v-b1698c31></i>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</button></div></div></section>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/requests/RequestComponent.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_6$2 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["__scopeId", "data-v-b1698c31"]]);
const _sfc_main$6 = {
  __name: "RequestTable",
  __ssrInlineRender: true,
  props: ["title", "canCancel"],
  setup(__props) {
    const theads = ["product", "created", "status", ""];
    const isRequestOpen = ref(false);
    const requests = ref([]);
    ref([]);
    const request = ref({});
    function openRequests(val) {
      samplerequestdetails(val).then((res) => {
        request.value = res.data.data;
        isRequestOpen.value = true;
      });
    }
    const queryParams = reactive({
      SupplierId: "",
      RequestStatus: "",
      ProducerId: "",
      ProductId: "",
      Search: "",
      SortOrder: "",
      PageNumber: 1,
      PageSize: 10
    });
    const isLoading = ref(true);
    function getRequests() {
      isLoading.value = true;
      samplerequests(queryParams).then((res) => {
        requests.value = res.data.data.data;
        queryParams.totalCount = res.data.data.totalCount;
        isLoading.value = false;
      });
    }
    const statusOptions = [
      {
        id: 0,
        text1: "New"
      },
      {
        id: 1,
        text1: "In Progress"
      }
    ];
    const debounceSearch = debounce(() => {
      getRequests();
    }, 800);
    watch(
      () => ({ ...queryParams }),
      () => {
        debounceSearch();
      }
    );
    provide("request", request);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormsCustomSelect = __nuxt_component_0$1;
      const _component_AppIcon = __nuxt_component_1;
      const _component_EmptyData = __nuxt_component_2$1;
      const _component_AppLoader = __nuxt_component_1$1;
      const _component_PaginationSimple = __nuxt_component_4$1;
      const _component_SideModal = __nuxt_component_5;
      const _component_SupplierRequestsRequestComponent = __nuxt_component_6$2;
      _push(`<!--[-->`);
      if (!unref(isLoading)) {
        _push(`<div data-v-a4a9726a><div class="hidden lg:flex justify-between items-center mb-8" data-v-a4a9726a><div class="flex gap-x-4 px-5" data-v-a4a9726a><div class="relative flex items-center" data-v-a4a9726a><span class="absolute left-4 pointer-events-none text-[#667085]" data-v-a4a9726a><i class="uil uil-search" data-v-a4a9726a></i></span><input${ssrRenderAttr("value", unref(queryParams).Search)} placeholder="Search" class="border border-[#E7E7E7] text-sm focus:pr-3 pl-10 rounded-lg w-[280px] focus:outline-none py-[10px] transition ease-in-out duration-300" type="search" data-v-a4a9726a></div><div class="" data-v-a4a9726a>`);
        _push(ssrRenderComponent(_component_FormsCustomSelect, {
          placeholder: "Status",
          options: statusOptions,
          modelValue: unref(queryParams).RequestStatus,
          "onUpdate:modelValue": ($event) => unref(queryParams).RequestStatus = $event,
          classStyles: "border border-[#E7E7E7] text-sm  rounded-lg min-w-[180px] py-[10px] px-[14px] focus:outline-none"
        }, null, _parent));
        _push(`</div></div></div>`);
        if (unref(requests).length && !unref(isLoading)) {
          _push(`<div class="overflow-x-auto max-w-[80vw] lg:max-w-full" data-v-a4a9726a><table class="w-full" data-v-a4a9726a><thead data-v-a4a9726a><tr data-v-a4a9726a><!--[-->`);
          ssrRenderList(theads, (item) => {
            _push(`<th class="capitalize text-[#475467] text-sm text-left font-medium border-t border-b py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-a4a9726a>${ssrInterpolate(item)}</th>`);
          });
          _push(`<!--]--></tr></thead><tbody data-v-a4a9726a><!--[-->`);
          ssrRenderList(unref(requests), (item) => {
            _push(`<tr data-v-a4a9726a><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-a4a9726a><div class="flex items-center" data-v-a4a9726a><span class="${ssrRenderClass(item.status == 4 ? "opacity-25" : "")}" data-v-a4a9726a><span class="text-sm font-medium" data-v-a4a9726a>${ssrInterpolate(item.productName)}</span><br data-v-a4a9726a><span class="text-xs font-normal" data-v-a4a9726a>${ssrInterpolate(item.producer)}</span></span></div></td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-a4a9726a>${ssrInterpolate(unref(moment)(item.created).format("lll"))}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-a4a9726a>`);
            if (item.requestStatus == 0) {
              _push(`<span class="px-[6px] py-[2px] text-xs rounded-full text-[#5925DC] border border-[#D9D6FE] bg-[#F4F3FF] flex gap-x-1 items-center max-w-max" data-v-a4a9726a>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` New</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.requestStatus == 1) {
              _push(`<span class="px-[6px] py-1 text-xs rounded-full border border-pink-100 bg-pink-50 text-pink-500 flex gap-x-1 items-center max-w-max" data-v-a4a9726a>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` In progress</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 2) {
              _push(`<span class="px-[6px] py-1 text-xs rounded-lg text-[#17B26A] border border-[#ABEFC6] bg-[#ECFDF3] flex gap-x-1 items-center max-w-max" data-v-a4a9726a>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` Shipped</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.requestStatus == 3) {
              _push(`<span class="px-[6px] py-1 text-xs rounded-lg text-[#17B26A] border border-[#ABEFC6] bg-[#ECFDF3] flex gap-x-1 items-center max-w-max" data-v-a4a9726a>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` Completed</span>`);
            } else {
              _push(`<!---->`);
            }
            _push(`</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-6 px-3 border-[#E7EBEE] relative"])}" data-v-a4a9726a>`);
            _push(ssrRenderComponent(unref(Menu), {
              class: "relative",
              as: "div"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(ssrRenderComponent(unref(MenuButton), { class: "outline-none" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<i class="uil uil-ellipsis-v" data-v-a4a9726a${_scopeId2}></i>`);
                      } else {
                        return [
                          createVNode("i", { class: "uil uil-ellipsis-v" })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                  _push2(ssrRenderComponent(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[140px] rounded-xl overflow-hidden" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<div class="py-2 px-4 hover:bg-gray-50 text-sm whitespace-nowrap cursor-pointer" data-v-a4a9726a${_scopeId2}><i class="uil uil-box mr-2" data-v-a4a9726a${_scopeId2}></i> Open Request </div>`);
                        if (__props.canCancel) {
                          _push3(`<div class="py-2 px-4 hover:bg-gray-50 text-sm whitespace-nowrap" data-v-a4a9726a${_scopeId2}><i class="uil uil-trash mr-2" data-v-a4a9726a${_scopeId2}></i> Set as Cancelled </div>`);
                        } else {
                          _push3(`<!---->`);
                        }
                      } else {
                        return [
                          createVNode("div", {
                            class: "py-2 px-4 hover:bg-gray-50 text-sm whitespace-nowrap cursor-pointer",
                            onClick: ($event) => openRequests(item.id)
                          }, [
                            createVNode("i", { class: "uil uil-box mr-2" }),
                            createTextVNode(" Open Request ")
                          ], 8, ["onClick"]),
                          __props.canCancel ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "py-2 px-4 hover:bg-gray-50 text-sm whitespace-nowrap",
                            onClick: ($event) => _ctx.handleCancel(item.id)
                          }, [
                            createVNode("i", { class: "uil uil-trash mr-2" }),
                            createTextVNode(" Set as Cancelled ")
                          ], 8, ["onClick"])) : createCommentVNode("", true)
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                } else {
                  return [
                    createVNode(unref(MenuButton), { class: "outline-none" }, {
                      default: withCtx(() => [
                        createVNode("i", { class: "uil uil-ellipsis-v" })
                      ]),
                      _: 1
                    }),
                    createVNode(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[140px] rounded-xl overflow-hidden" }, {
                      default: withCtx(() => [
                        createVNode("div", {
                          class: "py-2 px-4 hover:bg-gray-50 text-sm whitespace-nowrap cursor-pointer",
                          onClick: ($event) => openRequests(item.id)
                        }, [
                          createVNode("i", { class: "uil uil-box mr-2" }),
                          createTextVNode(" Open Request ")
                        ], 8, ["onClick"]),
                        __props.canCancel ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "py-2 px-4 hover:bg-gray-50 text-sm whitespace-nowrap",
                          onClick: ($event) => _ctx.handleCancel(item.id)
                        }, [
                          createVNode("i", { class: "uil uil-trash mr-2" }),
                          createTextVNode(" Set as Cancelled ")
                        ], 8, ["onClick"])) : createCommentVNode("", true)
                      ]),
                      _: 2
                    }, 1024)
                  ];
                }
              }),
              _: 2
            }, _parent));
            _push(`</td></tr>`);
          });
          _push(`<!--]--></tbody></table></div>`);
        } else {
          _push(ssrRenderComponent(_component_EmptyData, {
            url: "/markets",
            buttonText: "go to catalog",
            text: "No sample request have been made"
          }, null, _parent));
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isLoading)) {
        _push(`<div class="text-center p-6 lg:p-8 my-20" data-v-a4a9726a>`);
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="p-5" data-v-a4a9726a>`);
      _push(ssrRenderComponent(_component_PaginationSimple, {
        total: unref(queryParams).totalCount,
        current: unref(queryParams).PageNumber,
        "per-page": unref(queryParams).PageSize,
        pageRange: 5,
        onPageChanged: ($event) => unref(queryParams).PageNumber = $event
      }, null, _parent));
      _push(`</div>`);
      if (unref(isRequestOpen)) {
        _push(ssrRenderComponent(_component_SideModal, {
          isOpen: unref(isRequestOpen),
          onTogglePopup: ($event) => isRequestOpen.value = false
        }, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="h-full w-full bg-white rounded-lg p-6 lg:p-8 overflow-auto max-h-full" data-v-a4a9726a${_scopeId}><div class="mb-3" data-v-a4a9726a${_scopeId}><p class="text-[13px] text-[#B6B7B9] mb-2" data-v-a4a9726a${_scopeId}>Request ID</p><h2 class="font-medium text-2xl" data-v-a4a9726a${_scopeId}>${ssrInterpolate(unref(request).requestNumber)}</h2></div><hr class="my-3 border-gray-200" data-v-a4a9726a${_scopeId}>`);
              _push2(ssrRenderComponent(_component_SupplierRequestsRequestComponent, null, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "h-full w-full bg-white rounded-lg p-6 lg:p-8 overflow-auto max-h-full" }, [
                  createVNode("div", { class: "mb-3" }, [
                    createVNode("p", { class: "text-[13px] text-[#B6B7B9] mb-2" }, "Request ID"),
                    createVNode("h2", { class: "font-medium text-2xl" }, toDisplayString(unref(request).requestNumber), 1)
                  ]),
                  createVNode("hr", { class: "my-3 border-gray-200" }),
                  createVNode(_component_SupplierRequestsRequestComponent)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/requests/RequestTable.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["__scopeId", "data-v-a4a9726a"]]);
const _sfc_main$5 = {
  __name: "SingleDocument",
  __ssrInlineRender: true,
  setup(__props) {
    const document = inject("document");
    const stage = ref(1);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtImg = __nuxt_component_1$2;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "flex flex-col gap-y-8" }, _attrs))} data-v-c8f09bfb><div class="flex items-center" data-v-c8f09bfb><span class="mr-3 h-10 w-10 rounded-lg flex items-center justify-center border border-[#E7EBEE] p-2" data-v-c8f09bfb>`);
      _push(ssrRenderComponent(_component_NuxtImg, {
        class: "",
        src: unref(document).logo,
        alt: "alt"
      }, null, _parent));
      _push(`</span><span data-v-c8f09bfb><span class="text-xs font-medium" data-v-c8f09bfb>${ssrInterpolate(unref(document).productName)}</span><br data-v-c8f09bfb><span class="text-xs font-normal" data-v-c8f09bfb>${ssrInterpolate(unref(document).producer)}</span></span></div><div class="grid grid-cols-2 gap-y-8 gap-x-4 mb-8" data-v-c8f09bfb><div data-v-c8f09bfb><p class="text-[12px] text-[#B6B7B9] mb-2 uppercase" data-v-c8f09bfb>STATUS</p>`);
      if (unref(document).requestStatus == 0) {
        _push(`<span class="px-2 py-2 text-xs rounded-lg bg-[#D0C9FF]" data-v-c8f09bfb> New</span>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(document).requestStatus == 2) {
        _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#E0F7B0]" data-v-c8f09bfb> Completed</span>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(document).requestStatus == 1) {
        _push(`<span class="px-2 py-1 text-xs rounded-lg bg-[#FDD0AF]" data-v-c8f09bfb> In progress</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div data-v-c8f09bfb><p class="text-[12px] text-[#B6B7B9] mb-2 uppercase" data-v-c8f09bfb>created</p><span class="text-xs" data-v-c8f09bfb>${ssrInterpolate(unref(moment)(unref(document).created).format("ll"))}</span></div><div data-v-c8f09bfb><p class="text-[12px] text-[#B6B7B9] mb-2 uppercase" data-v-c8f09bfb>document type</p><span class="text-xs" data-v-c8f09bfb>SDS &amp; Other</span></div></div>`);
      if (unref(document).description) {
        _push(`<div class="bg-[#F1F3F5] rounded-lg p-6 text-matta-black" data-v-c8f09bfb><div class="" data-v-c8f09bfb><p class="text-sm font-normal" data-v-c8f09bfb>${ssrInterpolate(unref(document).description)}</p></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<button class="px-6 py-4 w-full border-primary- border text-sm rounded-full text-primary uppercase" data-v-c8f09bfb> see documents </button><hr class="my-4 border-[#E7EBEE]" data-v-c8f09bfb><div class="bg-[#F1F3F5] rounded-lg p-6 text-matta-black" data-v-c8f09bfb><div class="flex justify-between mb-6" data-v-c8f09bfb><h3 class="text-lg font-medium" data-v-c8f09bfb>Timeline</h3><span data-v-c8f09bfb><i class="uil uil-minusext-lg" data-v-c8f09bfb></i></span></div><div class="${ssrRenderClass([stage.value > 1 ? "opacity-50" : "", "flex justify-start items-center gap-x-2 mb-3"])}" data-v-c8f09bfb><span class="${ssrRenderClass([stage.value > 1 ? "" : " bg-primary-500 text-white", "w-[46px] h-[46px] rounded-full flex items-center justify-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black border border-[#ddd] shadow-xs"])}" data-v-c8f09bfb><i class="uil uil-check" data-v-c8f09bfb></i></span><span data-v-c8f09bfb><span class="text-xs text-[#ABABAB]" data-v-c8f09bfb>Mar 18, 13:05PM</span><br data-v-c8f09bfb><span class="text-xs" data-v-c8f09bfb><span data-v-c8f09bfb>Document request has been <span class="font-medium" data-v-c8f09bfb>completed</span>.</span></span></span></div><div class="${ssrRenderClass([stage.value > 2 ? "opacity-50" : "", "flex justify-start items-center gap-x-2 mb-3"])}" data-v-c8f09bfb><span class="${ssrRenderClass([
        stage.value > 2 ? "" : stage.value == 2 ? " bg-primary-500 text-white" : stage.value < 2 ? "bg-white text-matta-black" : "",
        "w-[46px] h-[46px] rounded-full flex items-center justify-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black border border-[#ddd] shadow-xs"
      ])}" data-v-c8f09bfb><i class="uil uil-refresh" data-v-c8f09bfb></i></span><span data-v-c8f09bfb><span class="text-xs text-[#ABABAB]" data-v-c8f09bfb>Mar 18, 13:05PM</span><br data-v-c8f09bfb><span class="text-xs" data-v-c8f09bfb><span data-v-c8f09bfb>Status changed from <span class="font-medium" data-v-c8f09bfb>New</span> to <span class="font-medium" data-v-c8f09bfb>In Progress</span>.</span></span></span></div><div class="${ssrRenderClass([stage.value > 3 ? "opacity-50" : "", "flex justify-start items-center gap-x-2 mb-3"])}" data-v-c8f09bfb><span class="${ssrRenderClass([
        stage.value > 3 ? "" : stage.value == 3 ? " bg-primary-500 text-white" : stage.value < 3 ? "bg-white text-matta-black" : "",
        "w-[46px] h-[46px] rounded-full flex items-center justify-center text-matta-black bg-transparent hover:text-white hover:bg-matta-black border border-[#ddd] shadow-xs"
      ])}" data-v-c8f09bfb><i class="uil uil-plus" data-v-c8f09bfb></i></span><span data-v-c8f09bfb><span class="text-xs text-[#ABABAB]" data-v-c8f09bfb>Mar 18, 13:05PM</span><br data-v-c8f09bfb><span class="text-xs" data-v-c8f09bfb><span data-v-c8f09bfb>Document request <span class="font-medium" data-v-c8f09bfb>#SE554-334</span> created.</span></span></span></div></div></section>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/requests/SingleDocument.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_6$1 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-c8f09bfb"]]);
const _sfc_main$4 = {
  __name: "DocumentsTable",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    const theads = ["product", "created", "Document type", "status", ""];
    const documents = ref([]);
    ref([]);
    const queryParams = reactive({
      SupplierId: "",
      RequestStatus: "",
      ProducerId: "",
      ProductId: "",
      Search: "",
      SortOrder: "",
      PageNumber: 1,
      PageSize: 10
    });
    const docLoading = ref(true);
    const isOpen = ref(false);
    function getRequestDoc() {
      docLoading.value = true;
      sellerdoc(queryParams).then((res) => {
        documents.value = res.data.data.data;
        queryParams.totalCount = res.data.data.totalCount;
        docLoading.value = false;
      });
    }
    function openRequest(item) {
      sellerdocdetails(item.id).then((res) => {
        document.value = res.data.data;
        isOpen.value = true;
      });
    }
    const document = ref({});
    const statusOptions = [
      {
        id: 0,
        text1: "New"
      },
      {
        id: 1,
        text1: "In Progress"
      }
    ];
    const debounceSearch = debounce(() => {
      getRequestDoc();
    }, 800);
    watch(
      () => ({ ...queryParams }),
      () => {
        debounceSearch();
      }
    );
    provide("document", document);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormsCustomSelect = __nuxt_component_0$1;
      const _component_AppIcon = __nuxt_component_1;
      const _component_EmptyData = __nuxt_component_2$1;
      const _component_AppLoader = __nuxt_component_1$1;
      const _component_PaginationSimple = __nuxt_component_4$1;
      const _component_SideModal = __nuxt_component_5;
      const _component_SupplierRequestsSingleDocument = __nuxt_component_6$1;
      _push(`<!--[-->`);
      if (!unref(docLoading)) {
        _push(`<div data-v-fb0e1919><div class="flex justify-between items-center mb-8" data-v-fb0e1919><div class="flex gap-x-4" data-v-fb0e1919><div class="relative flex items-center" data-v-fb0e1919><span class="absolute left-4 pointer-events-none text-[#667085]" data-v-fb0e1919><i class="uil uil-search" data-v-fb0e1919></i></span><input${ssrRenderAttr("value", unref(queryParams).Search)} placeholder="Search" class="border border-[#E7E7E7] text-sm focus:pr-3 pl-10 rounded-lg w-[280px] focus:outline-none py-[10px] transition ease-in-out duration-300" type="search" data-v-fb0e1919></div><div class="" data-v-fb0e1919>`);
        _push(ssrRenderComponent(_component_FormsCustomSelect, {
          placeholder: "Status",
          options: statusOptions,
          modelValue: unref(queryParams).RequestStatus,
          "onUpdate:modelValue": ($event) => unref(queryParams).RequestStatus = $event,
          classStyles: "border border-[#E7E7E7] text-sm  rounded-lg min-w-[180px] py-[10px] px-[14px] focus:outline-none"
        }, null, _parent));
        _push(`</div></div></div>`);
        if (unref(documents).length) {
          _push(`<div data-v-fb0e1919><table class="w-full" data-v-fb0e1919><thead data-v-fb0e1919><tr data-v-fb0e1919><!--[-->`);
          ssrRenderList(theads, (item) => {
            _push(`<th class="capitalize text-[#475467] text-sm text-left font-medium border-t border-b py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-fb0e1919>${ssrInterpolate(item)}</th>`);
          });
          _push(`<!--]--></tr></thead><tbody data-v-fb0e1919><!--[-->`);
          ssrRenderList(unref(documents), (item) => {
            _push(`<tr data-v-fb0e1919><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-fb0e1919><div class="flex items-center" data-v-fb0e1919><span class="${ssrRenderClass(item.status == 3 ? "opacity-25" : "")}" data-v-fb0e1919><span class="text-sm font-medium" data-v-fb0e1919>${ssrInterpolate(item.productName)}</span><br data-v-fb0e1919><span class="text-xs font-normal" data-v-fb0e1919>${ssrInterpolate(item.producer)}</span></span></div></td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap max-w-[260px] truncate"])}" data-v-fb0e1919>${ssrInterpolate(item.type)}</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-fb0e1919>${ssrInterpolate(unref(moment)(item.created).format("l"))}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-fb0e1919>`);
            if (item.requestStatus == 0) {
              _push(`<span class="px-[6px] py-[2px] text-xs rounded-full text-[#5925DC] border border-[#D9D6FE] bg-[#F4F3FF] flex gap-x-1 items-center max-w-max" data-v-fb0e1919>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` New</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 1) {
              _push(`<span class="px-[6px] py-1 text-xs rounded-full border border-pink-100 bg-pink-50 text-pink-500 flex gap-x-1 items-center max-w-max" data-v-fb0e1919>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` In progress</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 2) {
              _push(`<span class="px-[6px] py-1 text-xs rounded-full text-[#17B26A] border border-[#ABEFC6] bg-[#ECFDF3] flex gap-x-1 items-center max-w-max" data-v-fb0e1919>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` Shipped</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 3) {
              _push(`<span class="px-[6px] py-1 text-xs rounded-lg text-[#17B26A] border border-[#ABEFC6] bg-[#ECFDF3] flex gap-x-1 items-center max-w-max" data-v-fb0e1919>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` Completed</span>`);
            } else {
              _push(`<!---->`);
            }
            _push(`</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-fb0e1919>`);
            _push(ssrRenderComponent(unref(Menu), {
              class: "relative",
              as: "div"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(ssrRenderComponent(unref(MenuButton), { class: "outline-none" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<i class="uil uil-ellipsis-v" data-v-fb0e1919${_scopeId2}></i>`);
                      } else {
                        return [
                          createVNode("i", { class: "uil uil-ellipsis-v" })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                  _push2(ssrRenderComponent(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[180px] rounded-xl overflow-hidden" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<div class="py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap" data-v-fb0e1919${_scopeId2}><i class="uil uil-file mr-2" data-v-fb0e1919${_scopeId2}></i> Open Document </div><div class="py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap" data-v-fb0e1919${_scopeId2}><i class="uil uil-trash mr-2" data-v-fb0e1919${_scopeId2}></i> Set as Cancelled </div>`);
                      } else {
                        return [
                          createVNode("div", {
                            class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap",
                            onClick: ($event) => openRequest(item)
                          }, [
                            createVNode("i", { class: "uil uil-file mr-2" }),
                            createTextVNode(" Open Document ")
                          ], 8, ["onClick"]),
                          createVNode("div", {
                            onClick: _ctx.cancelRequest,
                            class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                          }, [
                            createVNode("i", { class: "uil uil-trash mr-2" }),
                            createTextVNode(" Set as Cancelled ")
                          ], 8, ["onClick"])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                } else {
                  return [
                    createVNode(unref(MenuButton), { class: "outline-none" }, {
                      default: withCtx(() => [
                        createVNode("i", { class: "uil uil-ellipsis-v" })
                      ]),
                      _: 1
                    }),
                    createVNode(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[180px] rounded-xl overflow-hidden" }, {
                      default: withCtx(() => [
                        createVNode("div", {
                          class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap",
                          onClick: ($event) => openRequest(item)
                        }, [
                          createVNode("i", { class: "uil uil-file mr-2" }),
                          createTextVNode(" Open Document ")
                        ], 8, ["onClick"]),
                        createVNode("div", {
                          onClick: _ctx.cancelRequest,
                          class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap"
                        }, [
                          createVNode("i", { class: "uil uil-trash mr-2" }),
                          createTextVNode(" Set as Cancelled ")
                        ], 8, ["onClick"])
                      ]),
                      _: 2
                    }, 1024)
                  ];
                }
              }),
              _: 2
            }, _parent));
            _push(`</td></tr>`);
          });
          _push(`<!--]--></tbody></table></div>`);
        } else {
          _push(ssrRenderComponent(_component_EmptyData, {
            url: "/markets",
            buttonText: "go to catalog",
            text: "No document request have been made"
          }, null, _parent));
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(docLoading)) {
        _push(`<div class="text-center p-6 lg:p-8 my-20" data-v-fb0e1919>`);
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="p-5" data-v-fb0e1919>`);
      _push(ssrRenderComponent(_component_PaginationSimple, {
        total: unref(queryParams).totalCount,
        current: unref(queryParams).PageNumber,
        "per-page": unref(queryParams).PageSize,
        pageRange: 5,
        onPageChanged: ($event) => unref(queryParams).PageNumber = $event
      }, null, _parent));
      _push(`</div>`);
      if (unref(isOpen)) {
        _push(ssrRenderComponent(_component_SideModal, {
          isOpen: unref(isOpen),
          onTogglePopup: ($event) => isOpen.value = false
        }, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="h-full w-full bg-white rounded-lg p-6 lg:p-8 overflow-auto max-h-full" data-v-fb0e1919${_scopeId}><div class="mb-3" data-v-fb0e1919${_scopeId}><p class="text-[13px] text-[#B6B7B9] mb-2" data-v-fb0e1919${_scopeId}>Request ID</p><h2 class="font-medium text-2xl" data-v-fb0e1919${_scopeId}>${ssrInterpolate(unref(document).requestNumber)}</h2></div><hr class="my-3 border-gray-200" data-v-fb0e1919${_scopeId}>`);
              _push2(ssrRenderComponent(_component_SupplierRequestsSingleDocument, null, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "h-full w-full bg-white rounded-lg p-6 lg:p-8 overflow-auto max-h-full" }, [
                  createVNode("div", { class: "mb-3" }, [
                    createVNode("p", { class: "text-[13px] text-[#B6B7B9] mb-2" }, "Request ID"),
                    createVNode("h2", { class: "font-medium text-2xl" }, toDisplayString(unref(document).requestNumber), 1)
                  ]),
                  createVNode("hr", { class: "my-3 border-gray-200" }),
                  createVNode(_component_SupplierRequestsSingleDocument)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/requests/DocumentsTable.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-fb0e1919"]]);
const _sfc_main$3 = {
  __name: "QuoteDetail",
  __ssrInlineRender: true,
  setup(__props) {
    var _a, _b, _c;
    const quote = inject("quote");
    const isUploading = ref(false);
    const form = reactive({
      sampleRequestId: (_a = quote == null ? void 0 : quote.value) == null ? void 0 : _a.id,
      documentName: `${(_c = (_b = quote == null ? void 0 : quote.value) == null ? void 0 : _b.productName) == null ? void 0 : _c.replaceAll(" ", "")}-Quote`,
      url: ""
    });
    const myrules = {
      sampleRequestId: { required },
      documentName: { required },
      url: { required }
    };
    const request$ = useVuelidate(myrules, form);
    const isLoading = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b2, _c2, _d;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="mb-8"><p class="text-gray-700 text-base mb-1">Dear ${ssrInterpolate(unref(quote).sellerName)},</p><p class="text-gray-700 text-base"> We\u2019ll be pleased if you could be kind to provide a quote based on the details below for <strong>${ssrInterpolate(unref(quote).productName)}</strong>. </p></div><div class="mb-8"><div class="grid grid-cols-2 gap-x-3 gap-y-6"><div><p class="font-nomrmal text-sm text-gray-500">Product name</p><p class="font-medium text-sm">${ssrInterpolate(unref(quote).productName)}</p></div><div><p class="font-nomrmal text-sm text-gray-500">Supplier</p><p class="font-medium text-sm">${ssrInterpolate(unref(quote).sellerName)}</p></div><div><p class="font-nomrmal text-sm text-gray-500">Market</p><p class="font-medium text-sm">${ssrInterpolate(unref(quote).market)}</p></div><div><p class="font-nomrmal text-sm text-gray-500">Application</p><p class="font-medium text-sm">${ssrInterpolate((_a2 = unref(quote)) == null ? void 0 : _a2.applications)}</p></div><div><p class="font-nomrmal text-sm text-gray-500">Package type</p><p class="font-medium text-sm capitalize">${ssrInterpolate((_d = (_c2 = (_b2 = unref(quote)) == null ? void 0 : _b2.package) == null ? void 0 : _c2.package) == null ? void 0 : _d.title)}</p></div></div><div></div><hr class="my-4"><div class="bg-[#F1F3F5] rounded-lg p-6 text-matta-black"><div class="mb-6"><label class="mb-2 text-xs block text-matta-black font-bold">Upload Quote</label><div class="relative flex items-center"><input class="border flex-1 block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200" type="file" id="formFile" accept=".xls, .xlsx, .png, .jpg, .jpeg, .docx, .pdf">`);
      if (unref(isUploading)) {
        _push(`<div class="ml-2"><i class="fa fa-spinner fa-spin" aria-hidden="true"></i></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><!--[-->`);
      ssrRenderList(unref(request$).url.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1"><div class="error-msg text-error text-xs font-semibold">${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div><button${ssrIncludeBooleanAttr(!unref(form).url || unref(isLoading)) ? " disabled" : ""} class="bg-matta-black text-sm px-6 py-2 rounded-lg text-white active:scale-95 ml-auto block disabled:opacity-60"> Upload `);
      if (unref(isLoading)) {
        _push(`<i class="fa fa-spinner fa-spin" aria-hidden="true"></i>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</button></div></div></div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/requests/QuoteDetail.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_6 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "QuotesTable",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    const theads = ["quote no", "product", "requested by", "created", "status", ""];
    inject("getquotes");
    const quoteLoading = inject("quoteLoading");
    const quotes = inject("quotes");
    const multi = ref([]);
    const quoteParams = inject("quoteParams");
    const isOpen = ref(false);
    function openRequest(item) {
      buyerquotedetail(item.id).then((res) => {
        quote.value = res.data.data;
        quote.value.id = item.id;
        isOpen.value = true;
      });
    }
    const quote = ref({});
    const statusOptions = [
      {
        id: 0,
        text1: "New"
      },
      {
        id: 1,
        text1: "In Progress"
      }
    ];
    const debounceSearch = debounce(() => {
    }, 800);
    watch(
      () => ({ ...quoteParams }),
      () => {
        debounceSearch();
      }
    );
    provide("quote", quote);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormsCustomSelect = __nuxt_component_0$1;
      const _component_AppIcon = __nuxt_component_1;
      const _component_EmptyData = __nuxt_component_2$1;
      const _component_AppLoader = __nuxt_component_1$1;
      const _component_PaginationSimple = __nuxt_component_4$1;
      const _component_SideModal = __nuxt_component_5;
      const _component_SupplierRequestsQuoteDetail = __nuxt_component_6;
      _push(`<!--[-->`);
      if (!unref(quoteLoading)) {
        _push(`<div data-v-93e1f474><div class="flex justify-between items-center mb-8" data-v-93e1f474><div class="flex gap-x-4 px-5" data-v-93e1f474><div class="relative flex items-center" data-v-93e1f474><span class="absolute left-4 pointer-events-none text-[#667085]" data-v-93e1f474><i class="uil uil-search" data-v-93e1f474></i></span><input${ssrRenderAttr("value", unref(quoteParams).Search)} placeholder="Search" class="border border-[#E7E7E7] text-sm focus:pr-3 pl-10 rounded-lg w-[280px] focus:outline-none py-[10px] transition ease-in-out duration-300" type="search" data-v-93e1f474></div><div class="" data-v-93e1f474>`);
        _push(ssrRenderComponent(_component_FormsCustomSelect, {
          placeholder: "Status",
          options: statusOptions,
          modelValue: unref(quoteParams).Status,
          "onUpdate:modelValue": ($event) => unref(quoteParams).Status = $event,
          classStyles: "border border-[#E7E7E7] text-sm  rounded-lg min-w-[180px] py-[10px] px-[14px] focus:outline-none"
        }, null, _parent));
        _push(`</div></div></div>`);
        if (unref(quotes).length) {
          _push(`<div data-v-93e1f474><table class="w-full" data-v-93e1f474><thead data-v-93e1f474><tr data-v-93e1f474><!--[-->`);
          ssrRenderList(theads, (item) => {
            _push(`<th class="capitalize text-[#475467] text-sm text-left font-medium border-t border-b py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-93e1f474>${ssrInterpolate(item)}</th>`);
          });
          _push(`<!--]--></tr></thead><tbody data-v-93e1f474><!--[-->`);
          ssrRenderList(unref(quotes), (item) => {
            _push(`<tr data-v-93e1f474><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-93e1f474>${ssrInterpolate(item.quoteNo)}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-93e1f474>${ssrInterpolate(item.product)}</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-93e1f474>${ssrInterpolate(item.requestedBy)}</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-93e1f474>${ssrInterpolate(unref(moment)(item.date).format("lll"))}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-93e1f474>`);
            if (item.status == 0) {
              _push(`<span class="px-[6px] py-[2px] text-xs rounded-full text-[#5925DC] border border-[#D9D6FE] bg-[#F4F3FF] flex gap-x-1 items-center max-w-max" data-v-93e1f474>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` ${ssrInterpolate(item.statusText)}</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 1) {
              _push(`<span class="px-[6px] py-1 text-xs rounded-full border border-pink-100 bg-pink-50 text-pink-500 flex gap-x-1 items-center max-w-max" data-v-93e1f474>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` ${ssrInterpolate(item.statusText)}</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 2) {
              _push(`<span class="px-[6px] py-1 text-xs rounded-lg text-[#17B26A] border border-[#ABEFC6] bg-[#ECFDF3] flex gap-x-1 items-center max-w-max" data-v-93e1f474>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` ${ssrInterpolate(item.statusText)}</span>`);
            } else {
              _push(`<!---->`);
            }
            if (item.status == 3) {
              _push(`<span class="px-[6px] py-1 text-xs rounded-lg text-[#17B26A] border border-[#ABEFC6] bg-[#ECFDF3] flex gap-x-1 items-center max-w-max" data-v-93e1f474>`);
              _push(ssrRenderComponent(_component_AppIcon, { icon: "octicon:dot-fill-24" }, null, _parent));
              _push(` ${ssrInterpolate(item.statusText)}</span>`);
            } else {
              _push(`<!---->`);
            }
            _push(`</td><td class="${ssrRenderClass([item.status == 3 ? "opacity-25" : "", "capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap"])}" data-v-93e1f474>`);
            _push(ssrRenderComponent(unref(Menu), {
              class: "relative",
              as: "div"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(ssrRenderComponent(unref(MenuButton), { class: "outline-none" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<i class="uil uil-ellipsis-v" data-v-93e1f474${_scopeId2}></i>`);
                      } else {
                        return [
                          createVNode("i", { class: "uil uil-ellipsis-v" })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                  _push2(ssrRenderComponent(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[180px] rounded-xl overflow-hidden" }, {
                    default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                      if (_push3) {
                        _push3(`<div class="py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap cursor-pointer" data-v-93e1f474${_scopeId2}><i class="uil uil-file mr-2" data-v-93e1f474${_scopeId2}></i> Open quote </div>`);
                      } else {
                        return [
                          createVNode("div", {
                            class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap cursor-pointer",
                            onClick: ($event) => openRequest(item)
                          }, [
                            createVNode("i", { class: "uil uil-file mr-2" }),
                            createTextVNode(" Open quote ")
                          ], 8, ["onClick"])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent2, _scopeId));
                } else {
                  return [
                    createVNode(unref(MenuButton), { class: "outline-none" }, {
                      default: withCtx(() => [
                        createVNode("i", { class: "uil uil-ellipsis-v" })
                      ]),
                      _: 1
                    }),
                    createVNode(unref(MenuItems), { class: "absolute z-[999] bg-white shadow-[5px_12px_35px_rgba(44,44,44,0.12)] py-2 right-0 min-w-[180px] rounded-xl overflow-hidden" }, {
                      default: withCtx(() => [
                        createVNode("div", {
                          class: "py-2 px-5 hover:bg-gray-50 text-sm whitespace-nowrap cursor-pointer",
                          onClick: ($event) => openRequest(item)
                        }, [
                          createVNode("i", { class: "uil uil-file mr-2" }),
                          createTextVNode(" Open quote ")
                        ], 8, ["onClick"])
                      ]),
                      _: 2
                    }, 1024)
                  ];
                }
              }),
              _: 2
            }, _parent));
            _push(`</td></tr>`);
          });
          _push(`<!--]--></tbody></table></div>`);
        } else {
          _push(ssrRenderComponent(_component_EmptyData, {
            url: "/markets",
            buttonText: "go to catalog",
            text: "No quote have been made"
          }, null, _parent));
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(quoteLoading)) {
        _push(`<div class="text-center p-6 lg:p-8 my-20" data-v-93e1f474>`);
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (multi.value.length) {
        _push(`<div class="px-6 py-5 rounded-lg bg-white flex justify-between items-center text-[13px]" data-v-93e1f474><span class="flex items-center gap-x-3" data-v-93e1f474><span data-v-93e1f474>${ssrInterpolate(multi.value.length)} items selected</span><span class="text-gray-300" data-v-93e1f474>|</span><span class="flex gap-x-3 items-center" data-v-93e1f474><button class="uppercase px-2" data-v-93e1f474>select all</button><button class="uppercase px-2" data-v-93e1f474> deselect </button></span></span><span class="flex gap-x-4 items-center" data-v-93e1f474><button class="bg-[#E7EBEE] text-matta-black rounded-lg px-5 py-4 uppercase" data-v-93e1f474> set as cancelled </button></span></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="p-5" data-v-93e1f474>`);
      _push(ssrRenderComponent(_component_PaginationSimple, {
        total: unref(quoteParams).totalCount,
        current: unref(quoteParams).PageNumber,
        "per-page": unref(quoteParams).PageSize,
        pageRange: 5,
        onPageChanged: ($event) => unref(quoteParams).PageNumber = $event
      }, null, _parent));
      _push(`</div>`);
      if (isOpen.value) {
        _push(ssrRenderComponent(_component_SideModal, {
          isOpen: isOpen.value,
          onTogglePopup: ($event) => isOpen.value = false
        }, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="h-full w-full max-w-[500px] bg-white rounded-lg p-6 lg:py-10 px-6 overflow-auto max-h-full" data-v-93e1f474${_scopeId}><div class="mb-3" data-v-93e1f474${_scopeId}><p class="text-[13px] text-[#B6B7B9] mb-2" data-v-93e1f474${_scopeId}>Quote No</p><h2 class="font-medium text-2xl" data-v-93e1f474${_scopeId}>${ssrInterpolate(quote.value.quoteNo)}</h2></div><hr class="my-3 border-gray-200" data-v-93e1f474${_scopeId}>`);
              _push2(ssrRenderComponent(_component_SupplierRequestsQuoteDetail, null, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "h-full w-full max-w-[500px] bg-white rounded-lg p-6 lg:py-10 px-6 overflow-auto max-h-full" }, [
                  createVNode("div", { class: "mb-3" }, [
                    createVNode("p", { class: "text-[13px] text-[#B6B7B9] mb-2" }, "Quote No"),
                    createVNode("h2", { class: "font-medium text-2xl" }, toDisplayString(quote.value.quoteNo), 1)
                  ]),
                  createVNode("hr", { class: "my-3 border-gray-200" }),
                  createVNode(_component_SupplierRequestsQuoteDetail)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/requests/QuotesTable.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-93e1f474"]]);
const _sfc_main$1 = {
  __name: "StoreRequests",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    const tabs = [
      {
        title: "samples",
        key: "samples"
      },
      {
        title: "documents",
        key: "documents"
      },
      {
        title: "quotes",
        key: "quotes"
      }
    ];
    const isLoading = ref(true);
    const quoteLoading = ref(true);
    const docLoading = ref(true);
    const documents = ref([]);
    const requests = ref([]);
    useRoute();
    const isOpen = ref(false);
    const active = ref("samples");
    const quotes = ref([]);
    const quoteParams = reactive({
      Status: "",
      Search: "",
      SortOrder: "",
      PageNumber: 1,
      PageSize: 10,
      totalCount: 0
    });
    const count = reactive({
      documents: 0,
      samples: 0,
      quotes: 0
    });
    function getquotes() {
      quoteLoading.value = true;
      sellerquotes(quoteParams).then((res) => {
        count.quotes = quoteParams.totalCount = res.data.data.totalCount;
        quotes.value = res.data.data.data;
        quoteLoading.value = false;
      });
    }
    const queryParams = reactive({
      SupplierId: "",
      RequestStatus: "",
      ProducerId: "",
      ProductId: "",
      Search: "",
      SortOrder: "",
      PageNumber: 1,
      PageSize: 10
    });
    function getRequests() {
      isLoading.value = true;
      samplerequests(queryParams).then((res) => {
        requests.value = res.data.data.data;
        queryParams.totalCount = res.data.data.totalCount;
        isLoading.value = false;
      });
    }
    function getRequestDoc() {
      docLoading.value = true;
      sellerdoc(queryParams).then((res) => {
        documents.value = res.data.data.data;
        queryParams.totalCount = res.data.data.totalCount;
        docLoading.value = false;
      });
    }
    watch(
      () => [quoteParams.Status, quoteParams.Search, quoteParams.SortOrder],
      () => {
        getquotes();
      }
    );
    provide("quotes", quotes);
    provide("quoteParams", quoteParams);
    provide("quoteLoading", quoteLoading);
    provide("docLoading", docLoading);
    provide("active", active);
    provide("getRequests", getRequests);
    provide("getRequestDoc", getRequestDoc);
    provide("getquotes", getquotes);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderComponent = __nuxt_component_0$2;
      const _component_AppTab = __nuxt_component_1$3;
      const _component_SupplierRequestsRequestTable = __nuxt_component_2;
      const _component_SupplierRequestsDocumentsTable = __nuxt_component_3;
      const _component_SupplierRequestsQuotesTable = __nuxt_component_4;
      const _component_IndexModal = __nuxt_component_0$3;
      const _component_AppIcon = __nuxt_component_1;
      _push(`<!--[--><div class="flex flex-col bg-white rounded-[10px]" data-v-ea60ddae>`);
      _push(ssrRenderComponent(_component_HeaderComponent, {
        title: "Store Requests",
        className: "!px-5",
        subtext: "List of your requests for samples and documents."
      }, null, _parent));
      _push(`<div class="pt-[30px]" data-v-ea60ddae>`);
      _push(ssrRenderComponent(_component_AppTab, {
        tabs,
        className: "px-5",
        count: unref(count)
      }, null, _parent));
      _push(`<div data-v-ea60ddae>`);
      if (unref(active) == "samples") {
        _push(ssrRenderComponent(_component_SupplierRequestsRequestTable, { canCancel: false }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(active) == "documents") {
        _push(ssrRenderComponent(_component_SupplierRequestsDocumentsTable, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(active) == "quotes") {
        _push(ssrRenderComponent(_component_SupplierRequestsQuotesTable, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
      if (unref(isOpen)) {
        _push(ssrRenderComponent(_component_IndexModal, {
          isOpen: unref(isOpen),
          onTogglePopup: ($event) => isOpen.value = false
        }, {
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="w-[400px] bg-white rounded-lg p-6 lg:p-8 relative" data-v-ea60ddae${_scopeId}><span class="hover:bg-gray-50 rounded-full h-6 w-6 flex items-center justify-center absolute top-4 right-4" data-v-ea60ddae${_scopeId}>`);
              _push2(ssrRenderComponent(_component_AppIcon, {
                icon: "heroicons-solid:x",
                class: "w-4 h-4"
              }, null, _parent2, _scopeId));
              _push2(`</span><h4 class="text-lg font-medium mb-3" data-v-ea60ddae${_scopeId}>Cancel document request</h4><p class="text-sm mb-8" data-v-ea60ddae${_scopeId}> Are your sure you want to cancel #DC455-084 document request? </p><div class="flex items-center gap-x-4" data-v-ea60ddae${_scopeId}><button type="button" class="text-[13px] uppercase text-matta-black px-2 py-2 hover:text-primary/80 w-full" data-v-ea60ddae${_scopeId}> don\u2019t cancel </button><button type="submit" class="border text-[13px] border-primary- uppercase w-full text-white bg-primary-500 rounded-lg px-2 py-3 hover:bg-primary/80" data-v-ea60ddae${_scopeId}> cancel request </button></div></div>`);
            } else {
              return [
                createVNode("div", { class: "w-[400px] bg-white rounded-lg p-6 lg:p-8 relative" }, [
                  createVNode("span", {
                    onClick: ($event) => isOpen.value = false,
                    class: "hover:bg-gray-50 rounded-full h-6 w-6 flex items-center justify-center absolute top-4 right-4"
                  }, [
                    createVNode(_component_AppIcon, {
                      icon: "heroicons-solid:x",
                      class: "w-4 h-4"
                    })
                  ], 8, ["onClick"]),
                  createVNode("h4", { class: "text-lg font-medium mb-3" }, "Cancel document request"),
                  createVNode("p", { class: "text-sm mb-8" }, " Are your sure you want to cancel #DC455-084 document request? "),
                  createVNode("div", { class: "flex items-center gap-x-4" }, [
                    createVNode("button", {
                      onClick: ($event) => isOpen.value = false,
                      type: "button",
                      class: "text-[13px] uppercase text-matta-black px-2 py-2 hover:text-primary/80 w-full"
                    }, " don\u2019t cancel ", 8, ["onClick"]),
                    createVNode("button", {
                      type: "submit",
                      class: "border text-[13px] border-primary- uppercase w-full text-white bg-primary-500 rounded-lg px-2 py-3 hover:bg-primary/80"
                    }, " cancel request ")
                  ])
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/StoreRequests.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-ea60ddae"]]);
const _sfc_main = {
  __name: "requests",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierStoreRequests = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierStoreRequests, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/storefront/requests.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=requests-aoFFUKWE.mjs.map
