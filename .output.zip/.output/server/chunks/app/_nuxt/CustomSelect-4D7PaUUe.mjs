import { useSSRContext, ref, watch, unref, mergeProps, withCtx, openBlock, createBlock, createVNode, toDisplayString, createCommentVNode, Fragment, renderList, Transition } from 'vue';
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderClass } from 'vue/server-renderer';
import { Listbox, ListboxButton, ListboxOptions, ListboxOption } from '@headlessui/vue';
import { ChevronDownIcon } from '@heroicons/vue/24/solid';

const _sfc_main = {
  __name: "CustomSelect",
  __ssrInlineRender: true,
  props: [
    "label",
    "options",
    "id",
    "modelValue",
    "placeholder",
    "classStyles"
  ],
  emits: ["onGetData", "update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emits = __emit;
    const selectedOption = ref(null);
    watch(selectedOption, () => {
      var _a;
      if (((_a = selectedOption.value) == null ? void 0 : _a.id) == null)
        return;
      emits("onGetData", selectedOption.value, props.id);
      emits("update:modelValue", selectedOption.value.id);
    });
    watch(
      () => props.modelValue,
      () => {
        if (!props.modelValue)
          return {};
        selectedOption.value = props.options.find((i) => i.id == props.modelValue);
      }
    );
    watch(
      () => [...props.options],
      () => {
        if (!props.modelValue)
          return {};
        selectedOption.value = props.options.find((i) => i.id == props.modelValue);
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(Listbox), mergeProps({
        modelValue: selectedOption.value,
        "onUpdate:modelValue": ($event) => selectedOption.value = $event
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="relative w-full"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ListboxButton), {
              class: [__props.classStyles, "relative w-full cursor-default min-h-[40px] min-w-[100px] bg-white text-left shadow-[0px_1px_2px_rgba(16,24,40,0.05)] sm:text-[14px] flex items-center"]
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  if (selectedOption.value) {
                    _push3(`<span class="block text-sm"${_scopeId2}><div class="text-[#3A3745] flex items-center gap-x-1"${_scopeId2}>`);
                    if (selectedOption.value.text1) {
                      _push3(`<span${_scopeId2}>${ssrInterpolate(selectedOption.value.text1)}</span>`);
                    } else {
                      _push3(`<!---->`);
                    }
                    if (selectedOption.value.text2) {
                      _push3(`<span${_scopeId2}>-</span>`);
                    } else {
                      _push3(`<!---->`);
                    }
                    if (selectedOption.value.text2) {
                      _push3(`<span${_scopeId2}>${ssrInterpolate(selectedOption.value.text2)}</span>`);
                    } else {
                      _push3(`<!---->`);
                    }
                    _push3(`</div></span>`);
                  } else {
                    _push3(`<span class="block text-base text-[#8F8C9A] whitespace-nowrap"${_scopeId2}>${ssrInterpolate(__props.placeholder)}</span>`);
                  }
                  _push3(`<span class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(ChevronDownIcon), {
                    class: "h-4 w-4 text-[#3A3745]",
                    "aria-hidden": "true"
                  }, null, _parent3, _scopeId2));
                  _push3(`</span>`);
                } else {
                  return [
                    selectedOption.value ? (openBlock(), createBlock("span", {
                      key: 0,
                      class: "block text-sm"
                    }, [
                      createVNode("div", { class: "text-[#3A3745] flex items-center gap-x-1" }, [
                        selectedOption.value.text1 ? (openBlock(), createBlock("span", { key: 0 }, toDisplayString(selectedOption.value.text1), 1)) : createCommentVNode("", true),
                        selectedOption.value.text2 ? (openBlock(), createBlock("span", { key: 1 }, "-")) : createCommentVNode("", true),
                        selectedOption.value.text2 ? (openBlock(), createBlock("span", { key: 2 }, toDisplayString(selectedOption.value.text2), 1)) : createCommentVNode("", true)
                      ])
                    ])) : (openBlock(), createBlock("span", {
                      key: 1,
                      class: "block text-base text-[#8F8C9A] whitespace-nowrap"
                    }, toDisplayString(__props.placeholder), 1)),
                    createVNode("span", { class: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" }, [
                      createVNode(unref(ChevronDownIcon), {
                        class: "h-4 w-4 text-[#3A3745]",
                        "aria-hidden": "true"
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(ListboxOptions), { class: "absolute max-h-60 w-full mt-[.5rem] min-w-[12rem] z-[999] overflow-auto rounded-lg bg-white text-sm shadow-[0px_12px_16px_-4px_rgba(16,24,40,0.08),_0px_4px_6px_-2px_rgba(16,24,40,0.03)] ring-1 ring-black ring-opacity-5 border-b-2 outline-0 sm:text-sm" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(__props.options, (option) => {
                    _push3(ssrRenderComponent(unref(ListboxOption), {
                      key: option.name,
                      value: option,
                      as: "template"
                    }, {
                      default: withCtx(({ active, selected }, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<li class="${ssrRenderClass([
                            active || selected ? "" : "",
                            "relative cursor-pointer select-none py-[11px] px-[13px] text-loft-black hover:bg-gray-100"
                          ])}"${_scopeId3}>`);
                          if (option.text1) {
                            _push4(`<p class="text-sm text-[#101828]"${_scopeId3}>${ssrInterpolate(option.text1)}</p>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          _push4(`<div class="flex items-center gap-x-1"${_scopeId3}>`);
                          if (option.text2) {
                            _push4(`<span class="text-[#667085]"${_scopeId3}>${ssrInterpolate(option.text2)}</span>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          if (option.text3) {
                            _push4(`<span class="text-[#667085]"${_scopeId3}>-</span>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          if (option.text3) {
                            _push4(`<span class="text-[#667085]"${_scopeId3}>${ssrInterpolate(option.text3)}</span>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          _push4(`</div></li>`);
                        } else {
                          return [
                            createVNode("li", {
                              class: [
                                active || selected ? "" : "",
                                "relative cursor-pointer select-none py-[11px] px-[13px] text-loft-black hover:bg-gray-100"
                              ]
                            }, [
                              option.text1 ? (openBlock(), createBlock("p", {
                                key: 0,
                                class: "text-sm text-[#101828]"
                              }, toDisplayString(option.text1), 1)) : createCommentVNode("", true),
                              createVNode("div", { class: "flex items-center gap-x-1" }, [
                                option.text2 ? (openBlock(), createBlock("span", {
                                  key: 0,
                                  class: "text-[#667085]"
                                }, toDisplayString(option.text2), 1)) : createCommentVNode("", true),
                                option.text3 ? (openBlock(), createBlock("span", {
                                  key: 1,
                                  class: "text-[#667085]"
                                }, "-")) : createCommentVNode("", true),
                                option.text3 ? (openBlock(), createBlock("span", {
                                  key: 2,
                                  class: "text-[#667085]"
                                }, toDisplayString(option.text3), 1)) : createCommentVNode("", true)
                              ])
                            ], 2)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                  if (!__props.options.length) {
                    _push3(`<div class="relative cursor-pointer select-none py-[11px] px-[13px] text-loft-black text-sm text-[#667085]"${_scopeId2}> No option </div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(__props.options, (option) => {
                      return openBlock(), createBlock(unref(ListboxOption), {
                        key: option.name,
                        value: option,
                        as: "template"
                      }, {
                        default: withCtx(({ active, selected }) => [
                          createVNode("li", {
                            class: [
                              active || selected ? "" : "",
                              "relative cursor-pointer select-none py-[11px] px-[13px] text-loft-black hover:bg-gray-100"
                            ]
                          }, [
                            option.text1 ? (openBlock(), createBlock("p", {
                              key: 0,
                              class: "text-sm text-[#101828]"
                            }, toDisplayString(option.text1), 1)) : createCommentVNode("", true),
                            createVNode("div", { class: "flex items-center gap-x-1" }, [
                              option.text2 ? (openBlock(), createBlock("span", {
                                key: 0,
                                class: "text-[#667085]"
                              }, toDisplayString(option.text2), 1)) : createCommentVNode("", true),
                              option.text3 ? (openBlock(), createBlock("span", {
                                key: 1,
                                class: "text-[#667085]"
                              }, "-")) : createCommentVNode("", true),
                              option.text3 ? (openBlock(), createBlock("span", {
                                key: 2,
                                class: "text-[#667085]"
                              }, toDisplayString(option.text3), 1)) : createCommentVNode("", true)
                            ])
                          ], 2)
                        ]),
                        _: 2
                      }, 1032, ["value"]);
                    }), 128)),
                    !__props.options.length ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "relative cursor-pointer select-none py-[11px] px-[13px] text-loft-black text-sm text-[#667085]"
                    }, " No option ")) : createCommentVNode("", true)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "relative w-full" }, [
                createVNode(unref(ListboxButton), {
                  class: [__props.classStyles, "relative w-full cursor-default min-h-[40px] min-w-[100px] bg-white text-left shadow-[0px_1px_2px_rgba(16,24,40,0.05)] sm:text-[14px] flex items-center"]
                }, {
                  default: withCtx(() => [
                    selectedOption.value ? (openBlock(), createBlock("span", {
                      key: 0,
                      class: "block text-sm"
                    }, [
                      createVNode("div", { class: "text-[#3A3745] flex items-center gap-x-1" }, [
                        selectedOption.value.text1 ? (openBlock(), createBlock("span", { key: 0 }, toDisplayString(selectedOption.value.text1), 1)) : createCommentVNode("", true),
                        selectedOption.value.text2 ? (openBlock(), createBlock("span", { key: 1 }, "-")) : createCommentVNode("", true),
                        selectedOption.value.text2 ? (openBlock(), createBlock("span", { key: 2 }, toDisplayString(selectedOption.value.text2), 1)) : createCommentVNode("", true)
                      ])
                    ])) : (openBlock(), createBlock("span", {
                      key: 1,
                      class: "block text-base text-[#8F8C9A] whitespace-nowrap"
                    }, toDisplayString(__props.placeholder), 1)),
                    createVNode("span", { class: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" }, [
                      createVNode(unref(ChevronDownIcon), {
                        class: "h-4 w-4 text-[#3A3745]",
                        "aria-hidden": "true"
                      })
                    ])
                  ]),
                  _: 1
                }, 8, ["class"]),
                createVNode(Transition, {
                  "leave-active-class": "transition duration-100 ease-in",
                  "leave-from-class": "opacity-100",
                  "leave-to-class": "opacity-0"
                }, {
                  default: withCtx(() => [
                    createVNode(unref(ListboxOptions), { class: "absolute max-h-60 w-full mt-[.5rem] min-w-[12rem] z-[999] overflow-auto rounded-lg bg-white text-sm shadow-[0px_12px_16px_-4px_rgba(16,24,40,0.08),_0px_4px_6px_-2px_rgba(16,24,40,0.03)] ring-1 ring-black ring-opacity-5 border-b-2 outline-0 sm:text-sm" }, {
                      default: withCtx(() => [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.options, (option) => {
                          return openBlock(), createBlock(unref(ListboxOption), {
                            key: option.name,
                            value: option,
                            as: "template"
                          }, {
                            default: withCtx(({ active, selected }) => [
                              createVNode("li", {
                                class: [
                                  active || selected ? "" : "",
                                  "relative cursor-pointer select-none py-[11px] px-[13px] text-loft-black hover:bg-gray-100"
                                ]
                              }, [
                                option.text1 ? (openBlock(), createBlock("p", {
                                  key: 0,
                                  class: "text-sm text-[#101828]"
                                }, toDisplayString(option.text1), 1)) : createCommentVNode("", true),
                                createVNode("div", { class: "flex items-center gap-x-1" }, [
                                  option.text2 ? (openBlock(), createBlock("span", {
                                    key: 0,
                                    class: "text-[#667085]"
                                  }, toDisplayString(option.text2), 1)) : createCommentVNode("", true),
                                  option.text3 ? (openBlock(), createBlock("span", {
                                    key: 1,
                                    class: "text-[#667085]"
                                  }, "-")) : createCommentVNode("", true),
                                  option.text3 ? (openBlock(), createBlock("span", {
                                    key: 2,
                                    class: "text-[#667085]"
                                  }, toDisplayString(option.text3), 1)) : createCommentVNode("", true)
                                ])
                              ], 2)
                            ]),
                            _: 2
                          }, 1032, ["value"]);
                        }), 128)),
                        !__props.options.length ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "relative cursor-pointer select-none py-[11px] px-[13px] text-loft-black text-sm text-[#667085]"
                        }, " No option ")) : createCommentVNode("", true)
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/forms/CustomSelect.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=CustomSelect-4D7PaUUe.mjs.map
