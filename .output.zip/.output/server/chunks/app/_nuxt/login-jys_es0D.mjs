import { _ as __nuxt_component_1 } from './index-eSH9oSpY.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-fc3HHrvA.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { ref, mergeProps, unref, isRef, withCtx, createTextVNode, useSSRContext } from 'vue';
import { a as useHead, d as useAuthStore, u as useRoute, e as useRouter } from '../server.mjs';
import { useTokenClient } from 'vue3-google-signin';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { useForm } from 'vee-validate';
import * as yup from 'yup';
import { toast } from 'vue3-toastify';
import { l as loginUser, s as sociallogin } from './authservices-pXd32gsl.mjs';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './_plugin-vue_export-helper-yVxbj29m.mjs';
import '../../rollup/_vue.mjs';
import 'cleave.js';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main = {
  __name: "login",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Login | Matta",
      meta: [{ name: "description", content: "Login | Matta" }]
    });
    const isLoading = ref(false);
    const formValues = {
      email: "",
      password: ""
    };
    const schema = yup.object({
      email: yup.string().required("Email is required").email("Please enter a valid email address"),
      password: yup.string().required("Password is required")
    });
    const { handleSubmit, defineField, errors } = useForm({
      validationSchema: schema,
      initialValues: formValues
    });
    const authStore = useAuthStore();
    const [email, emailAtt] = defineField("email");
    const [password, passwordAtt] = defineField("password");
    const route = useRoute();
    const router = useRouter();
    handleSubmit((values) => {
      isLoading.value = true;
      loginUser(values).then((res) => {
        var _a;
        if (res.status === 200) {
          authStore.setLoggedUser(res.data.data);
          if (!res.data.data.onboardingPageStatus && ((_a = res.data.data) == null ? void 0 : _a.businessUserType.toLowerCase()) === "supplier") {
            toast.info("Login successful, Complete your onboarding");
            (void 0).location.replace("/onboarding/company");
            return;
          }
          toast.success("Login successful");
          if (route.query.redirected_from) {
            (void 0).location.replace(route.query.redirected_from);
            return;
          }
          (void 0).location.replace("/");
        }
      }).catch((err) => {
        isLoading.value = false;
        if (err.response.data.message || err.response.data.Message) {
          toast.error(err.response.data.message || err.response.data.Message);
        }
        if ((err.response.data.message || err.response.data.Message).includes(
          "Email has not verified yet"
        )) {
          router.push(
            `/auth/resend-verification/${encodeURIComponent(values.email)}`
          );
        }
      });
    });
    const handleLoginSuccess = (response) => {
      console.log("\u{1F680} ~ handleLoginSuccess ~ response:", response);
      const { access_token } = response;
      let data = {
        provider: "GOOGLE",
        idToken: access_token,
        business_UserType: 0
      };
      sociallogin(data).then((res) => {
        if (res.status === 200) {
          store.commit("setUser", res.data.data);
          toast.success(res.data.message ? res.data.message : "Login successful");
          if (res.data.message.includes("Email has not verified yet")) {
            return;
          }
          if (!res.data.data.onboardingPageStatus) {
            (void 0).location.replace("/onboarding");
            return;
          }
          if (route.query.redirected_from) {
            (void 0).location.replace(route.query.redirected_from);
            return;
          }
          if (route.query.redirect_to) {
            (void 0).location.replace(route.query.redirect_to);
            return;
          }
          (void 0).location.replace("/");
        }
      }).catch((err) => {
        invalidCredentials.value = true;
        isLoading.value = false;
        if (err.response.data.message || err.response.data.Message) {
          toast.error(err.response.data.message || err.response.data.Message);
        }
        if ((err.response.data.message || err.response.data.Message).includes(
          "Email has not verified yet"
        )) {
          router.push(`/resend-verification/${form.email}`);
        }
      });
    };
    const handleLoginError = () => {
      console.error("Login failed");
    };
    const { isReady, login } = useTokenClient({
      onSuccess: handleLoginSuccess,
      onError: handleLoginError
      // other options
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Textinput = __nuxt_component_1;
      const _component_NuxtLink = __nuxt_component_0;
      const _component_AppButton = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "pt-10 lg:pt-0 w-full max-w-[500px] mx-auto" }, _attrs))}><h1 class="text-[#333] darks:text-white mb-[10px] text-3xl font-bold"> Welcome back </h1><p class="mb-[31px] text-sm text-[#666] darks:text-white/80"> Please enter your details to sign in </p><form><div class="mb-5">`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        icon: "line-md:email",
        placeholder: "",
        label: "Email",
        type: "email",
        name: "email"
      }, unref(emailAtt), {
        modelValue: unref(email),
        "onUpdate:modelValue": ($event) => isRef(email) ? email.value = $event : null,
        error: unref(errors).email
      }), null, _parent));
      _push(`</div><div class="mb-5">`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        hasicon: "",
        placeholder: "",
        label: "Password",
        type: "password",
        name: "password",
        modelValue: unref(password),
        "onUpdate:modelValue": ($event) => isRef(password) ? password.value = $event : null
      }, unref(passwordAtt), {
        error: unref(errors).password
      }), null, _parent));
      _push(`</div><span class="block text-sm text-[#333] darks:text-white/80 mb-10">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/auth/forgot-password",
        class: "font-medium"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Forgot password?`);
          } else {
            return [
              createTextVNode("Forgot password?")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</span><div class="grid gap-y-[22px] mb-9">`);
      _push(ssrRenderComponent(_component_AppButton, {
        type: "submit",
        isLoading: unref(isLoading),
        isDisabled: unref(isLoading),
        text: "Login",
        btnClass: "btn-primary !py-3"
      }, null, _parent));
      _push(ssrRenderComponent(_component_AppButton, {
        disabled: !unref(isReady),
        onClick: () => unref(login)(),
        text: "Sign in with Google",
        icon: "flat-color-icons:google",
        btnClass: "btn-dark !py-3 disabled:opacity-50",
        type: "button"
      }, null, _parent));
      _push(`</div><span class="flex items-center text-center text-sm text-[#333] darks:text-white/80 gap-x-1 justify-center"> Don\u2019t have an account? `);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/auth/register",
        class: "font-semibold text-[#2176FF]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Sign Up`);
          } else {
            return [
              createTextVNode("Sign Up")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</span></form></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/auth/login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=login-jys_es0D.mjs.map
