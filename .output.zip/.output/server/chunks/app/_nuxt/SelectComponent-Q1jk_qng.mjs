import { useSSRContext, ref, computed, watch, unref, mergeProps, withCtx, openBlock, createBlock, toDisplayString, createVNode, createCommentVNode, withDirectives, vModelText, Fragment, renderList, Transition } from 'vue';
import { ssrRenderComponent, ssrRenderClass, ssrInterpolate, ssrRenderAttr, ssrRenderList } from 'vue/server-renderer';
import { Listbox, ListboxButton, ListboxOptions, ListboxOption } from '@headlessui/vue';
import { CheckIcon } from '@heroicons/vue/24/solid';

const _sfc_main = {
  __name: "SelectComponent",
  __ssrInlineRender: true,
  props: {
    options: {
      type: Array
    },
    placeholder: {
      default: "Select"
    },
    classStyles: {
      type: String
    },
    showSearch: {
      type: Boolean,
      default: false
    },
    value: {
      default: ""
    },
    containerStyle: {
      type: String
    }
  },
  emits: ["onGetData"],
  setup(__props, { emit: __emit }) {
    const emits = __emit;
    const props = __props;
    const selectedoption = ref(null);
    const query = ref("");
    const filteredOption = computed(() => {
      if (!query.value)
        return props.options;
      return props.options.filter((item) => {
        return item.name.toLowerCase().includes(query.value.toLowerCase());
      });
    });
    watch(
      () => props.value,
      () => {
        if (props.value) {
          selectedoption.value = props.options.find((item) => {
            return item.value.toLowerCase() == props.value.toLowerCase();
          });
        }
      }
    );
    watch(selectedoption, () => {
      if (selectedoption.value) {
        emits("onGetData", selectedoption.value);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(Listbox), mergeProps({
        modelValue: selectedoption.value,
        "onUpdate:modelValue": ($event) => selectedoption.value = $event
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="${ssrRenderClass([__props.containerStyle, "relative w-full"])}"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ListboxButton), {
              class: [__props.classStyles, "relative w-full cursor-default rounded-full min-h-[40px] border border-[#D0D5DD] bg-white p-6 pr-8 text-left shadow-[0px_1px_2px_rgba(16,24,40,0.05)] sm:text-[14px] flex items-center"]
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  if (selectedoption.value) {
                    _push3(`<span class="block text-[#101828] text-[14px]"${_scopeId2}>${ssrInterpolate(selectedoption.value.name)}</span>`);
                  } else {
                    _push3(`<span class="block text-[#8F8C9A] text-[14px]"${_scopeId2}>${ssrInterpolate(__props.placeholder)}</span>`);
                  }
                  _push3(`<span class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2"${_scopeId2}><i class="uil uil-angle-down absolute right-2 appearance-none"${_scopeId2}></i></span>`);
                } else {
                  return [
                    selectedoption.value ? (openBlock(), createBlock("span", {
                      key: 0,
                      class: "block text-[#101828] text-[14px]"
                    }, toDisplayString(selectedoption.value.name), 1)) : (openBlock(), createBlock("span", {
                      key: 1,
                      class: "block text-[#8F8C9A] text-[14px]"
                    }, toDisplayString(__props.placeholder), 1)),
                    createVNode("span", { class: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" }, [
                      createVNode("i", { class: "uil uil-angle-down absolute right-2 appearance-none" })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ListboxOptions), { class: "absolute mt-1 w-full border border-gray-200 z-40 rounded-lg bg-white py-4 text-xs shadow-lg ring-1 ring-black ring-opacity-5 outline-0 sm:text-[13px]" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  if (__props.showSearch) {
                    _push3(`<div class="relative flex items-center mb-2 mt-3 px-4"${_scopeId2}><input${ssrRenderAttr("value", query.value)} placeholder="Search" class="text-xs rounded-lg px-3 py-1 h-10 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"${_scopeId2}></div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`<div class="max-h-60 overflow-y-auto py-2 px-3"${_scopeId2}><!--[-->`);
                  ssrRenderList(filteredOption.value, (option) => {
                    _push3(ssrRenderComponent(unref(ListboxOption), {
                      key: option.name,
                      value: option,
                      as: "template"
                    }, {
                      default: withCtx(({ active, selected }, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<li class="${ssrRenderClass([
                            active ? "bg-gray-100" : "",
                            "relative select-none py-2 px-2 rounded text-loft-black hover:bg-gray-100 cursor-pointer"
                          ])}"${_scopeId3}><span class="${ssrRenderClass([[selected ? "font-medium" : "font-normal", "block"], "sm:text-[13px] leading-normal"])}"${_scopeId3}>${ssrInterpolate(option.name)}</span>`);
                          if (selected) {
                            _push4(`<span class="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-700"${_scopeId3}>`);
                            _push4(ssrRenderComponent(unref(CheckIcon), {
                              class: "h-5 w-5",
                              "aria-hidden": "true"
                            }, null, _parent4, _scopeId3));
                            _push4(`</span>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          _push4(`</li>`);
                        } else {
                          return [
                            createVNode("li", {
                              class: [
                                active ? "bg-gray-100" : "",
                                "relative select-none py-2 px-2 rounded text-loft-black hover:bg-gray-100 cursor-pointer"
                              ]
                            }, [
                              createVNode("span", {
                                class: [[selected ? "font-medium" : "font-normal", "block"], "sm:text-[13px] leading-normal"]
                              }, toDisplayString(option.name), 3),
                              selected ? (openBlock(), createBlock("span", {
                                key: 0,
                                class: "absolute inset-y-0 right-0 pr-4 flex items-center text-gray-700"
                              }, [
                                createVNode(unref(CheckIcon), {
                                  class: "h-5 w-5",
                                  "aria-hidden": "true"
                                })
                              ])) : createCommentVNode("", true)
                            ], 2)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                  if (!filteredOption.value.length) {
                    _push3(`<div class="text-sm text-center text-gray-400"${_scopeId2}> No options available </div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div>`);
                } else {
                  return [
                    __props.showSearch ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "relative flex items-center mb-2 mt-3 px-4"
                    }, [
                      withDirectives(createVNode("input", {
                        "onUpdate:modelValue": ($event) => query.value = $event,
                        placeholder: "Search",
                        class: "text-xs rounded-lg px-3 py-1 h-10 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, query.value]
                      ])
                    ])) : createCommentVNode("", true),
                    createVNode("div", { class: "max-h-60 overflow-y-auto py-2 px-3" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(filteredOption.value, (option) => {
                        return openBlock(), createBlock(unref(ListboxOption), {
                          key: option.name,
                          value: option,
                          as: "template"
                        }, {
                          default: withCtx(({ active, selected }) => [
                            createVNode("li", {
                              class: [
                                active ? "bg-gray-100" : "",
                                "relative select-none py-2 px-2 rounded text-loft-black hover:bg-gray-100 cursor-pointer"
                              ]
                            }, [
                              createVNode("span", {
                                class: [[selected ? "font-medium" : "font-normal", "block"], "sm:text-[13px] leading-normal"]
                              }, toDisplayString(option.name), 3),
                              selected ? (openBlock(), createBlock("span", {
                                key: 0,
                                class: "absolute inset-y-0 right-0 pr-4 flex items-center text-gray-700"
                              }, [
                                createVNode(unref(CheckIcon), {
                                  class: "h-5 w-5",
                                  "aria-hidden": "true"
                                })
                              ])) : createCommentVNode("", true)
                            ], 2)
                          ]),
                          _: 2
                        }, 1032, ["value"]);
                      }), 128)),
                      !filteredOption.value.length ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "text-sm text-center text-gray-400"
                      }, " No options available ")) : createCommentVNode("", true)
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", {
                class: ["relative w-full", __props.containerStyle]
              }, [
                createVNode(unref(ListboxButton), {
                  class: [__props.classStyles, "relative w-full cursor-default rounded-full min-h-[40px] border border-[#D0D5DD] bg-white p-6 pr-8 text-left shadow-[0px_1px_2px_rgba(16,24,40,0.05)] sm:text-[14px] flex items-center"]
                }, {
                  default: withCtx(() => [
                    selectedoption.value ? (openBlock(), createBlock("span", {
                      key: 0,
                      class: "block text-[#101828] text-[14px]"
                    }, toDisplayString(selectedoption.value.name), 1)) : (openBlock(), createBlock("span", {
                      key: 1,
                      class: "block text-[#8F8C9A] text-[14px]"
                    }, toDisplayString(__props.placeholder), 1)),
                    createVNode("span", { class: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" }, [
                      createVNode("i", { class: "uil uil-angle-down absolute right-2 appearance-none" })
                    ])
                  ]),
                  _: 1
                }, 8, ["class"]),
                createVNode(Transition, {
                  "leave-active-class": "transition duration-100 ease-in",
                  "leave-from-class": "opacity-100",
                  "leave-to-class": "opacity-0"
                }, {
                  default: withCtx(() => [
                    createVNode("div", null, [
                      createVNode(unref(ListboxOptions), { class: "absolute mt-1 w-full border border-gray-200 z-40 rounded-lg bg-white py-4 text-xs shadow-lg ring-1 ring-black ring-opacity-5 outline-0 sm:text-[13px]" }, {
                        default: withCtx(() => [
                          __props.showSearch ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "relative flex items-center mb-2 mt-3 px-4"
                          }, [
                            withDirectives(createVNode("input", {
                              "onUpdate:modelValue": ($event) => query.value = $event,
                              placeholder: "Search",
                              class: "text-xs rounded-lg px-3 py-1 h-10 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, query.value]
                            ])
                          ])) : createCommentVNode("", true),
                          createVNode("div", { class: "max-h-60 overflow-y-auto py-2 px-3" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(filteredOption.value, (option) => {
                              return openBlock(), createBlock(unref(ListboxOption), {
                                key: option.name,
                                value: option,
                                as: "template"
                              }, {
                                default: withCtx(({ active, selected }) => [
                                  createVNode("li", {
                                    class: [
                                      active ? "bg-gray-100" : "",
                                      "relative select-none py-2 px-2 rounded text-loft-black hover:bg-gray-100 cursor-pointer"
                                    ]
                                  }, [
                                    createVNode("span", {
                                      class: [[selected ? "font-medium" : "font-normal", "block"], "sm:text-[13px] leading-normal"]
                                    }, toDisplayString(option.name), 3),
                                    selected ? (openBlock(), createBlock("span", {
                                      key: 0,
                                      class: "absolute inset-y-0 right-0 pr-4 flex items-center text-gray-700"
                                    }, [
                                      createVNode(unref(CheckIcon), {
                                        class: "h-5 w-5",
                                        "aria-hidden": "true"
                                      })
                                    ])) : createCommentVNode("", true)
                                  ], 2)
                                ]),
                                _: 2
                              }, 1032, ["value"]);
                            }), 128)),
                            !filteredOption.value.length ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "text-sm text-center text-gray-400"
                            }, " No options available ")) : createCommentVNode("", true)
                          ])
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  _: 1
                })
              ], 2)
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/forms/SelectComponent.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main;

export { __nuxt_component_2 as _ };
//# sourceMappingURL=SelectComponent-Q1jk_qng.mjs.map
