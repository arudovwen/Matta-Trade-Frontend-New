import { _ as __nuxt_component_1 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-fc3HHrvA.mjs';
import { mergeProps, withCtx, openBlock, createBlock, createVNode, createCommentVNode, toDisplayString, Fragment, createTextVNode, renderSlot, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderClass, ssrRenderComponent, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';

const _sfc_main = {
  components: {},
  name: "Button",
  props: {
    text: {
      type: String,
      default: ""
    },
    isDisabled: {
      type: Boolean,
      default: false
    },
    isLoading: {
      type: Boolean,
      default: false
    },
    btnClass: {
      type: String,
      default: "bg-primary-500  text-white"
    },
    icon: {
      type: String,
      default: ""
    },
    iconPosition: {
      type: String,
      default: "left"
    },
    iconClass: {
      type: String,
      default: "text-[20px]"
    },
    loadingClass: {
      type: String,
      default: ""
    },
    link: {
      type: String,
      default: ""
    },
    div: {
      type: Boolean,
      default: false
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_AppIcon = __nuxt_component_1;
  const _component_NuxtLink = __nuxt_component_0;
  _push(`<!--[-->`);
  if (!$props.link && !$props.div) {
    _push(`<button${ssrRenderAttrs(mergeProps({
      disabled: $props.isDisabled,
      class: [`
      ${$props.isLoading ? " pointer-events-none" : ""}
      ${$props.isDisabled ? " opacity-40 cursor-not-allowed" : ""}
      ${$props.btnClass}
      `, "btn inline-flex justify-center"]
    }, _ctx.$attrs))}>`);
    if (!$props.isLoading && !_ctx.$slots.default) {
      _push(`<span class="flex items-center">`);
      if ($props.icon) {
        _push(`<span class="${ssrRenderClass(`
            ${$props.iconPosition === "right" ? "order-1 ml-2" : " "}
            ${$props.text && $props.iconPosition === "left" ? "mr-2" : ""}
            
            ${$props.iconClass}
            
            `)}">`);
        _push(ssrRenderComponent(_component_AppIcon, { icon: $props.icon }, null, _parent));
        _push(`</span>`);
      } else {
        _push(`<!---->`);
      }
      if ($props.text) {
        _push(`<span>${ssrInterpolate($props.text)}</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</span>`);
    } else {
      _push(`<!---->`);
    }
    if ($props.isLoading) {
      _push(`<!--[--><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="${ssrRenderClass([$props.loadingClass, "animate-spin -ml-1 mr-3 h-5 w-5"])}"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Loading ... <!--]-->`);
    } else {
      _push(`<!---->`);
    }
    if (_ctx.$slots.default && !$props.isLoading) {
      _push(`<div>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    } else {
      _push(`<!---->`);
    }
    _push(`</button>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.link && !$props.div) {
    _push(ssrRenderComponent(_component_NuxtLink, {
      to: $props.link,
      class: ["btn inline-flex justify-center", `
      ${$props.isLoading ? " pointer-events-none" : ""}
      ${$props.isDisabled ? " opacity-40 cursor-not-allowed" : ""}
      ${$props.btnClass}
      `]
    }, {
      default: withCtx((_, _push2, _parent2, _scopeId) => {
        if (_push2) {
          if (!$props.isLoading && !_ctx.$slots.default) {
            _push2(`<span class="flex items-center"${_scopeId}>`);
            if ($props.icon) {
              _push2(`<span class="${ssrRenderClass(`
            ${$props.iconPosition === "right" ? "order-1 ml-2" : " "}
            ${$props.text && $props.iconPosition === "left" ? "mr-2" : ""}
            
            ${$props.iconClass}
            
            `)}"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_AppIcon, { icon: $props.icon }, null, _parent2, _scopeId));
              _push2(`</span>`);
            } else {
              _push2(`<!---->`);
            }
            if ($props.text) {
              _push2(`<span${_scopeId}>${ssrInterpolate($props.text)}</span>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</span>`);
          } else {
            _push2(`<!---->`);
          }
          if ($props.isLoading) {
            _push2(`<!--[--><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="${ssrRenderClass([$props.loadingClass, "animate-spin -ml-1 mr-3 h-5 w-5"])}"${_scopeId}><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"${_scopeId}></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"${_scopeId}></path></svg> Loading ... <!--]-->`);
          } else {
            _push2(`<!---->`);
          }
          if (_ctx.$slots.default && !$props.isLoading) {
            _push2(`<div${_scopeId}>`);
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
            _push2(`</div>`);
          } else {
            _push2(`<!---->`);
          }
        } else {
          return [
            !$props.isLoading && !_ctx.$slots.default ? (openBlock(), createBlock("span", {
              key: 0,
              class: "flex items-center"
            }, [
              $props.icon ? (openBlock(), createBlock("span", {
                key: 0,
                class: `
            ${$props.iconPosition === "right" ? "order-1 ml-2" : " "}
            ${$props.text && $props.iconPosition === "left" ? "mr-2" : ""}
            
            ${$props.iconClass}
            
            `
              }, [
                createVNode(_component_AppIcon, { icon: $props.icon }, null, 8, ["icon"])
              ], 2)) : createCommentVNode("", true),
              $props.text ? (openBlock(), createBlock("span", { key: 1 }, toDisplayString($props.text), 1)) : createCommentVNode("", true)
            ])) : createCommentVNode("", true),
            $props.isLoading ? (openBlock(), createBlock(Fragment, { key: 1 }, [
              (openBlock(), createBlock("svg", {
                class: ["animate-spin -ml-1 mr-3 h-5 w-5", $props.loadingClass],
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24"
              }, [
                createVNode("circle", {
                  class: "opacity-25",
                  cx: "12",
                  cy: "12",
                  r: "10",
                  stroke: "currentColor",
                  "stroke-width": "4"
                }),
                createVNode("path", {
                  class: "opacity-75",
                  fill: "currentColor",
                  d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                })
              ], 2)),
              createTextVNode(" Loading ... ")
            ], 64)) : createCommentVNode("", true),
            _ctx.$slots.default && !$props.isLoading ? (openBlock(), createBlock("div", { key: 2 }, [
              renderSlot(_ctx.$slots, "default")
            ])) : createCommentVNode("", true)
          ];
        }
      }),
      _: 3
    }, _parent));
  } else {
    _push(`<!---->`);
  }
  if ($props.div && !$props.link) {
    _push(`<div class="${ssrRenderClass([`
      ${$props.isLoading ? " pointer-events-none" : ""}
      ${$props.isDisabled ? " opacity-40 cursor-not-allowed" : ""}
      ${$props.btnClass}
      `, "btn inline-flex justify-center"])}">`);
    if (!$props.isLoading && !_ctx.$slots.default) {
      _push(`<span class="flex items-center">`);
      if ($props.icon) {
        _push(`<span class="${ssrRenderClass(`
            ${$props.iconPosition === "right" ? "order-1 ml-2" : " "}
            ${$props.text && $props.iconPosition === "left" ? "mr-2" : ""}
            
            ${$props.iconClass}
            
            `)}">`);
        _push(ssrRenderComponent(_component_AppIcon, { icon: $props.icon }, null, _parent));
        _push(`</span>`);
      } else {
        _push(`<!---->`);
      }
      if ($props.text) {
        _push(`<span>${ssrInterpolate($props.text)}</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</span>`);
    } else {
      _push(`<!---->`);
    }
    if ($props.isLoading) {
      _push(`<!--[--><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="${ssrRenderClass([$props.loadingClass, "animate-spin -ml-1 mr-3 h-5 w-5"])}"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Loading ... <!--]-->`);
    } else {
      _push(`<!---->`);
    }
    if (_ctx.$slots.default && !$props.isLoading) {
      _push(`<div>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    } else {
      _push(`<!---->`);
    }
    _push(`</div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<!--]-->`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/AppButton.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_4 as _ };
//# sourceMappingURL=AppButton-rwP1M0KN.mjs.map
