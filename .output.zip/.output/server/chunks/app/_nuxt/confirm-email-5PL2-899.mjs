import { useSSRContext, ref, resolveComponent, mergeProps, unref, withCtx, createVNode } from 'vue';
import { u as useRoute } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { CheckCircleIcon, XMarkIcon } from '@heroicons/vue/24/outline';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$1 = {
  __name: "EmailVerification",
  __ssrInlineRender: true,
  setup(__props) {
    const current = ref("pending");
    useRoute();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-[#E7EBEE] p-6 flex flex-col gap-y-2 h-screen w-full overflow-y-auto justify-center items-center" }, _attrs))} data-v-861c190e>`);
      if (unref(current) == "verified") {
        _push(`<div class="rounded-[20px] bg-white p-6 lg:p-10 shadow-lg text-center w-[300px] max-w-[400px]" data-v-861c190e>`);
        _push(ssrRenderComponent(unref(CheckCircleIcon), { class: "w-32 h-32 text-[#59B221] mx-auto" }, null, _parent));
        _push(`<h3 class="text-xl font-medium text-matta-black mb-6" data-v-861c190e>Email verified</h3>`);
        _push(ssrRenderComponent(_component_router_link, { to: "/auth/login" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<button class="appearance-none leading-none px-10 py-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase" data-v-861c190e${_scopeId}> Back to login </button>`);
            } else {
              return [
                createVNode("button", { class: "appearance-none leading-none px-10 py-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase" }, " Back to login ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(current) == "pending") {
        _push(`<div class="rounded-[20px] bg-white p-6 lg:p-10 shadow-lg text-center w-[300px] max-w-[400px]" data-v-861c190e><i class="fa fa-spinner fa-spin fa-6x mx-auto mb-6" aria-hidden="true" data-v-861c190e></i><h3 class="text-xl font-medium text-matta-black mb-6" data-v-861c190e> Verifying email.. </h3></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(current) == "failed") {
        _push(`<div class="rounded-[20px] bg-white p-6 lg:p-10 shadow-lg text-center w-[300px] max-w-[400px]" data-v-861c190e>`);
        _push(ssrRenderComponent(unref(XMarkIcon), { class: "w-32 h-32 text-red-500 mx-auto" }, null, _parent));
        _push(`<h3 class="text-xl font-medium text-matta-black mb-6" data-v-861c190e> Verification failed </h3>`);
        _push(ssrRenderComponent(_component_router_link, { to: "/auth/login" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<button class="appearance-none leading-none px-10 py-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase" data-v-861c190e${_scopeId}> Back to login </button>`);
            } else {
              return [
                createVNode("button", { class: "appearance-none leading-none px-10 py-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase" }, " Back to login ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/EmailVerification.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-861c190e"]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_EmailVerification = __nuxt_component_0;
  _push(`<div${ssrRenderAttrs(_attrs)}>`);
  _push(ssrRenderComponent(_component_EmailVerification, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/confirm-email.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const confirmEmail = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { confirmEmail as default };
//# sourceMappingURL=confirm-email-5PL2-899.mjs.map
