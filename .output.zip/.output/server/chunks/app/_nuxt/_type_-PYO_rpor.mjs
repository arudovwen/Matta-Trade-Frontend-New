import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0$2 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_1$1 } from './Stepper-MEQwgjWs.mjs';
import { u as useRoute, z as useRequestEvent, h as useRuntimeConfig } from '../server.mjs';
import { useSSRContext, ref, reactive, inject, mergeProps, unref, withCtx, isRef, createVNode, computed, provide } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderList, ssrInterpolate, ssrRenderAttr, ssrRenderClass, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import { _ as __nuxt_component_0$1 } from './index-oCDvIFtd.mjs';
import { C as CurrencyInput } from './CurrencyInput-krSh-4ij.mjs';
import { _ as __nuxt_component_4 } from './index-RMKHVahR.mjs';
import { _ as __nuxt_component_1 } from './index-eSH9oSpY.mjs';
import { _ as __nuxt_component_4$1 } from './AppButton-rwP1M0KN.mjs';
import { useForm } from 'vee-validate';
import * as yup from 'yup';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import { _ as __nuxt_component_1$2 } from './AppIcon-D3CPABPP.mjs';
import { s as sectors, _ as __nuxt_component_3$1 } from './FileUpload-oHb-LYnL.mjs';
import { H as getRequestURL, j as joinURL } from '../../nitro/node-server.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';
import 'vue-currency-input';
import '../../rollup/_vue.mjs';
import 'cleave.js';
import './nuxt-link-fc3HHrvA.mjs';
import '@iconify/vue';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';

function useRequestURL() {
  {
    const url = getRequestURL(useRequestEvent());
    url.pathname = joinURL(useRuntimeConfig().app.baseURL, url.pathname);
    return url;
  }
}
const _sfc_main$7 = {
  __name: "LoanRequest",
  __ssrInlineRender: true,
  setup(__props) {
    const isLoading = ref(false);
    const formValues = reactive({
      amount: null,
      tenor: "",
      about: ""
    });
    const active = inject("active");
    const schema = yup.object({
      amount: yup.string().required("Amount is required"),
      tenor: yup.string().required("Tenor is required"),
      about: yup.string().required("About is required")
    });
    const { handleSubmit, defineField, errors, setFieldValue } = useForm({
      validationSchema: schema,
      initialValues: formValues
    });
    const [amount, amountAtt] = defineField("amount");
    const [tenor, tenorAtt] = defineField("tenor");
    const [about, aboutAtt] = defineField("about");
    const formData = inject("formData");
    handleSubmit((values) => {
      console.log("\u{1F680} ~ onSubmit ~ values:", values);
      formData.loanRequest = values;
      active.value = 2;
    });
    const options = [
      {
        label: "1 month",
        value: 0
      },
      {
        label: "3 month",
        value: 1
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormGroup = __nuxt_component_0$1;
      const _component_CurrencyInput = CurrencyInput;
      const _component_Select = __nuxt_component_4;
      const _component_Textinput = __nuxt_component_1;
      const _component_AppButton = __nuxt_component_4$1;
      _push(`<form${ssrRenderAttrs(mergeProps({ class: "w-full mt-6" }, _attrs))} data-v-aa3143d9><div class="grid grid-cols-2 gap-x-[25px] gap-y-4 mb-[50px]" data-v-aa3143d9>`);
      _push(ssrRenderComponent(_component_FormGroup, {
        label: "How much do you require?",
        error: unref(errors).amount
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_CurrencyInput, {
              min: "1",
              class: `outline-none px-[14px] py-[10px] min-w-[180px] w-full !bg-white border !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).amount ? "border-red-500" : "border-[#D0D5DD]"}`,
              modelValue: unref(amount),
              "onUpdate:modelValue": ($event) => isRef(amount) ? amount.value = $event : null,
              options: {
                currency: "ngn",
                currencyDisplay: "hidden"
              }
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_CurrencyInput, {
                min: "1",
                class: `outline-none px-[14px] py-[10px] min-w-[180px] w-full !bg-white border !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).amount ? "border-red-500" : "border-[#D0D5DD]"}`,
                modelValue: unref(amount),
                "onUpdate:modelValue": ($event) => isRef(amount) ? amount.value = $event : null,
                options: {
                  currency: "ngn",
                  currencyDisplay: "hidden"
                }
              }, null, 8, ["class", "modelValue", "onUpdate:modelValue"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_FormGroup, {
        label: "Tenor",
        error: unref(errors).tenor,
        name: "tenor"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Select, {
              modelValue: unref(tenor),
              "onUpdate:modelValue": ($event) => isRef(tenor) ? tenor.value = $event : null,
              options,
              placeholder: "Select tenor",
              classInput: `min-w-[180px] !bg-white  !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).tenor ? "border-red-500" : "border-[#D0D5DD]"}`
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Select, {
                modelValue: unref(tenor),
                "onUpdate:modelValue": ($event) => isRef(tenor) ? tenor.value = $event : null,
                options,
                placeholder: "Select tenor",
                classInput: `min-w-[180px] !bg-white  !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).tenor ? "border-red-500" : "border-[#D0D5DD]"}`
              }, null, 8, ["modelValue", "onUpdate:modelValue", "classInput"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="md:col-span-2" data-v-aa3143d9>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Where did you hear about us?",
        name: "about"
      }, unref(aboutAtt), {
        modelValue: unref(about),
        "onUpdate:modelValue": ($event) => isRef(about) ? about.value = $event : null,
        error: unref(errors).about
      }), null, _parent));
      _push(`</div></div><div class="flex gap-x-4 items-center justify-end" data-v-aa3143d9>`);
      _push(ssrRenderComponent(_component_AppButton, {
        disabled: unref(isLoading),
        isLoading: unref(isLoading),
        btnClass: "bg-primary-500 text-white !px-16  !text-sm !py-[10px] disabled:cursor-not-allowed",
        type: "submit",
        text: "Next"
      }, null, _parent));
      _push(`</div></form>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/FinanceRequest/Trade/LoanRequest.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const LoanRequest = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["__scopeId", "data-v-aa3143d9"]]);
const _sfc_main$6 = {
  props: {
    placeholder: {
      type: String,
      default: "message"
    },
    label: {
      type: String
    },
    classLabel: {
      type: String,
      default: " "
    },
    classInput: {
      type: String,
      default: "classinput"
    },
    name: {
      type: String
    },
    modelValue: {
      type: String,
      default: ""
    },
    error: {
      type: String
    },
    isReadonly: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    },
    rows: {
      type: Number,
      default: 3
    },
    horizontal: {
      type: Boolean,
      default: false
    },
    validate: {
      type: String
    },
    msgTooltip: {
      type: Boolean,
      default: false
    },
    description: {
      type: String
    }
  },
  data() {
    return {
      types: this.type
    };
  },
  methods: {
    toggleType() {
      this.types = this.types === "text" ? "password" : "text";
    }
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_AppIcon = __nuxt_component_1$2;
  _push(`<div${ssrRenderAttrs(mergeProps({
    class: ["fromGroup relative", `${$props.error ? "has-error" : ""}  ${$props.horizontal ? "flex" : ""} ${$props.validate ? "is-valid" : ""} `]
  }, _attrs))}>`);
  if ($props.label) {
    _push(`<label class="${ssrRenderClass(`${$props.classLabel}  ${$props.horizontal ? "flex-0 mr-6 md:w-[100px] w-[60px] break-words" : ""}  inline-block input-label `)}"${ssrRenderAttr("for", $props.name)}>${ssrInterpolate($props.label)}</label>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<div class="${ssrRenderClass([$props.horizontal ? "flex-1" : "", "relative"])}"><textarea${ssrRenderAttr("name", $props.name)}${ssrRenderAttr("placeholder", $props.placeholder)} class="${ssrRenderClass(`${$props.classInput} input-control block w-full focus:outline-none pt-3 resize-none`)}"${ssrRenderAttr("error", $props.error)}${ssrRenderAttr("id", $props.name)}${ssrIncludeBooleanAttr($props.isReadonly) ? " readonly" : ""}${ssrIncludeBooleanAttr($props.disabled) ? " disabled" : ""}${ssrRenderAttr("rows", $props.rows)}${ssrRenderAttr("validate", $props.validate)}>${ssrInterpolate($props.modelValue)}</textarea><div class="flex text-xl absolute right-[14px] top-1/2 -translate-y-1/2">`);
  if ($props.error) {
    _push(`<span class="text-danger-500">`);
    _push(ssrRenderComponent(_component_AppIcon, { icon: "heroicons-outline:information-circle" }, null, _parent));
    _push(`</span>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.validate) {
    _push(`<span class="text-success-500">`);
    _push(ssrRenderComponent(_component_AppIcon, { icon: "bi:check-lg" }, null, _parent));
    _push(`</span>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div>`);
  if ($props.error) {
    _push(`<span class="${ssrRenderClass([
      $props.msgTooltip ? " inline-block bg-danger-500 text-white text-[10px] px-2 py-1 rounded" : " text-danger-500 block text-sm",
      "mt-2"
    ])}">${ssrInterpolate($props.error)}</span>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.validate) {
    _push(`<span class="${ssrRenderClass([
      $props.msgTooltip ? " inline-block bg-success-500 text-white text-[10px] px-2 py-1 rounded" : " text-success-500 block text-sm",
      "mt-2"
    ])}">${ssrInterpolate($props.validate)}</span>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.description) {
    _push(`<span class="block text-secondary-500 font-light leading-4 text-xs mt-2">${ssrInterpolate($props.description)}</span>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div>`);
}
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Textarea/index.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$5 = {
  __name: "Kyb",
  __ssrInlineRender: true,
  setup(__props) {
    const mappedSectors = computed(
      () => sectors.map((i) => ({ label: i.name, value: i.name }))
    );
    const isLoading = ref(false);
    const formValues = reactive({
      companyName: "",
      sector: "",
      date: "",
      businessType: "",
      address: "",
      productDesc: "",
      statusReport: "",
      incorporation: "",
      mermat: "",
      utilityBill: ""
    });
    const active = inject("active");
    const formSchema = yup.object().shape({
      companyName: yup.string().required("Company Name is required"),
      sector: yup.string().required("Sector is required"),
      date: yup.date().typeError("Invalid date").nullable().required("Date is required"),
      // Assuming date is a date type
      businessType: yup.string().required("Business Type is required"),
      address: yup.string().required("Address is required"),
      productDesc: yup.string().required("Product Description is required"),
      statusReport: yup.string().required("Status Report is required"),
      incorporation: yup.string().required("Incorporation is required"),
      // Assuming incorporation is a date type
      mermat: yup.string().required("Mermat is required"),
      utilityBill: yup.string().required("Utility Bill is required")
    });
    const { handleSubmit, defineField, errors, setFieldValue } = useForm({
      validationSchema: formSchema,
      initialValues: formValues
    });
    const [companyName, companyNameAtt] = defineField("companyName");
    const [sector, sectorAtt] = defineField("sector");
    const [date, dateAtt] = defineField("date");
    const [businessType, businessTypeAtt] = defineField("businessType");
    const [address, addressAtt] = defineField("address");
    const [productDesc, productDescAtt] = defineField("productDesc");
    function handleChange(id, value) {
      setFieldValue(id, value);
    }
    const formData = inject("formData");
    handleSubmit((values) => {
      console.log("\u{1F680} ~ onSubmit ~ values:", values);
      formData.kyb = values;
      active.value = 3;
    });
    const businessTypes = [
      {
        label: "Type A",
        value: 0
      },
      {
        label: "Type B",
        value: 1
      }
    ];
    provide("handleChange", handleChange);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Textinput = __nuxt_component_1;
      const _component_FormGroup = __nuxt_component_0$1;
      const _component_Select = __nuxt_component_4;
      const _component_Textarea = __nuxt_component_3;
      const _component_FileUpload = __nuxt_component_3$1;
      const _component_AppButton = __nuxt_component_4$1;
      _push(`<form${ssrRenderAttrs(mergeProps({ class: "w-full mt-6" }, _attrs))} data-v-2a58efaa><div class="grid grid-cols-2 gap-x-[25px] gap-y-4 mb-[50px]" data-v-2a58efaa>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Company name",
        name: "companyName"
      }, unref(companyNameAtt), {
        modelValue: unref(companyName),
        "onUpdate:modelValue": ($event) => isRef(companyName) ? companyName.value = $event : null,
        error: unref(errors).companyName
      }), null, _parent));
      _push(ssrRenderComponent(_component_FormGroup, {
        label: "Business type",
        error: unref(errors).businessType,
        name: "businessType"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Select, {
              modelValue: unref(businessType),
              "onUpdate:modelValue": ($event) => isRef(businessType) ? businessType.value = $event : null,
              options: businessTypes,
              placeholder: "Select type",
              classInput: `min-w-[180px] !bg-white  !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).tenor ? "border-red-500" : "border-[#D0D5DD]"}`
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Select, {
                modelValue: unref(businessType),
                "onUpdate:modelValue": ($event) => isRef(businessType) ? businessType.value = $event : null,
                options: businessTypes,
                placeholder: "Select type",
                classInput: `min-w-[180px] !bg-white  !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).tenor ? "border-red-500" : "border-[#D0D5DD]"}`
              }, null, 8, ["modelValue", "onUpdate:modelValue", "classInput"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Date of incorporation",
        name: "date",
        type: "date"
      }, unref(dateAtt), {
        modelValue: unref(date),
        "onUpdate:modelValue": ($event) => isRef(date) ? date.value = $event : null,
        error: unref(errors).date
      }), null, _parent));
      _push(ssrRenderComponent(_component_FormGroup, {
        label: "Sector",
        error: unref(errors).tenor,
        name: "sector"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Select, {
              modelValue: unref(sector),
              "onUpdate:modelValue": ($event) => isRef(sector) ? sector.value = $event : null,
              options: unref(mappedSectors),
              placeholder: "Select sector",
              classInput: `min-w-[180px] !bg-white  !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).tenor ? "border-red-500" : "border-[#D0D5DD]"}`
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Select, {
                modelValue: unref(sector),
                "onUpdate:modelValue": ($event) => isRef(sector) ? sector.value = $event : null,
                options: unref(mappedSectors),
                placeholder: "Select sector",
                classInput: `min-w-[180px] !bg-white  !rounded-lg !text-[#475467] !h-11 cursor-pointer ${unref(errors).tenor ? "border-red-500" : "border-[#D0D5DD]"}`
              }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "classInput"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="md:col-span-2" data-v-2a58efaa>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Business address",
        name: "address"
      }, unref(addressAtt), {
        modelValue: unref(address),
        "onUpdate:modelValue": ($event) => isRef(address) ? address.value = $event : null,
        error: unref(errors).address
      }), null, _parent));
      _push(`</div><div class="md:col-span-2" data-v-2a58efaa>`);
      _push(ssrRenderComponent(_component_Textarea, mergeProps({
        placeholder: "",
        label: "Brief description of the product",
        name: "productDesc"
      }, unref(productDescAtt), {
        modelValue: unref(productDesc),
        "onUpdate:modelValue": ($event) => isRef(productDesc) ? productDesc.value = $event : null,
        error: unref(errors).productDesc
      }), null, _parent));
      _push(`</div><label class="mb-2 mt-3 font-medium text-sm block" data-v-2a58efaa>Company documents <span class="text-[#B9B9B9]" data-v-2a58efaa>(Optional)</span></label>`);
      _push(ssrRenderComponent(_component_FormGroup, {
        error: unref(errors).mermat,
        class: "col-span-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FileUpload, {
              label: "Memorandum and Articles of Association",
              id: "mermat"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_FileUpload, {
                label: "Memorandum and Articles of Association",
                id: "mermat"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_FormGroup, {
        error: unref(errors).incorporation,
        class: "col-span-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FileUpload, {
              label: "Certificate of Incorporation",
              id: "incorporation"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_FileUpload, {
                label: "Certificate of Incorporation",
                id: "incorporation"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_FormGroup, {
        error: unref(errors).statusReport,
        class: "col-span-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FileUpload, {
              label: "CAC Status Report",
              id: "statusReport"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_FileUpload, {
                label: "CAC Status Report",
                id: "statusReport"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_FormGroup, {
        error: unref(errors).utilityBill,
        class: "col-span-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FileUpload, {
              label: "Utility bill",
              id: "utilityBill"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_FileUpload, {
                label: "Utility bill",
                id: "utilityBill"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex gap-x-4 items-center justify-between" data-v-2a58efaa>`);
      _push(ssrRenderComponent(_component_AppButton, {
        onClick: ($event) => active.value--,
        btnClass: "bg-white text-white !px-11  !text-sm !py-[10px] disabled:cursor-not-allowed border border-[#BDC0C5] !rounded-lg !text-[#333]",
        type: "button",
        text: "Previous"
      }, null, _parent));
      _push(ssrRenderComponent(_component_AppButton, {
        disabled: unref(isLoading),
        isLoading: unref(isLoading),
        btnClass: "bg-primary-500 text-white !px-16  !text-sm !py-[10px] disabled:cursor-not-allowed border  !rounded-lg border-primary-500",
        type: "submit",
        text: "Next"
      }, null, _parent));
      _push(`</div></form>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/FinanceRequest/Trade/Kyb.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const Kyb = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-2a58efaa"]]);
const _sfc_main$4 = {
  __name: "Documents",
  __ssrInlineRender: true,
  setup(__props) {
    const isLoading = ref(false);
    const formValues = reactive({
      previousExport: "",
      doneBusiness: "",
      other: "",
      bankStatement: "",
      proformaInvoice: "",
      evidence: ""
    });
    const active = inject("active");
    const formSchema = yup.object().shape({
      previousExport: yup.string().required("Previous Export is required"),
      doneBusiness: yup.string().required("Previous Business is required"),
      other: yup.string(),
      // Optional field, no specific validation provided
      bankStatement: yup.string().required("Bank Statement is required"),
      proformaInvoice: yup.string().required("Proforma Invoice is required"),
      evidence: yup.string().required("Evidence is required")
    });
    const { handleSubmit, defineField, errors, setFieldValue } = useForm({
      validationSchema: formSchema,
      initialValues: formValues
    });
    const [doneBusiness, doneBusinessAtt] = defineField("doneBusiness");
    const [previousExport, previousExportAtt] = defineField("previousExport");
    const formData = inject("formData");
    handleSubmit((values) => {
      console.log("\u{1F680} ~ onSubmit ~ values:", values);
      formData.documents = values;
      active.value = 5;
    });
    function handleChange(id, value) {
      setFieldValue(id, value);
    }
    provide("handleChange", handleChange);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormGroup = __nuxt_component_0$1;
      const _component_FileUpload = __nuxt_component_3$1;
      const _component_Textinput = __nuxt_component_1;
      const _component_AppButton = __nuxt_component_4$1;
      _push(`<form${ssrRenderAttrs(mergeProps({ class: "w-full mt-6" }, _attrs))} data-v-36e96caf><div class="grid grid-cols-2 gap-x-[25px] gap-y-4 mb-[50px]" data-v-36e96caf>`);
      _push(ssrRenderComponent(_component_FormGroup, {
        error: unref(errors).bankStatement,
        class: "col-span-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FileUpload, {
              label: "Bank Statement",
              id: "bankStatement"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_FileUpload, {
                label: "Bank Statement",
                id: "bankStatement"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_FormGroup, {
        error: unref(errors).proformaInvoice,
        class: "col-span-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FileUpload, {
              label: "Proforma Invoice",
              id: "proformaInvoice"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_FileUpload, {
                label: "Proforma Invoice",
                id: "proformaInvoice"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_FormGroup, {
        error: unref(errors).other,
        class: "col-span-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FileUpload, {
              label: "Evidence of previously successful supply contracts (PO and Paid Invoices)",
              id: "evidence"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_FileUpload, {
                label: "Evidence of previously successful supply contracts (PO and Paid Invoices)",
                id: "evidence"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_FormGroup, {
        error: unref(errors).other,
        class: "col-span-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FileUpload, {
              label: "Other documents",
              id: "other"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_FileUpload, {
                label: "Other documents",
                id: "other"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="md:col-span-2" data-v-36e96caf>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Have you done business with the buyer before?",
        name: "doneBusiness"
      }, unref(doneBusinessAtt), {
        modelValue: unref(doneBusiness),
        "onUpdate:modelValue": ($event) => isRef(doneBusiness) ? doneBusiness.value = $event : null,
        error: unref(errors).doneBusiness
      }), null, _parent));
      _push(`</div><div class="md:col-span-2" data-v-36e96caf>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Have you previously exported to the order\u2019s country of destination?",
        name: "previousExport"
      }, unref(previousExportAtt), {
        modelValue: unref(previousExport),
        "onUpdate:modelValue": ($event) => isRef(previousExport) ? previousExport.value = $event : null,
        error: unref(errors).previousExport
      }), null, _parent));
      _push(`</div></div><div class="flex gap-x-4 items-center justify-between" data-v-36e96caf>`);
      _push(ssrRenderComponent(_component_AppButton, {
        btnClass: "bg-white text-white !px-11  !text-sm !py-[10px] disabled:cursor-not-allowed border border-[#BDC0C5] !rounded-lg !text-[#333]",
        type: "button",
        text: "Previous",
        onClick: ($event) => active.value--
      }, null, _parent));
      _push(ssrRenderComponent(_component_AppButton, {
        disabled: unref(isLoading),
        isLoading: unref(isLoading),
        btnClass: "bg-primary-500 text-white !px-16  !text-sm !py-[10px] disabled:cursor-not-allowed border  !rounded-lg border-primary-500",
        type: "submit",
        text: "Next"
      }, null, _parent));
      _push(`</div></form>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/FinanceRequest/Trade/Documents.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const Documents = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-36e96caf"]]);
const _sfc_main$3 = {
  __name: "Directors",
  __ssrInlineRender: true,
  setup(__props) {
    const selected = ref("");
    const isLoading = ref(false);
    const directors = ref([]);
    const formValues = reactive({
      name: "",
      bvn: "",
      email: "",
      phoneNumber: "",
      linkedin: "",
      id: "",
      signature: ""
    });
    const active = inject("active");
    const formSchema = yup.object().shape({
      name: yup.string().required("Name is required"),
      bvn: yup.string().required("BVN is required").matches(/^\d{11}$/, "BVN must be 11 digits"),
      email: yup.string().required("Email is required").email("Invalid email address"),
      phoneNumber: yup.string().required("Phone Number is required").matches(/^\d{11}$/, "Phone Number must be 11 digits"),
      linkedin: yup.string().url("Invalid LinkedIn URL"),
      id: yup.string().required("ID is required"),
      signature: yup.string().required("Signature is required")
    });
    const { handleSubmit, defineField, errors, setFieldValue } = useForm({
      validationSchema: formSchema,
      initialValues: formValues
    });
    const [name, nameAtt] = defineField("name");
    const [bvn, bvnAtt] = defineField("bvn");
    const [email, emailAtt] = defineField("email");
    const [phoneNumber, phoneNumberAtt] = defineField("phoneNumber");
    const [linkedin, linkedinAtt] = defineField("linkedin");
    function handleChange(id, value) {
      setFieldValue(id, value);
    }
    const formData = inject("formData");
    handleSubmit((values) => {
      console.log("\u{1F680} ~ onSubmit ~ values:", values);
      directors.value = [...directors.value, values];
      formData.directors = directors.value;
    });
    const directorOptions = [
      {
        label: "James Bond",
        value: 0
      },
      {
        label: "Jason Momoa",
        value: 1
      }
    ];
    provide("handleChange", handleChange);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_FormGroup = __nuxt_component_0$1;
      const _component_Select = __nuxt_component_4;
      const _component_Textinput = __nuxt_component_1;
      const _component_FileUpload = __nuxt_component_3$1;
      const _component_AppButton = __nuxt_component_4$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-full mt-6" }, _attrs))} data-v-ce59ca1d><form class="grid grid-cols-2 gap-x-[25px] gap-y-4 mb-[50px]" data-v-ce59ca1d>`);
      _push(ssrRenderComponent(_component_FormGroup, {
        label: "Select a director from your profile or add a new director",
        name: "selected",
        class: "col-span-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Select, {
              modelValue: unref(selected),
              "onUpdate:modelValue": ($event) => isRef(selected) ? selected.value = $event : null,
              options: directorOptions,
              placeholder: "Select director",
              classInput: `min-w-[180px] !bg-white  !rounded-lg !text-[#475467] !h-11 cursor-pointer`
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Select, {
                modelValue: unref(selected),
                "onUpdate:modelValue": ($event) => isRef(selected) ? selected.value = $event : null,
                options: directorOptions,
                placeholder: "Select director",
                classInput: `min-w-[180px] !bg-white  !rounded-lg !text-[#475467] !h-11 cursor-pointer`
              }, null, 8, ["modelValue", "onUpdate:modelValue"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Full Name",
        name: "name"
      }, unref(nameAtt), {
        modelValue: unref(name),
        "onUpdate:modelValue": ($event) => isRef(name) ? name.value = $event : null,
        error: unref(errors).name
      }), null, _parent));
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "bvn",
        name: "bvn"
      }, unref(bvnAtt), {
        modelValue: unref(bvn),
        "onUpdate:modelValue": ($event) => isRef(bvn) ? bvn.value = $event : null,
        error: unref(errors).bvn
      }), null, _parent));
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Email",
        name: "email"
      }, unref(emailAtt), {
        modelValue: unref(email),
        "onUpdate:modelValue": ($event) => isRef(email) ? email.value = $event : null,
        error: unref(errors).email
      }), null, _parent));
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Phone number",
        name: "phoneNumber"
      }, unref(phoneNumberAtt), {
        modelValue: unref(phoneNumber),
        "onUpdate:modelValue": ($event) => isRef(phoneNumber) ? phoneNumber.value = $event : null,
        error: unref(errors).phoneNumber
      }), null, _parent));
      _push(`<div class="md:col-span-2" data-v-ce59ca1d>`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        placeholder: "",
        label: "Linkedin",
        name: "linkedin"
      }, unref(linkedinAtt), {
        modelValue: unref(linkedin),
        "onUpdate:modelValue": ($event) => isRef(linkedin) ? linkedin.value = $event : null,
        error: unref(errors).linkedin
      }), null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_FormGroup, {
        error: unref(errors).id,
        class: "col-span-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FileUpload, {
              label: "Upload ID (Passport, Driver\u2019s License, or NIN)",
              id: "id"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_FileUpload, {
                label: "Upload ID (Passport, Driver\u2019s License, or NIN)",
                id: "id"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_FormGroup, {
        error: unref(errors).signature,
        class: "col-span-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_FileUpload, {
              label: "Upload Signature",
              id: "signature"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_FileUpload, {
                label: "Upload Signature",
                id: "signature"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="flex itemx-center gap-x-2 mb-6" data-v-ce59ca1d><button type="submit" class="appearance-none leading-none px-[14px] py-[10px] grid-cols-1 lg:grid-cols-2 gap-4 rounded-lg text-primary-500 border border-primary-500 hover:opacity-70 text-xs" data-v-ce59ca1d><span class="" data-v-ce59ca1d> + Add another director</span></button><span class="text-[#B9B9B9]" data-v-ce59ca1d>(Optional)</span></div>`);
      if (unref(directors).length) {
        _push(`<div class="w-full rounded-[10px] border border-[#EAECF0] overflow-hidden" data-v-ce59ca1d><table class="w-full" data-v-ce59ca1d><thead data-v-ce59ca1d><tr data-v-ce59ca1d><th class="capitalize text-[#475467] text-sm text-left font-medium border-b py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-ce59ca1d> Name </th><th class="capitalize text-[#475467] text-sm text-left font-medium border-b py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-ce59ca1d></th></tr></thead><tbody data-v-ce59ca1d><!--[-->`);
        ssrRenderList(unref(directors), (director, id) => {
          _push(`<tr class="border-b last:border-none" data-v-ce59ca1d><td class="text-matta-black text-sm font-normal py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-ce59ca1d>${ssrInterpolate(director == null ? void 0 : director.name)}</td><td class="text-matta-black text-sm font-normal py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-ce59ca1d><span class="flex gap-x-3 items-center justify-end" data-v-ce59ca1d><span class="p-1" data-v-ce59ca1d><i class="uil uil-pen" data-v-ce59ca1d></i></span><span class="p-1" data-v-ce59ca1d><i class="uil uil-trash text-red-500" data-v-ce59ca1d></i></span></span></td></tr>`);
        });
        _push(`<!--]--></tbody></table></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</form><div class="flex gap-x-4 items-center justify-between" data-v-ce59ca1d>`);
      _push(ssrRenderComponent(_component_AppButton, {
        onClick: ($event) => active.value--,
        btnClass: "bg-white text-white !px-11  !text-sm !py-[10px] disabled:cursor-not-allowed border border-[#BDC0C5] !rounded-lg !text-[#333]",
        type: "button",
        text: "Previous"
      }, null, _parent));
      _push(ssrRenderComponent(_component_AppButton, {
        disabled: unref(isLoading) || !unref(directors).length,
        isLoading: unref(isLoading),
        btnClass: "bg-primary-500 text-white !px-16  !text-sm !py-[10px] disabled:cursor-not-allowed border  !rounded-lg border-primary-500",
        type: "button",
        text: "Next"
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/FinanceRequest/Trade/Directors.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const Directors = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-ce59ca1d"]]);
const _imports_0 = "" + publicAssetsURL("images/sent.png");
const _sfc_main$2 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_AppButton = __nuxt_component_4$1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-10 mt-20 flex flex-col justify-center items-center" }, _attrs))}><img${ssrRenderAttr("src", _imports_0)} class="mx-auto mb-2"><h1 class="mb-3 font-semibold text-2xl text-[#333]">Request Sent</h1><p class="text-sm text-[#444] mb-4 max-w-[363px] mx-auto"> Your request has been sent and will be reviewed. You will be contacted via mail or phone call on the next steps </p>`);
  _push(ssrRenderComponent(_component_AppButton, {
    link: "/financing/requests",
    btnClass: "bg-primary-500 text-white !px-16  !text-sm !py-[10px] disabled:cursor-not-allowed border  !rounded-lg border-primary-500",
    type: "button",
    text: "Return to Homepage"
  }, null, _parent));
  _push(`</div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/FinanceRequest/Trade/Final.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const Final = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main$1 = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const { type } = route.params;
    const formData = reactive({
      loanRequest: null,
      kyb: null,
      directors: null,
      documents: null
    });
    const active = ref(1);
    const tabs = [
      {
        name: "Loan request",
        value: 1
      },
      {
        name: "KYB",
        value: 2
      },
      {
        name: "Directors",
        value: 3
      },
      {
        name: "Documents",
        value: 4
      }
    ];
    provide("active", active);
    provide("formData", formData);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderComponent = __nuxt_component_0$2;
      const _component_Stepper = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "gap-y-2 flex flex-col bg-white rounded-[10px] border border-[#F4F7FE] py-[30px]" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_HeaderComponent, {
        title: `${unref(type)} Financing request`,
        canGoback: true
      }, null, _parent));
      if (unref(active) !== 5) {
        _push(`<div class="py-10">`);
        _push(ssrRenderComponent(_component_Stepper, { tabs }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(active) !== 5) {
        _push(`<div class="max-w-[576px] mx-auto w-full">`);
        if (unref(active) === 1) {
          _push(ssrRenderComponent(unref(LoanRequest), null, null, _parent));
        } else {
          _push(`<!---->`);
        }
        if (unref(active) === 2) {
          _push(ssrRenderComponent(unref(Kyb), null, null, _parent));
        } else {
          _push(`<!---->`);
        }
        if (unref(active) === 4) {
          _push(ssrRenderComponent(unref(Documents), null, null, _parent));
        } else {
          _push(`<!---->`);
        }
        if (unref(active) === 3) {
          _push(ssrRenderComponent(unref(Directors), null, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(active) === 5) {
        _push(ssrRenderComponent(unref(Final), null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/FinanceRequest/Trade/index.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$1;
const _sfc_main = {
  __name: "[type]",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const url = useRequestURL();
    console.log("\u{1F680} ~ route:", url.pathname);
    console.log("\u{1F680} ~ route:", route.params.type);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierFinanceRequestTrade = __nuxt_component_0;
      _push(ssrRenderComponent(_component_SupplierFinanceRequestTrade, _attrs, null, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/financing/requests/[type].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_type_-PYO_rpor.mjs.map
