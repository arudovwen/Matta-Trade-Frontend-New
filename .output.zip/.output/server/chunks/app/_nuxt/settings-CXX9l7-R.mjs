import { _ as __nuxt_component_0$1 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_1 } from './nuxt-img-qJohECzX.mjs';
import { P as PhoneCodes } from './PhoneCodes-TGlMinMT.mjs';
import { C as CountriesSelect } from './CountriesSelect-jqw8V4-X.mjs';
import { S as StatesSelect } from './StatesSelect-GYPQgjHx.mjs';
import { d as useAuthStore } from '../server.mjs';
import { useSSRContext, ref, reactive, computed, mergeProps, unref } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderAttr, ssrRenderClass, ssrRenderList, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderDynamicModel } from 'vue/server-renderer';
import { EyeIcon, EyeSlashIcon } from '@heroicons/vue/24/outline';
import { useRoute } from 'vue-router';
import moment from 'moment-timezone';
import useVuelidate from '@vuelidate/core';
import { helpers, required, minLength, maxLength, email, numeric } from '@vuelidate/validators';
import { c as countries } from './countries-4zSrMx8v.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './AppButton-rwP1M0KN.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import '@headlessui/vue';
import 'country-list-with-dial-code-and-flag';
import 'unhead';
import '@unhead/shared';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue3-toastify';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$1 = {
  __name: "SettingsComponent",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    useAuthStore();
    ref("");
    ref("crop");
    ref(false);
    ref("");
    const image = ref(null);
    ref(null);
    ref(null);
    useRoute();
    const isOpen = ref(false);
    const zones = moment.tz.names();
    const abbrs = {
      EST: "Eastern Standard Time",
      EDT: "Eastern Daylight Time",
      CST: "Central Standard Time",
      CDT: "Central Daylight Time",
      MST: "Mountain Standard Time",
      MDT: "Mountain Daylight Time",
      PST: "Pacific Standard Time",
      PDT: "Pacific Daylight Time",
      GMT: "Greenwich Mean Time",
      CAT: "Central Africa Time",
      WAT: "Western Africa Time",
      EAT: "Eastern Africa Time",
      EET: "Eastern European Time"
    };
    moment.fn.zoneName = function() {
      var abbr = this.zoneAbbr();
      return abbrs[abbr] || abbr;
    };
    const isLoading = ref(false);
    const form = reactive({
      photo: "",
      firstName: "",
      lastName: "",
      country: "",
      city: "",
      email: "",
      phone: "",
      timezone: "",
      code: "+234"
    });
    const newform = reactive({
      oldPassword: "",
      newPassword: "",
      confirmPassword: ""
    });
    const validPassword = (value) => {
      let res = /[a-z]/.test(value) && /[A-Z]/.test(value) && /[0-9]/.test(value);
      return res;
    };
    const specialPassword = (value) => {
      let res = /[@&!%#$%]/.test(value);
      return res;
    };
    const samePassword = (value) => value === newform.newPassword;
    const newrules = {
      oldPassword: {
        required: helpers.withMessage("Password field cannot be empty", required),
        minLength: minLength(8),
        maxLength: maxLength(16),
        validPassword: helpers.withMessage(
          "Password must include UPPER/lowercase characters and number",
          validPassword
        ),
        specialPassword: helpers.withMessage(
          "Password must contain at least 1 of the special  characters @&!-%#$%",
          specialPassword
        )
      },
      newPassword: {
        required: helpers.withMessage("Password field cannot be empty", required),
        minLength: minLength(8),
        maxLength: maxLength(16),
        validPassword: helpers.withMessage(
          "Password must include UPPER/lowercase characters and number",
          validPassword
        ),
        specialPassword: helpers.withMessage(
          "Password must contain at least 1 of the special  characters @&!-%#$%",
          specialPassword
        )
      },
      confirmPassword: {
        required: helpers.withMessage(
          "Confirm Password field cannot be empty",
          required
        ),
        minLength: minLength(8),
        maxLength: maxLength(16),
        validPassword: helpers.withMessage(
          "Confirm Password is invalid",
          validPassword
        ),
        samePassword: helpers.withMessage("Passwords do not match!", samePassword)
      }
    };
    const states = computed(() => {
      if (!form.country)
        return [];
      return countries.find(
        (item) => form.country.toLowerCase() === item.name.toLowerCase()
      ).states || [];
    });
    const validPhoneLength = (value) => form.code === "+234" ? value.length > 9 && value.length < 12 : true;
    const rules = {
      email: {
        required,
        email: helpers.withMessage("Email is invalid", email),
        maxLength: maxLength(50)
      },
      firstName: {
        required,
        maxLength: maxLength(50)
      },
      lastName: {
        required,
        maxLength: maxLength(50)
      },
      country: {
        required,
        maxLength: maxLength(50)
      },
      city: {
        required,
        maxLength: maxLength(50)
      },
      phone: {
        numeric,
        required,
        validPhoneLength: helpers.withMessage(
          "Phone number must be between 10 0r 11 digits",
          validPhoneLength
        )
      },
      timezone: {
        required,
        maxLength: maxLength(250)
      },
      photo: {
        required
      }
    };
    computed(() => {
      return `${form.firstName} ${form.lastName}`;
    });
    const v$ = useVuelidate(rules, form);
    const newv$ = useVuelidate(newrules, newform);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderComponent = __nuxt_component_0$1;
      const _component_NuxtImg = __nuxt_component_1;
      const _component_FormsPhoneCodes = PhoneCodes;
      const _component_FormsCountriesSelect = CountriesSelect;
      const _component_FormsStatesSelect = StatesSelect;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "gap-y-2 flex flex-col pb-10 bg-white rounded-[10px]" }, _attrs))} data-v-7c0f88bd><div class="" data-v-7c0f88bd>`);
      _push(ssrRenderComponent(_component_HeaderComponent, { title: "Profile information" }, null, _parent));
      _push(`<div class="flex gap-x-[76px] pt-[30px] px-4 lg:px-[30px] flex-col lg:flex-row gap-y-7 lg:gap-y-" data-v-7c0f88bd><div class="w-[300px]" data-v-7c0f88bd><h2 class="text-sm text-[#101828] font-semibold" data-v-7c0f88bd>Personal info</h2><p class="text-xs text-[#475467]" data-v-7c0f88bd> Update your photo and personal details here. </p></div><div class="flex-1" data-v-7c0f88bd><div class="flex gap-x-3 items-center mb-10" data-v-7c0f88bd><div class="flex items-center" data-v-7c0f88bd><span data-v-7c0f88bd>`);
      if (!unref(image)) {
        _push(`<span class="h-24 w-24 rounded-full flex items-center text-sm justify-center bg-[#F1F3F5]" data-v-7c0f88bd>Photo</span>`);
      } else {
        _push(ssrRenderComponent(_component_NuxtImg, {
          src: unref(image),
          class: "h-24 w-24 rounded-full flex items-center justify-center bg-[#F1F3F5]"
        }, null, _parent));
      }
      _push(`</span></div><div class="flex items-center gap-x-3" data-v-7c0f88bd><label for="upload" data-v-7c0f88bd><span class="text-[#344054] rounded-full px-1 py-3 text-sm cursor-pointer" data-v-7c0f88bd> Upload photo </span><input type="file" accept="image/*" id="upload" class="hidden" data-v-7c0f88bd></label></div></div><form data-v-7c0f88bd><div data-v-7c0f88bd><div class="grid lg:grid-cols-2 gap-x-6" data-v-7c0f88bd><div class="mb-6" data-v-7c0f88bd><label class="mb-2 font-normal text-sm block" data-v-7c0f88bd>First name</label><input${ssrRenderAttr("value", unref(v$).firstName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).firstName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" data-v-7c0f88bd><!--[-->`);
      ssrRenderList(unref(v$).firstName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-7c0f88bd><div class="error-msg text-error text-sm font-semibold" data-v-7c0f88bd>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6" data-v-7c0f88bd><label class="mb-2 font-normal text-sm block" data-v-7c0f88bd>Last name</label><input${ssrRenderAttr("value", unref(v$).lastName.$model)} class="${ssrRenderClass([{ "border-red-500": unref(v$).lastName.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}" autocomplete="off" autofocus="on" data-v-7c0f88bd><!--[-->`);
      ssrRenderList(unref(v$).lastName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-7c0f88bd><div class="error-msg text-error text-sm font-semibold" data-v-7c0f88bd>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="grid lg:grid-cols-2 gap-x-6" data-v-7c0f88bd><div class="mb-6" data-v-7c0f88bd><label class="mb-2 font-normal text-sm block" data-v-7c0f88bd>E-mail</label><div class="flex relative items-center" data-v-7c0f88bd><input${ssrRenderAttr("value", unref(form).email)} class="rounded-lg px-[14px] py-[10px] h-11 w-full border placeholder:text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" autofocus="on" disabled readonnly data-v-7c0f88bd><i class="uil uil-lock absolute right-4 text-gray-600" data-v-7c0f88bd></i></div><!--[-->`);
      ssrRenderList(unref(v$).email.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-7c0f88bd><div class="error-msg text-error text-sm font-semibold" data-v-7c0f88bd>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6" data-v-7c0f88bd><label class="mb-2 font-normal text-sm block" data-v-7c0f88bd>Phone number</label><div class="flex relative rounded-lg h-11" data-v-7c0f88bd>`);
      _push(ssrRenderComponent(_component_FormsPhoneCodes, {
        modelValue: unref(form).code,
        "onUpdate:modelValue": ($event) => unref(form).code = $event
      }, null, _parent));
      _push(`<input class="${ssrRenderClass([{ "border-red-500": unref(v$).phone.$error }, "flex-1 rounded-r-lg px-[14px] py-[10px] h-11 w-full border placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}"${ssrRenderAttr("value", unref(v$).phone.$model)} autocomplete="off" autofocus="on" placeholder="08160723884" type="tel" data-v-7c0f88bd></div><!--[-->`);
      ssrRenderList(unref(v$).phone.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-7c0f88bd><div class="error-msg text-error text-sm font-semibold" data-v-7c0f88bd>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="grid lg:grid-cols-2 gap-x-6" data-v-7c0f88bd><div class="mb-6" data-v-7c0f88bd><label class="mb-2 font-normal text-sm block" data-v-7c0f88bd>Country</label><div class="flex relative" data-v-7c0f88bd>`);
      _push(ssrRenderComponent(_component_FormsCountriesSelect, {
        modelValue: unref(v$).country.$model,
        "onUpdate:modelValue": ($event) => unref(v$).country.$model = $event
      }, null, _parent));
      _push(`<!--[-->`);
      ssrRenderList(unref(v$).country.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-7c0f88bd><div class="error-msg text-error text-sm font-semibold" data-v-7c0f88bd>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="mb-6" data-v-7c0f88bd><label class="mb-2 font-normal text-sm block" data-v-7c0f88bd>State</label>`);
      _push(ssrRenderComponent(_component_FormsStatesSelect, {
        modelValue: unref(v$).city.$model,
        "onUpdate:modelValue": ($event) => unref(v$).city.$model = $event,
        states: unref(states)
      }, null, _parent));
      _push(`<!--[-->`);
      ssrRenderList(unref(v$).city.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-7c0f88bd><div class="error-msg text-error text-sm font-semibold" data-v-7c0f88bd>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="" data-v-7c0f88bd><div class="mb-6" data-v-7c0f88bd><label class="mb-2 font-normal text-sm block" data-v-7c0f88bd>Timezone</label><div class="flex relative items-center w-full" data-v-7c0f88bd><select class="appearance-none rounded-lg px-[14px] py-[10px] h-11 w-full border placeholder:text-[#B6B7B9]" data-v-7c0f88bd><!--[-->`);
      ssrRenderList(unref(zones), (z) => {
        _push(`<option data-v-7c0f88bd> (${ssrInterpolate(unref(moment).tz(/* @__PURE__ */ new Date(), z).format("z - Z"))}) ${ssrInterpolate(unref(moment).tz(/* @__PURE__ */ new Date(), z).format("zz"))} ${ssrInterpolate(z)}</option>`);
      });
      _push(`<!--]--></select><i class="uil uil-sort absolute right-3 pointer-events-none" data-v-7c0f88bd></i></div></div></div><div class="mt-6 flex justify-end" data-v-7c0f88bd><button${ssrIncludeBooleanAttr(unref(isLoading)) ? " disabled" : ""} class="${ssrRenderClass([unref(isLoading) && "bg-primary/80", "border border-primary-500 text-sm bg-primary-500 text-white rounded-[10px] block w-full lg:w-auto px-10 font-semibold py-[10px] hover:bg-primary/80"])}" type="submit" data-v-7c0f88bd> Save changes </button></div></div></form></div></div><hr class="my-10 border-[#F4F7FE]" data-v-7c0f88bd><div class="flex gap-x-[76px] px-4 lg:px-[30px] flex-col lg:flex-row gap-y-7 lg:gap-y-" data-v-7c0f88bd><div class="w-[300px]" data-v-7c0f88bd><h2 class="text-sm text-[#101828] font-semibold" data-v-7c0f88bd>Password</h2><p class="text-xs text-[#475467]" data-v-7c0f88bd> Please enter your current password to change your password. </p></div><div class="flex-1" data-v-7c0f88bd><form data-v-7c0f88bd><div class="mb-6" data-v-7c0f88bd><label class="mb-2 font-normal text-sm block text-matta-black" data-v-7c0f88bd>Current Password</label><div class="relative flex items-center" data-v-7c0f88bd><input class="${ssrRenderClass([{ "border-red-500": unref(newv$).oldPassword.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}"${ssrRenderDynamicModel(!unref(isOpen) ? "oldPassword" : "text", unref(newv$).oldPassword.$model, null)} placeholder="Password" autocomplete="off"${ssrRenderAttr("type", !unref(isOpen) ? "oldPassword" : "text")} data-v-7c0f88bd>`);
      if (!unref(isOpen)) {
        _push(ssrRenderComponent(unref(EyeIcon), {
          onClick: ($event) => isOpen.value = !unref(isOpen),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      } else {
        _push(ssrRenderComponent(unref(EyeSlashIcon), {
          onClick: ($event) => isOpen.value = !unref(isOpen),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      }
      _push(`</div><!--[-->`);
      ssrRenderList(unref(newv$).oldPassword.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-7c0f88bd><div class="error-msg text-error text-sm font-semibold" data-v-7c0f88bd>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6" data-v-7c0f88bd><label class="mb-2 font-normal text-sm block text-matta-black" data-v-7c0f88bd>New Password</label><div class="relative flex items-center" data-v-7c0f88bd><input class="${ssrRenderClass([{ "border-red-500": unref(newv$).newPassword.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}"${ssrRenderDynamicModel(!unref(isOpen) ? "oldPassword" : "text", unref(newv$).newPassword.$model, null)} placeholder="Password" autocomplete="off"${ssrRenderAttr("type", !unref(isOpen) ? "oldPassword" : "text")} data-v-7c0f88bd>`);
      if (!unref(isOpen)) {
        _push(ssrRenderComponent(unref(EyeIcon), {
          onClick: ($event) => isOpen.value = !unref(isOpen),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      } else {
        _push(ssrRenderComponent(unref(EyeSlashIcon), {
          onClick: ($event) => isOpen.value = !unref(isOpen),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      }
      _push(`</div><!--[-->`);
      ssrRenderList(unref(newv$).newPassword.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-7c0f88bd><div class="error-msg text-error text-sm font-semibold" data-v-7c0f88bd>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-12" data-v-7c0f88bd><label class="mb-2 font-normal text-sm block text-matta-black" data-v-7c0f88bd>Confirm Password</label><div class="relative flex items-center" data-v-7c0f88bd><input class="${ssrRenderClass([{ "border-red-500": unref(newv$).confirmPassword.$error }, "rounded-lg px-[14px] py-[10px] h-11 w-full border placeholder:text-[#B6B7B9] focus:outline-matta-black/20"])}"${ssrRenderDynamicModel(!unref(isOpen) ? "oldPassword" : "text", unref(newv$).confirmPassword.$model, null)} placeholder="Confirm oldPassword" autocomplete="off"${ssrRenderAttr("type", !unref(isOpen) ? "oldPassword" : "text")} data-v-7c0f88bd>`);
      if (!unref(isOpen)) {
        _push(ssrRenderComponent(unref(EyeIcon), {
          onClick: ($event) => isOpen.value = !unref(isOpen),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      } else {
        _push(ssrRenderComponent(unref(EyeSlashIcon), {
          onClick: ($event) => isOpen.value = !unref(isOpen),
          class: "w-4 h-4 absolute cursor-pointer right-6"
        }, null, _parent));
      }
      _push(`</div><!--[-->`);
      ssrRenderList(unref(newv$).confirmPassword.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-7c0f88bd><div class="error-msg text-error text-sm font-semibold" data-v-7c0f88bd>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="flex justify-end" data-v-7c0f88bd><button${ssrIncludeBooleanAttr(unref(isLoading)) ? " disabled" : ""} class="${ssrRenderClass([unref(isLoading) && "bg-primary/80", "border-2 border-primary-500 text-[13px] bg-primary-500 text-white rounded-[10px] block w-full lg:w-auto px-12 font-semibold py-3 hover:bg-primary/80"])}" type="submit" data-v-7c0f88bd> Change password </button></div></form></div></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/SettingsComponent.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-7c0f88bd"]]);
const _sfc_main = {
  __name: "settings",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierSettingsComponent = __nuxt_component_0;
      _push(ssrRenderComponent(_component_SupplierSettingsComponent, _attrs, null, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/account/settings.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=settings-CXX9l7-R.mjs.map
