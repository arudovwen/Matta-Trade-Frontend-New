import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderClass, ssrRenderAttr, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';

const _sfc_main = {
  components: {},
  props: {
    label: {
      type: String
    },
    classLabel: {
      type: String,
      default: " "
    },
    classInput: {
      type: String,
      default: "classinput"
    },
    name: {
      type: String
    },
    error: {
      type: String
    },
    horizontal: {
      type: Boolean,
      default: false
    },
    validate: {
      type: String
    },
    msgTooltip: {
      type: Boolean,
      default: false
    },
    description: {
      type: String
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({
    class: ["formGroup relative w-full md:w-auto", `${$props.error ? "has-error" : ""}  ${$props.horizontal ? "flex" : ""}  ${$props.validate ? "is-valid" : ""} `]
  }, _attrs))}>`);
  if ($props.label) {
    _push(`<label class="${ssrRenderClass(`${$props.classLabel} inline-block input-label `)}"${ssrRenderAttr("for", $props.name)}>${ssrInterpolate($props.label)}</label>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<div class="relative">`);
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`</div>`);
  if ($props.error) {
    _push(`<span class="${ssrRenderClass([
      $props.msgTooltip ? " inline-block bg-danger-500 text-white text-[10px] px-2 py-1 rounded" : " text-danger-500 block text-sm",
      "mt-2"
    ])}">${ssrInterpolate($props.error)}</span>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.validate) {
    _push(`<span class="${ssrRenderClass([
      $props.msgTooltip ? " inline-block bg-success-500 text-white text-[10px] px-2 py-1 rounded" : " text-success-500 block text-sm",
      "mt-2"
    ])}">${ssrInterpolate($props.validate)}</span>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.description) {
    _push(`<span class="block text-secondary-500 font-light leading-4 text-xs mt-2">${ssrInterpolate($props.description)}</span>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/FormGroup/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_0 as _ };
//# sourceMappingURL=index-oCDvIFtd.mjs.map
