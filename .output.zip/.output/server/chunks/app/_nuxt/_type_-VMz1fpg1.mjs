import { useSSRContext, resolveComponent, mergeProps, withCtx, createVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { useRoute } from 'vue-router';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';

const _sfc_main = {
  __name: "[type]",
  __ssrInlineRender: true,
  setup(__props) {
    useRoute();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-[#E7EBEE] p-6 flex flex-col gap-y-2 h-screen w-full overflow-y-auto justify-center items-center" }, _attrs))} data-v-4b5cbb5b><div class="rounded-[20px] bg-white p-6 lg:p-10 shadow-lg text-center max-w-[400px]" data-v-4b5cbb5b><i class="uil uil-check-circle text-[#59B221] mb-8 text-[80px]" data-v-4b5cbb5b></i><h3 class="text-xl font-medium text-matta-black mb-6" data-v-4b5cbb5b> Congratulations! </h3><p class="text-matta-black mb-10" data-v-4b5cbb5b> Thank you! We will contact you shortly to verify your account. </p>`);
      _push(ssrRenderComponent(_component_router_link, { to: "/overview" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button class="appearance-none leading-none px-10 py-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase" data-v-4b5cbb5b${_scopeId}> Proceed to dashboard </button>`);
          } else {
            return [
              createVNode("button", { class: "appearance-none leading-none px-10 py-4 rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase" }, " Proceed to dashboard ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/onboarding/complete/[type].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _type_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-4b5cbb5b"]]);

export { _type_ as default };
//# sourceMappingURL=_type_-VMz1fpg1.mjs.map
