import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0, a as __nuxt_component_1 } from './AppFooter-UymqQBAh.mjs';
import { x as useCookie, d as useAuthStore } from '../server.mjs';
import { u as useCartStore } from './cart-fg4oswtQ.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot, ssrRenderAttr } from 'vue/server-renderer';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './client-only-uY1C8Tgt.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import './nuxt-img-qJohECzX.mjs';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './_plugin-vue_export-helper-yVxbj29m.mjs';
import './AppButton-rwP1M0KN.mjs';
import './data-ZuhAAsy0.mjs';
import '@headlessui/vue';
import './authservices-pXd32gsl.mjs';
import './Center-HbcRsv6_.mjs';
import './IndexModal-vEF7RYpX.mjs';
import '@heroicons/vue/24/solid';
import '@vuelidate/core';
import '@vuelidate/validators';
import 'vue3-toastify';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';
import './cartservice-JuOkMZ9e.mjs';
import './retry-handling-kb1itlan.mjs';

const _imports_0 = "" + buildAssetsURL("whatsapp.11g7H9tU.png");
const _sfc_main = {
  __name: "default",
  __ssrInlineRender: true,
  setup(__props) {
    useCookie("cart");
    useAuthStore();
    useCartStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppHeader = __nuxt_component_0;
      const _component_AppFooter = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-[#F4F4F4] darks:bg-gray-800 relative w-screen" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_AppHeader, null, null, _parent));
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(ssrRenderComponent(_component_AppFooter, null, null, _parent));
      _push(`<a href="https://wa.me/+2349169983235" target="_blank" class="z-[99999]"><button class="fixed bottom-6 transition duration-300 right-4 opacity-80 hover:opacity-100 hover:scale-[1.1]"><img${ssrRenderAttr("src", _imports_0)} width="60" height="60" alt="whatsapp link" class="drop-shadow-lg"></button></a></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=default-fjZRdYPn.mjs.map
