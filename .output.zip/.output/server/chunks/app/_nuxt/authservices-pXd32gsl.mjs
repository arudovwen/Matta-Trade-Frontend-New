import { q as post, r as urls, d as useAuthStore } from '../server.mjs';

async function loginUser(user, config = {}) {
  return await post(urls.LOGIN_USER, user, config);
}
async function logOut() {
  const authStore = useAuthStore();
  authStore.logOut();
}
async function registerUser(user, config = {}) {
  return await post(urls.REGISTER, user, config);
}
async function forgotPassword(user, config = {}) {
  return await post(urls.FORGOT_PASSWORD, user, config);
}
async function resetPassword(user, config = {}) {
  return await post(urls.RESET_PASSWORD, user, config);
}
async function sociallogin(data) {
  return await post(urls.SOCIAL_LOGIN, data);
}
async function sendMessage(data) {
  return await post(urls.CONTACT_USER, data);
}

export { resetPassword as a, logOut as b, sendMessage as c, forgotPassword as f, loginUser as l, registerUser as r, sociallogin as s };
//# sourceMappingURL=authservices-pXd32gsl.mjs.map
