import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_1 } from './index-eSH9oSpY.mjs';
import { _ as __nuxt_component_4 } from './AppButton-rwP1M0KN.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-fc3HHrvA.mjs';
import { ref, mergeProps, unref, isRef, withCtx, createTextVNode, createVNode, useSSRContext } from 'vue';
import { a as useHead, u as useRoute, e as useRouter } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { useForm } from 'vee-validate';
import * as yup from 'yup';
import { toast } from 'vue3-toastify';
import { f as forgotPassword } from './authservices-pXd32gsl.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './AppIcon-D3CPABPP.mjs';
import '@iconify/vue';
import './_plugin-vue_export-helper-yVxbj29m.mjs';
import '../../rollup/_vue.mjs';
import 'cleave.js';
import 'vue-router';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';

const _imports_0 = "" + buildAssetsURL("mail.kNGna4vI.svg");
const title1 = "Forgot password";
const title2 = "Check your email";
const text1 = "Enter the email associated with your account and we\u201Dll send you instructions to reset your password";
const text2 = "We have sent an account activation link to your email address. Click on the link to activate your account.";
const _sfc_main = {
  __name: "forgot-password",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Forgot password | Matta"
    });
    const isSent = ref(false);
    const isLoading = ref(false);
    const formValues = {
      email: ""
    };
    const schema = yup.object({
      email: yup.string().required("Email is required").email("Please enter a valid email address")
    });
    const { handleSubmit, defineField, errors } = useForm({
      validationSchema: schema,
      initialValues: formValues
    });
    const [email, emailAtt] = defineField("email");
    useRoute();
    useRouter();
    handleSubmit((values) => {
      isLoading.value = true;
      forgotPassword(values).then((res) => {
        if (res.status === 200) {
          isSent.value = true;
        }
      }).catch((err) => {
        isLoading.value = false;
        if (err.response.data.message || err.response.data.Message) {
          toast.error(err.response.data.message || err.response.data.Message);
        }
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Textinput = __nuxt_component_1;
      const _component_AppButton = __nuxt_component_4;
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "pt-0 lg:pt-0 max-w-[500px] mx-auto items-center grid flex-1" }, _attrs))}><div class="w-full">`);
      if (unref(isSent)) {
        _push(`<div class="mb-6"><img${ssrRenderAttr("src", _imports_0)} class="mx-auto"></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<h1 class="text-[#333] darks:text-white mb-[10px] text-[28px] font-bold text-center">${ssrInterpolate(unref(isSent) ? title2 : title1)}</h1><p class="mb-[28px] text-sm text-[#666] darks:text-white/80 text-center">${ssrInterpolate(unref(isSent) ? text2 : text1)}</p>`);
      if (!unref(isSent)) {
        _push(`<form><div class="mb-5">`);
        _push(ssrRenderComponent(_component_Textinput, mergeProps({
          icon: "line-md:email",
          placeholder: "",
          label: "Email address",
          type: "email"
        }, unref(emailAtt), {
          modelValue: unref(email),
          "onUpdate:modelValue": ($event) => isRef(email) ? email.value = $event : null,
          error: unref(errors).email
        }), null, _parent));
        _push(`</div><div class="grid gap-y-[22px] mb-9">`);
        _push(ssrRenderComponent(_component_AppButton, {
          type: "submit",
          isLoading: unref(isLoading),
          isDisabled: unref(isLoading),
          text: "Continue",
          btnClass: "btn-primary !py-3"
        }, null, _parent));
        _push(`</div><span class="flex items-center text-center text-sm text-[#333] darks:text-white/80 gap-x-1 justify-center"> Have an account? `);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: "/auth/login",
          class: "font-semibold text-[#2176FF]"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Sign in`);
            } else {
              return [
                createTextVNode("Sign in")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</span></form>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isSent)) {
        _push(`<div class="pt-5">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: "/auth/login",
          class: "w-full"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_AppButton, {
                text: "Return to Login",
                btnClass: "btn-primary !py-3 w-full !normal-case"
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_AppButton, {
                  text: "Return to Login",
                  btnClass: "btn-primary !py-3 w-full !normal-case"
                })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/auth/forgot-password.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=forgot-password-IegXxdzv.mjs.map
