import { _ as __nuxt_component_0$3 } from './HeaderComponent-IydhH04E.mjs';
import { _ as __nuxt_component_1$2 } from './Stepper-MEQwgjWs.mjs';
import { _ as __nuxt_component_1$3 } from './AppLoader-SkdFRsgH.mjs';
import { _ as __nuxt_component_0$2 } from './IndexModal-vEF7RYpX.mjs';
import { F as FeaturedProp, _ as __nuxt_component_2, a as _imports_0, P as Preview } from './filetype-LhTNRnFG.mjs';
import { m as measurements } from './constants-7QnerJ-N.mjs';
import { useSSRContext, reactive, ref, computed, inject, watch, provide, resolveComponent, unref, withCtx, isRef, createVNode, openBlock, createBlock, toDisplayString, createCommentVNode, Fragment, renderList, Transition, withModifiers, createTextVNode, withDirectives, vModelText, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderClass, ssrIncludeBooleanAttr, ssrLooseContain, ssrGetDynamicModelProps } from 'vue/server-renderer';
import { useRoute, useRouter } from 'vue-router';
import { _ as __nuxt_component_1 } from './AppIcon-D3CPABPP.mjs';
import { _ as __nuxt_component_1$1 } from './nuxt-img-qJohECzX.mjs';
import { _ as __unimport_currencyFormat } from './currencyFormat-ET0sIbrj.mjs';
import { _ as __nuxt_component_1$4 } from './index-eSH9oSpY.mjs';
import { C as CurrencyInput } from './CurrencyInput-krSh-4ij.mjs';
import * as yup from 'yup';
import { Combobox, ComboboxInput, ComboboxButton, TransitionRoot, ComboboxOptions, ComboboxOption, Listbox, ListboxButton, ListboxOptions, ListboxOption } from '@headlessui/vue';
import { useForm } from 'vee-validate';
import useVuelidate from '@vuelidate/core';
import { required, maxLength, helpers } from '@vuelidate/validators';
import { toast } from 'vue3-toastify';
import { C as getSupplierProduct, D as addproducer, E as getFeaturedManufacturer } from '../server.mjs';
import { _ as __nuxt_component_0$1 } from './UploadComponent-Lr7bqIOL.mjs';
import { CheckIcon, ChevronUpDownIcon } from '@heroicons/vue/24/solid';
import { C as CountriesSelect } from './CountriesSelect-jqw8V4-X.mjs';
import { S as StatesSelect } from './StatesSelect-GYPQgjHx.mjs';
import { u as uploadfile } from './onboardingservices-NoJPITnD.mjs';
import { c as countries } from './countries-4zSrMx8v.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-yVxbj29m.mjs';
import './AppButton-rwP1M0KN.mjs';
import './nuxt-link-fc3HHrvA.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ipx';
import './index-4NCxcAqd.mjs';
import '@heroicons/vue/24/outline';
import 'vue3-carousel';
import '@tinymce/tinymce-vue';
import '@iconify/vue';
import '../../rollup/_vue.mjs';
import 'cleave.js';
import 'vue-currency-input';
import 'unhead';
import '@unhead/shared';
import 'pinia-plugin-persistedstate';
import 'click-outside-vue3';
import 'vue-toastification';
import 'vue3-clipboard';
import 'vue-devtools-stub';
import 'axios';

const _sfc_main$6 = {
  __name: "PackageForm",
  __ssrInlineRender: true,
  emits: ["close"],
  setup(__props, { emit: __emit }) {
    const emits = __emit;
    const packForm = reactive({
      title: "",
      amount: null,
      color: "",
      purity: "",
      size: "",
      isAvailable: false
    });
    const packageForms = [
      "Plastic drum",
      "Metal drum",
      "Keg",
      "Carton",
      "Bag",
      "Cylinder",
      "Tank"
    ];
    const packFormSchema = yup.object({
      title: yup.string().required(),
      amount: yup.string().required(),
      color: yup.string(),
      purity: yup.number().typeError("Invalid value").max(100, "Maximum is 100"),
      size: yup.number().typeError("Invalid value").required(),
      isAvailable: yup.boolean()
    });
    const { handleSubmit, defineField, errors } = useForm({
      validationSchema: packFormSchema,
      initialValues: packForm
    });
    const form = inject("form");
    const [title, titleAtt] = defineField("title");
    const [amount, amountAtt] = defineField("amount");
    const [color, colorAtt] = defineField("color");
    const [size, sizeAtt] = defineField("size");
    const [isAvailable, isAvailableAtt] = defineField("isAvailable");
    const [purity, purityAtt] = defineField("purity");
    handleSubmit((values) => {
      form.packagesAvailable = [
        ...form.packagesAvailable,
        { ...values, package: { title: values.title } }
      ];
      emits("close");
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1;
      const _component_Textinput = __nuxt_component_1$4;
      const _component_CurrencyInput = CurrencyInput;
      let _temp0;
      _push(`<form${ssrRenderAttrs(mergeProps({ class: "grid bg-white p-10 rounded-[10px]" }, _attrs))}><div class="flex gap-x-5 justify-between items-center mb-4"><legend class="text-[#18273AF0] text-lg font-bold">Add Package</legend><button type="button" class="h-6 w-6 text-[#8C8C8C] bg-[#F5F5F5] rounded-full flex items-center justify-center text-[13px]">`);
      _push(ssrRenderComponent(_component_AppIcon, { icon: "ph:x-bold" }, null, _parent));
      _push(`</button></div><div class="grid relative gap-y-6 mb-7"><div><div class="flex justify-between items-center"><label class="mb-2 font-medium text-sm text-[#344054] block text-left"><span class="text-red-500 mr-[.5px]">*</span> Package name </label></div>`);
      _push(ssrRenderComponent(unref(Listbox), mergeProps({
        modelValue: unref(title),
        "onUpdate:modelValue": ($event) => isRef(title) ? title.value = $event : null
      }, unref(titleAtt), { name: "title" }), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="relative mt-1"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ListboxButton), { class: "relative w-full text-left rounded-lg flex items-center appearance-none px-[14px] py-[10px] h-11 border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span class="block truncate text-sm"${_scopeId2}>${ssrInterpolate(unref(title))}</span><span class="right-0 pr-2 absolute"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_AppIcon, {
                    icon: "ph:caret-down-bold",
                    iconClass: "h-4 w-4 text-[#667085]",
                    "aria-hidden": "true"
                  }, null, _parent3, _scopeId2));
                  _push3(`</span>`);
                } else {
                  return [
                    createVNode("span", { class: "block truncate text-sm" }, toDisplayString(unref(title)), 1),
                    createVNode("span", { class: "right-0 pr-2 absolute" }, [
                      createVNode(_component_AppIcon, {
                        icon: "ph:caret-down-bold",
                        iconClass: "h-4 w-4 text-[#667085]",
                        "aria-hidden": "true"
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(ListboxOptions), { class: "absolute mt-1 w-[200px] z-40 rounded-md bg-white py-4 text-base shadow-lg focus:outline-none sm:text-sm border border-gray-100" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="mx-h-60 overflow-y-auto"${_scopeId2}><!--[-->`);
                  ssrRenderList(packageForms, (p, i) => {
                    _push3(ssrRenderComponent(unref(ListboxOption), {
                      key: i,
                      value: p,
                      as: "template"
                    }, {
                      default: withCtx(({ selected }, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<li class="${ssrRenderClass([
                            "relative cursor-pointer  text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                          ])}"${_scopeId3}><span class="${ssrRenderClass([selected ? "font-medium" : "font-normal"])}"${_scopeId3}>${ssrInterpolate(p)}</span></li>`);
                        } else {
                          return [
                            createVNode("li", { class: [
                              "relative cursor-pointer  text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                            ] }, [
                              createVNode("span", {
                                class: [selected ? "font-medium" : "font-normal"]
                              }, toDisplayString(p), 3)
                            ])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]--></div>`);
                } else {
                  return [
                    createVNode("div", { class: "mx-h-60 overflow-y-auto" }, [
                      (openBlock(), createBlock(Fragment, null, renderList(packageForms, (p, i) => {
                        return createVNode(unref(ListboxOption), {
                          key: i,
                          value: p,
                          as: "template"
                        }, {
                          default: withCtx(({ selected }) => [
                            createVNode("li", { class: [
                              "relative cursor-pointer  text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                            ] }, [
                              createVNode("span", {
                                class: [selected ? "font-medium" : "font-normal"]
                              }, toDisplayString(p), 3)
                            ])
                          ]),
                          _: 2
                        }, 1032, ["value"]);
                      }), 64))
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "relative mt-1" }, [
                createVNode(unref(ListboxButton), { class: "relative w-full text-left rounded-lg flex items-center appearance-none px-[14px] py-[10px] h-11 border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" }, {
                  default: withCtx(() => [
                    createVNode("span", { class: "block truncate text-sm" }, toDisplayString(unref(title)), 1),
                    createVNode("span", { class: "right-0 pr-2 absolute" }, [
                      createVNode(_component_AppIcon, {
                        icon: "ph:caret-down-bold",
                        iconClass: "h-4 w-4 text-[#667085]",
                        "aria-hidden": "true"
                      })
                    ])
                  ]),
                  _: 1
                }),
                createVNode(Transition, {
                  "leave-active-class": "transition duration-100 ease-in",
                  "leave-from-class": "opacity-100",
                  "leave-to-class": "opacity-0"
                }, {
                  default: withCtx(() => [
                    createVNode(unref(ListboxOptions), { class: "absolute mt-1 w-[200px] z-40 rounded-md bg-white py-4 text-base shadow-lg focus:outline-none sm:text-sm border border-gray-100" }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "mx-h-60 overflow-y-auto" }, [
                          (openBlock(), createBlock(Fragment, null, renderList(packageForms, (p, i) => {
                            return createVNode(unref(ListboxOption), {
                              key: i,
                              value: p,
                              as: "template"
                            }, {
                              default: withCtx(({ selected }) => [
                                createVNode("li", { class: [
                                  "relative cursor-pointer  text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                                ] }, [
                                  createVNode("span", {
                                    class: [selected ? "font-medium" : "font-normal"]
                                  }, toDisplayString(p), 3)
                                ])
                              ]),
                              _: 2
                            }, 1032, ["value"]);
                          }), 64))
                        ])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="grid grid-cols-2 gap-x-4 gap-y-6"><div><label class="mb-2 font-medium text-sm text-[#344054] block text-left"><span class="text-red-500 mr-[.5px]">*</span> Size </label><div class="relative flex items-center">`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        modelValue: unref(size),
        "onUpdate:modelValue": ($event) => isRef(size) ? size.value = $event : null
      }, unref(sizeAtt), {
        name: "size",
        placeholder: "",
        type: "text",
        error: unref(errors).size,
        class: "h-11"
      }), null, _parent));
      _push(`<span class="absolute right-2 text-xs">${ssrInterpolate(unref(form).unit)}</span></div></div><div><label class="mb-2 font-medium text-sm text-[#344054] flex items-center gap-x-1 text-left"><span class="text-red-500 mr-[.5px]">*</span><span>Price </span><span data-toggle="tooltip" data-placement="top" title="Please indicate price with respect to the selected unit of measurement" class="cursor-pointer">`);
      _push(ssrRenderComponent(_component_AppIcon, {
        icon: "quill:info",
        iconClass: "text-gray-600"
      }, null, _parent));
      _push(`</span></label><div class="relative"><div class="relative flex items-center">`);
      _push(ssrRenderComponent(_component_CurrencyInput, mergeProps({
        modelValue: unref(amount),
        "onUpdate:modelValue": ($event) => isRef(amount) ? amount.value = $event : null
      }, unref(amountAtt), {
        name: "amount",
        class: "rounded-lg text-sm px-[14px] py-3 h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
        placeholder: "",
        options: {
          currency: "ngn",
          currencyDisplay: "narrowSymbol"
        }
      }), null, _parent));
      _push(`<span class="absolute right-2 text-xs">/${ssrInterpolate(unref(form).unit)}</span></div></div></div><div><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Color </label><div class="flex relative items-center">`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        modelValue: unref(color),
        "onUpdate:modelValue": ($event) => isRef(color) ? color.value = $event : null
      }, unref(colorAtt), {
        name: "color",
        placeholder: "",
        type: "text",
        error: unref(errors).color,
        class: "!h-11"
      }), null, _parent));
      _push(`</div></div><div><label class="mb-2 font-medium text-sm text-[#344054] block text-left">Purity </label><div class="relative"><div class="relative flex items-center">`);
      _push(ssrRenderComponent(_component_Textinput, mergeProps({
        modelValue: unref(purity),
        "onUpdate:modelValue": ($event) => isRef(purity) ? purity.value = $event : null
      }, unref(purityAtt), {
        name: "purity",
        placeholder: "",
        min: "0",
        max: "100",
        error: unref(errors).purity
      }), null, _parent));
      _push(`<span class="absolute right-2 text-xs">%</span></div></div></div></div><div><label for="isAvailable" class="flex item-center leading-[normal]"><input${ssrRenderAttrs((_temp0 = mergeProps({
        id: "isAvailable",
        type: "checkbox",
        class: "mr-2 accent-primary-500",
        checked: Array.isArray(unref(isAvailable)) ? ssrLooseContain(unref(isAvailable), null) : unref(isAvailable)
      }, unref(isAvailableAtt), { name: "isAvailable" }), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, unref(isAvailable)))))}><span>Package is available</span></label></div></div><div class="flex gap-x-4 items-center justify-end"><button type="submit" class="appearance-none leading-none px-10 py-4 w-full rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px]"> Add package </button></div></form>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/AddProduct/PackageForm.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const _sfc_main$5 = {
  __name: "ProductInfo",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    useRouter();
    const producerForm = reactive({
      title: "",
      location: "",
      country: "",
      state: "",
      logo: ""
    });
    reactive({
      Search: "",
      PageSize: 10,
      PageNumber: 1,
      productId: route.query.id
    });
    const isLoadingLogo = ref(false);
    const states = computed(() => {
      if (!producerForm.country)
        return [];
      return countries.find(
        (item) => producerForm.country.toLowerCase() === item.name.toLowerCase()
      ).states || [];
    });
    const getProducers = inject("getProducers");
    const technologies = inject("technologies");
    ref([]);
    const form = inject("form");
    inject("togglePreview");
    const allmarkets = inject("allmarkets");
    const producers = inject("producers");
    const headers = computed(() => [
      "name",
      `size (${form.unit})`,
      `price / ${form.unit}`,
      "color",
      "purity",
      ""
    ]);
    const isAddingPackage = ref(false);
    const isLoading = ref(false);
    ref(measurements[0]);
    let query = ref("");
    let filteredProducers = computed(
      () => query.value === "" ? producers.value : producers.value.filter(
        (i) => i.title.toLowerCase().replace(/\s+/g, "").includes(query.value.toLowerCase().replace(/\s+/g, ""))
      )
    );
    const rules = {
      name: {
        required,
        maxLength: maxLength(100)
      },
      manufacturer: {
        required: helpers.withMessage("Select a producer", required)
      },
      markets: {
        required: helpers.withMessage("Select a market", required)
      },
      marketApplications: {
        required: helpers.withMessage("Select a market application", required)
      },
      techApplications: {
        required: helpers.withMessage("Select a Sub-application", required)
      },
      technologies: {
        required: helpers.withMessage("Select an application", required)
      },
      description: {
        maxLength: maxLength(400)
      },
      unit: { required },
      packagesAvailable: {
        required
      },
      productBrandName: { maxLength: maxLength(100) },
      gallery: {
        required: helpers.withMessage("At least 1 image is required", required)
      }
    };
    ref(false);
    const v$ = useVuelidate(rules, form);
    function getTechValue(data) {
      form.technologies = data.selectedmarkets;
      form.techApplications = data.applications;
      form.techSubApplications = data.subapplications;
    }
    function getMarketValue(data) {
      form.markets = data.selectedmarkets;
      form.marketApplications = data.applications;
      form.marketSubapplications = data.subapplications;
    }
    watch(
      () => form.unit,
      () => {
        if (!form && !form.packagesAvailable)
          return;
        form.packagesAvailable = form.packagesAvailable.map((i) => {
          i.unit = form.unit;
          return i;
        });
      }
    );
    function handleProducer() {
      isLoading.value = true;
      producerForm.location = `${producerForm.state}, ${producerForm.country}`;
      addproducer(producerForm).then((res) => {
        if (res.status == 200) {
          getProducers();
          form.manufacturer = producerForm.title;
          producerForm.title = "";
          producerForm.location = "";
          producerForm.country = "";
          producerForm.state = "";
          isAddingPackage.value = false;
          isLoading.value = false;
        }
      }).catch((err) => {
        isLoading.value = false;
        toast.error(err.response.data.message || err.response.data.Message);
      });
    }
    function handleEvent(e) {
      isLoadingLogo.value = true;
      var files = e.target.files || e.dataTransfer.files;
      if (!files.length)
        return;
      const file = files[0];
      if (!file.type.startsWith("image/")) {
        toast.error("Please upload an image file.");
        isLoadingLogo.value = false;
        return;
      }
      const maxSize = 800 * 1024;
      if (file.size > maxSize) {
        toast.error("File size exceeds the limit (800 KB).");
        isLoadingLogo.value = false;
        return;
      }
      if (producerForm.logo) {
        URL.revokeObjectURL(producerForm.logo);
      }
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onloadend = () => {
        const base64String = reader.result;
        uploadfile({
          base64: base64String.replace(/^data:image\/[a-z]+;base64,/, "")
        }).then((res) => {
          producerForm.logo = res.data.message;
          isLoadingLogo.value = false;
        }).catch(() => {
          isLoadingLogo.value = false;
        });
      };
    }
    function onGetFiles(file) {
      form.gallery = [...form.gallery, file];
    }
    function removeFile(id) {
      form.gallery.splice(id, 1);
    }
    const typeForm = ref("");
    function handleAddingProducer() {
      typeForm.value = "producer";
      isAddingPackage.value = true;
    }
    provide("images", form.gallery);
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_AppIcon = __nuxt_component_1;
      const _component_NuxtImg = __nuxt_component_1$1;
      const _component_MultiInput = __nuxt_component_2;
      const _component_router_link = resolveComponent("router-link");
      _push(`<!--[--><form class="px-[30px] text-left" data-v-65fa42ae><div class="flex gap-x-[78px] justify-between" data-v-65fa42ae><div class="w-[300px] text-left" data-v-65fa42ae><h2 class="text-sm text-[#101828] font-semibold" data-v-65fa42ae>Product info</h2><p class="text-xs text-[#475467]" data-v-65fa42ae>Add your product details here.</p></div><div class="max-w-[654px] w-full" data-v-65fa42ae><div class="" data-v-65fa42ae><div data-v-65fa42ae><div data-v-65fa42ae><div class="grid grid-cols-2 gap-x-4" data-v-65fa42ae><div class="mb-6" data-v-65fa42ae><label class="mb-2 font-medium text-sm text-[#344054] block text-left capitalize" data-v-65fa42ae><span class="text-red-500 mr-[.5px]" data-v-65fa42ae>*</span> Product generic name </label><input${ssrRenderAttr("value", unref(v$).name.$model)} class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" autofocus="on" placeholder="" data-v-65fa42ae><!--[-->`);
      ssrRenderList(unref(v$).name.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-65fa42ae><div class="error-msg text-error text-xs font-semibold" data-v-65fa42ae>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><div class="mb-6" data-v-65fa42ae><label class="mb-2 font-medium text-sm text-[#344054] block text-left capitalize" data-v-65fa42ae> Product brand name </label><div class="flex relative items-center" data-v-65fa42ae><input${ssrRenderAttr("value", unref(v$).productBrandName.$model)} class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" placeholder="" data-v-65fa42ae></div><!--[-->`);
      ssrRenderList(unref(v$).productBrandName.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-65fa42ae><div class="error-msg text-error text-xs font-semibold" data-v-65fa42ae>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="" data-v-65fa42ae><div class="mb-6" data-v-65fa42ae><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-65fa42ae><span class="text-red-500 mr-[.5px]" data-v-65fa42ae>*</span> Producer </label>`);
      _push(ssrRenderComponent(unref(Combobox), {
        modelValue: unref(form).manufacturer,
        "onUpdate:modelValue": ($event) => unref(form).manufacturer = $event
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="relative mt-1" data-v-65fa42ae${_scopeId}><div class="relative w-full cursor-default overflow-hidden rounded-lg bg-white text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75 focus-visible:ring-offset-2 focus-visible:ring-offset-teal-300 sm:text-sm" data-v-65fa42ae${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ComboboxInput), {
              class: "px-[14px] py-[10px] h-11 rounded-lg w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
              displayValue: (i) => i,
              onChange: ($event) => isRef(query) ? query.value = $event.target.value : query = $event.target.value,
              placeholder: "Type a producer name"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(ComboboxButton), { class: "absolute inset-y-0 right-0 flex items-center pr-2" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span data-v-65fa42ae${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_AppIcon, {
                    icon: "ph:caret-down-bold",
                    iconClass: "h-4 w-4 text-[#667085]",
                    "aria-hidden": "true"
                  }, null, _parent3, _scopeId2));
                  _push3(`</span>`);
                } else {
                  return [
                    createVNode("span", null, [
                      createVNode(_component_AppIcon, {
                        icon: "ph:caret-down-bold",
                        iconClass: "h-4 w-4 text-[#667085]",
                        "aria-hidden": "true"
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(unref(TransitionRoot), {
              leave: "transition ease-in duration-100",
              leaveFrom: "opacity-100",
              leaveTo: "opacity-0",
              onAfterLeave: ($event) => isRef(query) ? query.value = "" : query = ""
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(ComboboxOptions), { class: "absolute mt-1 max-h-80 md:min-w-[350px] px-3 overflow-y-auto rounded-lg z-40 bg-white py-4 text-base shadow-[0px_2px_4px_0px_rgba(0,0,0,0.04)] border border-[#DCDEE6] sm:text-sm" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        if (unref(filteredProducers).length === 0 && unref(query) !== "") {
                          _push4(`<div class="relative cursor-default select-none py-2 px-4 text-gray-700" data-v-65fa42ae${_scopeId3}><p class="mb-2" data-v-65fa42ae${_scopeId3}>Nothing found.</p><hr class="my-4" data-v-65fa42ae${_scopeId3}><div class="flex justify-end" data-v-65fa42ae${_scopeId3}><button type="button" class="appearance-none text-xs leading-none px-6 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase" data-v-65fa42ae${_scopeId3}> Add new </button></div></div>`);
                        } else {
                          _push4(`<!---->`);
                        }
                        _push4(`<!--[-->`);
                        ssrRenderList(unref(filteredProducers), (i) => {
                          _push4(ssrRenderComponent(unref(ComboboxOption), {
                            as: "template",
                            key: i.id,
                            value: i.title
                          }, {
                            default: withCtx(({ selected, active }, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(`<li class="relative cursor-default select-none py-2" data-v-65fa42ae${_scopeId4}><div class="flex items-center gap-x-4" data-v-65fa42ae${_scopeId4}><span class="h-11 w-12 rounded-lg bg-white shadow p-4 flex items-center justify-center mr-4 border border-[#E7EBEE]" data-v-65fa42ae${_scopeId4}>`);
                                if (i.logo) {
                                  _push5(ssrRenderComponent(_component_NuxtImg, {
                                    src: i.logo,
                                    alt: "logo"
                                  }, null, _parent5, _scopeId4));
                                } else {
                                  _push5(`<p class="uppercase text-base" data-v-65fa42ae${_scopeId4}>${ssrInterpolate(i.title.slice(0, 2))}</p>`);
                                }
                                _push5(`</span><div data-v-65fa42ae${_scopeId4}><p class="${ssrRenderClass([{
                                  "font-medium": selected,
                                  "font-normal": !selected
                                }, "block truncate mb-1"])}" data-v-65fa42ae${_scopeId4}>${ssrInterpolate(i.title)}</p><p class="block truncate text-matta-black/80 text-sm" data-v-65fa42ae${_scopeId4}>${ssrInterpolate(i.location)}</p></div></div>`);
                                if (selected) {
                                  _push5(`<span class="${ssrRenderClass([{
                                    "text-white": active,
                                    "text-teal-600": !active
                                  }, "absolute inset-y-0 left-0 flex items-center pl-3"])}" data-v-65fa42ae${_scopeId4}>`);
                                  _push5(ssrRenderComponent(unref(CheckIcon), {
                                    class: "h-5 w-5",
                                    "aria-hidden": "true"
                                  }, null, _parent5, _scopeId4));
                                  _push5(`</span>`);
                                } else {
                                  _push5(`<!---->`);
                                }
                                _push5(`</li>`);
                              } else {
                                return [
                                  createVNode("li", { class: "relative cursor-default select-none py-2" }, [
                                    createVNode("div", { class: "flex items-center gap-x-4" }, [
                                      createVNode("span", { class: "h-11 w-12 rounded-lg bg-white shadow p-4 flex items-center justify-center mr-4 border border-[#E7EBEE]" }, [
                                        i.logo ? (openBlock(), createBlock(_component_NuxtImg, {
                                          key: 0,
                                          src: i.logo,
                                          alt: "logo"
                                        }, null, 8, ["src"])) : (openBlock(), createBlock("p", {
                                          key: 1,
                                          class: "uppercase text-base"
                                        }, toDisplayString(i.title.slice(0, 2)), 1))
                                      ]),
                                      createVNode("div", null, [
                                        createVNode("p", {
                                          class: ["block truncate mb-1", {
                                            "font-medium": selected,
                                            "font-normal": !selected
                                          }]
                                        }, toDisplayString(i.title), 3),
                                        createVNode("p", { class: "block truncate text-matta-black/80 text-sm" }, toDisplayString(i.location), 1)
                                      ])
                                    ]),
                                    selected ? (openBlock(), createBlock("span", {
                                      key: 0,
                                      class: ["absolute inset-y-0 left-0 flex items-center pl-3", {
                                        "text-white": active,
                                        "text-teal-600": !active
                                      }]
                                    }, [
                                      createVNode(unref(CheckIcon), {
                                        class: "h-5 w-5",
                                        "aria-hidden": "true"
                                      })
                                    ], 2)) : createCommentVNode("", true)
                                  ])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                        });
                        _push4(`<!--]-->`);
                      } else {
                        return [
                          unref(filteredProducers).length === 0 && unref(query) !== "" ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "relative cursor-default select-none py-2 px-4 text-gray-700"
                          }, [
                            createVNode("p", { class: "mb-2" }, "Nothing found."),
                            createVNode("hr", { class: "my-4" }),
                            createVNode("div", { class: "flex justify-end" }, [
                              createVNode("button", {
                                onClick: handleAddingProducer,
                                type: "button",
                                class: "appearance-none text-xs leading-none px-6 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase"
                              }, " Add new ")
                            ])
                          ])) : createCommentVNode("", true),
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(filteredProducers), (i) => {
                            return openBlock(), createBlock(unref(ComboboxOption), {
                              as: "template",
                              key: i.id,
                              value: i.title
                            }, {
                              default: withCtx(({ selected, active }) => [
                                createVNode("li", { class: "relative cursor-default select-none py-2" }, [
                                  createVNode("div", { class: "flex items-center gap-x-4" }, [
                                    createVNode("span", { class: "h-11 w-12 rounded-lg bg-white shadow p-4 flex items-center justify-center mr-4 border border-[#E7EBEE]" }, [
                                      i.logo ? (openBlock(), createBlock(_component_NuxtImg, {
                                        key: 0,
                                        src: i.logo,
                                        alt: "logo"
                                      }, null, 8, ["src"])) : (openBlock(), createBlock("p", {
                                        key: 1,
                                        class: "uppercase text-base"
                                      }, toDisplayString(i.title.slice(0, 2)), 1))
                                    ]),
                                    createVNode("div", null, [
                                      createVNode("p", {
                                        class: ["block truncate mb-1", {
                                          "font-medium": selected,
                                          "font-normal": !selected
                                        }]
                                      }, toDisplayString(i.title), 3),
                                      createVNode("p", { class: "block truncate text-matta-black/80 text-sm" }, toDisplayString(i.location), 1)
                                    ])
                                  ]),
                                  selected ? (openBlock(), createBlock("span", {
                                    key: 0,
                                    class: ["absolute inset-y-0 left-0 flex items-center pl-3", {
                                      "text-white": active,
                                      "text-teal-600": !active
                                    }]
                                  }, [
                                    createVNode(unref(CheckIcon), {
                                      class: "h-5 w-5",
                                      "aria-hidden": "true"
                                    })
                                  ], 2)) : createCommentVNode("", true)
                                ])
                              ]),
                              _: 2
                            }, 1032, ["value"]);
                          }), 128))
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(ComboboxOptions), { class: "absolute mt-1 max-h-80 md:min-w-[350px] px-3 overflow-y-auto rounded-lg z-40 bg-white py-4 text-base shadow-[0px_2px_4px_0px_rgba(0,0,0,0.04)] border border-[#DCDEE6] sm:text-sm" }, {
                      default: withCtx(() => [
                        unref(filteredProducers).length === 0 && unref(query) !== "" ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "relative cursor-default select-none py-2 px-4 text-gray-700"
                        }, [
                          createVNode("p", { class: "mb-2" }, "Nothing found."),
                          createVNode("hr", { class: "my-4" }),
                          createVNode("div", { class: "flex justify-end" }, [
                            createVNode("button", {
                              onClick: handleAddingProducer,
                              type: "button",
                              class: "appearance-none text-xs leading-none px-6 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase"
                            }, " Add new ")
                          ])
                        ])) : createCommentVNode("", true),
                        (openBlock(true), createBlock(Fragment, null, renderList(unref(filteredProducers), (i) => {
                          return openBlock(), createBlock(unref(ComboboxOption), {
                            as: "template",
                            key: i.id,
                            value: i.title
                          }, {
                            default: withCtx(({ selected, active }) => [
                              createVNode("li", { class: "relative cursor-default select-none py-2" }, [
                                createVNode("div", { class: "flex items-center gap-x-4" }, [
                                  createVNode("span", { class: "h-11 w-12 rounded-lg bg-white shadow p-4 flex items-center justify-center mr-4 border border-[#E7EBEE]" }, [
                                    i.logo ? (openBlock(), createBlock(_component_NuxtImg, {
                                      key: 0,
                                      src: i.logo,
                                      alt: "logo"
                                    }, null, 8, ["src"])) : (openBlock(), createBlock("p", {
                                      key: 1,
                                      class: "uppercase text-base"
                                    }, toDisplayString(i.title.slice(0, 2)), 1))
                                  ]),
                                  createVNode("div", null, [
                                    createVNode("p", {
                                      class: ["block truncate mb-1", {
                                        "font-medium": selected,
                                        "font-normal": !selected
                                      }]
                                    }, toDisplayString(i.title), 3),
                                    createVNode("p", { class: "block truncate text-matta-black/80 text-sm" }, toDisplayString(i.location), 1)
                                  ])
                                ]),
                                selected ? (openBlock(), createBlock("span", {
                                  key: 0,
                                  class: ["absolute inset-y-0 left-0 flex items-center pl-3", {
                                    "text-white": active,
                                    "text-teal-600": !active
                                  }]
                                }, [
                                  createVNode(unref(CheckIcon), {
                                    class: "h-5 w-5",
                                    "aria-hidden": "true"
                                  })
                                ], 2)) : createCommentVNode("", true)
                              ])
                            ]),
                            _: 2
                          }, 1032, ["value"]);
                        }), 128))
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "relative mt-1" }, [
                createVNode("div", { class: "relative w-full cursor-default overflow-hidden rounded-lg bg-white text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75 focus-visible:ring-offset-2 focus-visible:ring-offset-teal-300 sm:text-sm" }, [
                  createVNode(unref(ComboboxInput), {
                    class: "px-[14px] py-[10px] h-11 rounded-lg w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
                    displayValue: (i) => i,
                    onChange: ($event) => isRef(query) ? query.value = $event.target.value : query = $event.target.value,
                    placeholder: "Type a producer name"
                  }, null, 8, ["displayValue", "onChange"]),
                  createVNode(unref(ComboboxButton), { class: "absolute inset-y-0 right-0 flex items-center pr-2" }, {
                    default: withCtx(() => [
                      createVNode("span", null, [
                        createVNode(_component_AppIcon, {
                          icon: "ph:caret-down-bold",
                          iconClass: "h-4 w-4 text-[#667085]",
                          "aria-hidden": "true"
                        })
                      ])
                    ]),
                    _: 1
                  })
                ]),
                createVNode(unref(TransitionRoot), {
                  leave: "transition ease-in duration-100",
                  leaveFrom: "opacity-100",
                  leaveTo: "opacity-0",
                  onAfterLeave: ($event) => isRef(query) ? query.value = "" : query = ""
                }, {
                  default: withCtx(() => [
                    createVNode(unref(ComboboxOptions), { class: "absolute mt-1 max-h-80 md:min-w-[350px] px-3 overflow-y-auto rounded-lg z-40 bg-white py-4 text-base shadow-[0px_2px_4px_0px_rgba(0,0,0,0.04)] border border-[#DCDEE6] sm:text-sm" }, {
                      default: withCtx(() => [
                        unref(filteredProducers).length === 0 && unref(query) !== "" ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "relative cursor-default select-none py-2 px-4 text-gray-700"
                        }, [
                          createVNode("p", { class: "mb-2" }, "Nothing found."),
                          createVNode("hr", { class: "my-4" }),
                          createVNode("div", { class: "flex justify-end" }, [
                            createVNode("button", {
                              onClick: handleAddingProducer,
                              type: "button",
                              class: "appearance-none text-xs leading-none px-6 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase"
                            }, " Add new ")
                          ])
                        ])) : createCommentVNode("", true),
                        (openBlock(true), createBlock(Fragment, null, renderList(unref(filteredProducers), (i) => {
                          return openBlock(), createBlock(unref(ComboboxOption), {
                            as: "template",
                            key: i.id,
                            value: i.title
                          }, {
                            default: withCtx(({ selected, active }) => [
                              createVNode("li", { class: "relative cursor-default select-none py-2" }, [
                                createVNode("div", { class: "flex items-center gap-x-4" }, [
                                  createVNode("span", { class: "h-11 w-12 rounded-lg bg-white shadow p-4 flex items-center justify-center mr-4 border border-[#E7EBEE]" }, [
                                    i.logo ? (openBlock(), createBlock(_component_NuxtImg, {
                                      key: 0,
                                      src: i.logo,
                                      alt: "logo"
                                    }, null, 8, ["src"])) : (openBlock(), createBlock("p", {
                                      key: 1,
                                      class: "uppercase text-base"
                                    }, toDisplayString(i.title.slice(0, 2)), 1))
                                  ]),
                                  createVNode("div", null, [
                                    createVNode("p", {
                                      class: ["block truncate mb-1", {
                                        "font-medium": selected,
                                        "font-normal": !selected
                                      }]
                                    }, toDisplayString(i.title), 3),
                                    createVNode("p", { class: "block truncate text-matta-black/80 text-sm" }, toDisplayString(i.location), 1)
                                  ])
                                ]),
                                selected ? (openBlock(), createBlock("span", {
                                  key: 0,
                                  class: ["absolute inset-y-0 left-0 flex items-center pl-3", {
                                    "text-white": active,
                                    "text-teal-600": !active
                                  }]
                                }, [
                                  createVNode(unref(CheckIcon), {
                                    class: "h-5 w-5",
                                    "aria-hidden": "true"
                                  })
                                ], 2)) : createCommentVNode("", true)
                              ])
                            ]),
                            _: 2
                          }, 1032, ["value"]);
                        }), 128))
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }, 8, ["onAfterLeave"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--[-->`);
      ssrRenderList(unref(v$).manufacturer.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-65fa42ae><div class="error-msg text-error text-xs font-semibold" data-v-65fa42ae>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="" data-v-65fa42ae><div class="mb-6" data-v-65fa42ae><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-65fa42ae><span class="text-red-500 mr-[.5px]" data-v-65fa42ae>*</span> Markets </label>`);
      if (unref(allmarkets).length) {
        _push(ssrRenderComponent(_component_MultiInput, {
          markets: unref(allmarkets),
          selectedmarkets: unref(form).markets,
          applications: unref(form).marketApplications,
          subapplications: unref(form).marketSubapplications,
          onGetValue: getMarketValue
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--[-->`);
      ssrRenderList(unref(v$).markets.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-65fa42ae><div class="error-msg text-error text-xs font-semibold" data-v-65fa42ae>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--><!--[-->`);
      ssrRenderList(unref(v$).marketApplications.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-65fa42ae><div class="error-msg text-error text-xs font-semibold" data-v-65fa42ae>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="" data-v-65fa42ae><div class="mb-6" data-v-65fa42ae><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-65fa42ae><span class="text-red-500 mr-[.5px]" data-v-65fa42ae>*</span> Applications </label>`);
      if (unref(technologies).length) {
        _push(ssrRenderComponent(_component_MultiInput, {
          markets: unref(technologies),
          onGetValue: getTechValue,
          selectedmarkets: unref(form).technologies,
          applications: unref(form).techApplications,
          subapplications: unref(form).techSubApplications
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<!--[-->`);
      ssrRenderList(unref(v$).technologies.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-65fa42ae><div class="error-msg text-error text-xs font-semibold" data-v-65fa42ae>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--><!--[-->`);
      ssrRenderList(unref(v$).techApplications.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-65fa42ae><div class="error-msg text-error text-xs font-semibold" data-v-65fa42ae>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="mb-6" data-v-65fa42ae><label class="mb-2 font-medium text-sm text-[#344054] text-left flex items-center gap-x-1" data-v-65fa42ae><span class="text-red-500 mr-[.5px]" data-v-65fa42ae>*</span><span data-v-65fa42ae>Description </span><span data-toggle="tooltip" data-placement="top" title="Brief general information about the chemicals, its chemical composition, other names, important uses or any specificity" class="cursor-pointer" data-v-65fa42ae>`);
      _push(ssrRenderComponent(_component_AppIcon, {
        icon: "quill:info",
        iconClass: "text-gray-600"
      }, null, _parent));
      _push(`</span></label><textarea rows="3" placeholder="Product description" class="rounded-lg px-[14px] py-[10px] w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20 resize-none" data-v-65fa42ae>${ssrInterpolate(unref(v$).description.$model)}</textarea><!--[-->`);
      ssrRenderList(unref(v$).description.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-65fa42ae><div class="error-msg text-error text-xs font-semibold" data-v-65fa42ae>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div></div></div></div></div></div><hr class="border-[#F4F7FE] my-10" data-v-65fa42ae><div class="flex gap-x-[78px] justify-between flex-col lg:flex-row gap-y-7 lg:gap-y-" data-v-65fa42ae><div class="w-[300px]" data-v-65fa42ae><h2 class="text-sm text-[#101828] font-semibold" data-v-65fa42ae> Packages &amp; Availability <span class="text-red-500 mr-[.5px]" data-v-65fa42ae>*</span></h2><p class="text-xs text-[#475467]" data-v-65fa42ae>Provide package information here.</p></div><div class="max-w-[654px] w-full" data-v-65fa42ae><div class="mb-6" data-v-65fa42ae>`);
      _push(ssrRenderComponent(unref(Listbox), {
        modelValue: unref(form).unit,
        "onUpdate:modelValue": ($event) => unref(form).unit = $event
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="relative mt-1" data-v-65fa42ae${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ListboxButton), { class: "relative w-[250px] text-left rounded-lg appearance-none px-[14px] py-[10px] flex items-center h-11 border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                var _a2, _b;
                if (_push3) {
                  _push3(`<span class="block truncate" data-v-65fa42ae${_scopeId2}>${ssrInterpolate((_a2 = ("measurements" in _ctx ? _ctx.measurements : unref(measurements)).find((i) => i.value == unref(form).unit)) == null ? void 0 : _a2.name)}</span><span class="right-0 pr-2 absolute" data-v-65fa42ae${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_AppIcon, {
                    icon: "ph:caret-down-bold",
                    iconClass: "h-4 w-4 text-[#667085]",
                    "aria-hidden": "true"
                  }, null, _parent3, _scopeId2));
                  _push3(`</span>`);
                } else {
                  return [
                    createVNode("span", { class: "block truncate" }, toDisplayString((_b = ("measurements" in _ctx ? _ctx.measurements : unref(measurements)).find((i) => i.value == unref(form).unit)) == null ? void 0 : _b.name), 1),
                    createVNode("span", { class: "right-0 pr-2 absolute" }, [
                      createVNode(_component_AppIcon, {
                        icon: "ph:caret-down-bold",
                        iconClass: "h-4 w-4 text-[#667085]",
                        "aria-hidden": "true"
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(ListboxOptions), { class: "absolute mt-1 mx-h-60 w-[200px] z-40 overflow-auto rounded-[10px] bg-white py-1 text-base shadow-lg focus:outline-none sm:text-sm" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList("measurements" in _ctx ? _ctx.measurements : unref(measurements), (i) => {
                    _push3(ssrRenderComponent(unref(ListboxOption), {
                      key: i.name,
                      value: i.value,
                      as: "template"
                    }, {
                      default: withCtx(({ selected }, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<li class="${ssrRenderClass([
                            "relative cursor-pointer  text-matta-black  hover:text-primary select-none py-2 pl-10 pr-4 text-left"
                          ])}" data-v-65fa42ae${_scopeId3}><span class="${ssrRenderClass([selected ? "font-medium" : "font-normal"])}" data-v-65fa42ae${_scopeId3}>${ssrInterpolate(i.name)}</span></li>`);
                        } else {
                          return [
                            createVNode("li", { class: [
                              "relative cursor-pointer  text-matta-black  hover:text-primary select-none py-2 pl-10 pr-4 text-left"
                            ] }, [
                              createVNode("span", {
                                class: [selected ? "font-medium" : "font-normal"]
                              }, toDisplayString(i.name), 3)
                            ])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList("measurements" in _ctx ? _ctx.measurements : unref(measurements), (i) => {
                      return openBlock(), createBlock(unref(ListboxOption), {
                        key: i.name,
                        value: i.value,
                        as: "template"
                      }, {
                        default: withCtx(({ selected }) => [
                          createVNode("li", { class: [
                            "relative cursor-pointer  text-matta-black  hover:text-primary select-none py-2 pl-10 pr-4 text-left"
                          ] }, [
                            createVNode("span", {
                              class: [selected ? "font-medium" : "font-normal"]
                            }, toDisplayString(i.name), 3)
                          ])
                        ]),
                        _: 2
                      }, 1032, ["value"]);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "relative mt-1" }, [
                createVNode(unref(ListboxButton), { class: "relative w-[250px] text-left rounded-lg appearance-none px-[14px] py-[10px] flex items-center h-11 border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" }, {
                  default: withCtx(() => {
                    var _a2;
                    return [
                      createVNode("span", { class: "block truncate" }, toDisplayString((_a2 = ("measurements" in _ctx ? _ctx.measurements : unref(measurements)).find((i) => i.value == unref(form).unit)) == null ? void 0 : _a2.name), 1),
                      createVNode("span", { class: "right-0 pr-2 absolute" }, [
                        createVNode(_component_AppIcon, {
                          icon: "ph:caret-down-bold",
                          iconClass: "h-4 w-4 text-[#667085]",
                          "aria-hidden": "true"
                        })
                      ])
                    ];
                  }),
                  _: 1
                }),
                createVNode(Transition, {
                  "leave-active-class": "transition duration-100 ease-in",
                  "leave-from-class": "opacity-100",
                  "leave-to-class": "opacity-0"
                }, {
                  default: withCtx(() => [
                    createVNode(unref(ListboxOptions), { class: "absolute mt-1 mx-h-60 w-[200px] z-40 overflow-auto rounded-[10px] bg-white py-1 text-base shadow-lg focus:outline-none sm:text-sm" }, {
                      default: withCtx(() => [
                        (openBlock(true), createBlock(Fragment, null, renderList("measurements" in _ctx ? _ctx.measurements : unref(measurements), (i) => {
                          return openBlock(), createBlock(unref(ListboxOption), {
                            key: i.name,
                            value: i.value,
                            as: "template"
                          }, {
                            default: withCtx(({ selected }) => [
                              createVNode("li", { class: [
                                "relative cursor-pointer  text-matta-black  hover:text-primary select-none py-2 pl-10 pr-4 text-left"
                              ] }, [
                                createVNode("span", {
                                  class: [selected ? "font-medium" : "font-normal"]
                                }, toDisplayString(i.name), 3)
                              ])
                            ]),
                            _: 2
                          }, 1032, ["value"]);
                        }), 128))
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--[-->`);
      ssrRenderList(unref(v$).unit.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-65fa42ae><div class="error-msg text-error text-xs font-semibold" data-v-65fa42ae>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--></div><button type="button" class="bg-primary-500 text-white rounded-lg px-[14px] py-[10px] text-sm text-left leading-[normal]" data-v-65fa42ae><i class="uil uil-plus" data-v-65fa42ae></i> Add a package </button><div class="border border-[#F4F7FE] rounded-[10px] overflow-hidden mt-6" data-v-65fa42ae>`);
      if ((_a = unref(form).packagesAvailable) == null ? void 0 : _a.length) {
        _push(`<table class="w-full" data-v-65fa42ae><thead data-v-65fa42ae><tr data-v-65fa42ae><!--[-->`);
        ssrRenderList(headers.value, (item, i) => {
          _push(`<th class="capitalize text-[#475467] text-sm text-left font-medium border-b border-t py-3 px-6 border-[#EAECF0] whitespace-nowrap bg-[#F9FAFB]" data-v-65fa42ae>${ssrInterpolate(item)}</th>`);
        });
        _push(`<!--]--></tr></thead><tbody data-v-65fa42ae><!--[-->`);
        ssrRenderList(unref(form).packagesAvailable, (item) => {
          _push(`<tr data-v-65fa42ae><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-65fa42ae>${ssrInterpolate(item == null ? void 0 : item.title)}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-65fa42ae>${ssrInterpolate(item == null ? void 0 : item.size)}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-65fa42ae>${ssrInterpolate(("currencyFormat" in _ctx ? _ctx.currencyFormat : unref(__unimport_currencyFormat))(item == null ? void 0 : item.amount))}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-65fa42ae>${ssrInterpolate(item == null ? void 0 : item.color)}</td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-65fa42ae>${ssrInterpolate(item == null ? void 0 : item.purity)}5 </td><td class="capitalize text-matta-black text-sm font-normal border-b py-4 px-6 border-[#EAECF0] whitespace-nowrap" data-v-65fa42ae><span class="flex gap-x-4" data-v-65fa42ae><span data-v-65fa42ae>`);
          _push(ssrRenderComponent(_component_AppIcon, {
            icon: "fa-trash-o",
            iconClass: "text-[#E53F3F]"
          }, null, _parent));
          _push(`</span><span data-v-65fa42ae>`);
          _push(ssrRenderComponent(_component_AppIcon, {
            icon: "prime:pencil",
            iconClass: "text-[#475467]"
          }, null, _parent));
          _push(`</span></span></td></tr>`);
        });
        _push(`<!--]--></tbody></table>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div><hr class="border-[#F4F7FE] my-10" data-v-65fa42ae><div class="flex gap-x-[78px] justify-between flex-col lg:flex-row gap-y-7 lg:gap-y-" data-v-65fa42ae><div class="w-[300px]" data-v-65fa42ae><h2 class="text-sm text-[#101828] font-semibold" data-v-65fa42ae>Gallery</h2><p class="text-xs text-[#475467]" data-v-65fa42ae> Upload pictures of your products here. </p></div><div class="max-w-[654px] w-full" data-v-65fa42ae>`);
      _push(ssrRenderComponent(unref(__nuxt_component_0$1), {
        onOnGetFiles: onGetFiles,
        onRemoveFile: removeFile,
        isMultiple: true,
        gallery: unref(form).gallery,
        support: "SVG, PNG, JPG or GIF (max. 800x400px)"
      }, null, _parent));
      _push(`<!--[-->`);
      ssrRenderList(unref(v$).gallery.$errors, (error) => {
        _push(`<div class="text-red-500 mt-1" data-v-65fa42ae><div class="error-msg text-error text-xs font-semibold" data-v-65fa42ae>${ssrInterpolate(error.$message)}</div></div>`);
      });
      _push(`<!--]--><div class="bg-white rounded-lg py-6 mt-6 flex gap-x-10 items-center" data-v-65fa42ae><label class="flex item-center leading-[normal]" data-v-65fa42ae><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(form).sampleAvailable) ? ssrLooseContain(unref(form).sampleAvailable, null) : unref(form).sampleAvailable) ? " checked" : ""} class="mr-2 accent-primary-500" data-v-65fa42ae><span class="text-[#344054]" data-v-65fa42ae> Sample is available</span></label><label class="flex item-center leading-[normal]" data-v-65fa42ae><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(form).hideProduct) ? ssrLooseContain(unref(form).hideProduct, null) : unref(form).hideProduct) ? " checked" : ""} class="mr-2 accent-primary-500" data-v-65fa42ae><span class="text-[#344054]" data-v-65fa42ae>Hide product</span></label><label class="flex item-center leading-[normal]" data-v-65fa42ae><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(unref(form).hidePrice) ? ssrLooseContain(unref(form).hidePrice, null) : unref(form).hidePrice) ? " checked" : ""} class="mr-2 accent-primary-500" data-v-65fa42ae><span class="text-[#344054]" data-v-65fa42ae>Hide price</span></label></div></div></div><hr class="border-[#F4F7FE] my-10" data-v-65fa42ae><div class="bg-white flex justify-between gap-x-10 items-center sticky bottom-0 pb-6" data-v-65fa42ae><button type="button" class="appearance-none leading-none px-10 py-[10px] rounded-lg text-primary border-primary-500 text-primary-500 border hover:bg-gray-300 text-[13px]" data-v-65fa42ae> Preview </button><div class="flex gap-x-4 items-center" data-v-65fa42ae>`);
      _push(ssrRenderComponent(_component_router_link, { to: "/storefront/products" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button type="button" class="appearance-none leading-none px-10 py-[10px] rounded-lg text-primary border-primary- border hover:bg-gray-300 text-[13px]" data-v-65fa42ae${_scopeId}> Cancel </button>`);
          } else {
            return [
              createVNode("button", {
                type: "button",
                class: "appearance-none leading-none px-10 py-[10px] rounded-lg text-primary border-primary- border hover:bg-gray-300 text-[13px]"
              }, " Cancel ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<button${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} class="${ssrRenderClass([{
        "bg-primary/60 cursor-not-allowed": isLoading.value
      }, "appearance-none leading-none px-10 py-[10px] rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px]"])}" type="submit" data-v-65fa42ae> Next </button></div></div></form><div data-v-65fa42ae>`);
      _push(ssrRenderComponent(unref(__nuxt_component_0$2), {
        isOpen: isAddingPackage.value,
        onToggleModal: ($event) => isAddingPackage.value = false
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (typeForm.value === "producer") {
              _push2(`<form class="bg-white px-4 pt-5 pb-8 sm:p-6 sm:pb-4 w-[500px] rounded-lg" data-v-65fa42ae${_scopeId}><div class="flex justify-between mb-8 items-center" data-v-65fa42ae${_scopeId}><h4 class="font-medium text-matta-black text-xl" data-v-65fa42ae${_scopeId}>Add Producer</h4><i class="uil uil-times cursor-pointer text-lg hover:ring-1 w-6 h-6 ring-gray-200 flex items-center justify-center hover:ring-offset-2 rounded-full" data-v-65fa42ae${_scopeId}></i></div><div class="mb-5" data-v-65fa42ae${_scopeId}><label class="mb-2 font-normal text-xs block" data-v-65fa42ae${_scopeId}>Name <span class="text-red-500 pl-[.5px]" data-v-65fa42ae${_scopeId}>*</span></label><input${ssrRenderAttr("value", producerForm.title)} class="rounded-lg px-[14px] py-3 h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" placeholder="Enter producer name" required data-v-65fa42ae${_scopeId}></div><div class="flex gap-x-6 mb-5" data-v-65fa42ae${_scopeId}><div class="w-full" data-v-65fa42ae${_scopeId}><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-65fa42ae${_scopeId}>Country</label>`);
              _push2(ssrRenderComponent(unref(CountriesSelect), {
                modelValue: producerForm.country,
                "onUpdate:modelValue": ($event) => producerForm.country = $event
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="w-full" data-v-65fa42ae${_scopeId}><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-65fa42ae${_scopeId}>State</label>`);
              _push2(ssrRenderComponent(unref(StatesSelect), {
                modelValue: producerForm.state,
                "onUpdate:modelValue": ($event) => producerForm.state = $event,
                states: states.value
              }, null, _parent2, _scopeId));
              _push2(`</div></div><div data-v-65fa42ae${_scopeId}><label class="mb-2 font-medium text-sm text-[#344054] block text-left" data-v-65fa42ae${_scopeId}>Producer Logo</label><label for="upload" class="cursor-pointer" data-v-65fa42ae${_scopeId}><input type="file" accept="image/*" id="upload" class="hidden" data-v-65fa42ae${_scopeId}><div data-v-65fa42ae${_scopeId}>`);
              if (!producerForm.logo) {
                _push2(`<span class="h-16 w-16 rounded-full flex items-center text-xs bg-[#F1F3F5] mr-4 justify-center" data-v-65fa42ae${_scopeId}>Logo</span>`);
              } else {
                _push2(ssrRenderComponent(_component_NuxtImg, {
                  src: producerForm.logo,
                  class: "h-16 w-16 rounded-full flex items-center bg-[#F1F3F5] mr-4 justify-center"
                }, null, _parent2, _scopeId));
              }
              _push2(`</div>`);
              if (isLoadingLogo.value) {
                _push2(`<i class="fa fa-spinner fa-spin ml-6" aria-hidden="true" data-v-65fa42ae${_scopeId}></i>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</label></div><hr class="my-6" data-v-65fa42ae${_scopeId}><div class="flex justify-end gap-x-2 items-center mt-8" data-v-65fa42ae${_scopeId}><button type="button" class="appearance-none text-xs leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 uppercase" data-v-65fa42ae${_scopeId}> Cancel </button><button${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} type="submit" class="appearance-none text-xs leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase disabled:opacity-50" data-v-65fa42ae${_scopeId}> Save </button></div></form>`);
            } else {
              _push2(`<!---->`);
            }
            if (typeForm.value === "package") {
              _push2(ssrRenderComponent(unref(_sfc_main$6), {
                onClose: ($event) => isAddingPackage.value = false
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              typeForm.value === "producer" ? (openBlock(), createBlock("form", {
                key: 0,
                class: "bg-white px-4 pt-5 pb-8 sm:p-6 sm:pb-4 w-[500px] rounded-lg",
                onSubmit: withModifiers(handleProducer, ["prevent"])
              }, [
                createVNode("div", { class: "flex justify-between mb-8 items-center" }, [
                  createVNode("h4", { class: "font-medium text-matta-black text-xl" }, "Add Producer"),
                  createVNode("i", {
                    class: "uil uil-times cursor-pointer text-lg hover:ring-1 w-6 h-6 ring-gray-200 flex items-center justify-center hover:ring-offset-2 rounded-full",
                    onClick: ($event) => isAddingPackage.value = false
                  }, null, 8, ["onClick"])
                ]),
                createVNode("div", { class: "mb-5" }, [
                  createVNode("label", { class: "mb-2 font-normal text-xs block" }, [
                    createTextVNode("Name "),
                    createVNode("span", { class: "text-red-500 pl-[.5px]" }, "*")
                  ]),
                  withDirectives(createVNode("input", {
                    "onUpdate:modelValue": ($event) => producerForm.title = $event,
                    class: "rounded-lg px-[14px] py-3 h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
                    placeholder: "Enter producer name",
                    required: ""
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, producerForm.title]
                  ])
                ]),
                createVNode("div", { class: "flex gap-x-6 mb-5" }, [
                  createVNode("div", { class: "w-full" }, [
                    createVNode("label", { class: "mb-2 font-medium text-sm text-[#344054] block text-left" }, "Country"),
                    createVNode(unref(CountriesSelect), {
                      modelValue: producerForm.country,
                      "onUpdate:modelValue": ($event) => producerForm.country = $event
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  createVNode("div", { class: "w-full" }, [
                    createVNode("label", { class: "mb-2 font-medium text-sm text-[#344054] block text-left" }, "State"),
                    createVNode(unref(StatesSelect), {
                      modelValue: producerForm.state,
                      "onUpdate:modelValue": ($event) => producerForm.state = $event,
                      states: states.value
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "states"])
                  ])
                ]),
                createVNode("div", null, [
                  createVNode("label", { class: "mb-2 font-medium text-sm text-[#344054] block text-left" }, "Producer Logo"),
                  createVNode("label", {
                    for: "upload",
                    class: "cursor-pointer"
                  }, [
                    createVNode("input", {
                      onChange: ($event) => handleEvent($event),
                      type: "file",
                      accept: "image/*",
                      id: "upload",
                      class: "hidden"
                    }, null, 40, ["onChange"]),
                    createVNode("div", null, [
                      !producerForm.logo ? (openBlock(), createBlock("span", {
                        key: 0,
                        class: "h-16 w-16 rounded-full flex items-center text-xs bg-[#F1F3F5] mr-4 justify-center"
                      }, "Logo")) : (openBlock(), createBlock(_component_NuxtImg, {
                        key: 1,
                        src: producerForm.logo,
                        class: "h-16 w-16 rounded-full flex items-center bg-[#F1F3F5] mr-4 justify-center"
                      }, null, 8, ["src"]))
                    ]),
                    isLoadingLogo.value ? (openBlock(), createBlock("i", {
                      key: 0,
                      class: "fa fa-spinner fa-spin ml-6",
                      "aria-hidden": "true"
                    })) : createCommentVNode("", true)
                  ])
                ]),
                createVNode("hr", { class: "my-6" }),
                createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                  createVNode("button", {
                    type: "button",
                    onClick: ($event) => isAddingPackage.value = false,
                    class: "appearance-none text-xs leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 uppercase"
                  }, " Cancel ", 8, ["onClick"]),
                  createVNode("button", {
                    disabled: isLoading.value,
                    type: "submit",
                    class: "appearance-none text-xs leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase disabled:opacity-50"
                  }, " Save ", 8, ["disabled"])
                ])
              ], 32)) : createCommentVNode("", true),
              typeForm.value === "package" ? (openBlock(), createBlock(unref(_sfc_main$6), {
                key: 1,
                onClose: ($event) => isAddingPackage.value = false
              }, null, 8, ["onClose"])) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/AddProduct/ProductInfo.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const ProductInfo = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-65fa42ae"]]);
const _sfc_main$4 = {
  __name: "ProductProperties",
  __ssrInlineRender: true,
  setup(__props) {
    useRoute();
    useRouter();
    inject("toggleNext");
    inject("togglePreview");
    const form = inject("form");
    const rules = {
      propertyItems: {
        property: {
          propertyItems: {
            required,
            $each: helpers.forEach({
              property: {
                required
              },
              propertyValue: {
                required
              }
            })
          }
        },
        technical: {
          propertyItems: {
            required,
            $each: helpers.forEach({
              property: {
                required
              },
              propertyValue: {
                required
              }
            })
          }
        },
        // applications: {
        //   propertyItems: {
        //     required,
        //     $each: helpers.forEach({
        //       property: {
        //         required,
        //       },
        //       propertyValue: {
        //         required,
        //       },
        //     }),
        //   },
        // },
        // features: {
        //   propertyItems: {
        //     $each: helpers.forEach({
        //       property: {
        //         required,
        //       },
        //       propertyValue: {
        //         required,
        //       },
        //     }),
        //   },
        // },
        compliance: {
          propertyItems: {
            $each: helpers.forEach({
              property: {
                required
              },
              propertyValue: {
                required
              }
            })
          }
        }
      }
    };
    const v$ = useVuelidate(rules, form);
    const isLoading = ref(false);
    function addProperty(val) {
      form.properties.push(val);
    }
    function addPropertyValue(val) {
      form.propertyValueList.push(val.name);
    }
    provide("addPropertyValue", addPropertyValue);
    provide("addProperty", addProperty);
    provide("form", form);
    provide("v$", v$);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<form${ssrRenderAttrs(mergeProps({ class: "px-[30px]" }, _attrs))} data-v-cd5d3c27>`);
      _push(ssrRenderComponent(unref(FeaturedProp), {
        title: "Properties",
        type: "property"
      }, null, _parent));
      _push(`<hr class="border-[#F4F7FE] my-10" data-v-cd5d3c27>`);
      _push(ssrRenderComponent(unref(FeaturedProp), {
        title: "Technical Details & Test Data",
        type: "technical"
      }, null, _parent));
      _push(`<hr class="border-[#F4F7FE] my-10" data-v-cd5d3c27>`);
      _push(ssrRenderComponent(unref(FeaturedProp), {
        title: "Regulatory & Compliance",
        type: "compliance",
        optional: true
      }, null, _parent));
      _push(`<hr class="border-[#F4F7FE] my-10" data-v-cd5d3c27><div class="bg-white rounded-lg px-10 py-6 flex justify-between gap-x-10 items-center" data-v-cd5d3c27><button type="button" class="appearance-none leading-none px-10 py-[10px] rounded-lg text-primary border-primary-500 text-primary-500 border hover:bg-gray-300 text-[13px]" data-v-cd5d3c27> Preview </button><div class="flex justify-center gap-x-4 items-center" data-v-cd5d3c27><button type="button" class="appearance-none leading-none px-10 py-[10px] rounded-lg text-primary border-primary- border hover:bg-gray-300 text-[13px]" data-v-cd5d3c27> Back </button><button${ssrIncludeBooleanAttr(isLoading.value || unref(v$).$silentErrors.length) ? " disabled" : ""} class="${ssrRenderClass([{
        "opacity-60 cursor-not-allowed": isLoading.value
      }, "appearance-none leading-none px-10 py-[10px] rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px]"])}" type="submit" data-v-cd5d3c27> Next </button></div></div></form>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/AddProduct/ProductProperties.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const ProductProperties = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-cd5d3c27"]]);
const _sfc_main$3 = {
  __name: "ProductDocuments",
  __ssrInlineRender: true,
  setup(__props) {
    useRouter();
    const category = ref("");
    const isAdding = ref(false);
    const index = ref(null);
    inject("toggleNext");
    inject("togglePreview");
    const form = inject("form");
    function onGetFiles(file) {
      form.documents = [
        ...form.documents,
        {
          id: 0,
          category: "",
          fileName: file.fileName,
          file: file.url,
          size: file.size,
          fileSize: file.fileSize,
          documentUrl: file.url
        }
      ];
    }
    function handleAddingPackage() {
      form.documentproperties.push(category.value);
      form.documents[index.value].category = category.value;
      isAdding.value = false;
      category.value = "";
    }
    const isLoading = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppIcon = __nuxt_component_1;
      _push(`<!--[--><section class="p-[30px]"><div class="flex gap-x-[78px] justify-between text-left"><div class="w-[350px] text-left"><h2 class="text-sm text-[#101828] font-semibold">Product documents</h2><p class="mb-5 flex items-center text-xs"> Please attach the manufacturer&#39;s MSDS, COA, and TDS here and indicate the document type. </p></div><div class="max-w-[654px] w-full">`);
      _push(ssrRenderComponent(unref(__nuxt_component_0$1), {
        onOnGetFiles: onGetFiles,
        isMultiple: true,
        type: "doc"
      }, null, _parent));
      if (unref(form).documents.length) {
        _push(`<div class="bg-white py-6 lg:py-8 rounded-lg"><div class=""><!--[-->`);
        ssrRenderList(unref(form).documents, (n, id) => {
          _push(`<div class="flex items-center gap-x-4 mb-3"><div class="border rounded-xl p-4 flex flex-1 justify-between"><div class="flex gap-x-3 items-center"><img${ssrRenderAttr("src", _imports_0)} class="w-8 h-auto"><div><p class="text-sm text-matta-black capitalize truncate max-w-[250px]">${ssrInterpolate(n.fileName)}</p><p class="text-xs text-[#ABABAB]">${ssrInterpolate(n.size)}</p></div></div><div class="flex items-center gap-x-5 text-xs relative"><div class="absolute -bottom-2 -right-2">`);
          _push(ssrRenderComponent(unref(Listbox), {
            modelValue: n.category,
            "onUpdate:modelValue": ($event) => n.category = $event
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<div class="relative mt-1"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(ListboxButton), { class: "relative text-left flex gap-x-6 items-center rounded-lg pl-[14px] pr-4 placeholder:text-[#B6B7B9] focus:outline-matta-black/20" }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      if (n.category) {
                        _push3(`<span class="mr-2 capitalize max-w-[130px] truncate"${_scopeId2}>${ssrInterpolate(n.category)}</span>`);
                      } else {
                        _push3(`<span class="text-matta-black mr-2 whitespace-nowrap"${_scopeId2}>Select category</span>`);
                      }
                      _push3(`<span class="pointer-events-none absolute inset-y-0 -right-1 flex items-center"${_scopeId2}>`);
                      _push3(ssrRenderComponent(unref(ChevronUpDownIcon), {
                        class: "h-5 w-5 text-gray-400",
                        "aria-hidden": "true"
                      }, null, _parent3, _scopeId2));
                      _push3(`</span>`);
                    } else {
                      return [
                        n.category ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "mr-2 capitalize max-w-[130px] truncate"
                        }, toDisplayString(n.category), 1)) : (openBlock(), createBlock("span", {
                          key: 1,
                          class: "text-matta-black mr-2 whitespace-nowrap"
                        }, "Select category")),
                        createVNode("span", { class: "pointer-events-none absolute inset-y-0 -right-1 flex items-center" }, [
                          createVNode(unref(ChevronUpDownIcon), {
                            class: "h-5 w-5 text-gray-400",
                            "aria-hidden": "true"
                          })
                        ])
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(ssrRenderComponent(unref(ListboxOptions), { class: "absolute mt-1 mx-h-60 w-[300px] z-40 overflow-auto rounded-md bg-white py-4 text-base shadow-lg focus:outline-none sm:text-sm" }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<!--[-->`);
                      ssrRenderList(unref(form).documentproperties, (p, i) => {
                        _push3(ssrRenderComponent(unref(ListboxOption), {
                          key: i,
                          value: p.value,
                          as: "template"
                        }, {
                          default: withCtx(({ selected }, _push4, _parent4, _scopeId3) => {
                            if (_push4) {
                              _push4(`<li class="${ssrRenderClass([
                                selected ? "text-blue-800 bg-blue-50" : "font-normal text-matta-black",
                                "relative cursor-pointer capitalize text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                              ])}"${_scopeId3}><div class="flex gap-x-4 items-start"${_scopeId3}><div${_scopeId3}><p class="text-sm font-medium"${_scopeId3}>${ssrInterpolate(p.text)}</p><p class="text-xs"${_scopeId3}>${ssrInterpolate(p.item)}</p></div>`);
                              if (selected) {
                                _push4(`<i class="uil uil-check text-blue-800"${_scopeId3}></i>`);
                              } else {
                                _push4(`<!---->`);
                              }
                              _push4(`</div></li>`);
                            } else {
                              return [
                                createVNode("li", {
                                  class: [
                                    selected ? "text-blue-800 bg-blue-50" : "font-normal text-matta-black",
                                    "relative cursor-pointer capitalize text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                                  ]
                                }, [
                                  createVNode("div", { class: "flex gap-x-4 items-start" }, [
                                    createVNode("div", null, [
                                      createVNode("p", { class: "text-sm font-medium" }, toDisplayString(p.text), 1),
                                      createVNode("p", { class: "text-xs" }, toDisplayString(p.item), 1)
                                    ]),
                                    selected ? (openBlock(), createBlock("i", {
                                      key: 0,
                                      class: "uil uil-check text-blue-800"
                                    })) : createCommentVNode("", true)
                                  ])
                                ], 2)
                              ];
                            }
                          }),
                          _: 2
                        }, _parent3, _scopeId2));
                      });
                      _push3(`<!--]-->`);
                      if (!unref(form).documentproperties.length) {
                        _push3(`<p class="text-[#B6B7B9] py-2 pl-6 pr-4 text-sm"${_scopeId2}> Nothing found </p>`);
                      } else {
                        _push3(`<!---->`);
                      }
                    } else {
                      return [
                        (openBlock(true), createBlock(Fragment, null, renderList(unref(form).documentproperties, (p, i) => {
                          return openBlock(), createBlock(unref(ListboxOption), {
                            key: i,
                            value: p.value,
                            as: "template"
                          }, {
                            default: withCtx(({ selected }) => [
                              createVNode("li", {
                                class: [
                                  selected ? "text-blue-800 bg-blue-50" : "font-normal text-matta-black",
                                  "relative cursor-pointer capitalize text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                                ]
                              }, [
                                createVNode("div", { class: "flex gap-x-4 items-start" }, [
                                  createVNode("div", null, [
                                    createVNode("p", { class: "text-sm font-medium" }, toDisplayString(p.text), 1),
                                    createVNode("p", { class: "text-xs" }, toDisplayString(p.item), 1)
                                  ]),
                                  selected ? (openBlock(), createBlock("i", {
                                    key: 0,
                                    class: "uil uil-check text-blue-800"
                                  })) : createCommentVNode("", true)
                                ])
                              ], 2)
                            ]),
                            _: 2
                          }, 1032, ["value"]);
                        }), 128)),
                        !unref(form).documentproperties.length ? (openBlock(), createBlock("p", {
                          key: 0,
                          class: "text-[#B6B7B9] py-2 pl-6 pr-4 text-sm"
                        }, " Nothing found ")) : createCommentVNode("", true)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</div>`);
              } else {
                return [
                  createVNode("div", { class: "relative mt-1" }, [
                    createVNode(unref(ListboxButton), { class: "relative text-left flex gap-x-6 items-center rounded-lg pl-[14px] pr-4 placeholder:text-[#B6B7B9] focus:outline-matta-black/20" }, {
                      default: withCtx(() => [
                        n.category ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "mr-2 capitalize max-w-[130px] truncate"
                        }, toDisplayString(n.category), 1)) : (openBlock(), createBlock("span", {
                          key: 1,
                          class: "text-matta-black mr-2 whitespace-nowrap"
                        }, "Select category")),
                        createVNode("span", { class: "pointer-events-none absolute inset-y-0 -right-1 flex items-center" }, [
                          createVNode(unref(ChevronUpDownIcon), {
                            class: "h-5 w-5 text-gray-400",
                            "aria-hidden": "true"
                          })
                        ])
                      ]),
                      _: 2
                    }, 1024),
                    createVNode(Transition, {
                      "leave-active-class": "transition duration-100 ease-in",
                      "leave-from-class": "opacity-100",
                      "leave-to-class": "opacity-0"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(ListboxOptions), { class: "absolute mt-1 mx-h-60 w-[300px] z-40 overflow-auto rounded-md bg-white py-4 text-base shadow-lg focus:outline-none sm:text-sm" }, {
                          default: withCtx(() => [
                            (openBlock(true), createBlock(Fragment, null, renderList(unref(form).documentproperties, (p, i) => {
                              return openBlock(), createBlock(unref(ListboxOption), {
                                key: i,
                                value: p.value,
                                as: "template"
                              }, {
                                default: withCtx(({ selected }) => [
                                  createVNode("li", {
                                    class: [
                                      selected ? "text-blue-800 bg-blue-50" : "font-normal text-matta-black",
                                      "relative cursor-pointer capitalize text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                                    ]
                                  }, [
                                    createVNode("div", { class: "flex gap-x-4 items-start" }, [
                                      createVNode("div", null, [
                                        createVNode("p", { class: "text-sm font-medium" }, toDisplayString(p.text), 1),
                                        createVNode("p", { class: "text-xs" }, toDisplayString(p.item), 1)
                                      ]),
                                      selected ? (openBlock(), createBlock("i", {
                                        key: 0,
                                        class: "uil uil-check text-blue-800"
                                      })) : createCommentVNode("", true)
                                    ])
                                  ], 2)
                                ]),
                                _: 2
                              }, 1032, ["value"]);
                            }), 128)),
                            !unref(form).documentproperties.length ? (openBlock(), createBlock("p", {
                              key: 0,
                              class: "text-[#B6B7B9] py-2 pl-6 pr-4 text-sm"
                            }, " Nothing found ")) : createCommentVNode("", true)
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ])
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div><span class="text-sm absolute -top-3 -right-2 z-10 text-[#475467] cursor-pointer">`);
          _push(ssrRenderComponent(_component_AppIcon, { icon: "fa:trash-o" }, null, _parent));
          _push(`</span></div></div></div>`);
        });
        _push(`<!--]--></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><hr class="border-[#F4F7FE] my-10"><div class="bg-white rounded-lg flex justify-between gap-x-10 items-center"><button type="button" class="appearance-none leading-none px-10 py-[10px] rounded-lg text-primary border-primary-500 text-primary-500 border hover:bg-gray-300 text-[13px]"> Preview </button><div class="flex justify-center gap-x-4 items-center"><button type="button" class="appearance-none leading-none px-10 py-[10px] rounded-lg text-primary border-primary- border hover:bg-gray-300 text-[13px]"> Back </button><button type="button"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} class="${ssrRenderClass([{
        "bg-primary/60 cursor-not-allowed": isLoading.value
      }, "appearance-none leading-none px-10 py-[10px] rounded-lg text-white bg-primary-500 hover:opacity-70 text-[13px]"])}"> Complete </button></div></div></section><div>`);
      _push(ssrRenderComponent(unref(__nuxt_component_0$2), {
        isOpen: isAdding.value,
        onToggleModal: ($event) => isAdding.value = false
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 w-[400px]"${_scopeId}><div class="flex justify-between mb-5 items-center"${_scopeId}><h4 class="font-medium text-matta-black text-xl"${_scopeId}>Add new value</h4><i class="uil uil-times cursor-pointer text-lg hover:ring-1 w-6 h-6 ring-gray-200 flex items-center justify-center hover:ring-offset-2 rounded-full"${_scopeId}></i></div><input${ssrRenderAttr("value", category.value)} class="rounded-lg px-3 py-3 h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" autofocus="on" placeholder="Enter package name..."${_scopeId}><div class="flex justify-end gap-x-2 items-center mt-8"${_scopeId}><button type="button" class="appearance-none text-xs leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 uppercase"${_scopeId}> Cancel </button><button type="button" class="appearance-none text-xs leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase"${_scopeId}> Save </button></div></div>`);
          } else {
            return [
              createVNode("div", { class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 w-[400px]" }, [
                createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                  createVNode("h4", { class: "font-medium text-matta-black text-xl" }, "Add new value"),
                  createVNode("i", {
                    class: "uil uil-times cursor-pointer text-lg hover:ring-1 w-6 h-6 ring-gray-200 flex items-center justify-center hover:ring-offset-2 rounded-full",
                    onClick: ($event) => isAdding.value = false
                  }, null, 8, ["onClick"])
                ]),
                withDirectives(createVNode("input", {
                  "onUpdate:modelValue": ($event) => category.value = $event,
                  class: "rounded-lg px-3 py-3 h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
                  autocomplete: "off",
                  autofocus: "on",
                  placeholder: "Enter package name..."
                }, null, 8, ["onUpdate:modelValue"]), [
                  [vModelText, category.value]
                ]),
                createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                  createVNode("button", {
                    type: "button",
                    onClick: ($event) => isAdding.value = false,
                    class: "appearance-none text-xs leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 uppercase"
                  }, " Cancel ", 8, ["onClick"]),
                  createVNode("button", {
                    type: "button",
                    onClick: handleAddingPackage,
                    class: "appearance-none text-xs leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase"
                  }, " Save ")
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/AddProduct/ProductDocuments.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {
  __name: "AdditionalInformation",
  __ssrInlineRender: true,
  setup(__props) {
    const form = inject("form");
    useRouter();
    const query = ref("");
    inject("toggleNext");
    inject("togglePreview");
    const filteredExperts = computed(
      () => query.value === "" ? experts.value : experts.value.filter((person) => {
        return person.name.toLowerCase().includes(query.value.toLowerCase());
      })
    );
    function handleFile(e) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onloadend = () => {
        const base64String = reader.result;
        uploadfile({
          base64: base64String.replace("data:", "").replace(/^.+,/, "")
        }).then((res) => {
          expertAnswer.photo = res.data.message;
        });
      };
    }
    const experts = ref([
      {
        name: "John Jones",
        email: "johnjones@email.com",
        phone: "0860723910",
        language: "English, French",
        photo: "",
        role: "Manager"
      }
    ]);
    const tags = ref([]);
    const isLoading = ref(false);
    const adding = ref("");
    const isAdding = ref(false);
    const answer = ref("");
    const expertAnswer = reactive({
      name: "",
      email: "",
      phone: "",
      language: "",
      photo: "",
      role: ""
    });
    function addExpert() {
      experts.value.push(expertAnswer);
      isAdding.value = false;
      form.productExperts[form.productExperts.length - 1].name = expertAnswer.name;
      form.productExperts[form.productExperts.length - 1].email = expertAnswer.email;
      form.productExperts[form.productExperts.length - 1].phone = expertAnswer.phone;
      form.productExperts[form.productExperts.length - 1].language = expertAnswer.language;
      form.productExperts[form.productExperts.length - 1].photo = expertAnswer.photo;
      form.productExperts[form.productExperts.length - 1].role = expertAnswer.role;
    }
    function addTag() {
      form.tags.push(answer.value);
      tags.value.push(answer.value);
      isAdding.value = false;
      answer.value = "";
    }
    const index = ref(null);
    function openmodal(val, id) {
      adding.value = val;
      isAdding.value = true;
      index.value = id;
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><form class="flex flex-col gap-y-3"><div class="bg-white p-6 lg:p-8 rounded-lg"><div class="w-[85%]"><label class="mb-4 font-normal block"> Questions </label>`);
      if (unref(form).productQuestions.length) {
        _push(`<div class="flex flex-wrap gap-3 mb-6"><!--[-->`);
        ssrRenderList(unref(form).productQuestions, (n) => {
          _push(`<span>`);
          if (n.question) {
            _push(`<span class="border border-gray-[300] text-matta-black px-3 rounded-full py-1 text-sm">${ssrInterpolate(n.question)}</span>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</span>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--[-->`);
      ssrRenderList(unref(form).productQuestions, (n, i) => {
        _push(`<div class="flex gap-x-2 items-start"><div class="flex-1"><div class="mb-6"><input${ssrRenderAttr("value", n.question)} class="rounded-lg px-[14px] py-[10px] h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" placeholder="Enter question"></div><div class="mb-6"><textarea rows="3" placeholder="Enter answer" class="rounded-lg px-[14px] py-[10px] w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20">${ssrInterpolate(n.answer)}</textarea></div></div><div class="flex items-center"><span class="bg-gray-200 rounded-full h-8 w-8 flex items-center justify-center"><i class="uil uil-times"></i></span></div></div>`);
      });
      _push(`<!--]--><div class="mt-3"><button type="button" class="text-primary"><i class="uil uil-plus text-sm"></i> Add new question </button></div></div></div><div class="grid grid-cols-2 gap-x-3"><div class="bg-white p-6 lg:p-8 rounded-lg"><div class="mb-5 text-left"><label class="mb-2 font-normal block"> Experts </label><!--[-->`);
      ssrRenderList(unref(form).productExperts, (e, id) => {
        _push(`<div class="flex gap-x-2 items-center mb-2"><div class="relative flex-1">`);
        _push(ssrRenderComponent(unref(Combobox), {
          modelValue: unref(form).productExperts[id],
          "onUpdate:modelValue": ($event) => unref(form).productExperts[id] = $event
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(unref(ComboboxInput), {
                class: "px-5 py-1 h-10 rounded-lg w-full text-left flex items-center justify-between border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
                onChange: ($event) => query.value = $event.target.value,
                displayValue: (p) => p.name && p.role ? `${p.name}, ${p.role}` : "Search expert"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(unref(TransitionRoot), {
                leave: "transition ease-in duration-100",
                leaveFrom: "opacity-100",
                leaveTo: "opacity-0",
                onAfterLeave: ($event) => query.value = ""
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(unref(ComboboxOptions), { class: "absolute mt-1 max-h-60 w-full overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          if (filteredExperts.value.length === 0 && query.value !== "") {
                            _push4(`<div class="relative cursor-default select-none py-2 px-4 text-gray-700"${_scopeId3}> Nothing found. </div>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          _push4(`<!--[-->`);
                          ssrRenderList(filteredExperts.value, (p, i) => {
                            _push4(ssrRenderComponent(unref(ComboboxOption), {
                              as: "template",
                              key: i,
                              value: p
                            }, {
                              default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                                if (_push5) {
                                  _push5(`<li class="${ssrRenderClass([
                                    "relative cursor-pointer flex items-cente gap-x-2 capitalize text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                                  ])}"${_scopeId4}><div class="flex items-center gap-x-4"${_scopeId4}><span class="h-8 w-8 rounded-full flex items-start justify-center bg-gray-100 uppercase p-2"${_scopeId4}>${ssrInterpolate(p.name.slice(0, 2))}</span><div${_scopeId4}><p class="text-[13px] mb-1"${_scopeId4}>${ssrInterpolate(p.name)}</p><p class="text-[11px]"${_scopeId4}>${ssrInterpolate(p.role)}</p></div></div></li>`);
                                } else {
                                  return [
                                    createVNode("li", { class: [
                                      "relative cursor-pointer flex items-cente gap-x-2 capitalize text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                                    ] }, [
                                      createVNode("div", { class: "flex items-center gap-x-4" }, [
                                        createVNode("span", { class: "h-8 w-8 rounded-full flex items-start justify-center bg-gray-100 uppercase p-2" }, toDisplayString(p.name.slice(0, 2)), 1),
                                        createVNode("div", null, [
                                          createVNode("p", { class: "text-[13px] mb-1" }, toDisplayString(p.name), 1),
                                          createVNode("p", { class: "text-[11px]" }, toDisplayString(p.role), 1)
                                        ])
                                      ])
                                    ])
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent4, _scopeId3));
                          });
                          _push4(`<!--]-->`);
                        } else {
                          return [
                            filteredExperts.value.length === 0 && query.value !== "" ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "relative cursor-default select-none py-2 px-4 text-gray-700"
                            }, " Nothing found. ")) : createCommentVNode("", true),
                            (openBlock(true), createBlock(Fragment, null, renderList(filteredExperts.value, (p, i) => {
                              return openBlock(), createBlock(unref(ComboboxOption), {
                                as: "template",
                                key: i,
                                value: p
                              }, {
                                default: withCtx(() => [
                                  createVNode("li", { class: [
                                    "relative cursor-pointer flex items-cente gap-x-2 capitalize text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                                  ] }, [
                                    createVNode("div", { class: "flex items-center gap-x-4" }, [
                                      createVNode("span", { class: "h-8 w-8 rounded-full flex items-start justify-center bg-gray-100 uppercase p-2" }, toDisplayString(p.name.slice(0, 2)), 1),
                                      createVNode("div", null, [
                                        createVNode("p", { class: "text-[13px] mb-1" }, toDisplayString(p.name), 1),
                                        createVNode("p", { class: "text-[11px]" }, toDisplayString(p.role), 1)
                                      ])
                                    ])
                                  ])
                                ]),
                                _: 2
                              }, 1032, ["value"]);
                            }), 128))
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(unref(ComboboxOptions), { class: "absolute mt-1 max-h-60 w-full overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm" }, {
                        default: withCtx(() => [
                          filteredExperts.value.length === 0 && query.value !== "" ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "relative cursor-default select-none py-2 px-4 text-gray-700"
                          }, " Nothing found. ")) : createCommentVNode("", true),
                          (openBlock(true), createBlock(Fragment, null, renderList(filteredExperts.value, (p, i) => {
                            return openBlock(), createBlock(unref(ComboboxOption), {
                              as: "template",
                              key: i,
                              value: p
                            }, {
                              default: withCtx(() => [
                                createVNode("li", { class: [
                                  "relative cursor-pointer flex items-cente gap-x-2 capitalize text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                                ] }, [
                                  createVNode("div", { class: "flex items-center gap-x-4" }, [
                                    createVNode("span", { class: "h-8 w-8 rounded-full flex items-start justify-center bg-gray-100 uppercase p-2" }, toDisplayString(p.name.slice(0, 2)), 1),
                                    createVNode("div", null, [
                                      createVNode("p", { class: "text-[13px] mb-1" }, toDisplayString(p.name), 1),
                                      createVNode("p", { class: "text-[11px]" }, toDisplayString(p.role), 1)
                                    ])
                                  ])
                                ])
                              ]),
                              _: 2
                            }, 1032, ["value"]);
                          }), 128))
                        ]),
                        _: 1
                      })
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            } else {
              return [
                createVNode(unref(ComboboxInput), {
                  class: "px-5 py-1 h-10 rounded-lg w-full text-left flex items-center justify-between border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
                  onChange: ($event) => query.value = $event.target.value,
                  displayValue: (p) => p.name && p.role ? `${p.name}, ${p.role}` : "Search expert"
                }, null, 8, ["onChange", "displayValue"]),
                createVNode(unref(TransitionRoot), {
                  leave: "transition ease-in duration-100",
                  leaveFrom: "opacity-100",
                  leaveTo: "opacity-0",
                  onAfterLeave: ($event) => query.value = ""
                }, {
                  default: withCtx(() => [
                    createVNode(unref(ComboboxOptions), { class: "absolute mt-1 max-h-60 w-full overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm" }, {
                      default: withCtx(() => [
                        filteredExperts.value.length === 0 && query.value !== "" ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "relative cursor-default select-none py-2 px-4 text-gray-700"
                        }, " Nothing found. ")) : createCommentVNode("", true),
                        (openBlock(true), createBlock(Fragment, null, renderList(filteredExperts.value, (p, i) => {
                          return openBlock(), createBlock(unref(ComboboxOption), {
                            as: "template",
                            key: i,
                            value: p
                          }, {
                            default: withCtx(() => [
                              createVNode("li", { class: [
                                "relative cursor-pointer flex items-cente gap-x-2 capitalize text-matta-black  hover:text-primary select-none py-2 pl-6 pr-4 text-left"
                              ] }, [
                                createVNode("div", { class: "flex items-center gap-x-4" }, [
                                  createVNode("span", { class: "h-8 w-8 rounded-full flex items-start justify-center bg-gray-100 uppercase p-2" }, toDisplayString(p.name.slice(0, 2)), 1),
                                  createVNode("div", null, [
                                    createVNode("p", { class: "text-[13px] mb-1" }, toDisplayString(p.name), 1),
                                    createVNode("p", { class: "text-[11px]" }, toDisplayString(p.role), 1)
                                  ])
                                ])
                              ])
                            ]),
                            _: 2
                          }, 1032, ["value"]);
                        }), 128))
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }, 8, ["onAfterLeave"])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div><i class="uil uil-times cursor-pointer text-lg hover:ring-1 w-6 h-6 ring-gray-200 flex items-center justify-center hover:ring-offset-2 rounded-full"></i></div>`);
      });
      _push(`<!--]--><div class="py-2 pr-4 mt-4 flex justify-between"><button type="button" class="text-primary text-sm"><i class="uil uil-plus text-sm"></i> Create expert </button><button type="button" class="text-primary text-sm"><i class="uil uil-plus text-sm"></i> Add new </button></div></div></div><div class="bg-white p-6 lg:p-8 rounded-lg"><div class="mb-5 text-left"><label class="mb-2 font-normal block"> Tags </label>`);
      _push(ssrRenderComponent(unref(Listbox), {
        modelValue: unref(form).tags,
        "onUpdate:modelValue": ($event) => unref(form).tags = $event
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="relative mt-1"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ListboxButton), { class: "px-5 py-1 rounded-lg min-h-[40px] w-full text-left flex items-center justify-between border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  if (unref(form).tags.length) {
                    _push3(`<div class=""${_scopeId2}><div class="flex flex-wrap items-center gap-x-3 gap-y-1"${_scopeId2}><!--[-->`);
                    ssrRenderList(unref(form).tags, (tag, id) => {
                      _push3(`<span class="px-2 py-1 gap-x-3 flex items-center bg-white text-xs rounded-full"${_scopeId2}><span${_scopeId2}>${ssrInterpolate(tag)}</span><i class="uil uil-times text-matta-black"${_scopeId2}></i></span>`);
                    });
                    _push3(`<!--]--></div></div>`);
                  } else {
                    _push3(`<span class="text-sm text-[#B6B7B9]"${_scopeId2}>Enter tag</span>`);
                  }
                  _push3(`<span class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(ChevronUpDownIcon), {
                    class: "h-5 w-5 text-gray-400",
                    "aria-hidden": "true"
                  }, null, _parent3, _scopeId2));
                  _push3(`</span>`);
                } else {
                  return [
                    unref(form).tags.length ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: ""
                    }, [
                      createVNode("div", { class: "flex flex-wrap items-center gap-x-3 gap-y-1" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(unref(form).tags, (tag, id) => {
                          return openBlock(), createBlock("span", {
                            key: tag,
                            class: "px-2 py-1 gap-x-3 flex items-center bg-white text-xs rounded-full"
                          }, [
                            createVNode("span", null, toDisplayString(tag), 1),
                            createVNode("i", {
                              class: "uil uil-times text-matta-black",
                              onClick: ($event) => unref(form).tags.splice(id, 1)
                            }, null, 8, ["onClick"])
                          ]);
                        }), 128))
                      ])
                    ])) : (openBlock(), createBlock("span", {
                      key: 1,
                      class: "text-sm text-[#B6B7B9]"
                    }, "Enter tag")),
                    createVNode("span", { class: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" }, [
                      createVNode(unref(ChevronUpDownIcon), {
                        class: "h-5 w-5 text-gray-400",
                        "aria-hidden": "true"
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(ListboxOptions), { class: "absolute mt-1 max-h-80 w-[200px] z-40 overflow-auto rounded-md bg-white py-4 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="py-2 pl-6 pr-4"${_scopeId2}><button type="button" class="text-primary"${_scopeId2}><i class="uil uil-plus text-sm"${_scopeId2}></i> Add new tag </button></div>`);
                } else {
                  return [
                    createVNode("div", { class: "py-2 pl-6 pr-4" }, [
                      createVNode("button", {
                        type: "button",
                        class: "text-primary",
                        onClick: ($event) => openmodal("tag")
                      }, [
                        createVNode("i", { class: "uil uil-plus text-sm" }),
                        createTextVNode(" Add new tag ")
                      ], 8, ["onClick"])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "relative mt-1" }, [
                createVNode(unref(ListboxButton), { class: "px-5 py-1 rounded-lg min-h-[40px] w-full text-left flex items-center justify-between border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" }, {
                  default: withCtx(() => [
                    unref(form).tags.length ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: ""
                    }, [
                      createVNode("div", { class: "flex flex-wrap items-center gap-x-3 gap-y-1" }, [
                        (openBlock(true), createBlock(Fragment, null, renderList(unref(form).tags, (tag, id) => {
                          return openBlock(), createBlock("span", {
                            key: tag,
                            class: "px-2 py-1 gap-x-3 flex items-center bg-white text-xs rounded-full"
                          }, [
                            createVNode("span", null, toDisplayString(tag), 1),
                            createVNode("i", {
                              class: "uil uil-times text-matta-black",
                              onClick: ($event) => unref(form).tags.splice(id, 1)
                            }, null, 8, ["onClick"])
                          ]);
                        }), 128))
                      ])
                    ])) : (openBlock(), createBlock("span", {
                      key: 1,
                      class: "text-sm text-[#B6B7B9]"
                    }, "Enter tag")),
                    createVNode("span", { class: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2" }, [
                      createVNode(unref(ChevronUpDownIcon), {
                        class: "h-5 w-5 text-gray-400",
                        "aria-hidden": "true"
                      })
                    ])
                  ]),
                  _: 1
                }),
                createVNode(Transition, {
                  "leave-active-class": "transition duration-100 ease-in",
                  "leave-from-class": "opacity-100",
                  "leave-to-class": "opacity-0"
                }, {
                  default: withCtx(() => [
                    createVNode(unref(ListboxOptions), { class: "absolute mt-1 max-h-80 w-[200px] z-40 overflow-auto rounded-md bg-white py-4 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm" }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "py-2 pl-6 pr-4" }, [
                          createVNode("button", {
                            type: "button",
                            class: "text-primary",
                            onClick: ($event) => openmodal("tag")
                          }, [
                            createVNode("i", { class: "uil uil-plus text-sm" }),
                            createTextVNode(" Add new tag ")
                          ], 8, ["onClick"])
                        ])
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div><div class="bg-white rounded-lg px-10 py-6 flex justify-between gap-x-10 items-center"><button type="button" class="appearance-none leading-none px-10 py-4 rounded-full text-primary border-primary- border hover:bg-gray-100 text-[13px] uppercase"> PREVIEW </button><div class="flex justify-center gap-x-4 items-center"><button type="button" class="appearance-none leading-none px-10 py-4 rounded-full text-matta-black bg-[#F1F3F5] hover:bg-gray-100 text-[13px] uppercase"> Back </button><button type="submit"${ssrIncludeBooleanAttr(isLoading.value) ? " disabled" : ""} class="${ssrRenderClass([{
        "bg-primary/60 cursor-not-allowed": isLoading.value
      }, "appearance-none leading-none px-10 py-4 rounded-full text-white bg-primary-500 hover:opacity-70 text-[13px] uppercase"])}"> Complete </button></div></div></form><div>`);
      _push(ssrRenderComponent(unref(__nuxt_component_0$2), {
        isOpen: isAdding.value,
        onToggleModal: ($event) => isAdding.value = false
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (adding.value == "expert") {
              _push2(`<div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 w-[400px]"${_scopeId}><div class="flex justify-between mb-5 items-center"${_scopeId}><h4 class="font-medium text-matta-black text-xl"${_scopeId}>Add new value</h4><i class="uil uil-times cursor-pointer text-lg hover:ring-1 w-6 h-6 ring-gray-200 flex items-center justify-center hover:ring-offset-2 rounded-full"${_scopeId}></i></div><input${ssrRenderAttr("value", expertAnswer.name)} class="rounded-lg px-3 py-3 h-11 mb-5 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" placeholder="Enter expert name..."${_scopeId}><input${ssrRenderAttr("value", expertAnswer.role)} class="rounded-lg px-3 py-3 h-11 mb-5 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" placeholder="Enter expert role..."${_scopeId}><input${ssrRenderAttr("value", expertAnswer.phone)} class="rounded-lg px-3 py-3 h-11 mb-5 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" placeholder="Enter phone number.." type="number"${_scopeId}><input${ssrRenderAttr("value", expertAnswer.email)} class="rounded-lg px-3 py-3 h-11 mb-5 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" placeholder="Enter email..." type="email"${_scopeId}><input${ssrRenderAttr("value", expertAnswer.language)} class="rounded-lg px-3 py-3 h-11 mb-5 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" placeholder="Enter language..."${_scopeId}><input type="file" id="file" class="" accept="image/*"${_scopeId}><div class="flex justify-end gap-x-2 items-center mt-8"${_scopeId}><button type="button" class="appearance-none text-xs leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 uppercase"${_scopeId}> Cancel </button><button type="button" class="appearance-none text-xs leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase"${_scopeId}> Save </button></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (adding.value == "tag") {
              _push2(`<div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 w-[400px]"${_scopeId}><div class="flex justify-between mb-5 items-center"${_scopeId}><h4 class="font-medium text-matta-black text-xl"${_scopeId}>Add new value</h4><i class="uil uil-times cursor-pointer text-lg hover:ring-1 w-6 h-6 ring-gray-200 flex items-center justify-center hover:ring-offset-2 rounded-full"${_scopeId}></i></div><input${ssrRenderAttr("value", answer.value)} class="rounded-lg px-3 py-3 h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20" autocomplete="off" placeholder="Enter package name..."${_scopeId}><div class="flex justify-end gap-x-2 items-center mt-8"${_scopeId}><button type="button" class="appearance-none text-xs leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 uppercase"${_scopeId}> Cancel </button><button type="button" class="appearance-none text-xs leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase"${_scopeId}> Save </button></div></div>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              adding.value == "expert" ? (openBlock(), createBlock("div", {
                key: 0,
                class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 w-[400px]"
              }, [
                createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                  createVNode("h4", { class: "font-medium text-matta-black text-xl" }, "Add new value"),
                  createVNode("i", {
                    class: "uil uil-times cursor-pointer text-lg hover:ring-1 w-6 h-6 ring-gray-200 flex items-center justify-center hover:ring-offset-2 rounded-full",
                    onClick: ($event) => isAdding.value = false
                  }, null, 8, ["onClick"])
                ]),
                withDirectives(createVNode("input", {
                  "onUpdate:modelValue": ($event) => expertAnswer.name = $event,
                  class: "rounded-lg px-3 py-3 h-11 mb-5 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
                  autocomplete: "off",
                  placeholder: "Enter expert name..."
                }, null, 8, ["onUpdate:modelValue"]), [
                  [vModelText, expertAnswer.name]
                ]),
                withDirectives(createVNode("input", {
                  "onUpdate:modelValue": ($event) => expertAnswer.role = $event,
                  class: "rounded-lg px-3 py-3 h-11 mb-5 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
                  autocomplete: "off",
                  placeholder: "Enter expert role..."
                }, null, 8, ["onUpdate:modelValue"]), [
                  [vModelText, expertAnswer.role]
                ]),
                withDirectives(createVNode("input", {
                  "onUpdate:modelValue": ($event) => expertAnswer.phone = $event,
                  class: "rounded-lg px-3 py-3 h-11 mb-5 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
                  autocomplete: "off",
                  placeholder: "Enter phone number..",
                  type: "number"
                }, null, 8, ["onUpdate:modelValue"]), [
                  [vModelText, expertAnswer.phone]
                ]),
                withDirectives(createVNode("input", {
                  "onUpdate:modelValue": ($event) => expertAnswer.email = $event,
                  class: "rounded-lg px-3 py-3 h-11 mb-5 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
                  autocomplete: "off",
                  placeholder: "Enter email...",
                  type: "email"
                }, null, 8, ["onUpdate:modelValue"]), [
                  [vModelText, expertAnswer.email]
                ]),
                withDirectives(createVNode("input", {
                  "onUpdate:modelValue": ($event) => expertAnswer.language = $event,
                  class: "rounded-lg px-3 py-3 h-11 mb-5 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
                  autocomplete: "off",
                  placeholder: "Enter language..."
                }, null, 8, ["onUpdate:modelValue"]), [
                  [vModelText, expertAnswer.language]
                ]),
                createVNode("input", {
                  type: "file",
                  id: "file",
                  class: "",
                  accept: "image/*",
                  onChange: handleFile
                }, null, 32),
                createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                  createVNode("button", {
                    type: "button",
                    onClick: ($event) => isAdding.value = false,
                    class: "appearance-none text-xs leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 uppercase"
                  }, " Cancel ", 8, ["onClick"]),
                  createVNode("button", {
                    type: "button",
                    onClick: addExpert,
                    class: "appearance-none text-xs leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase"
                  }, " Save ")
                ])
              ])) : createCommentVNode("", true),
              adding.value == "tag" ? (openBlock(), createBlock("div", {
                key: 1,
                class: "bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 w-[400px]"
              }, [
                createVNode("div", { class: "flex justify-between mb-5 items-center" }, [
                  createVNode("h4", { class: "font-medium text-matta-black text-xl" }, "Add new value"),
                  createVNode("i", {
                    class: "uil uil-times cursor-pointer text-lg hover:ring-1 w-6 h-6 ring-gray-200 flex items-center justify-center hover:ring-offset-2 rounded-full",
                    onClick: ($event) => isAdding.value = false
                  }, null, 8, ["onClick"])
                ]),
                withDirectives(createVNode("input", {
                  "onUpdate:modelValue": ($event) => answer.value = $event,
                  class: "rounded-lg px-3 py-3 h-11 w-full border border-[#DCDEE6] placeholder:text-[#B6B7B9] focus:outline-matta-black/20",
                  autocomplete: "off",
                  placeholder: "Enter package name..."
                }, null, 8, ["onUpdate:modelValue"]), [
                  [vModelText, answer.value]
                ]),
                createVNode("div", { class: "flex justify-end gap-x-2 items-center mt-8" }, [
                  createVNode("button", {
                    type: "button",
                    onClick: ($event) => isAdding.value = false,
                    class: "appearance-none text-xs leading-none px-8 py-3 rounded-lg text-matta-black hover:bg-gray-100 uppercase"
                  }, " Cancel ", 8, ["onClick"]),
                  createVNode("button", {
                    type: "button",
                    onClick: addTag,
                    class: "appearance-none text-xs leading-none px-8 py-3 rounded-lg text-white bg-primary-500 hover:opacity-70 uppercase"
                  }, " Save ")
                ])
              ])) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/AddProduct/AdditionalInformation.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "index",
  __ssrInlineRender: true,
  props: ["title"],
  setup(__props) {
    const tabs = [
      {
        name: "Product Info",
        value: 1
      },
      {
        name: "Properties",
        value: 2
      },
      {
        name: "Documents",
        value: 3
      }
    ];
    const route = useRoute();
    const router = useRouter();
    const isPreviewing = ref(false);
    const isPageLoading = ref(true);
    const active = ref(1);
    const technologies = ref([]);
    const allmarkets = ref([]);
    const producers = ref([]);
    const form = reactive({
      id: "",
      name: "",
      manufacturer: "",
      markets: [],
      marketApplications: [],
      marketSubapplications: [],
      technologies: [],
      techApplications: [],
      techSubApplications: [],
      description: "",
      gallery: [],
      price: 0,
      sampleAvailable: false,
      packagesAvailable: [],
      packages: [],
      hideProduct: false,
      hidePrice: false,
      productBrandName: "",
      propertyItems: {
        features: {
          propertyItems: [],
          subSection: []
        },
        applications: {
          propertyItems: [{ property: null, propertyValue: [] }],
          subSection: []
        },
        property: {
          propertyItems: [{ property: null, propertyValue: [] }],
          subSection: []
        },
        compliance: {
          propertyItems: [],
          subSection: []
        },
        technical: {
          propertyItems: [{ property: null, propertyValue: [] }],
          subSection: []
        }
      },
      properties: [],
      propertyValueList: [],
      ProductId: route.query.id,
      documents: [],
      category: "",
      documentproperties: [
        {
          text: "Material safety data sheet (MSDS)",
          item: "Info such as the chemical properties.",
          value: "Material safety data sheet (MSDS)"
        },
        {
          text: "Certificate of analysis (COA)",
          item: "Certificate of analysis of product.",
          value: "Certificate of analysis (COA)"
        },
        {
          text: "Technical data sheet (TDS)",
          item: "Document with technical data of product.",
          value: "Technical data sheet (TDS)"
        },
        {
          text: "Other",
          item: "Other types of product documents.",
          value: "other"
        }
      ],
      productExperts: [],
      productQuestions: [],
      tags: [],
      unit: "g"
    });
    const queryParams = reactive({
      Search: "",
      PageSize: 10,
      PageNumber: 1,
      productId: route.query.id
    });
    function togglePreview() {
      isPreviewing.value = !isPreviewing.value;
    }
    function toggleNext(val) {
      router.push(
        `/storefront/products/add-product?stage=${val}&id=${route.query.id}`
      );
    }
    function getProducers() {
      getFeaturedManufacturer({
        Search: "",
        PageNumber: 1,
        PageSize: 1e6
      }).then((res) => {
        producers.value = [...res.data.data.data];
      });
    }
    function create_UUID() {
      var dt = (/* @__PURE__ */ new Date()).getTime();
      var uuid = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
        /[xy]/g,
        function(c) {
          var r = (dt + Math.random() * 16) % 16 | 0;
          dt = Math.floor(dt / 16);
          return (c == "x" ? r : r & 3 | 8).toString(16);
        }
      );
      return uuid;
    }
    const selectedMeasurement = ref(measurements[0]);
    const product = ref({
      id: "",
      ProductId: "",
      name: "",
      manufacturer: "",
      markets: [],
      marketApplications: [],
      marketSubapplications: [],
      technologies: [],
      techApplications: [],
      techSubApplications: [],
      description: "",
      gallery: [],
      price: 0,
      sampleAvailable: false,
      packagesAvailable: [],
      supplierId: null,
      packages: [],
      hideProduct: false,
      hidePrice: false,
      productBrandName: "",
      unit: "g"
    });
    function updateData() {
      form.id = route.query.id;
      form.ProductId = route.query.id;
      form.name = product.value.name;
      form.unit = product.value.packagesAvailable ? product.value.packagesAvailable[0].unit : "";
      form.manufacturer = product.value.manufacturer || [];
      form.markets = product.value.markets || [];
      form.marketApplications = product.value.marketApplications || [];
      form.marketSubapplications = product.value.marketSubapplications || [];
      form.technologies = product.value.technologies || [];
      form.techApplications = product.value.techApplications || [];
      form.techSubApplications = product.value.techSubApplications || [];
      form.description = product.value.description;
      form.gallery = product.value.gallery || [];
      form.price = product.value.price;
      form.sampleAvailable = product.value.sampleAvailable;
      form.packagesAvailable = product.value.packagesAvailable || [
        {
          package: {
            id: create_UUID(),
            title: ""
          },
          unit: selectedMeasurement.value ? selectedMeasurement.value.value : "",
          size: null,
          amount: null,
          isAvailable: false,
          color: "",
          purity: ""
        }
      ];
      form.packages = product.value.packages || [];
      form.hideProduct = product.value.hideProduct;
      form.hidePrice = product.value.hidePrice;
      form.productBrandName = product.value.productBrandName;
      form.documents = product.value.documentInfoModels || [];
      form.productExperts = product.value.productExperts || [];
      form.productQuestions = product.value.productQuestions || [];
      form.tags = product.value.tags || [];
      form.supplierId = product.value.supplierId;
      form.propertyItems = !Object.keys(product.value.propertyItems.propertyItems).length ? {
        features: {
          propertyItems: [],
          subSection: []
        },
        applications: {
          propertyItems: [{ property: null, propertyValue: [] }],
          subSection: []
        },
        property: {
          propertyItems: [{ property: null, propertyValue: [] }],
          subSection: []
        },
        compliance: {
          propertyItems: [],
          subSection: []
        },
        technical: {
          propertyItems: [{ property: null, propertyValue: [] }],
          subSection: []
        }
      } : product.value.propertyItems.propertyItems;
      form.documentproperties = [
        {
          text: "Material safety data sheet (MSDS)",
          item: "Info such as the chemical properties.",
          value: "Material safety data sheet (MSDS)"
        },
        {
          text: "Certificate of analysis (COA)",
          item: "Certificate of analysis of product.",
          value: "Certificate of analysis (COA)"
        },
        {
          text: "Technical data sheet (TDS)",
          item: "Document with technical data of product.",
          value: "Technical data sheet (TDS)"
        },
        {
          text: "Other",
          item: "Other types of product documents.",
          value: "other"
        }
      ], form.properties = product.value.propertyItems.properties || [];
      form.propertyValueList = product.value.propertyItems.propertyValueList || [];
    }
    watch(route, () => {
      active.value = route.query.stage;
      if (route.query.id) {
        queryParams.productId = route.query.id;
        getSupplierProduct(queryParams).then((res) => {
          product.value = res.data.data;
          updateData();
        });
      }
    });
    provide("technologies", technologies);
    provide("allmarkets", allmarkets);
    provide("form", form);
    provide("product", form);
    provide("togglePreview", togglePreview);
    provide("toggleNext", toggleNext);
    provide("producers", producers);
    provide("getProducers", getProducers);
    provide("active", active);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderComponent = __nuxt_component_0$3;
      const _component_Stepper = __nuxt_component_1$2;
      const _component_AppLoader = __nuxt_component_1$3;
      const _component_IndexModal = __nuxt_component_0$2;
      const _component_PreviewIndexPreview = Preview;
      _push(`<!--[--><div class="gap-y-8 flex flex-col bg-white rounded-[10px] border border-[#F4F7FE]" data-v-62116fd6>`);
      _push(ssrRenderComponent(_component_HeaderComponent, {
        title: "Add a product",
        className: "!px-5",
        canGoback: true
      }, null, _parent));
      _push(ssrRenderComponent(_component_Stepper, { tabs }, null, _parent));
      if (!isPageLoading.value) {
        _push(`<div class="mt-[50px]" data-v-62116fd6>`);
        if (active.value == 1) {
          _push(ssrRenderComponent(unref(ProductInfo), null, null, _parent));
        } else {
          _push(`<!---->`);
        }
        if (active.value == 2) {
          _push(ssrRenderComponent(unref(ProductProperties), null, null, _parent));
        } else {
          _push(`<!---->`);
        }
        if (active.value == 3) {
          _push(ssrRenderComponent(unref(_sfc_main$3), null, null, _parent));
        } else {
          _push(`<!---->`);
        }
        if (active.value == 4) {
          _push(ssrRenderComponent(unref(_sfc_main$2), null, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<div class="text-center p-6 lg:p-8 my-28" data-v-62116fd6>`);
        _push(ssrRenderComponent(_component_AppLoader, null, null, _parent));
        _push(`</div>`);
      }
      _push(`</div>`);
      _push(ssrRenderComponent(_component_IndexModal, {
        isOpen: isPreviewing.value,
        onToggleIndexModal: ($event) => isPreviewing.value = false,
        canClose: false
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="max-w-[98vw] relative" data-v-62116fd6${_scopeId}>`);
            _push2(ssrRenderComponent(_component_PreviewIndexPreview, null, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "max-w-[98vw] relative" }, [
                createVNode(_component_PreviewIndexPreview)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Supplier/AddProduct/index.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-62116fd6"]]);
const _sfc_main = {
  __name: "add-product",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_SupplierAddProduct = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_SupplierAddProduct, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/storefront/products/add-product.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=add-product-Po43FUls.mjs.map
