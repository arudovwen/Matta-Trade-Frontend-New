const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.BPkQVQZr.mjs').then(interopDefault),
  "pages/account/notifications.vue": () => import('./_nuxt/notifications-styles.ot03S61C.mjs').then(interopDefault),
  "pages/account/saved-searches.vue": () => import('./_nuxt/saved-searches-styles.7IfLwtam.mjs').then(interopDefault),
  "pages/account/settings.vue": () => import('./_nuxt/settings-styles.0dQABp4a.mjs').then(interopDefault),
  "pages/campaign/index.vue": () => import('./_nuxt/index-styles.xoszcQLs.mjs').then(interopDefault),
  "pages/campaign/new.vue": () => import('./_nuxt/new-styles.Pv5OPtUf.mjs').then(interopDefault),
  "pages/campaign/transactions/[id].vue": () => import('./_nuxt/_id_-styles.AOeebsva.mjs').then(interopDefault),
  "pages/company/customization.vue": () => import('./_nuxt/customization-styles.2tyTKj0G.mjs').then(interopDefault),
  "pages/company/settings.vue": () => import('./_nuxt/settings-styles.Sr7aWDle.mjs').then(interopDefault),
  "pages/confirm-email.vue": () => import('./_nuxt/confirm-email-styles.8dGmik1T.mjs').then(interopDefault),
  "pages/financing/index.vue": () => import('./_nuxt/index-styles._RXmT0k8.mjs').then(interopDefault),
  "pages/financing/requests/[type].vue": () => import('./_nuxt/_type_-styles.uR80YQ_2.mjs').then(interopDefault),
  "pages/index.vue": () => import('./_nuxt/index-styles.y4ONXgtJ.mjs').then(interopDefault),
  "pages/onboarding/company.vue": () => import('./_nuxt/company-styles.3hCLz3G5.mjs').then(interopDefault),
  "pages/onboarding/complete/[type].vue": () => import('./_nuxt/_type_-styles.dp3yI67z.mjs').then(interopDefault),
  "pages/onboarding/personal.vue": () => import('./_nuxt/personal-styles.dIZ5N6v1.mjs').then(interopDefault),
  "pages/overview.vue": () => import('./_nuxt/overview-styles.5ccrPKXX.mjs').then(interopDefault),
  "pages/policy.vue": () => import('./_nuxt/policy-styles.KNU6fMBD.mjs').then(interopDefault),
  "pages/procurement/my-orders.vue": () => import('./_nuxt/my-orders-styles.b2lqWck0.mjs').then(interopDefault),
  "pages/procurement/my-requests.vue": () => import('./_nuxt/my-requests-styles.WoeDK2hh.mjs').then(interopDefault),
  "pages/procurement/shipping-addresses.vue": () => import('./_nuxt/shipping-addresses-styles.DFVsgWrj.mjs').then(interopDefault),
  "pages/product/[name]/[[category]]/[id].vue": () => import('./_nuxt/_id_-styles.li7DfCAS.mjs').then(interopDefault),
  "pages/storefront/orders.vue": () => import('./_nuxt/orders-styles.Pj4eCb0n.mjs').then(interopDefault),
  "pages/storefront/products/add-product.vue": () => import('./_nuxt/add-product-styles.KkCw5Mtq.mjs').then(interopDefault),
  "pages/storefront/products/edit-product.vue": () => import('./_nuxt/edit-product-styles.ZrbHvIu5.mjs').then(interopDefault),
  "pages/storefront/products/index.vue": () => import('./_nuxt/index-styles.FOlS6s28.mjs').then(interopDefault),
  "pages/storefront/requests.vue": () => import('./_nuxt/requests-styles.4YH-NBiS.mjs').then(interopDefault),
  "pages/terms.vue": () => import('./_nuxt/terms-styles.QkSIkKU3.mjs').then(interopDefault),
  "pages/user-management.vue": () => import('./_nuxt/user-management-styles.FKfvB_oX.mjs').then(interopDefault),
  "pages/wallet/home.vue": () => import('./_nuxt/home-styles.IORp-6Aa.mjs').then(interopDefault),
  "pages/wallet/settings.vue": () => import('./_nuxt/settings-styles.cgg34nue.mjs').then(interopDefault),
  "pages/wallet/transactions.vue": () => import('./_nuxt/transactions-styles.3jKVIhuq.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
