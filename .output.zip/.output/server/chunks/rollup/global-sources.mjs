const sources = [
    {
        "context": {
            "name": "sitemap:urls",
            "description": "Set with the `sitemap.urls` config."
        },
        "urls": [],
        "sourceType": "user"
    },
    {
        "context": {
            "name": "nuxt:pages",
            "description": "Generated from your static page files.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:pages'] }`."
            ]
        },
        "urls": [
            {
                "loc": "/account/notifications"
            },
            {
                "loc": "/account/saved-searches"
            },
            {
                "loc": "/account/settings"
            },
            {
                "loc": "/application"
            },
            {
                "loc": "/auth/forgot-password"
            },
            {
                "loc": "/auth/login"
            },
            {
                "loc": "/auth/register"
            },
            {
                "loc": "/auth/reset-password"
            },
            {
                "loc": "/auth/vendor-register"
            },
            {
                "loc": "/campaign"
            },
            {
                "loc": "/campaign/new"
            },
            {
                "loc": "/cart"
            },
            {
                "loc": "/checkout"
            },
            {
                "loc": "/company"
            },
            {
                "loc": "/company/customization"
            },
            {
                "loc": "/company/settings"
            },
            {
                "loc": "/confirm-email"
            },
            {
                "loc": "/finance"
            },
            {
                "loc": "/financing"
            },
            {
                "loc": "/"
            },
            {
                "loc": "/markets"
            },
            {
                "loc": "/onboarding/account"
            },
            {
                "loc": "/onboarding/company"
            },
            {
                "loc": "/onboarding/personal"
            },
            {
                "loc": "/order-success"
            },
            {
                "loc": "/overview"
            },
            {
                "loc": "/policy"
            },
            {
                "loc": "/procurement/my-orders"
            },
            {
                "loc": "/procurement/my-requests"
            },
            {
                "loc": "/procurement/shipping-addresses"
            },
            {
                "loc": "/request-product"
            },
            {
                "loc": "/storefront"
            },
            {
                "loc": "/storefront/orders"
            },
            {
                "loc": "/storefront/products/add-product"
            },
            {
                "loc": "/storefront/products/edit-product"
            },
            {
                "loc": "/storefront/products"
            },
            {
                "loc": "/storefront/requests"
            },
            {
                "loc": "/terms"
            },
            {
                "loc": "/user-management"
            },
            {
                "loc": "/wallet/home"
            },
            {
                "loc": "/wallet/settings"
            },
            {
                "loc": "/wallet/transactions"
            }
        ],
        "sourceType": "app"
    },
    {
        "context": {
            "name": "nuxt:prerender",
            "description": "Generated at build time when prerendering.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:prerender'] }`."
            ]
        },
        "urls": [
            {
                "loc": "/"
            },
            {
                "loc": "/finance"
            },
            {
                "loc": "/cart"
            },
            {
                "loc": "/policy"
            },
            {
                "loc": "/terms"
            },
            {
                "loc": "/market/products"
            },
            {
                "loc": "/market/all"
            },
            {
                "loc": "/request-product"
            },
            {
                "loc": "/auth/register"
            },
            {
                "loc": "/auth/login"
            },
            {
                "loc": "/auth/vendor-register"
            },
            {
                "loc": "/market/Ammonia Liquor"
            },
            {
                "loc": "/market/Hydrogenated Oil"
            },
            {
                "loc": "/market/Caustic Soda"
            },
            {
                "loc": "/market/all products"
            },
            {
                "loc": "/checkout"
            },
            {
                "loc": "/financing/requests/trade"
            },
            {
                "loc": "/financing/requests/export"
            },
            {
                "loc": "/financing/requests/supply"
            },
            {
                "loc": "/financing/requests/import"
            },
            {
                "loc": "/auth/forgot-password"
            }
        ],
        "sourceType": "app"
    }
];

export { sources };
//# sourceMappingURL=global-sources.mjs.map
